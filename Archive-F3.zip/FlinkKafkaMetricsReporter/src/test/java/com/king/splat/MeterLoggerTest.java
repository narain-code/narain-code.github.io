package com.king.splat;

import java.util.ArrayList;
import java.util.List;

import org.apache.flink.api.java.tuple.Tuple2;
import org.junit.Assert;
import org.junit.Test;

import com.king.splat.flink.metrics.serializer.MeterLoggerSerializer;
import com.king.splat.flink.metrics.serializer.MetricKey;

public class MeterLoggerTest {

	@Test
	public void testSourceMetric() {
		String m = "splat12.taskmanager.b90aa836886df4679f22d67f06de7b59.event-bifrost-log.Source: KafkaEventInput.0.KafkaConsumer.current-offsets.event-bifrost-log-13";
		String m2 = "splat12.taskmanager.b90aa836886df4679f22d67f06de7b59.event-bifrost-log.Source: Kafka[rbeaDeploymentsplatprod5].0.KafkaConsumer.current-offsets.rbeaDeploymentsplatprod5-7";
		System.out.println(MetricKey.parse(m));
		System.out.println(MetricKey.parse(m2));
	}

	@Test
	public void tesOperatorMetric() {
		String m = "splat12.taskmanager.id123124.job-name.opname.-with.-dots.1.numBytesInLocal";
		MetricKey result = MetricKey.parse(m);
		Assert.assertEquals("splat12", result.host);
		Assert.assertEquals("opname--with--dots", result.operator);
		Assert.assertEquals("job-name", result.jobName);
		Assert.assertEquals("1", result.subtaskIndex);
		Assert.assertEquals("taskmanager-numBytesInLocal", result.metricName);
		List<Tuple2> out = new ArrayList<>();
		new MeterLoggerSerializer("test").createMetricRecord(out, "meter.log", 0, m, 10);
		Assert.assertEquals("id123124", result.tmId);
		System.out.println(new String(((Tuple2<byte[], byte[]>) out.get(0)).f1));
	}

	@Test
	public void testJMMetric1() {
		String m = "splat12.jobmanager.simple";
		MetricKey result = MetricKey.parse(m);
		Assert.assertEquals("splat12", result.host);
		Assert.assertEquals(null, result.operator);
		Assert.assertEquals(null, result.jobName);
		Assert.assertEquals(null, result.subtaskIndex);
		Assert.assertEquals("jobmanager-simple", result.metricName);
		List<Tuple2> out = new ArrayList<>();
		new MeterLoggerSerializer("test").createMetricRecord(out, "meter.log", 0, m, 10);
		System.out.println(new String(((Tuple2<byte[], byte[]>) out.get(0)).f1));
	}

	@Test
	public void testJMMetric2() {
		String m = "splat12.jobmanager.jobname.simple";
		MetricKey result = MetricKey.parse(m);
		Assert.assertEquals("splat12", result.host);
		Assert.assertEquals(null, result.operator);
		Assert.assertEquals("jobname", result.jobName);
		Assert.assertEquals(null, result.subtaskIndex);
		Assert.assertEquals("jobmanager-simple", result.metricName);
		List<Tuple2> out = new ArrayList<>();
		new MeterLoggerSerializer("test").createMetricRecord(out, "meter.log", 0, m, 10);
		System.out.println(new String(((Tuple2<byte[], byte[]>) out.get(0)).f1));
	}

	@Test
	public void testTaskMetric() {
		String m = "splat12.taskmanager.taskid.jobname.simple";
		MetricKey result = MetricKey.parse(m);
		Assert.assertEquals("splat12", result.host);
		Assert.assertEquals(null, result.operator);
		Assert.assertEquals("jobname", result.jobName);
		Assert.assertEquals("taskid", result.tmId);
		Assert.assertEquals(null, result.subtaskIndex);
		Assert.assertEquals("taskmanager-simple", result.metricName);
		List<Tuple2> out = new ArrayList<>();
		new MeterLoggerSerializer("test").createMetricRecord(out, "meter.log", 0, m, 10);
		System.out.println(new String(((Tuple2<byte[], byte[]>) out.get(0)).f1));
	}

	@Test
	public void testGCTaskMetric() {
		String m = "splat9.taskmanager.container_e24_1506437486913_1334_01_000002.Status.JVM.GarbageCollector.PS MarkSweep.Count";
		MetricKey result = MetricKey.parse(m);
		Assert.assertEquals("splat9", result.host);
		Assert.assertEquals(null, result.operator);
		Assert.assertEquals(null, result.jobName);
		Assert.assertEquals(null, result.subtaskIndex);
		Assert.assertEquals("container_e24_1506437486913_1334_01_000002", result.tmId);
		Assert.assertEquals("taskmanager-JVM-GC-MarkSweep-Count", result.metricName);
		List<Tuple2> out = new ArrayList<>();
		new MeterLoggerSerializer("test").createMetricRecord(out, "meter.log", 0, m, 10);
		System.out.println(new String(((Tuple2<byte[], byte[]>) out.get(0)).f1));
	}
}
