package com.king.splat.flink.metrics.serializer;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.concurrent.TimeUnit;

import org.apache.flink.api.java.tuple.Tuple2;

import com.codahale.metrics.Counter;
import com.codahale.metrics.Gauge;
import com.codahale.metrics.Histogram;
import com.codahale.metrics.Meter;
import com.codahale.metrics.Metric;
import com.codahale.metrics.Snapshot;
import com.codahale.metrics.Timer;

public class MeterLoggerSerializer implements KafkaMetricsSerializer {

	private final String environment;

	public MeterLoggerSerializer(String environment) {
		this.environment = environment;
	}

	public static final String LATENCY = "latency";
	public static final String LATENCY_HISTO = "latencyHisto";

	private static final String jmNotags = "B rbea.%s %d %s env=%s host=%s ";
	private static final String jmTags = "B rbea.%s %d %s env=%s host=%s topic=%s ";
	private static final String tmTags = "B rbea.%s %d %s env=%s host=%s topic=%s tm=%s";
	private static final String tmOperator = "B rbea.%s %d %s env=%s host=%s topic=%s operator=%s subtask=%s tm=%s";

	private String jobName = null;

	public void createMetricRecord(List<Tuple2> messageList, String topic, long time, String key,
			Object count) {

		MetricKey keyParsed = MetricKey.parse(key);
		if (keyParsed == null) {
			return;
		}

		if (!key.contains(".Status.") && !key.contains(".JVM.") && keyParsed.jobName != null) {
			jobName = keyParsed.jobName;
		} else if (keyParsed.jobName != null) {
			keyParsed.jobName = jobName;
		}

		String value;
		if (keyParsed.jobName == null) {
			value = String.format(jmNotags, keyParsed.metricName, time, count,
					environment, keyParsed.host);
		} else if (keyParsed.operator == null) {
			if (keyParsed.tmId == null) {
				value = String.format(jmTags, keyParsed.metricName, time, count,
						environment, keyParsed.host, keyParsed.jobName);
			} else {
				value = String.format(tmTags, keyParsed.metricName, time, count,
						environment, keyParsed.host, keyParsed.jobName, keyParsed.tmId);
			}
		} else {
			value = String.format(tmOperator, keyParsed.metricName, time, count,
					environment, keyParsed.host, keyParsed.jobName, keyParsed.operator, keyParsed.subtaskIndex,
					keyParsed.tmId);
		}

		messageList.add(metricRecord(topic, key, value));
	}

	protected Tuple2<?, ?> metricRecord(String topic, String key, String value) {
		return new Tuple2<byte[], byte[]>(key.getBytes(), value.getBytes());
	}

	protected <T extends Metric> void addGuageMetricMessages(List<Tuple2> messageList,
			SortedMap<String, Gauge> metrics,
			String topic)
			throws java.io.IOException {

		long time = System.currentTimeMillis();

		for (Map.Entry<String, Gauge> metric : metrics.entrySet()) {
			if (metric.getKey().indexOf(LATENCY) != -1) {
				continue;
			}
			Object value = metric.getValue().getValue();

			createMetricRecord(messageList, topic, time, metric.getKey(), value);
		}
	}

	protected <T extends Metric> void addCounterMetricMessages(List<Tuple2> messageList,
			SortedMap<String, Counter> metrics,
			String topic)
			throws java.io.IOException {

		long time = System.currentTimeMillis();
		for (Map.Entry<String, Counter> metric : metrics.entrySet()) {
			if (metric.getKey().indexOf(LATENCY) != -1) {
				continue;
			}
			Long count = metric.getValue().getCount();
			createMetricRecord(messageList, topic, time, metric.getKey(), count);
		}
	}

	protected <T extends Metric> void addHistogramMetricMessages(List<Tuple2> messageList,
			SortedMap<String, Histogram> metrics,
			String topic)
			throws java.io.IOException {

		long time = System.currentTimeMillis();
		for (Map.Entry<String, Histogram> metric : metrics.entrySet()) {
			if (metric.getKey().indexOf(LATENCY) != -1 && metric.getKey().indexOf(LATENCY_HISTO) == -1) {
				continue;
			}
			// long value = metric.getValue().getCount();
			final Snapshot snapshot = metric.getValue().getSnapshot();

			createMetricRecord(messageList, topic, time, metric.getKey() + "Count", metric.getValue().getCount());
			createMetricRecord(messageList, topic, time, metric.getKey() + "max", snapshot.getMax());
			createMetricRecord(messageList, topic, time, metric.getKey() + "min", snapshot.getMin());
			createMetricRecord(messageList, topic, time, metric.getKey() + "mean", snapshot.getMean());
			createMetricRecord(messageList, topic, time, metric.getKey() + "stddev", snapshot.getStdDev());
			createMetricRecord(messageList, topic, time, metric.getKey() + "median", snapshot.getMedian());
			createMetricRecord(messageList, topic, time, metric.getKey() + "p75", snapshot.get75thPercentile());
			createMetricRecord(messageList, topic, time, metric.getKey() + "p95", snapshot.get95thPercentile());
			createMetricRecord(messageList, topic, time, metric.getKey() + "p98", snapshot.get98thPercentile());
			createMetricRecord(messageList, topic, time, metric.getKey() + "p99", snapshot.get999thPercentile());
			createMetricRecord(messageList, topic, time, metric.getKey() + "p999", snapshot.get999thPercentile());

		}
	}

	protected <T extends Metric> void addMetersMetricMessages(List<Tuple2> messageList,
			SortedMap<String, Meter> metrics,
			String topic)
			throws java.io.IOException {

		long time = System.currentTimeMillis();
		for (Map.Entry<String, Meter> metric : metrics.entrySet()) {
			if (metric.getKey().indexOf(LATENCY) != -1) {
				continue;
			}
			long value = metric.getValue().getCount();

			createMetricRecord(messageList, topic, time, metric.getKey(), value);

		}
	}

	protected <T extends Metric> void addTimerMetricMessages(List<Tuple2> messageList,
			SortedMap<String, Timer> metrics,
			String topic)
			throws java.io.IOException {

		long time = System.currentTimeMillis();
		for (Map.Entry<String, Timer> metric : metrics.entrySet()) {
			if (metric.getKey().indexOf(LATENCY) != -1) {
				continue;
			}
			long value = metric.getValue().getCount();

			createMetricRecord(messageList, topic, time, metric.getKey(), value);
		}
	}

	@Override
	public List<Tuple2> serialize(SortedMap<String, Gauge> gauges, SortedMap<String, Counter> counters,
			SortedMap<String, Histogram> histograms, SortedMap<String, Meter> meters, SortedMap<String, Timer> timers,
			String topic, Date timestamp, TimeUnit rateUnit, TimeUnit durationUnit) throws RuntimeException {
		try {
			List<Tuple2> messages = new ArrayList<Tuple2>();
			addGuageMetricMessages(messages, gauges, topic);
			addCounterMetricMessages(messages, counters, topic);
			addHistogramMetricMessages(messages, histograms, topic);
			addMetersMetricMessages(messages, meters, topic);
			addTimerMetricMessages(messages, timers, topic);
			return messages;
		} catch (java.io.IOException e) {
			throw new RuntimeException(e.getMessage(), e);
		}
	}

}
