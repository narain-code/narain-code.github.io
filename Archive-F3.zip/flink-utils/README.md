# flink-utils
Utilities for Flink applications

## <a name="release"></a>Release process

In order to build and ship to Artifactory: 

`mvn release:prepare release:perform -DignoreSnapshots=true`
