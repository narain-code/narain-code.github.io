package com.king.flink.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.king.constants.external.EventType;
import com.king.event.Event;
import com.king.event.format.EventFormat;
import com.king.event.format.EventFormatException;
import com.king.flink.utils.events.LazyEvent;
import com.king.flink.utils.events.LazyEventFormat;
import com.king.kgk.SCGameEnd;
import com.king.kgk.SCGameStart;

public class LazyEventTest {

	@Test
	public void testTs() throws EventFormatException {
		EventFormat ef = new LazyEventFormat();

		Event e = CustomEvent.create(EventType.Saga2GameStart).withTimeStamp(10).withField(0, true);
		String raw = ef.format(e);

		LazyEvent lazy = (LazyEvent) ef.parse(raw);
		assertFalse(lazy.headerParsed());
		assertFalse(lazy.eventParsed());

		assertEquals(10, lazy.getTimeStamp());
		assertTrue(lazy.headerParsed());
		assertFalse(lazy.eventParsed());
		assertEquals(EventType.Saga2GameStart, lazy.getEventType());

		assertFalse(lazy.eventParsed());
	}

	@Test
	public void testEt() throws EventFormatException {
		EventFormat ef = new LazyEventFormat();

		Event e = CustomEvent.create(EventType.Saga2GameStart).withField(0, true);
		String raw = ef.format(e);

		LazyEvent lazy = (LazyEvent) ef.parse(raw);
		assertFalse(lazy.headerParsed());
		assertFalse(lazy.eventParsed());

		lazy.getEventType();
		assertTrue(lazy.headerParsed());
		assertFalse(lazy.eventParsed());
	}

	@Test
	public void gestGetFirst() throws EventFormatException {
		EventFormat ef = new LazyEventFormat();

		Event e = CustomEvent.create(EventType.Saga2GameStart).withField(0, true).withTimeStamp(10);
		String raw = ef.format(e);

		LazyEvent lazy = (LazyEvent) ef.parse(raw);
		assertFalse(lazy.headerParsed());
		assertFalse(lazy.eventParsed());

		lazy.getBoolean(0);
		assertTrue(lazy.headerParsed());
		assertTrue(lazy.eventParsed());

		assertEquals(10, lazy.getTimeStamp());
		assertEquals(EventType.Saga2GameStart, lazy.getEventType());
	}

	@Test
	public void testSC() throws EventFormatException {
		EventFormat ef = new LazyEventFormat();

		Event e = CustomEvent.create(EventType.Saga2GameStart).withField(0, true);
		String raw = ef.format(e);

		LazyEvent lazy = (LazyEvent) ef.parse(raw);

		assertFalse(lazy.headerParsed());
		assertFalse(lazy.eventParsed());

		SCGameEnd ge = SCGameEnd.process(lazy);
		assertTrue(lazy.headerParsed());
		assertFalse(lazy.eventParsed());
		assertNull(ge);
		SCGameStart gs = SCGameStart.process(lazy);
		assertNotNull(gs);
	}

}
