package com.king.flink.utils;

import org.junit.Test;

import com.king.constants.external.EventType;
import com.king.event.Event;
import com.king.event.format.DelegatingEventFormat;
import com.king.event.format.EventFormat;
import com.king.event.format.EventFormatException;
import com.king.flink.utils.events.LazyEventFormat;

public class LazyEventBenchmark {

	String current;

	@Test
	public void testTs() throws EventFormatException {
		runTest(new LazyEventFormat());
		runTest(new DelegatingEventFormat());
	}

	public void runTest(EventFormat ef) throws EventFormatException {
		Event e = CustomEvent.create(EventType.Saga2GameStart).withTimeStamp(10).withField(0, true);
		String raw = ef.format(e);

		for (int i = 0; i < 100000; i++) {
			Event parsed = ef.parse(raw);
			parsed.getTimeStamp();
			parsed.getEventType();
			current = ef.format(parsed);
		}

		long start = System.nanoTime();
		for (int i = 0; i < 10_000_000; i++) {
			Event parsed = ef.parse(raw);
			parsed.getTimeStamp();
			parsed.getEventType();
			current = ef.format(parsed);
		}
		System.out.println("Elapsed: " + (System.nanoTime() - start) / 1000000 + " ms");
	}

}
