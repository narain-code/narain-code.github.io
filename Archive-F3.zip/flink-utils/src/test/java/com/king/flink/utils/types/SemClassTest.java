package com.king.flink.utils.types;

import static org.junit.Assert.assertNotNull;

import java.io.IOException;

import org.apache.flink.api.common.ExecutionConfig;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeutils.TypeSerializer;
import org.apache.flink.util.InstantiationUtil;
import org.junit.Test;

import com.king.flink.utils.CustomEvent;
import com.king.flink.utils.types.SemanticClassUtils.SerializableSC;
import com.king.kgk.SCGameStart;

public class SemClassTest {

	@Test
	public void testSerializaiton() throws ClassNotFoundException, IOException {
		SerializableSC ss = new SerializableSC(SCGameStart.class);
		SerializableSC des = InstantiationUtil.deserializeObject(InstantiationUtil.serializeObject(ss),
				this.getClass().getClassLoader());
		des.process(CustomEvent.create(0));
		assertNotNull(des.sc);
	}

	@Test
	public void testKryo() throws Exception {
		SerializableSC ss = new SerializableSC(SCGameStart.class);
		TypeSerializer<SerializableSC> t = new TypeHint<SerializableSC>() {}.getTypeInfo()
				.createSerializer(new ExecutionConfig());
		SerializableSC des = InstantiationUtil.deserializeFromByteArray(t,
				InstantiationUtil.serializeToByteArray(t, ss));
		des.process(CustomEvent.create(0));
		assertNotNull(des.sc);
	}

}
