package com.king.flink.utils;

import java.util.Optional;

import com.king.constants.external.EventField;
import com.king.event.Event;

public class CoreUserIdFetcher {

	public static Optional<Long> getCoreUserId(Event event) {
		try {
			String[] fields = EventField.FIELDS_BY_EVENT_ID.get(event.getEventType());

			if (fields != null && fields.length > 0) {

				for (int i = 0; i < fields.length; i++) {
					// This might make out of order data, hopefully most of them
					// will be on position 0 on
					String fieldName = fields[i];
					if (fieldName.toLowerCase().equals("coreuserid")
							|| fieldName.toLowerCase().equals("fromcoreuserid")) {
						long cuid = event.getLong(i);
						if (cuid >= 1_000_000_000) {
							return Optional.of(cuid);
						} else {
							return Optional.empty();
						}
					}
				}
			}

		} catch (Throwable e) {

		}
		return Optional.empty();
	}

}
