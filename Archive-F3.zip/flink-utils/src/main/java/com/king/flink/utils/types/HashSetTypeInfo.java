package com.king.flink.utils.types;

import java.util.HashSet;

import org.apache.flink.api.common.ExecutionConfig;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeutils.TypeSerializer;

public class HashSetTypeInfo<T> extends WrapperTypeInfo<T, HashSet<T>> {
	private static final long serialVersionUID = 1L;

	public HashSetTypeInfo(TypeInformation<T> innerType) {
		super(innerType);
	}

	@Override
	public TypeSerializer<HashSet<T>> createSerializer(ExecutionConfig config) {
		return new HashSetSerializer<T>(getInnerType().createSerializer(config));
	}

	@SuppressWarnings("unchecked")
	@Override
	public Class<HashSet<T>> getTypeClass() {
		return (Class<HashSet<T>>) new HashSet<T>().getClass();
	}

	@Override
	public String toString() {
		return "HashSet(" + innerType.toString() + ")";
	}
}
