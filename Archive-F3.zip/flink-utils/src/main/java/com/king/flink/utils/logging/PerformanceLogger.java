package com.king.flink.utils.logging;

import java.io.Serializable;

import org.slf4j.Logger;

public class PerformanceLogger implements Serializable {
	private static final long serialVersionUID = 1L;

	private final Logger LOG;
	private final int frequency;
	private final String message;

	private long startTime = -1;
	private long totalTime = 0;
	private int count = 0;

	public PerformanceLogger(int frequency, String message, Logger LOG) {
		this.frequency = frequency;
		this.LOG = LOG;
		this.message = "Performance log (" + message + ") (numOperations, totalTime) = ({}, {})";
	}

	public void startMeasurement() {
		if (startTime > 0) {
			throw new RuntimeException("Started twice in a row");
		}
		startTime = System.nanoTime();
	}

	public void stopMeasurement() {
		if (startTime < 0) {
			throw new RuntimeException("Start first");
		}
		count++;
		totalTime += (System.nanoTime() - startTime);
		startTime = -1;

		if (count > 0 && count % frequency == 0) {
			LOG.info(message, frequency, totalTime / 1000000);
			totalTime = 0;
			count = 0;
		}
	}
}
