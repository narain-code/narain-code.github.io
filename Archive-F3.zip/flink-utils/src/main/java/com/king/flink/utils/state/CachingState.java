package com.king.flink.utils.state;

import java.io.IOException;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Consumer;

import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.operators.AbstractStreamOperator;

import com.king.flink.utils.Unchecked;
import com.king.flink.utils.metrics.Watch;

public class CachingState<V> implements ValueState<V> {

	private final AbstractStreamOperator<?> op;
	private final ValueState<V> state;

	private transient LRUMap<Object, Tuple2<Boolean, V>> values;

	public final int maxSize;

	private final ValueState<V> bypassingState;

	// Metric trackers
	private final Consumer<Boolean> cacheHitTracker;
	private final Watch getWatch;
	private final Watch writeWatch;
	private final Consumer<V> stateSizeTracker;

	public CachingState(int maxSize, ValueState<V> state, AbstractStreamOperator<?> op) {
		this(maxSize, state, op, null, null, null, null);
	}

	public CachingState(int maxSize, ValueState<V> state, AbstractStreamOperator<?> op,
			Consumer<Boolean> cacheHitTracker, Watch readWatch, Watch writeWatch, Consumer<V> stateSizeTracker) {

		if (maxSize < 1) {
			throw new RuntimeException("Cache size needs to be at least 1");
		}

		this.state = state;
		this.op = op;
		this.maxSize = maxSize;
		this.cacheHitTracker = cacheHitTracker;
		this.getWatch = readWatch;
		this.writeWatch = writeWatch;
		this.stateSizeTracker = stateSizeTracker;

		this.bypassingState = new CacheBypassingState();

		this.values = new LRUMap<>(maxSize, Unchecked.consumer(eldest -> {
			if (eldest.getValue().f0) {
				Object prevKey = op.getCurrentKey();
				writeIfDirty(eldest);
				if (prevKey != null) {
					op.setCurrentKey(prevKey);
				}
			}
		}));
	}

	public void writeAllToDb() throws IOException {
		Object prevKey = op.getCurrentKey();
		for (Entry<Object, Tuple2<Boolean, V>> entry : values.entrySet()) {
			writeIfDirty(entry);
		}
		if (prevKey != null) {
			op.setCurrentKey(prevKey);
		}
	}

	private void writeIfDirty(Entry<Object, Tuple2<Boolean, V>> entry) throws IOException {
		Tuple2<Boolean, V> t = entry.getValue();

		// If state hasn't changed, nothing to write
		if (!t.f0) {
			return;
		}

		V val = t.f1;

		op.setCurrentKey(entry.getKey());
		if (writeWatch != null) {
			writeWatch.restart();
			state.update(val);
			writeWatch.stopAndRecord();
		} else {
			state.update(val);
		}

		// Mark state change as false
		t.f0 = false;
	}

	private void put(Object key, V value, boolean dirty) throws IOException {
		values.put(key, Tuple2.of(dirty, value));
	}

	private V get(Object key, boolean bypassCache) throws IOException {
		Tuple2<Boolean, V> t = values.get(key);
		V val = t == null ? null : t.f1;

		if (cacheHitTracker != null) {
			cacheHitTracker.accept(val != null);
		}

		if (val == null) {
			if (getWatch != null) {
				getWatch.restart();
				val = state.value();
				getWatch.stopAndRecord();
			} else {
				val = state.value();
			}

			if (val != null) {
				if (stateSizeTracker != null) {
					stateSizeTracker.accept(val);
				}
				if (!bypassCache) {
					put(op.getCurrentKey(), val, false);
				}
			}
		}
		return val;
	}

	@Override
	public void clear() {
		values.remove(op.getCurrentKey());
		state.clear();
	}

	@Override
	public void update(V value) throws IOException {
		update(value, false);
	}

	private void update(V value, boolean bypassCache) throws IOException {
		if (!bypassCache || values.containsKey(op.getCurrentKey())) {
			put(op.getCurrentKey(), value, true);
		} else {
			state.update(value);
		}
	}

	@Override
	public V value() throws IOException {
		return value(false);
	}

	private V value(boolean bypassCache) throws IOException {
		return get(op.getCurrentKey(), bypassCache);
	}

	@Override
	public String toString() {
		return "CachingState [values=" + values + "]";
	}

	public ValueState<V> bypassCache() {
		return bypassingState;
	}

	public Map<Object, Tuple2<Boolean, V>> getValues() {
		return values;
	}

	private class CacheBypassingState implements ValueState<V> {

		@Override
		public void clear() {
			CachingState.this.clear();
		}

		@Override
		public V value() throws IOException {
			return CachingState.this.value(true);
		}

		@Override
		public void update(V value) throws IOException {
			CachingState.this.update(value, true);
		}
	}
}