package com.king.flink.utils.types;

import java.util.ArrayList;

import org.apache.flink.api.common.ExecutionConfig;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeutils.TypeSerializer;

public class ArrayListTypeInfo<T> extends WrapperTypeInfo<T, ArrayList<T>> {
	private static final long serialVersionUID = 1L;

	public ArrayListTypeInfo(TypeInformation<T> innerType) {
		super(innerType);
	}

	@Override
	public TypeSerializer<ArrayList<T>> createSerializer(ExecutionConfig config) {
		return new ArrayListSerializer<T>(getInnerType().createSerializer(config));
	}

	@SuppressWarnings("unchecked")
	@Override
	public Class<ArrayList<T>> getTypeClass() {
		return (Class<ArrayList<T>>) new ArrayList<T>().getClass();
	}

	@Override
	public String toString() {
		return "ArrayList(" + innerType.toString() + ")";
	}
}
