package com.king.flink.utils.source;

import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.Properties;
import java.util.regex.Pattern;

import org.apache.flink.api.common.serialization.DeserializationSchema;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.typeutils.TypeExtractor;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.AssignerWithPeriodicWatermarks;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer010;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumerBase;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.king.event.Event;
import com.king.event.format.DelegatingEventFormat;
import com.king.event.format.EventFormat;
import com.king.event.format.EventFormatException;

public class Kafka {

	static final Logger LOG = LoggerFactory.getLogger(Kafka.class);

	public static final class EventDeserializationSchema implements DeserializationSchema<Event> {
		private static final long serialVersionUID = 1L;
		public static final EventFormat eventFormat = new DelegatingEventFormat();

		@Override
		public TypeInformation<Event> getProducedType() {
			return TypeExtractor.getForClass(Event.class);
		}

		@Override
		public Event deserialize(byte[] bytes) throws IOException {
			try {
				return eventFormat.parse(new String(bytes));
			} catch (EventFormatException e) {
				throw new RuntimeException();
			}
		}

		@Override
		public boolean isEndOfStream(Event event) {
			return false;
		}
	}

	public static SingleOutputStreamOperator<Event> readEvents(String kafkaHost, String zkHost,
			String groupId, List<String> eventTopics, StreamExecutionEnvironment env,
			AssignerWithPeriodicWatermarks<Event> tsAssigner,
			boolean assignPerPartition, int p, String uid) {
		return readEvents(kafkaHost, zkHost, groupId, eventTopics, env, tsAssigner, assignPerPartition, p, uid,
				new EventDeserializationSchema());
	}

	public static SingleOutputStreamOperator<Event> readEvents(String kafkaHost, String zkHost,
			String groupId, List<String> eventTopics, StreamExecutionEnvironment env,
			AssignerWithPeriodicWatermarks<Event> tsAssigner,
			boolean assignPerPartition, int p, String uid, String sourceName) {
		return readEvents(kafkaHost, zkHost, groupId, eventTopics, env, tsAssigner, assignPerPartition, p, uid,
				new EventDeserializationSchema(), sourceName);
	}

	public static SingleOutputStreamOperator<Event> readEvents(String kafkaHost, String zkHost,
			String groupId, List<String> eventTopics, StreamExecutionEnvironment env,
			AssignerWithPeriodicWatermarks<Event> tsAssigner,
			boolean assignPerPartition, int p, String uid, DeserializationSchema<Event> deserializer) {
		return readEvents(kafkaHost, zkHost, groupId, eventTopics, env, tsAssigner, assignPerPartition, p, uid,
				deserializer, "Kafka[" + eventTopics + "]");
	}

	public static SingleOutputStreamOperator<Event> readEvents(String kafkaHost, String zkHost,
			String groupId, List<String> eventTopics, StreamExecutionEnvironment env,
			AssignerWithPeriodicWatermarks<Event> tsAssigner,
			boolean assignPerPartition, int p, String uid, DeserializationSchema<Event> deserializer,
			String sourceName) {

		FlinkKafkaConsumerBase<Event> c = new FlinkKafkaConsumer010<Event>(eventTopics,
				deserializer, getKafkaProps(kafkaHost, zkHost, groupId));
		return readEvents(env, tsAssigner, assignPerPartition, p, uid, c, sourceName);
	}

	public static SingleOutputStreamOperator<Event> readEvents(String kafkaHost, String zkHost,
			String groupId, Pattern eventTopics, StreamExecutionEnvironment env,
			AssignerWithPeriodicWatermarks<Event> tsAssigner,
			boolean assignPerPartition, int p, String uid) {
		return readEvents(kafkaHost, zkHost, groupId, eventTopics, env, tsAssigner, assignPerPartition, p, uid,
				new EventDeserializationSchema());
	}

	public static SingleOutputStreamOperator<Event> readEvents(String kafkaHost, String zkHost,
			String groupId, Pattern eventTopics, StreamExecutionEnvironment env,
			AssignerWithPeriodicWatermarks<Event> tsAssigner,
			boolean assignPerPartition, int p, String uid, String sourceName) {
		return readEvents(kafkaHost, zkHost, groupId, eventTopics, env, tsAssigner, assignPerPartition, p, uid,
				new EventDeserializationSchema(), sourceName);
	}

	public static SingleOutputStreamOperator<Event> readEvents(String kafkaHost, String zkHost,
			String groupId, Pattern eventTopics, StreamExecutionEnvironment env,
			AssignerWithPeriodicWatermarks<Event> tsAssigner,
			boolean assignPerPartition, int p, String uid, DeserializationSchema<Event> deserializer) {
		return readEvents(kafkaHost, zkHost, groupId, eventTopics, env, tsAssigner, assignPerPartition, p, uid,
				deserializer, "Kafka[" + eventTopics + "]");
	}

	public static SingleOutputStreamOperator<Event> readEvents(String kafkaHost, String zkHost,
			String groupId, Pattern topicPattern, StreamExecutionEnvironment env,
			AssignerWithPeriodicWatermarks<Event> tsAssigner,
			boolean assignPerPartition, int p, String uid, DeserializationSchema<Event> deserializer,
			String sourceName) {

		FlinkKafkaConsumerBase<Event> c = new FlinkKafkaConsumer010<Event>(topicPattern,
				deserializer, getKafkaProps(kafkaHost, zkHost, groupId));
		return readEvents(env, tsAssigner, assignPerPartition, p, uid, c, sourceName);
	}

	private static SingleOutputStreamOperator<Event> readEvents(StreamExecutionEnvironment env,
			AssignerWithPeriodicWatermarks<Event> tsAssigner, boolean assignPerPartition, int p, String uid,
			FlinkKafkaConsumerBase<Event> c,
			String sourceName) {

		c.setStartFromGroupOffsets();

		if (tsAssigner != null && assignPerPartition) {
			c = c.assignTimestampsAndWatermarks(tsAssigner);
		}

		SingleOutputStreamOperator<Event> source = env.addSource(c).uid(uid)
				.name(sourceName).setParallelism(p);

		if (tsAssigner != null && !assignPerPartition) {
			source = source.assignTimestampsAndWatermarks(tsAssigner).name("Timestamp assigner").setParallelism(p);
		}

		return source;
	}

	/**
	 * Provides properties usable in instances of {@link FlinkKafkaConsumer08}. All
	 * parameters are optional and won't be added when null.
	 */
	public static Properties getKafkaProps(String kafkaHost, String zkHost, String groupId) {
		Properties properties = new Properties();
		Optional.ofNullable(kafkaHost)
				.ifPresent(v -> properties.setProperty(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, v));
		Optional.ofNullable(zkHost).ifPresent(v -> properties.setProperty("zookeeper.connect", v));
		Optional.ofNullable(groupId).ifPresent(v -> properties.setProperty(ConsumerConfig.GROUP_ID_CONFIG, v));
		properties.setProperty("auto.commit.enable", "true");
		properties.setProperty("auto.commit.interval.ms", "30000");
		return properties;
	}

}
