package com.king.flink.utils.types;

import java.io.IOException;

import org.apache.flink.api.common.typeutils.CompatibilityResult;
import org.apache.flink.api.common.typeutils.ParameterlessTypeSerializerConfig;
import org.apache.flink.api.common.typeutils.TypeSerializer;
import org.apache.flink.api.common.typeutils.TypeSerializerConfigSnapshot;
import org.apache.flink.api.common.typeutils.base.StringSerializer;
import org.apache.flink.core.memory.DataInputView;
import org.apache.flink.core.memory.DataOutputView;

import com.king.event.Event;
import com.king.event.format.EventFormat;
import com.king.event.format.EventFormatException;
import com.king.flink.utils.events.LazyEventFormat;
import com.king.flink.utils.types.SemanticClassUtils.SerializableSC;
import com.king.kgk.KingDataClass;

@SuppressWarnings("unchecked")
public class SemanticClazzSerializer<SC extends KingDataClass> extends TypeSerializer<SC> {

	private static final long serialVersionUID = 1L;

	private final SerializableSC sc;
	private final StringSerializer ss = StringSerializer.INSTANCE;
	public static final EventFormat eventFormat = new LazyEventFormat();

	public SemanticClazzSerializer(Class<SC> clazz) throws NoSuchFieldException, IllegalAccessException {
		this.sc = new SerializableSC(clazz);
	}

	public Class<?> getSemanticClass() {
		return sc.getSemanticClass();
	}

	@Override
	public boolean canEqual(Object o) {
		return o instanceof SemanticClassTypeInfo;
	}

	@Override
	public SC copy(SC sc) {
		return sc;
	}

	@Override
	public SC copy(SC from, SC reuse) {
		return from;
	}

	@Override
	public void copy(DataInputView in, DataOutputView out) throws IOException {
		ss.copy(in, out);
	}

	@Override
	public SC createInstance() {
		return null;
	}

	@Override
	public SC deserialize(DataInputView in) throws IOException {
		String rawEvent = ss.deserialize(in);
		try {
			Event event = eventFormat.parse(rawEvent);
			return (SC) sc.process(event);
		} catch (EventFormatException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public SC deserialize(SC reuse, DataInputView in) throws IOException {
		return deserialize(in);
	}

	@Override
	public TypeSerializer<SC> duplicate() {
		return this;
	}

	@Override
	public boolean equals(Object arg0) {
		return arg0 instanceof SemanticClazzSerializer;
	}

	@Override
	public int getLength() {
		return 0;
	}

	@Override
	public int hashCode() {
		return 0;
	}

	@Override
	public boolean isImmutableType() {
		return true;
	}

	@Override
	public void serialize(SC sc, DataOutputView out) throws IOException {
		try {
			Event event = sc.getRawEvent();
			ss.serialize(eventFormat.format(event), out);
		} catch (Throwable e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public String toString() {
		return "SemClassSerializer(" + getSemanticClass().getSimpleName() + ")";
	}

	@Override
	public TypeSerializerConfigSnapshot snapshotConfiguration() {
		return new ParameterlessTypeSerializerConfig(this.getClass().getSimpleName());
	}

	@Override
	public CompatibilityResult<SC> ensureCompatibility(TypeSerializerConfigSnapshot arg0) {
		return CompatibilityResult.compatible();
	}

}
