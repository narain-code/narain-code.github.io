package com.king.flink.utils.events;

import com.king.event.Event;
import com.king.event.format.DelegatingEventFormat;
import com.king.event.format.EventFormat;
import com.king.event.format.EventFormatException;


public class LazyEventFormat implements EventFormat {

	private static final EventFormat format = new DelegatingEventFormat();

	@Override
	public String format(Event event) {
		if (event instanceof LazyEvent) {
			return ((LazyEvent) event).getRaw();
		} else {
			return format.format(event);
		}
	}

	@Override
	public Event parse(String raw) throws EventFormatException {
		return new LazyEvent(raw);
	}
}
