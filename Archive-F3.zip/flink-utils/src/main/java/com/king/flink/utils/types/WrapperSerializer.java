package com.king.flink.utils.types;

import java.io.IOException;

import org.apache.flink.api.common.typeutils.CompatibilityResult;
import org.apache.flink.api.common.typeutils.ParameterlessTypeSerializerConfig;
import org.apache.flink.api.common.typeutils.TypeSerializer;
import org.apache.flink.api.common.typeutils.TypeSerializerConfigSnapshot;
import org.apache.flink.core.memory.DataInputView;
import org.apache.flink.core.memory.DataOutputView;

public abstract class WrapperSerializer<T, O> extends TypeSerializer<O> {
	private static final long serialVersionUID = 1L;
	protected final TypeSerializer<T> s;

	public WrapperSerializer(TypeSerializer<T> innerSerializer) {
		this.s = innerSerializer;
	}

	public TypeSerializer<T> getInnerSerializer() {
		return s;
	}

	@Override
	public boolean canEqual(Object obj) {
		return obj instanceof WrapperSerializer
				&& ((WrapperSerializer<?, ?>) obj).getInnerSerializer().canEqual(s);
	}

	@Override
	public int getLength() {
		return 0;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((s == null) ? 0 : s.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof WrapperSerializer)) {
			return false;
		}
		WrapperSerializer<?, ?> other = (WrapperSerializer<?, ?>) obj;
		if (s == null) {
			if (other.s != null) {
				return false;
			}
		} else if (!s.equals(other.s)) {
			return false;
		}
		return true;
	}

	@Override
	public boolean isImmutableType() {
		return s.isImmutableType();
	}

	@Override
	public void copy(DataInputView source, DataOutputView target) throws IOException {
		throw new UnsupportedOperationException();
	}

	@Override
	public TypeSerializerConfigSnapshot snapshotConfiguration() {
		return new ParameterlessTypeSerializerConfig(this.getClass().getSimpleName());
	}

	@Override
	public CompatibilityResult<O> ensureCompatibility(TypeSerializerConfigSnapshot arg0) {
		return CompatibilityResult.compatible();
	}
}
