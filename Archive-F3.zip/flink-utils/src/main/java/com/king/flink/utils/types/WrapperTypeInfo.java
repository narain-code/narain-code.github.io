package com.king.flink.utils.types;

import org.apache.flink.api.common.typeinfo.TypeInformation;

public abstract class WrapperTypeInfo<T, O> extends TypeInformation<O> {
	private static final long serialVersionUID = 1L;
	protected final TypeInformation<T> innerType;

	public WrapperTypeInfo(TypeInformation<T> innerType) {
		this.innerType = innerType;
	}

	public TypeInformation<T> getInnerType() {
		return innerType;
	}

	@Override
	public boolean canEqual(Object obj) {
		return obj instanceof WrapperTypeInfo && ((WrapperTypeInfo<?, ?>) obj).getInnerType().canEqual(innerType);
	}

	@Override
	public int getArity() {
		return 0;
	}

	@Override
	public int getTotalFields() {
		return 0;
	}

	@Override
	public boolean isBasicType() {
		return innerType.isBasicType();
	}

	@Override
	public boolean isKeyType() {
		return innerType.isKeyType();
	}

	@Override
	public boolean isTupleType() {
		return false;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((innerType == null) ? 0 : innerType.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof WrapperTypeInfo)) {
			return false;
		}
		WrapperTypeInfo<?, ?> other = (WrapperTypeInfo<?, ?>) obj;
		if (innerType == null) {
			if (other.innerType != null) {
				return false;
			}
		} else if (!innerType.equals(other.innerType)) {
			return false;
		}
		return true;
	}

}
