package com.king.flink.utils.types;

import static com.king.flink.utils.Unchecked.consumer;

import java.io.IOException;
import java.util.Optional;

import org.apache.flink.api.common.typeutils.TypeSerializer;
import org.apache.flink.core.memory.DataInputView;
import org.apache.flink.core.memory.DataOutputView;

public class OptionSerializer<T> extends WrapperSerializer<T, Optional<T>> {

	private static final long serialVersionUID = 1L;

	public OptionSerializer(TypeSerializer<T> innerSerializer) {
		super(innerSerializer);
	}

	@Override
	public Optional<T> copy(Optional<T> from) {
		return from.map(s::copy);
	}

	@Override
	public Optional<T> copy(Optional<T> from, Optional<T> reuse) {
		return from.map(t -> reuse.isPresent() ? s.copy(t, reuse.get()) : s.copy(t));
	}

	@Override
	public void copy(DataInputView source, DataOutputView target) throws IOException {
		boolean isPresent = source.readBoolean();
		target.writeBoolean(isPresent);
		if (isPresent) {
			s.copy(source, target);
		}
	}

	@Override
	public Optional<T> createInstance() {
		return Optional.of(s.createInstance());
	}

	@Override
	public void serialize(Optional<T> record, DataOutputView target) throws IOException {
		boolean isPresent = record.isPresent();
		target.writeBoolean(isPresent);
		record.ifPresent(consumer(t -> {
			s.serialize(t, target);
		}));
	}

	@Override
	public Optional<T> deserialize(DataInputView source) throws IOException {
		boolean isPresent = source.readBoolean();
		return isPresent ? Optional.of(s.deserialize(source)) : Optional.empty();
	}

	@Override
	public Optional<T> deserialize(Optional<T> reuse, DataInputView source) throws IOException {
		boolean isPresent = source.readBoolean();

		if (isPresent) {
			if (reuse.isPresent()) {
				return Optional.of(s.deserialize(reuse.get(), source));
			} else {
				return Optional.of(s.deserialize(source));
			}
		} else {
			return Optional.empty();
		}
	}

	@Override
	public TypeSerializer<Optional<T>> duplicate() {
		return new OptionSerializer<>(s.duplicate());
	}
}
