package com.king.flink.utils.types;

import org.apache.flink.api.common.ExecutionConfig;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeutils.TypeSerializer;

import com.king.kgk.KingDataClass;

public class SemanticClassTypeInfo<SC extends KingDataClass> extends TypeInformation<SC> {

	private static final long serialVersionUID = 1L;
	private final Class<SC> clazz;

	public SemanticClassTypeInfo(Class<SC> clazz) {
		this.clazz = clazz;
	}

	@Override
	public boolean canEqual(Object o) {
		return o instanceof SemanticClassTypeInfo;
	}

	@Override
	public TypeSerializer<SC> createSerializer(ExecutionConfig arg0) {
		try {
			return new SemanticClazzSerializer<>(clazz);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public boolean equals(Object o) {
		return o instanceof SemanticClassTypeInfo && ((SemanticClassTypeInfo<?>) o).clazz.equals(clazz);
	}

	@Override
	public int getArity() {
		return 0;
	}

	@Override
	public int getTotalFields() {
		return 0;
	}

	@Override
	public Class<SC> getTypeClass() {
		return clazz;
	}

	@Override
	public int hashCode() {
		return clazz.hashCode();
	}

	@Override
	public boolean isBasicType() {
		return false;
	}

	@Override
	public boolean isKeyType() {
		return false;
	}

	@Override
	public boolean isTupleType() {
		return false;
	}

	@Override
	public String toString() {
		return "SemanticClass(" + clazz.getSimpleName() + ")";
	}

}
