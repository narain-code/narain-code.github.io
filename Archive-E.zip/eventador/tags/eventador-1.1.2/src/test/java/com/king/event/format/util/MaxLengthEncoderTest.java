package com.king.event.format.util;

import static org.junit.Assert.*;

import org.junit.Test;

import com.king.event.format.Encoder;

public class MaxLengthEncoderTest {

	@Test
	public void test() {
		Encoder encoder = new MaxLengthEncoder(new IdentityEncoder(), 10);
		
		assertEquals(0, encoder.encode("").length());
		assertEquals(1, encoder.encode("1").length());
		assertEquals(9, encoder.encode("123456789").length());
		assertEquals(10, encoder.encode("1234567890").length());
		assertEquals(10, encoder.encode("1234567890_").length());
		assertEquals(10, encoder.encode("1234567890___").length());
	}

}
