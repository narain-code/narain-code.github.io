package com.king.event.format.util;

import com.king.event.format.Encoder;


public class MaxLengthEncoder implements Encoder {
	private final Encoder delegate;
	private final int maxLength;

	public MaxLengthEncoder(Encoder delegate, int maxLength) {
		this.delegate = delegate;
		this.maxLength = maxLength;
	}

	@Override
	public String encode(String s) {
		String encoded = delegate.encode(s);
		if (encoded.length() > maxLength) {
			return encoded.substring(0, maxLength);
		}
		else {
			return encoded;
		}
	}

}
