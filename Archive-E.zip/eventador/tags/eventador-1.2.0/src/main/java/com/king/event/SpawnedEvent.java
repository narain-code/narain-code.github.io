package com.king.event;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class SpawnedEvent extends TypedEventFieldAccessor implements Event {

	private final long timeStamp;
	private final int flavourId;
	private final long eventType;
	private final long uniqueId;
	private final String hostname;
	private final List<String> fields;

	public SpawnedEvent(long timeStamp, int flavourId, long eventType, long uniqueId, String hostname) {
		this.timeStamp = timeStamp;
		this.flavourId = flavourId;
		this.eventType = eventType;
		this.uniqueId = uniqueId;
		this.hostname = hostname;
		fields = new ArrayList<String>();
	}

	public SpawnedEvent(long timeStamp, int flavourId, long eventType, long uniqueId, String hostname, List<String> fields) {
		this.timeStamp = timeStamp;
		this.flavourId = flavourId;
		this.eventType = eventType;
		this.uniqueId = uniqueId;
		this.hostname = hostname;
		this.fields = new ArrayList<String>(fields.size());
		for (String field : fields) {
			addField(field);
		}
	}

	@Override
	public long getTimeStamp() {
		return timeStamp;
	}

	@Override
	public int getFlavourId() {
		return flavourId;
	}

	@Override
	public long getEventType() {
		return eventType;
	}

	@Override
	public long getUniqueId() {
		return uniqueId;
	}

	@Override
	public String getHostname() {
		return hostname;
	}

	@Override
	public Iterable<String> fields() {
		return fields;
	}

	public void addField(String field) {
		fields.add(field);
	}

	public void addFields(Collection<String> fields) {
		this.fields.addAll(fields);
	}

	@Override
	public String getString(int index) {
		return fields.get(index);
	}

	@Override
	public long getLong(int index) {
		return Long.parseLong(getString(index));
	}

	@Override
	public int getInt(int index) {
		return Integer.parseInt(getString(index));
	}

	@Override
	public double getDouble(int index) {
		return Double.parseDouble(getString(index));
	}

}
