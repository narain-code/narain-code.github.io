package com.king.event.format.A;

import java.util.Iterator;

import com.king.event.Event;
import com.king.event.TypedEventFieldAccessor;
import com.king.event.format.Decoder;
import com.king.event.format.util.NumberParser;


/*
 * NOTE: concurrent iterators over fields in an event is not supported!
 */
// TODO cache index of fields on first field access
class EventA extends TypedEventFieldAccessor implements Iterable<String>, Iterator<String>, Event {

	private final Decoder decoder;
	private final String event;
	private final int eventLength;
	private final long timeStamp;
	private final int flavourId;
	private final long eventType;
	private final long uniqueEventId;
	private final int hostnameBeginIndex;
	private final int hostnameEndIndex;
	private final int fieldsStartIndex;
	private int currentFieldIndex;


	public EventA(Decoder decoder, String event, long timeStamp, int flavourId, long eventType, long uniqueEventId, int hostnameBeginIndex, int hostnameEndIndex, int fieldsStartIndex) {
		this.decoder = decoder;
		this.event = event;
		this.eventLength = event.length();
		this.timeStamp = timeStamp;
		this.flavourId = flavourId;
		this.eventType = eventType;
		this.uniqueEventId = uniqueEventId;
		this.hostnameBeginIndex = hostnameBeginIndex;
		this.hostnameEndIndex = hostnameEndIndex;
		this.fieldsStartIndex = fieldsStartIndex;
	}

	@Override
	public long getTimeStamp() {
		return timeStamp;
	}

	@Override
	public int getFlavourId() {
		return flavourId;
	}

	@Override
	public long getEventType() {
		return eventType;
	}

	@Override
	public long getUniqueId() {
		return uniqueEventId;
	}

	@Override
	public String getHostname() {
		return event.substring(hostnameBeginIndex, hostnameEndIndex);
	}

	@Override
	public Iterable<String> fields() {
		return this;
	}

	@Override
	public Iterator<String> iterator() {
		currentFieldIndex = fieldsStartIndex;
		return this;
	}

	@Override
	public boolean hasNext() {
		return currentFieldIndex != -1 && currentFieldIndex < eventLength;
	}

	@Override
	public String next() {
		if (!hasNext()) {
			throw new IllegalStateException("Iterator exhausted");
		}
		int fieldStartIndex = currentFieldIndex;
		int fieldEndIndex = event.indexOf(EventFormatA.FIELD_DELIMITER, fieldStartIndex);

		String field;
		if (fieldEndIndex == -1) {
			field = event.substring(fieldStartIndex);
			currentFieldIndex = -1;
		}
		else {
			field = event.substring(fieldStartIndex, fieldEndIndex);
			currentFieldIndex = fieldEndIndex + 1;
		}

		return decoder.decode(field);
	}

	@Override
	public void remove() {
		// Not implemented
	}

	public String toString() {
		return event;
	}

	@Override
	public String getString(int index) {
		int startOffset = getFieldOffset(index);
		return decoder.decode(event.substring(startOffset, getFieldEndOffset(startOffset)));
	}

	@Override
	public int getInt(int index) {
		int startOffset = getFieldOffset(index);
		return NumberParser.parseInt(event, startOffset, getFieldEndOffset(startOffset));
	}

	@Override
	public long getLong(int index) {
		int startOffset = getFieldOffset(index);
		return NumberParser.parseLong(event, startOffset, getFieldEndOffset(startOffset));
	}

	@Override
	public double getDouble(int index) {
		return Double.parseDouble(getString(index));
	}

	private int getFieldOffset(int index) {
		int offset = fieldsStartIndex;
		for (int i=0; i < index; i++) {
			offset = event.indexOf('\t', offset);
			if (offset == -1) {
				throw new ArrayIndexOutOfBoundsException(index);
			}
			offset++;
		}

		return offset;
	}

	private int getFieldEndOffset(int fieldStartOffset) {
		int fieldEndOffset = event.indexOf('\t', fieldStartOffset);
		if (fieldEndOffset > 0) {
			return fieldEndOffset;
		}
		else {
			return event.length();
		}
	}

}
