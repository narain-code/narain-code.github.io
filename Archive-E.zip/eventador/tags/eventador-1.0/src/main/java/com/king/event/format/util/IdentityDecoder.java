package com.king.event.format.util;

import com.king.event.format.Decoder;


public class IdentityDecoder implements Decoder {

	@Override
	public String decode(String s) {
		return s;
	}

}
