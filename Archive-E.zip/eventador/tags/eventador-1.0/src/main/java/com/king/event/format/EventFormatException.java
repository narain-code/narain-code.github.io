package com.king.event.format;

public class EventFormatException extends Exception {

	public EventFormatException() {
	}

	public EventFormatException(String message, Throwable cause) {
		super(message, cause);
	}

	public EventFormatException(String message) {
		super(message);
	}

}
