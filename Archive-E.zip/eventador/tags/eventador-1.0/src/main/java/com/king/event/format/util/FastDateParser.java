package com.king.event.format.util;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import com.king.event.format.EventFormatException;

public class FastDateParser {

	private final static int[] leapYearMonthDays = new int[]{0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335};
    private final static int[] monthDays = new int[]{0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334};
    private final TimeZone zoneSTHLM = TimeZone.getTimeZone("Europe/Stockholm");

    public String format(long millis) {
    	StringBuilder sb = new StringBuilder(25);
    	format(millis, sb);
    	return sb.toString();
    }

    /*
     * This is about twice as fast as compared to joda. Could be faster by not
     * using Calendar but it gets a little bit involved. SimpleDateFormat is a little
     * bit faster than joda but unusable as it's not thread safe.
     */
    public void format(long millis, StringBuilder buffer) {
    	GregorianCalendar calendar = new GregorianCalendar(zoneSTHLM);
    	calendar.setTime(new Date(millis));

		pad(buffer, calendar.get(Calendar.YEAR), 4);
		pad(buffer, calendar.get(Calendar.MONTH)+1, 2);
		pad(buffer, calendar.get(Calendar.DAY_OF_MONTH), 2);
		buffer.append('T');
		pad(buffer, calendar.get(Calendar.HOUR_OF_DAY), 2);
		pad(buffer, calendar.get(Calendar.MINUTE), 2);
		pad(buffer, calendar.get(Calendar.SECOND), 2);
		buffer.append('.');
		pad(buffer, calendar.get(Calendar.MILLISECOND), 3);

		int tzOffset = calendar.get(Calendar.ZONE_OFFSET) + calendar.get(Calendar.DST_OFFSET);
		int tzOffsetHours = tzOffset / 1000 / 60 / 60;
		int tzOffsetMinutes = (tzOffset / 1000 / 60) - (tzOffsetHours * 60);
		buffer.append('+');
		pad(buffer, tzOffsetHours, 2);
		pad(buffer, tzOffsetMinutes, 2);
    }

    private void pad(StringBuilder buffer, int value, int length) {
    	for (int i=stringSize(value); i < length; i++) {
    		buffer.append('0');
    	}
    	buffer.append(value);
    }

    final static int [] sizeTable = { 9, 99, 999, 9999, 99999, 999999, 9999999, 99999999, 999999999, Integer.MAX_VALUE };

    static int stringSize(int x) {
    	for (int i=0; ; i++) {
    		if (x <=sizeTable[i]) {
    			return i+1;
    		}
    	}
    }


    /*
     * Parses dates of format: "yyyyMMddTHHmmss.SSS([+|-]ZZZZ)?"
     * 
     * About 25 times faster than joda.
     */
	public long parse(String date, int start, int end) throws EventFormatException {
		int length = end-start;

		// Default time zone offset to 0 (will be fixed at bottom of method if missing)
		int timeZoneHours = 0;
		int timeZoneMinutes = 0;
		int tzSign = -1;

		// Time zone offset (if any)
		if(length == 24) {
			char tzSignChar = date.charAt(start+19);
			if (tzSignChar == '+') {
				tzSign = 1;
			}
			else if (tzSignChar != '-') {
				throw new EventFormatException("Illegal date format, expected timezone sign, found '" + tzSignChar + "' in date " + date.substring(start, end));
			}

			timeZoneHours = parseInt2(date, start+20);
			timeZoneMinutes = parseInt2(date, start+22);
		}
		else if (length != 19) {
		 	throw new EventFormatException("Illegal date format: " + date.substring(start, end));
		}

		int year = parseInt4(date, start+0);
		int month = parseInt2(date, start+4);
		int day = parseInt2(date, start+6);
		if (month < 1 || month > 12) {
			throw new EventFormatException("Illegal month: " + month + " in date " + date.substring(start, end));
		}
		if (day < 1 || day > 31) {
			throw new EventFormatException("Illegal day: " + day + " in date " + date.substring(start, end));
		}

		char dateTimeSeparator = date.charAt(start+8);
		if (dateTimeSeparator != 'T') {
			throw new EventFormatException("Illegal date format, expected separator 'T' found: " + dateTimeSeparator);
		}

		int hour = parseInt2(date, start+9);
		int minute = parseInt2(date, start+11);
		int second = parseInt2(date, start+13);
		if (hour > 23) {
			throw new EventFormatException("Illegal hour: " + hour + " in date " + date.substring(start, end));
		}
		if (minute > 59) {
			throw new EventFormatException("Illegal minute: " + minute + " in date " + date.substring(start, end));
		}
		if (second > 59) {
			throw new EventFormatException("Illegal second: " + second + " in date " + date.substring(start, end));
		}

		// Milliseconds
		char milliSeparator = date.charAt(start+15);
		if (milliSeparator != '.') {
			throw new EventFormatException("Illegal date format, expected separator '.' found: " + milliSeparator);
		}

		int ms = parseInt3(date, start+16);

		// Choose days/month table depending on leap year or not
		int[] actualMonthDays;
		if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) {
			actualMonthDays = leapYearMonthDays;
		} else {
			actualMonthDays = monthDays;
		}

		int leapDays;
		if (year >= 1970) {
			leapDays = (year - 1969) / 4; // How many leap years since 1970
			leapDays -= (year - 1901) / 100; // centuries are not leap years, remove them
			leapDays += (year - 1601) / 400; // but quad centuries are
		}
		else {
			leapDays = (year-1972) / 4;
			leapDays -= (year-2000) / 100; // as above correct for centuries
			leapDays += (year-2000) / 400; // as above correct for centuries
		}
		long yearDays = (year - 1970) * 365;
		long days = yearDays + leapDays + (actualMonthDays[month - 1] + (day-1));
		long seconds = (hour-(timeZoneHours*tzSign)) * 3600 + (minute-(timeZoneMinutes*tzSign)) * 60 + second;

		long millis = (1000L * ((days * 3600L * 24L) + seconds)) + ms;

		// Finally fix time zone if it was missing
		if (length == 19) {
			millis -= zoneSTHLM.getOffset(millis);
		}
		
		return millis;
	}

	private final int parseInt2(String s, int index) throws EventFormatException {
		int d = s.charAt(index) -'0';
		int u = s.charAt(index+1) - '0';
		verifyDigits(d, u, s);

		return d*10 + u;
	}

	private final int parseInt3(String s, int index) throws EventFormatException {
		int c = s.charAt(index) - '0';
		int d = s.charAt(index+1) - '0';
		verifyDigits(c, d, s);
		int u = s.charAt(index+2) - '0';
		verifyDigits(u, d, s);

		return c*100 + d*10 + u;
	}

	private final int parseInt4(String s, int index) throws EventFormatException {
		int m = s.charAt(index) - '0';
		int c = s.charAt(index+1) - '0';
		verifyDigits(m, c, s);
		int d = s.charAt(index+2) - '0';
		int u = s.charAt(index+3) - '0';
		verifyDigits(d, u, s);

		return m*1000 + c*100 + d*10 + u;
	}

	private final void verifyDigits(int d1, int d2, String org) throws EventFormatException {
		if (d1 < 0 || d1 > 9) {
			throw new EventFormatException("Illegal date format expected digit found: " + ((char)d1+'0') + ", in date: " + org);
		}
		if (d2 < 0 || d2 > 9) {
			throw new EventFormatException("Illegal date format expected digit found: " + ((char)d2+'0') + ", in date: " + org);
		}
	}

}
