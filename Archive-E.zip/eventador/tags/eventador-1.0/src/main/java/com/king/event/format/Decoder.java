package com.king.event.format;

public interface Decoder {

	String decode(String s);

}
