package com.king.event.format.original;

import com.king.event.Event;
import com.king.event.format.Decoder;
import com.king.event.format.Encoder;
import com.king.event.format.EventFormat;
import com.king.event.format.EventFormatException;
import com.king.event.format.util.FastDateParser;
import com.king.event.format.util.HTMLEntityDecoder;
import com.king.event.format.util.HTMLEntityEncoder;
import com.king.event.format.util.NumberParser;


public class OriginalEventFormat implements EventFormat {

	private static final char FIELD_SEPARATOR = '\t';
	private static FastDateParser dateParser = new FastDateParser();

	private final Encoder encoder;
	private final Decoder decoder;

	public OriginalEventFormat() {
		this(new HTMLEntityEncoder(), new HTMLEntityDecoder());
	}

	public OriginalEventFormat(Encoder encoder, Decoder decoder) {
		this.encoder = encoder;
		this.decoder = decoder;
	}

	@Override
	public Event parse(String event) throws EventFormatException {

		int currentFieldStart = 0;

		// Date
		int currentFieldEnd = event.indexOf(FIELD_SEPARATOR, currentFieldStart);
		long timeStamp = dateParser.parse(event, currentFieldStart, currentFieldEnd);
		currentFieldStart = currentFieldEnd+1;

		// Flavour id
		currentFieldEnd = event.indexOf(FIELD_SEPARATOR, currentFieldStart);
		try {
			int flavourId = NumberParser.parseInt(event, currentFieldStart, currentFieldEnd);
			currentFieldStart = currentFieldEnd+1;

			// Event type
			currentFieldEnd = event.indexOf(FIELD_SEPARATOR, currentFieldStart);
			if (currentFieldEnd == -1) {
				currentFieldEnd = event.length();
			}
			long eventTypeId = NumberParser.parseLong(event, currentFieldStart, currentFieldEnd);
			
			return new OriginalEvent(decoder, event, timeStamp, flavourId, eventTypeId, currentFieldEnd);
		}
		catch (NumberFormatException e) {
			throw new EventFormatException(event, e);
		}
	}

	@Override
	public String format(Event event) {
		StringBuilder builder = new StringBuilder(100);

		dateParser.format(event.getTimeStamp(), builder);
		builder.append(FIELD_SEPARATOR);
		builder.append(event.getFlavourId()).append(FIELD_SEPARATOR);
		builder.append(event.getEventType());

		for (String field : event.fields()) {
			builder.append(FIELD_SEPARATOR).append(encoder.encode(field));
		}

		return builder.toString();
	}

}
