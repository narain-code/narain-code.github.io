package com.king.event.format;

import com.king.event.Event;

public interface EventFormat {

	String format(Event event);

	Event parse(String event) throws EventFormatException;

}
