package com.king.event.format.util;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.king.event.format.Decoder;


public class HTMLEntityDecoder implements Decoder {

	private static boolean[] loggableCharacters = new boolean[128];
	static {
		for (int i = 0; i < loggableCharacters.length; i++) {
			loggableCharacters[i] = !Character.isISOControl(i) && i != '&';
		}
	}

	@Override
	public String decode(String s) {
		StringBuilder sb = new StringBuilder(s.length());

		for (int i=0; i < s.length(); i++) {
			char c = s.charAt(i);
			if (c == '&') {
				int entityEnd = s.indexOf(';', i);
				if (entityEnd-i > 1) {
					char firstChar = s.charAt(i+1);
					char secondChar = s.charAt(i+2);
					if (firstChar == '#' && (secondChar == 'x' || secondChar == 'X')) {
						// hex entity spec
						String hex = s.substring(i+3, entityEnd);
						try {
							int codePoint = Integer.parseInt(hex, 16);
							sb.append(Character.toChars(codePoint));
						}
						catch (NumberFormatException e) {
							// Lenient parsing, ignore invalid number, retain original bogus data
							sb.append("&#").append(secondChar).append(hex).append(";");
						}
					}
					else if (firstChar == '#') {
						// decimal entity spec
						String dec = s.substring(i+2, entityEnd);
						try {
							int codePoint = Integer.parseInt(dec);
							sb.append(Character.toChars(codePoint));
						}
						catch (NumberFormatException e) {
							// Lenient parsing, ignore invalid number, retain original bogus data
							sb.append("&#").append(dec).append(";");
						}
					}
					else {
						// named entity
						String entityName = s.substring(i+1, entityEnd);
						Integer codePoint = entityMap.get(entityName);
						if (codePoint != null) {
							sb.append(new String(Character.toChars(codePoint)));
						}
						else {
							// Lenient parsing, ignore invalid number, retain original bogus data
							sb.append("&").append(entityName).append(";");
						}
					}

					i = entityEnd;
				}
				else {
					sb.append(c);
				}
			}
			else {
				sb.append(c);
			}
		}

		if (sb.length() != s.length()) {
			return sb.toString();
		}
		else {
			return s;
		}
	}

	/**
	 * Iterate of all unixcode code points in a string
	 * 
	 * @param s
	 * @return
	 */
	static Iterable<Integer> codePoints(final String s) {
		return new Iterable<Integer>() {
			@Override
            public Iterator<Integer> iterator() {
				return new Iterator<Integer>() {
					int nextIndex = 0;

					@Override
                    public boolean hasNext() {
						return nextIndex < s.length();
					}

					@Override
                    public Integer next() {
						int result = s.codePointAt(nextIndex);
						nextIndex += Character.charCount(result);
						return result;
					}

					@Override
                    public void remove() {
						throw new UnsupportedOperationException();
					}
				};
			}
		};
	}

	private final static Map<String, Integer> entityMap = new HashMap<String, Integer>();	
	
	private static final String[][] entites = {
		{"quot", "0022"},
		{"amp", "0026"},
		{"apos", "0027"},
		{"lt", "003C"},
		{"gt", "003E"},
		{"nbsp", "00A0"},
		{"iexcl", "00A1"},
		{"cent", "00A2"},
		{"pound", "00A3"},
		{"curren", "00A4"},
		{"yen", "00A5"},
		{"brvbar", "00A6"},
		{"sect", "00A7"},
		{"uml", "00A8"},
		{"copy", "00A9"},
		{"ordf", "00AA"},
		{"laquo", "00AB"},
		{"not", "00AC"},
		{"shy", "00AD"},
		{"reg", "00AE"},
		{"macr", "00AF"},
		{"deg", "00B0"},
		{"plusmn", "00B1"},
		{"sup2", "00B2"},
		{"sup3", "00B3"},
		{"acute", "00B4"},
		{"micro", "00B5"},
		{"para", "00B6"},
		{"middot", "00B7"},
		{"cedil", "00B8"},
		{"sup1", "00B9"},
		{"ordm", "00BA"},
		{"raquo", "00BB"},
		{"frac14", "00BC"},
		{"frac12", "00BD"},
		{"frac34", "00BE"},
		{"iquest", "00BF"},
		{"Agrave", "00C0"},
		{"Aacute", "00C1"},
		{"Acirc", "00C2"},
		{"Atilde", "00C3"},
		{"Auml", "00C4"},
		{"Aring", "00C5"},
		{"AElig", "00C6"},
		{"Ccedil", "00C7"},
		{"Egrave", "00C8"},
		{"Eacute", "00C9"},
		{"Ecirc", "00CA"},
		{"Euml", "00CB"},
		{"Igrave", "00CC"},
		{"Iacute", "00CD"},
		{"Icirc", "00CE"},
		{"Iuml", "00CF"},
		{"ETH", "00D0"},
		{"Ntilde", "00D1"},
		{"Ograve", "00D2"},
		{"Oacute", "00D3"},
		{"Ocirc", "00D4"},
		{"Otilde", "00D5"},
		{"Ouml", "00D6"},
		{"times", "00D7"},
		{"Oslash", "00D8"},
		{"Ugrave", "00D9"},
		{"Uacute", "00DA"},
		{"Ucirc", "00DB"},
		{"Uuml", "00DC"},
		{"Yacute", "00DD"},
		{"THORN", "00DE"},
		{"szlig", "00DF"},
		{"agrave", "00E0"},
		{"aacute", "00E1"},
		{"acirc", "00E2"},
		{"atilde", "00E3"},
		{"auml", "00E4"},
		{"aring", "00E5"},
		{"aelig", "00E6"},
		{"ccedil", "00E7"},
		{"egrave", "00E8"},
		{"eacute", "00E9"},
		{"ecirc", "00EA"},
		{"euml", "00EB"},
		{"igrave", "00EC"},
		{"iacute", "00ED"},
		{"icirc", "00EE"},
		{"iuml", "00EF"},
		{"eth", "00F0"},
		{"ntilde", "00F1"},
		{"ograve", "00F2"},
		{"oacute", "00F3"},
		{"ocirc", "00F4"},
		{"otilde", "00F5"},
		{"ouml", "00F6"},
		{"divide", "00F7"},
		{"oslash", "00F8"},
		{"ugrave", "00F9"},
		{"uacute", "00FA"},
		{"ucirc", "00FB"},
		{"uuml", "00FC"},
		{"yacute", "00FD"},
		{"thorn", "00FE"},
		{"yuml", "00FF"},
		{"OElig", "0152"},
		{"oelig", "0153"},
		{"Scaron", "0160"},
		{"scaron", "0161"},
		{"Yuml", "0178"},
		{"fnof", "0192"},
		{"circ", "02C6"},
		{"tilde", "02DC"},
		{"Alpha", "0391"},
		{"Beta", "0392"},
		{"Gamma", "0393"},
		{"Delta", "0394"},
		{"Epsilon", "0395"},
		{"Zeta", "0396"},
		{"Eta", "0397"},
		{"Theta", "0398"},
		{"Iota", "0399"},
		{"Kappa", "039A"},
		{"Lambda", "039B"},
		{"Mu", "039C"},
		{"Nu", "039D"},
		{"Xi", "039E"},
		{"Omicron", "039F"},
		{"Pi", "03A0"},
		{"Rho", "03A1"},
		{"Sigma", "03A3"},
		{"Tau", "03A4"},
		{"Upsilon", "03A5"},
		{"Phi", "03A6"},
		{"Chi", "03A7"},
		{"Psi", "03A8"},
		{"Omega", "03A9"},
		{"alpha", "03B1"},
		{"beta", "03B2"},
		{"gamma", "03B3"},
		{"delta", "03B4"},
		{"epsilon", "03B5"},
		{"zeta", "03B6"},
		{"eta", "03B7"},
		{"theta", "03B8"},
		{"iota", "03B9"},
		{"kappa", "03BA"},
		{"lambda", "03BB"},
		{"mu", "03BC"},
		{"nu", "03BD"},
		{"xi", "03BE"},
		{"omicron", "03BF"},
		{"pi", "03C0"},
		{"rho", "03C1"},
		{"sigmaf", "03C2"},
		{"sigma", "03C3"},
		{"tau", "03C4"},
		{"upsilon", "03C5"},
		{"phi", "03C6"},
		{"chi", "03C7"},
		{"psi", "03C8"},
		{"omega", "03C9"},
		{"thetasym", "03D1"},
		{"upsih", "03D2"},
		{"piv", "03D6"},
		{"ensp", "2002"},
		{"emsp", "2003"},
		{"thinsp", "2009"},
		{"zwnj", "200C"},
		{"zwj", "200D"},
		{"lrm", "200E"},
		{"rlm", "200F"},
		{"ndash", "2013"},
		{"mdash", "2014"},
		{"lsquo", "2018"},
		{"rsquo", "2019"},
		{"sbquo", "201A"},
		{"ldquo", "201C"},
		{"rdquo", "201D"},
		{"bdquo", "201E"},
		{"dagger", "2020"},
		{"Dagger", "2021"},
		{"bull", "2022"},
		{"hellip", "2026"},
		{"permil", "2030"},
		{"prime", "2032"},
		{"Prime", "2033"},
		{"lsaquo", "2039"},
		{"rsaquo", "203A"},
		{"oline", "203E"},
		{"frasl", "2044"},
		{"euro", "20AC"},
		{"image", "2111"},
		{"weierp", "2118"},
		{"real", "211C"},
		{"trade", "2122"},
		{"alefsym", "2135"},
		{"larr", "2190"},
		{"uarr", "2191"},
		{"rarr", "2192"},
		{"darr", "2193"},
		{"harr", "2194"},
		{"crarr", "21B5"},
		{"lArr", "21D0"},
		{"uArr", "21D1"},
		{"rArr", "21D2"},
		{"dArr", "21D3"},
		{"hArr", "21D4"},
		{"forall", "2200"},
		{"part", "2202"},
		{"exist", "2203"},
		{"empty", "2205"},
		{"nabla", "2207"},
		{"isin", "2208"},
		{"notin", "2209"},
		{"ni", "220B"},
		{"prod", "220F"},
		{"sum", "2211"},
		{"minus", "2212"},
		{"lowast", "2217"},
		{"radic", "221A"},
		{"prop", "221D"},
		{"infin", "221E"},
		{"ang", "2220"},
		{"and", "2227"},
		{"or", "2228"},
		{"cap", "2229"},
		{"cup", "222A"},
		{"int", "222B"},
		{"there4", "2234"},
		{"sim", "223C"},
		{"cong", "2245"},
		{"asymp", "2248"},
		{"ne", "2260"},
		{"equiv", "2261"},
		{"le", "2264"},
		{"ge", "2265"},
		{"sub", "2282"},
		{"sup", "2283"},
		{"nsub", "2284"},
		{"sube", "2286"},
		{"supe", "2287"},
		{"oplus", "2295"},
		{"otimes", "2297"},
		{"perp", "22A5"},
		{"sdot", "22C5"},
		{"vellip", "22EE"},
		{"lceil", "2308"},
		{"rceil", "2309"},
		{"lfloor", "230A"},
		{"rfloor", "230B"},
		{"lang", "2329"},
		{"rang", "232A"},
		{"loz", "25CA"},
		{"spades", "2660"},
		{"clubs", "2663"},
		{"hearts", "2665"},
		{"diams", "2666"},
	};

	static {
		for (int i=0; i < entites.length; i++) {
			entityMap.put(entites[i][0], Integer.parseInt(entites[i][1], 16));
		}
	}

}
