package com.king.event.format;

import com.king.event.Event;
import com.king.event.format.A.EventFormatA;
import com.king.event.format.original.OriginalEventFormat;

/**
 * Supports parsing of all versions of event formats. Outputs the latest version.
 */
public class DelegatingEventFormat implements EventFormat {
	private final OriginalEventFormat originalEventFormat;
	private final EventFormatA eventFormatA;

	public DelegatingEventFormat() {
		this.originalEventFormat = new OriginalEventFormat();
		this.eventFormatA = new EventFormatA();
	}

	@Override
	public String format(Event event) {
		return eventFormatA.format(event);
	}

	@Override
	public Event parse(String event) throws EventFormatException {
		char firstChar = event.charAt(0);
		if (firstChar == 'A') {
			return eventFormatA.parse(event);
		}
		else if (firstChar == '2') {
			return originalEventFormat.parse(event);
		}
		else {
			throw new IllegalStateException("Unparsable event: " + event);
		}
	}

}
