package com.king.event.format;

public interface Encoder {

	String encode(String s);

}
