package com.king.event.format.util;

public class NumberParser {


	public static int parseInt(String str, int start, int end) throws NumberFormatException {
	    final int length = end - start;
	    if (length < 1) {
	    	throw new NumberFormatException("Attempt to parse empty string as number:  " + str);
	    }

		final boolean negative;
		final int limit;
		int i = 0;
	    if (str.charAt(start) == '-') {
	    	negative = true;
	    	limit = Integer.MIN_VALUE;
	    	i++;
	    } else {
	    	negative = false;
	    	limit = -Integer.MAX_VALUE;
	    }
		final int beforeMultLimit = limit / 10;

		int number = 0;
	    for ( ; i < length; i++) {
	    	int digit = str.charAt(start + i) - '0';
	        if (digit < 0 || digit > 9) {
	        	throw new NumberFormatException("Malformed number:  " + str.substring(start, end));
	        }
	    	if (number < beforeMultLimit) {
	        	throw new NumberFormatException("Over/under flow:  " + str.substring(start, end));
	    	}
	    	number *= 10;
	    	if (number < limit + digit) {
	        	throw new NumberFormatException("Over/under flow:  " + str.substring(start, end));
	    	}
	    	number -= digit;
	    }

		if (negative) {
			if (i > 1) {
				return number;
			} else {
	        	throw new NumberFormatException("Malformed number:  " + str.substring(start, end));
			}
		} else {
			return -number;
		}
	}

	public static long parseLong(String str, int start, int end) throws NumberFormatException {
	    final int length = end - start;
	    if (length < 1) {
	    	throw new NumberFormatException("Attempt to parse empty string as number");
	    }

		final boolean negative;
		final long limit;
		int i = 0;
	    if (str.charAt(start) == '-') {
	    	negative = true;
	    	limit = Long.MIN_VALUE;
	    	i++;
	    } else {
	    	negative = false;
	    	limit = -Long.MAX_VALUE;
	    }
		final long beforeMultLimit = limit / 10;

		long number = 0;
	    for ( ; i < length; i++) {
	    	int digit = str.charAt(start + i) - '0';
	        if (digit < 0 || digit > 9) {
	        	throw new NumberFormatException("Malformed number:  " + str.substring(start, end));
	        }
	    	if (number < beforeMultLimit) {
	        	throw new NumberFormatException("Over/under flow:  " + str.substring(start, end));
	    	}
	    	number *= 10;
	    	if (number < limit + digit) {
	        	throw new NumberFormatException("Over/under flow:  " + str.substring(start, end));
	    	}
	    	number -= digit;
	    }

		if (negative) {
			if (i > 1) {
				return number;
			} else {
	        	throw new NumberFormatException("Malformed number:  " + str.substring(start, end));
			}
		} else {
			return -number;
		}
	}

}
