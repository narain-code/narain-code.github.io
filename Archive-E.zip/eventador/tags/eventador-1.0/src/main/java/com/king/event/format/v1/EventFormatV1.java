package com.king.event.format.v1;

import com.king.event.Event;
import com.king.event.format.EventFormat;
import com.king.event.format.EventFormatException;
import com.king.event.format.util.FastDateParser;
import com.king.event.format.util.NumberParser;


/**
 * 	New tracking event syntax (roughly expressed in some variant of EBNF)
 *
 * - Builds on proud King tradition of simplicity, efficiency and NIH.
 * - Should we include a host source in the event?
 * - Is the unique-id a number or a identifier or a any string not containing ws?
 * - What should we require from the unique-id?
 *    - Unique in itself
 *    - Unique together with?
 *    - timestamp, event-type (probably hard to implement)?
 *    - timestamp, event-type, flavour-id (probably hard to implement)?
 *    - all the content in the event?
 *    - timestamp, event-type, flavour-id and host-id if we choose to include it?
 *
 *
 * event = header, body;
 *
 * header = version, header-delimiter,
 *          timestamp, header-delimiter,
 *          flavour-id, header-delimiter,
 *          event-type, header-delimiter,
 *          unique-id, header-delimiter;
 *
 * version = digit, {digit};
 *
 * header-delimiter = "\u001f"; ? ASCII unit separator character?
 *
 * timestamp = ? ISO... i.e. YYYYMMDD'T'HHmmss.SSS'Z' ?;
 *
 * flavour-id = ? natural number ?;
 *
 * event-type = ? natural number ?;
 *
 * unique-id = ? ?;
 *
 * body = { tab, event-field };
 *
 * tab = "\t" ? single tab character, UTF code point U+0009 ?;
 *
 * event-field = ? any sequence of UTF-8 characters except tab (U+0009) ?;
 */
public class EventFormatV1 implements EventFormat {

	private static final int EVENT_VERSION = 1;
	private static final char HEADER_DELIMITER = '\u001f';
	private static final char FIELD_DELIMITER = '\t';
	private static final FastDateParser dateParser = new FastDateParser();


	@Override
	public Event parse(String event) throws EventFormatException {

		int currentHeaderStart = 0;

		// Version
		int currentHeaderEnd = event.indexOf(HEADER_DELIMITER, currentHeaderStart);
		int version = NumberParser.parseInt(event, currentHeaderStart, currentHeaderEnd);
		if (version != EVENT_VERSION) {
			throw new EventFormatException("Unsupported event version " + version + " in event " + event);
		}
		currentHeaderStart = currentHeaderEnd+1;

		// Date
		currentHeaderEnd = event.indexOf(HEADER_DELIMITER, currentHeaderStart);
		long timeStamp = dateParser.parse(event, currentHeaderStart, currentHeaderEnd);
		currentHeaderStart = currentHeaderEnd+1;

		// Flavour id
		try {
			currentHeaderEnd = event.indexOf(HEADER_DELIMITER, currentHeaderStart);
			int flavourId = NumberParser.parseInt(event, currentHeaderStart, currentHeaderEnd);
			currentHeaderStart = currentHeaderEnd+1;

			// Event type
			currentHeaderEnd = event.indexOf(HEADER_DELIMITER, currentHeaderStart);
			long eventTypeId = NumberParser.parseLong(event, currentHeaderStart, currentHeaderEnd);
			currentHeaderStart = currentHeaderEnd+1;

			// Unique id
			int uniqeFieldStart = currentHeaderStart;
			int uniqeFieldEnd = event.indexOf(HEADER_DELIMITER, uniqeFieldStart);
			if (uniqeFieldEnd == -1) {
				throw new EventFormatException("Malformed event, missing header delimiter in event: " + event);
			}
			currentHeaderStart = uniqeFieldEnd+1;

			// Find first field
			int fieldStartIndex = event.indexOf(FIELD_DELIMITER, currentHeaderStart);

			return new EventV1(event, timeStamp, flavourId, eventTypeId, uniqeFieldStart, uniqeFieldEnd, fieldStartIndex);
		}
		catch (NumberFormatException e) {
			throw new EventFormatException(event, e);
		}
	}

	@Override
	public String format(Event event) {
		StringBuilder builder = new StringBuilder(100);

		builder.append('1').append(HEADER_DELIMITER);

		dateParser.format(event.getTimeStamp(), builder);
		builder.append(HEADER_DELIMITER);
		builder.append(event.getFlavourId()).append(HEADER_DELIMITER);
		builder.append(event.getEventType()).append(HEADER_DELIMITER);
		builder.append(event.getUniqueId()).append(HEADER_DELIMITER);

		for (String field : event.fields()) {
			builder.append(FIELD_DELIMITER).append(field);
		}

		return builder.toString();
	}

}
