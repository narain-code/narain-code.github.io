package com.king.event;

/**
 * This is the magic integration with event fields from king_constants, don't be judgemental.
 * 
 * Now, this is magic and mandates an explanation.
 * The dimensions of the int array determines the type of the 
 * field in the event and the first number deep in the array is the 
 * event id and the second number is the position of the parameter.
 * The reason to have it this way is for it to look good when 
 * picking it up and not have to share anything but this contract with the 
 * decoder. Don't create new implementations relying on this without
 * serious discussion!
 * int[] means int
 * int[][] means long
 * int[][][] means String
 * int[][][][] means double
 * long[] means Integer
 * long[][] means Long
 * long[][][] <reserved>
 * long[][][][] means Double
 * Enums should not be in the event type definition in the first place!
 */
public abstract class TypedEventFieldAccessor implements Event {

	@Override
	public int get(int[] intIndex) {
		checkEventType(intIndex[0]);
		return getInt(intIndex[1]);
	}

	@Override
	public long get(int[][] longIndex) {
		checkEventType(longIndex[0][0]);
		return getLong(longIndex[0][1]);
	}

	@Override
	public String get(int[][][] stringIndex) {
		checkEventType(stringIndex[0][0][0]);
		return getString(stringIndex[0][0][1]);
	}

	@Override
	public double get(int[][][][] doubleIndex) {
		checkEventType(doubleIndex[0][0][0][0]);
		return getDouble(doubleIndex[0][0][0][1]);
	}

	@Override
	public Integer get(long[] intIndex) {
		checkEventType(intIndex[0]);
		String str = getString((int)intIndex[1]);
		if (str.equals("")) {
			return null;
		}
		return Integer.parseInt(str);
	}

	@Override
	public Long get(long[][] longIndex) {
		checkEventType(longIndex[0][0]);
		String str = getString((int)longIndex[0][1]);
		if (str.equals("")) {
			return null;
		}
		return Long.parseLong(str);
	}

	@Override
	public Double get(long[][][][] doubleIndex) {
		checkEventType(doubleIndex[0][0][0][0]);
		String str = getString((int)doubleIndex[0][0][0][1]);
		if (str.equals("")) {
			return null;
		}
		return Double.parseDouble(str);
	}

	private void checkEventType(long specEventType) {
		if (specEventType != getEventType()) {
			throw new IllegalArgumentException("Event type mismatch in field specifier, was " + specEventType + ", actual event type " + getEventType());
		}
	}

}
