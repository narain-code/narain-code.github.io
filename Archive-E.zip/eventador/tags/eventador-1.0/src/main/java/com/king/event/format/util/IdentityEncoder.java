package com.king.event.format.util;

import com.king.event.format.Encoder;


public class IdentityEncoder implements Encoder {

	@Override
	public String encode(String s) {
		return s;
	}

}
