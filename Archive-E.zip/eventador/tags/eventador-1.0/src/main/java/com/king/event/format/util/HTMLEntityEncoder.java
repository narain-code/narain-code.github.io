package com.king.event.format.util;

import com.king.event.format.Encoder;


public class HTMLEntityEncoder implements Encoder {

	private static boolean[] loggableCharacters = new boolean[128];
	static {
		for (int i = 0; i < loggableCharacters.length; i++) {
			loggableCharacters[i] = !Character.isISOControl(i) && i != '&';
		}
	}

	@Override
	public String encode(String s) {
		StringBuilder sb = new StringBuilder(s.length() + 5); // Pray good sir, is there only one character in need of escaping? Yes dear!
		boolean escapedSomething = false;
		
		for (int index = 0; index < s.length(); ) {
			int codePoint = s.codePointAt(index);
			index += Character.charCount(codePoint);
			if (!needsEscaping(codePoint)) {
				sb.appendCodePoint(codePoint);
			} else {
				sb.append("&#x").append(Integer.toHexString(codePoint)).append(';');
				escapedSomething = true;
			}
		}

		if (escapedSomething) {
			return sb.toString();
		}
		else {
			return s;
		}
	}

	public boolean needsEscaping(String s) {
		for (int index = 0; index < s.length(); ) {
			int codePoint = s.codePointAt(index);
			index += Character.charCount(codePoint);
			if (needsEscaping(codePoint)) {
				return true;
			}
		}
		return false;
	}

	private boolean needsEscaping(int codePoint) {
		return !(codePoint >= 0 && codePoint < loggableCharacters.length && loggableCharacters[codePoint]);
	}

}
