package com.king.event.format.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.TimeZone;

import org.junit.Before;
import org.junit.Test;
import org.junit.Ignore;
import static org.junit.Assert.*;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import com.king.event.format.EventFormatException;

public class FastDateParserTest {

	private DateFormat dateFormat;

    private final TimeZone zoneSTHLM = TimeZone.getTimeZone("Europe/Stockholm");

	@Before
	public void setup() {
		dateFormat = new SimpleDateFormat("yyyyMMdd'T'HHmmss'.'SSSZ");
        dateFormat.setTimeZone(zoneSTHLM);
	}

	@Test
	@Ignore
	public void performanceTestFormat() throws EventFormatException, ParseException {
		Random rnd = new Random(768654);
		FastDateParser parser = new FastDateParser();
		long lowerBound = dateFormat.parse("00000102T000000.000+0000").getTime();
		long upperBound = dateFormat.parse("99991231T235959.999+0000").getTime();

		StringBuilder buffer = new StringBuilder();

		// Warm up
		for (int i=0; i < 500000; i++) {
			long millis = lowerBound + (long)(rnd.nextDouble()*(upperBound-lowerBound));
			buffer.setLength(0);
			parser.format(millis, buffer);
			buffer.append(parser.format(millis));
		}

		// Test
		System.out.println("Measuring...");
		long start = System.currentTimeMillis();

		for (int i=0; i < 10000000; i++) {
			long millis = lowerBound + (long)(rnd.nextDouble()*(upperBound-lowerBound));
			buffer.setLength(0);
			parser.format(millis, buffer);
		}

		long end = System.currentTimeMillis();
		System.out.println("Final date: " + buffer.toString());
		System.out.println("Time: " + (end-start));
	}

	@Test
	@Ignore
	public void performanceTestParse() throws EventFormatException {
		FastDateParser parser = new FastDateParser();
		String[] dates = {
				"19700101T000000.000+0200",
				"19700101T000000.999+0200",
				"20010101T173918.555+0200",
				"24010101T173918.555+0200",
				"24130422T173918.555+0200",
				"15630801T010000.000+0000",
				"20120229T010000.000+0000",
				"20120229T010000.000+0100",
				"99990227T010000.000+0000",
				"00010227T010000.345+0000",
				"65630323T061920.142+0345",
		};

		long result = 0;

		// Warmup
		for (int i=0; i < 100000; i++) {
			for (String dateStr : dates) {
				long millis = parser.parse(dateStr, 0, dateStr.length());
				// long millis = dateFormat.parseDateTime(dateStr).getMillis();
				result += millis;
			}
		}

		// Test
		System.out.println("Measuring...");
		long start = System.currentTimeMillis();

		for (int i=0; i < 10000000; i++) {
			for (String dateStr : dates) {
				// long millis = i;
				long millis = parser.parse(dateStr, 0, dateStr.length());
				// long millis = dateFormat.parseDateTime(dateStr).getMillis();
				result += millis;
			}
		}

		long end = System.currentTimeMillis();
		System.out.println("Time: " + (end-start));

		System.out.println("Result: " + result);
	}

	@Test
	public void testCorrect() throws EventFormatException, ParseException {
		// Given
		FastDateParser parser = new FastDateParser();
		String[] dates = {
				"19700101T000000.000+0100",
				"19700101T000000.999+0200",
				"20010101T173918.555+0200",
				"24010101T173918.555+0200",
				"24130422T173918.555+0200",
				// "15821014T010000.000+0000", // TODO fails
				"15821015T010000.000+0000", // works
				"20120229T010000.000+0000",
				"99990227T010000.000+0000",
				//"00010227T010000.345+0000", // TODO fails
				"65630323T061920.142+0345",
		};

		// Then
		for (String dateStr : dates) {
			long millis = parser.parse(dateStr, 0, dateStr.length());

			// verify
			long javaMillis = dateFormat.parse(dateStr).getTime();
			assertEquals("delta: " + (javaMillis-millis) + "java: " + dateFormat.format(javaMillis) + " fast: " + parser.format(millis), javaMillis, millis);
		}
	}

	@Test
	public void testFormatMillis() {
		// Given
		FastDateParser parser = new FastDateParser();

		// When
		String dateStr = parser.format(99);

		// Then
		assertTrue(dateStr.contains(".099+"));
	}

	@Test
	public void testCorrectOldShortFormat() throws EventFormatException {
		// Given
		DateTimeFormatter shortDateFormat = DateTimeFormat.forPattern("yyyyMMdd'T'HHmmss'.'SSS").withZone(DateTimeZone.forID("Europe/Stockholm"));
		FastDateParser parser = new FastDateParser();
		String[] dates = {
				"19700101T000000.000",
				"19700101T000000.999",
				"20010101T173918.555",
				"24010101T173918.555",
				"24130422T173918.555",
				"20120229T010000.000",
				"99990227T010000.000",
				"65630323T061920.142",
		};

		// Then
		for (String dateStr : dates) {
			long millis = parser.parse(dateStr, 0, dateStr.length());

			// verify
			long jodaMillis = shortDateFormat.parseDateTime(dateStr).getMillis();
			assertEquals("delta: " + (jodaMillis-millis) + ": " + dateStr, jodaMillis, millis);
		}
	}

	@Test
	public void testFormatRandomDates() throws EventFormatException, ParseException {
		Random rnd = new Random(680826);
		long lowerBound = dateFormat.parse("00010101T000000.000+0000").getTime();
		long upperBound = dateFormat.parse("99991231T235959.999+0000").getTime();
		long delta = upperBound - lowerBound;
		FastDateParser parser = new FastDateParser();

		for (int i=0; i < 100000; i++) {
			long pointInTime = (rnd.nextLong() % delta) + lowerBound;
			String fast = parser.format(pointInTime);
			String java = dateFormat.format(pointInTime);
			assertEquals(java, fast);
		}
	}

	@Test
	public void testParseRandomDates() throws EventFormatException, ParseException {
		int[] tzHourOffsets = {-12, -11, -10, -9, -8, -7, -6, -5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14};
		int[] tzMinuteOffsets = {0, 30, 45};
		Random rnd = new Random(768654);
		FastDateParser parser = new FastDateParser();

		long lowerBound = dateFormat.parse("00000102T000000.000+0000").getTime();
		long upperBound = dateFormat.parse("99991231T235959.999+0000").getTime();

		for (int i=0; i < 100000; i++) {
			long millis = lowerBound + (long)(rnd.nextDouble()*(upperBound-lowerBound));

			DateTimeZone zone = DateTimeZone.forOffsetHoursMinutes(tzHourOffsets[rnd.nextInt(tzHourOffsets.length)], tzMinuteOffsets[rnd.nextInt(tzMinuteOffsets.length)]);
			DateTime date = new DateTime(millis, zone);

			String dateStr = dateFormat.format(new Date(date.getHourOfDay()));

			long fastMillis = parser.parse(dateStr, 0, dateStr.length());
			long jodaMillis = dateFormat.parse(dateStr).getTime();

			// verify
			assertEquals("delta: " + (jodaMillis-fastMillis) + " for date: " + dateStr, jodaMillis, fastMillis);
		}
	}


	@Test
	public void testFormatValidationFails() {
		// Given
		FastDateParser parser = new FastDateParser();
		String[] failDates = {
				"20130422T173918.555+020",    // Too short
				"20130422T173918.555x0200",   // wrong tz sign
				"20130422x173918.555+0200",   // wrong T separator
				"20130422T173918x555+0200",   // wrong . separator

				// The rest is checks for digits in all positions
				"x0130422T173918.555+0200",
				"2x130422T173918.555+0200",
				"20x30422T173918.555+0200",
				"201x0422T173918.555+0200",
				"2013x422T173918.555+0200",
				"20130x22T173918.555+0200",
				"201304x2T173918.555+0200",
				"2013042xT173918.555+0200",
				"20130422Tx73918.555+0200",
				"20130422T1x3918.555+0200",
				"20130422T17x918.555+0200",
				"20130422T173x18.555+0200",
				"20130422T1739x8.555+0200",
				"20130422T17391x.555+0200",
				"20130422T173918.x55+0200",
				"20130422T173918.5x5+0200",
				"20130422T173918.55x+0200",
				"20130422T173918.555+x200",
				"20130422T173918.555+0x00",
				"20130422T173918.555+02x0",
				"20130422T173918.555+020x",

				// Tests validity of date
				"00001301T173918.555+0200",
				"00000001T173918.555+0200",
				"00001200T173918.555+0200",
				"00001232T173918.555+0200",
				
				// Tests validity of time
				"00000101T240000.555+0200",
				"00000101T006000.555+0200",
				"00000100T000060.555+0200",
		};

		// When
		for (String dateStr : failDates) {
			try {
				parser.parse(dateStr, 0, dateStr.length());
				assertTrue("Parse succeeded for illegal date: " + dateStr, false);
			}
			catch (EventFormatException e) {
				// expected
			}
		}

		// Then
		// ... every parse above failed
	}
}
