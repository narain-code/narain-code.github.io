package com.king.event.format.v1;

import java.io.FileWriter;
import java.util.Iterator;

import org.junit.Test;
import static org.junit.Assert.*;

import com.king.event.Event;
import com.king.event.format.EventFormat;
import com.king.event.format.EventFormatException;
import com.king.event.format.original.OriginalEventFormat;
import com.king.event.format.v1.EventFormatV1;

public class EventFormatV1Test {

	String[] events = {
			"1*20130324T143820.315+0200*25*12002*0*\t1070514986\tlevel_start_popup\tplay_button\t",
			"1*20130324T143820.719+0200*25*40002*0*\t1070514986\t31\t1366807100719\t",
			"1*20130324T143820.719+0200*25*40000*0*\t1070514986\t-1\t4\t10211\t",
			"1*20130324T143820.728+0200*25*12000*0*\t1070514986\tGAME_SCREEN\t",
			"1*20130324T143819.587+0200*25*12000*0*\t1019671803\tlevel_start_popup\t",
			"1*20130324T143821.633+0200*25*12002*0*\t1019671803\tlevel_start_popup\tplay_button\t",
			"1*20130324T143822.035+0200*25*40002*0*\t1019671803\t60\t1366807102035\t",
			"1*20130324T143822.036+0200*25*40000*0*\t1019671803\t-1\t4\t10211\t",
			"1*20130324T143822.161+0200*25*12000*0*\t1019671803\tGAME_SCREEN\t",
			"1*20130324T143824.285+0200*25*2005*0*\ta861105313edba81\t177\t1000227834\t",
			"1*20130324T143824.246+0200*25*2005*0*\t4873e49fcf8bc895\t162\t1000227834\t",
			"1*20130324T143824.246+0200*25*2005*0*\t594d4cf4c0e63e78\t179\t1000227834\t",
			"1*20130324T143821.627+0200*25*21*0**\t1000227834\t0\t28\t1366797947\t",
			"1*20130324T143821.628+0200*25*69*0*\t1000227834\t0\t28\t0\t1366807101\tfacebook\tbookmark_apps\t\t\t0\tfb_source=bookmark_apps&#x26;ref=bookmarks&#x26;count=2&#x26;fb_bmpos=5_2\t",
			"1*20130324T143821.631+0200*25*38*0*\t1000227834\t25faa5aa\tWINDOWS_VISTA\tCHROME\t26.0.1410.64\tMozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.64 Safari/537.31\t",
			"1*20130324T143822.205+0200*25*102*0*\t1000227834\t1000518933\t0\t0\tfb\tnotif\tgiveLifeTo\t",
			"1*20130324T143822.206+0200*25*102*0*\t1000227834\t1000298358\t0\t0\tfb\tnotif\tgiveLifeTo\t",
			"1*20130324T143822.402+0200*25*9001*0*\t1000227834\tSE\tm\t\t6\tkent_olsson65@hotmail.com\t\tKent\tsv_SE\t",
			"1*20130324T143822.403+0200*25*9010*0*\t1000227834\tAndroid\tn/a\t",
			"1*20130324T143823.562+0200*25*12000*0*\t1002267294\tlevel_start_popup\t",
			"1*20130324T143823.575+0200*25*40200*0*\t5\t1366807018630\t151\t283\t661\t3105\t525\t166\t86\t33\t21\t19\t",
			"1*20130324T143824.246+0200*25*2005*0*\t9096589305b4aa1d\t163\t1000227834\t",
			"1*20130324T143824.246+0200*25*2005*0*\t3bff9d13c7632721\t164\t1000227834\t",
			"1*20130324T143824.247+0200*25*2005*0*\t53d0c6f8559a67ab\t164\t1000227834\t",
			"1*20130324T143824.247+0200*25*2005*0*\tf6bdaa846cda04b1\t163\t1000227834\t",
			"1*20130324T143820.679+0200*25*12002*0*\t1032286410\tlevel_win_popup\tclose_button\t",
			"1*20130324T143820.808+0200*25*12000*0*\t1032286410\tAPP_SCREEN\t",
			"1*20130324T143824.246+0200*25*2005*0*\t1c08a10d6df636f1\t158\t1000227834\t",
			"1*20130324T143824.247+0200*25*2005*0*\t8b4bcd9a92380f2e\t161\t1000227834\t",
			"1*20130324T143821.181+0200*25*12000*0*\t1137917214\tlevel_start_popup\t",
			"1*20130324T143822.415+0200*25*12002*0*\t1157493448\tlevel_win_popup\tclose_button\t",
			"1*20130324T143822.495+0200*25*12002*0*\t1137917214\tlevel_start_popup\tplay_button\t",
			"1*20130324T143822.502+0200*25*12000*0*\t1157493448\tAPP_SCREEN\t",
			"1*20130324T144403.011+0200*16*69*0*\t1024780338\t0\t12\t0\t1366807443\tfacebook\tbookmark_apps\t\t\t0\t&#x26;fb_source=bookmark_apps&#x26;ref=bookmarks&#x26;count=0&#x26;fb_bmpos=2_0\t",
			"1*20130324T144403.014+0200*16*38*0*\t1024780338\td9472dc8\tWINDOWS_7\tCHROME\t25.0.1364.45\tMozilla/5.0 (Windows NT 6.1) AppleWebKit/537.22 (KHTML, like Gecko) Chrome/25.0.1364.45 Safari/537.22\t",
			"1*20130324T144403.029+0200*16*1101*0*\t1045742560\t2004\t0\t5121\t0\t1\t6:4\t",
			"1*20130324T144403.064+0200*16*12000*0*\t1013734883\tAPP_SCREEN\t",
			"1*20130324T144403.068+0200*16*1101*0*\t1003050074\t2004\t0\t5121\t0\t2\t4:6\t",
			"1*20130324T144403.079+0200*16*21*0*\t1216216702\t0\t64\t1366804134",
	};


	private String fix(String event) {
		return event.replace('*', '\037');
	}

	@Test
	public void testParseFormatParse() throws Exception {
		EventFormat format = new EventFormatV1();
		FileWriter out = new FileWriter("events.log", false);

		for (String eventStr : events) {
			Event event = format.parse(fix(eventStr));
			// System.out.println(format.format(event));
			out.append(format.format(event));
			out.append("\n");
			Event eventCopy = format.parse(format.format(event));

			Iterator<String> it1 = event.fields().iterator();
			Iterator<String> it2 = eventCopy.fields().iterator();

			while (it1.hasNext() || it2.hasNext()) {
				assertEquals(it1.next(), it2.next());
			}
		}
		
		out.close();
	}

	@Test(expected=EventFormatException.class)
	public void testBogusDate() throws Exception {
		new EventFormatV1().parse(fix("1*20131324T143824.247+0200*25*2005*0*\t53d0c6f8559a67ab\t164\t1000227834"));
	}

	@Test(expected=EventFormatException.class)
	public void testBogusFlavour() throws Exception {
		new EventFormatV1().parse(fix("1*20131224T143824.247+0200*2x5*2005*0*\t53d0c6f8559a67ab\t164\t1000227834"));
	}

	@Test(expected=EventFormatException.class)
	public void testBogusEventType() throws Exception {
		new OriginalEventFormat().parse(fix("1*20131224T143824.247+0200*25*2x005*0*\t53d0c6f8559a67ab\t164\t1000227834"));
	}

	@Test
	public void testHeaderAccessors() throws Exception {
		// When
		Event event = new EventFormatV1().parse(fix("1*19700101T000000.000+0000*25*2005*666*\t123\t123456789123\t0.345"));

		// Then
		assertEquals(0, event.getTimeStamp());
		assertEquals(25, event.getFlavourId());
		assertEquals(2005, event.getEventType());
		assertEquals(666, event.getUniqueId());
	}

	@Test
	public void testFieldAccessors() throws Exception {
		// When
		Event event = new EventFormatV1().parse(fix("1*20131224T143824.247+0200*25*2005*0*\t123\t123456789123\t0.345"));

		// Then
		assertEquals("123", event.getString(0));
		assertEquals(123, event.getInt(0));
		assertEquals(123456789123L, event.getLong(1));
		assertEquals(0.345, event.getDouble(2), 0.0);
	}

	@Test
	public void testEmptyEvent() throws Exception {
		// Given
		Event event = new EventFormatV1().parse(fix("1*19700101T000000.000+0000*25*2005*666*"));

		// Then
		assertEquals(666, event.getUniqueId());
	}

	@Test(expected=NumberFormatException.class)
	public void testMissingUniqueId() throws Exception {
		// When
		Event event = new EventFormatV1().parse(fix("1*19700101T000000.000+0000*25*2005**\t123\t123456789123\t0.345"));

		// Then
		assertEquals(666, event.getUniqueId());
	}

	@Test(expected=IndexOutOfBoundsException.class)
	public void testEmptyEventFieldAccess() throws Exception {
		// Given
		Event event = new EventFormatV1().parse(fix("1*19700101T000000.000+0000*25*2005*666*"));

		// Then
		event.getString(0);
	}

	@Test(expected=IndexOutOfBoundsException.class)
	public void testEmptyEventFieldAccess2() throws Exception {
		// Given
		Event event = new EventFormatV1().parse(fix("1*19700101T000000.000+0000*25*2005*666*"));

		// Then
		event.getString(23);
	}

	@Test
	public void testFieldIterator() throws Exception {
		// When
		Event event = new EventFormatV1().parse(fix("1*20131224T143824.247+0200*25*2005*0*\t\tA\tB\t"));

		// Then
		Iterator<String> it = event.fields().iterator();
		assertEquals("", it.next());
		assertTrue(it.hasNext());
		assertEquals("A", it.next());
		assertTrue(it.hasNext());
		assertEquals("B", it.next());
		assertTrue(it.hasNext());
		assertEquals("", it.next());
		assertFalse(it.hasNext());
	}

	@Test
	public void testEmptyFieldIterator() throws Exception {
		// When
		Event event = new EventFormatV1().parse(fix("1*20131224T143824.247+0200*25*2005*0*"));

		// Then
		Iterator<String> it = event.fields().iterator();
		assertFalse(it.hasNext());
	}

	// @Test
	public void performanceTest() throws Exception {
		EventFormat format = new EventFormatV1();

		// Warm up
		long result = 0;
		for (int i=0; i<100000; i++) {
			for (String eventStr : events) {
				Event event = format.parse(eventStr);
				result += event.getTimeStamp();
			}
		}
		// Test
		System.out.println("Measuring...");
		long start = System.currentTimeMillis();

		long eventCount = 0;
		for (int i=0 ; i<2000001; i++) {
			for (String eventStr : events) {
				Event event = format.parse(eventStr);
				result += event.getTimeStamp();
				eventCount++;
			}
		}

		long end = System.currentTimeMillis();
		System.out.println("Time: " + (end-start));
		System.out.println("Events: " + eventCount);
		System.out.println("" + eventCount/(end-start)*1000 + " events/s");
		System.out.println("Dummy (please ignore): " + result);
	}

}
