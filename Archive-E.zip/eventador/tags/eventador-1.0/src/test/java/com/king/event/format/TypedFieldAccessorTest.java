package com.king.event.format;

import org.junit.Test;
import static org.junit.Assert.*;

import static com.king.constants.EventField.*;
import com.king.event.Event;
import com.king.event.format.A.EventFormatA;
import com.king.event.format.v1.EventFormatV1;

public class TypedFieldAccessorTest {

	@Test
	public void testABunchOfGetters() throws EventFormatException {
		// Given
		Event event = new EventFormatA().parse("A\t20130324T144403.011+0200\t16\t69\t0\t666\t0\t777\t0\t999\tfacebook\tbookmark_apps\t\t\t0\t&#x26;fb_source=bookmark_apps&#x26;ref=bookmarks&#x26;count=0&#x26;fb_bmpos=2_0\t");

		// When
		long userId = event.get(SignInTracking3.coreUserId);
		Long lastSignIn = event.get(SignInTracking3.lastSignIn);
		int signIns = event.get(SignInTracking3.numSignIns);
		String type = event.get(SignInTracking3.type);

		// Then
		assertEquals(userId, 666);
		assertEquals(lastSignIn.longValue(), 999L);
		assertEquals(signIns, 777);
		assertEquals(type, "facebook");
	}

	@Test
	public void testABunchOfGettersX() throws EventFormatException {
		// Given
		Event event = new EventFormatA().parse("A\t20130324T143820.315+0200\t25\t12002\t0\t666\tlevel_start_popup\tplay_button\t");

		// When
		long userId = event.get(GuiLeft.coreUserId);
		String elementId = event.get(GuiLeft.guiElementId);

		// Then
		assertEquals(userId, 666);
		assertEquals(elementId, "play_button");
	}

	@Test
	public void testNullBoxedLong() throws EventFormatException {
		// Given
		Event event = new EventFormatA().parse("A\t20130324T143821.628+0200\t25\t69\t0\t1000227834\t0\t28\t0\t\tfacebook\tbookmark_apps\t\t\t0\tfb_source=bookmark_apps&#x26;ref=bookmarks&#x26;count=2&#x26;fb_bmpos=5_2\t");

		// When
		Long lastSignIn = event.get(SignInTracking3.lastSignIn);

		// Then
		assertEquals(lastSignIn, null);
	}

	@Test(expected=NumberFormatException.class)
	public void testEmptyLong() throws EventFormatException {
		// Given
		Event event = new EventFormatV1().parse("1*20130324T143820.315+0200*25*12002*0*\t\tlevel_start_popup\tplay_button\t");

		// When (... should throw)
		event.get(GuiLeft.coreUserId);
	}

	@Test(expected=NumberFormatException.class)
	public void testEmptyInteger() throws EventFormatException {
		// Given
		Event event = new EventFormatV1().parse("1*20130324T143820.719+0200*25*40002*0*\t1070514986\t\t1366807100719\t");

		// When (... should throw)
		event.get(JuegoGameStart.levelId);
	}

	@Test(expected=IllegalArgumentException.class)
	public void testWrongEventType() throws EventFormatException {
		// Given
		Event event = new EventFormatV1().parse("1*20130324T143824.246+0200*25*2005*0*\t3bff9d13c7632721\t164\t1000227834\t");

		// When (... should throw)
		event.get(ItemTransaction2.coreUserId);
	}
}
