package com.king.event.format.util;

import org.junit.Before;
import org.junit.Test;

import com.king.event.format.util.HTMLEntityDecoder;
import com.king.event.format.util.HTMLEntityEncoder;

import static org.junit.Assert.*;

public class HTMLEntityEncoderTest {

	private HTMLEntityEncoder htmlEntityEncoder;

	@Before
	public void setup() {
		htmlEntityEncoder = new HTMLEntityEncoder();
	}

    @Test
    public void testNoNeedToEscapeAscii() {
    	// Test all printable ASCII characters except amp and DEL
    	for (int i=32; i < '&'; i++) {
    		assertFalse(htmlEntityEncoder.needsEscaping(new String(new char[] { (char)i })));
    	}
    	for (int i='&'+1; i < 125; i++) {
    		assertFalse(htmlEntityEncoder.needsEscaping(new String(new char[] { (char)i })));
    	}
    }

    @Test
    public void testNeedEscapeAscii() {
    	// All printable ASCII characters except &
    	for (int i=0; i < 32; i++) {
    		assertTrue(htmlEntityEncoder.needsEscaping(new String(new char[] { (char)i })));
    	}

    	// ... and amp
		assertTrue(htmlEntityEncoder.needsEscaping(new String(new char[] { '&' })));

    	// ... and finally delete
		assertTrue(htmlEntityEncoder.needsEscaping(new String(new char[] { (char)127 })));
    }

    @Test
    public void testNeedEscapeUnicode() {
    	// All unicode code points > US-ASCII
    	for (int i=128; i < 0x10FFFF; i++) {
    		assertTrue(htmlEntityEncoder.needsEscaping(new String(Character.toChars(i))));
    	}
    }

    @Test
    public void testEncodeDecode() {
    	HTMLEntityDecoder htmlEntityDecoder = new HTMLEntityDecoder();

    	for (int i=0; i < 0x10000; i++) {
    		String str = "abcd" + new String(Character.toChars(i)) + "efgh-" + i;
			assertEquals(str, htmlEntityDecoder.decode(htmlEntityEncoder.encode(str)));
    	}
    }

}
