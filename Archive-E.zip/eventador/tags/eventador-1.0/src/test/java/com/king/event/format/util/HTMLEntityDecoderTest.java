package com.king.event.format.util;

import org.junit.Before;
import org.junit.Test;

import com.king.event.format.util.HTMLEntityDecoder;

import static org.junit.Assert.*;

public class HTMLEntityDecoderTest {

	private HTMLEntityDecoder htmlEntityDecoder;

	@Before
	public void setup() {
		htmlEntityDecoder = new HTMLEntityDecoder();
	}

    @Test
    public void testDecodeHex() {
    	for (int i=0; i < 0x10000; i++) {
    		String escapedString = "abcd" + "&#x" + Integer.toHexString(i) + ";" + "efgh-" + i;
    		String validateString = "abcd" + new String(Character.toChars(i)) + "efgh-" + i;
        	assertEquals(validateString, htmlEntityDecoder.decode(escapedString));
    	}
    }

    @Test
    public void testDecodeHexCapitalX() {
    	assertEquals("\u2ea0", htmlEntityDecoder.decode("&#X2EA0;"));
    }
    
    @Test
    public void testDecodeDec() {
    	for (int i=0; i < 0x10000; i++) {
    		String escapedString = "abcd" + "&#" + Integer.toString(i) + ";" + "efgh";
    		String validateString = "abcd" + new String(Character.toChars(i)) + "efgh";
        	assertEquals(validateString, htmlEntityDecoder.decode(escapedString));
    	}
    }

    @Test
    public void testDecodeMultipleChars() {
    	assertEquals("\u2D95\u2DAB", htmlEntityDecoder.decode("&#x2D95;&#x2DAB;"));
    }

    @Test
    public void testDecodeNamedEntities() {
    	assertEquals("&\u00A9", htmlEntityDecoder.decode("&amp;&copy;"));
    	assertEquals("\u00DD", htmlEntityDecoder.decode("&Yacute;"));
    }

    @Test
    public void testDegradeGracefully() {
    	String[] illegals = {
    			"&",
    			"&#",
    			"&#;",
    			"&#x",
    			"&#x;",
    			"&foo;",
    			"&frotz",
    			"&#x1",
    			"&#x112dde",
    			"&#x112r3;",
    			"&#112r3;",
    	};

    	for (String illegal : illegals) {
    		assertEquals(illegal, htmlEntityDecoder.decode(illegal));
    	}
    }

}
