package com.king.event.format.util;

import org.junit.Test;

import com.king.event.format.util.NumberParser;

import static org.junit.Assert.*;

public class NumberParserTest {

	@Test
	public void testInteger() throws Exception {
		int[] numbers = {
				Integer.MAX_VALUE,
				Integer.MIN_VALUE,
				-1,
				-0,
				0,
				1,
				1234567,
				-1234567,
		};

		for (int number : numbers) {
			String str = Integer.toString(number);
			int x = NumberParser.parseInt(str, 0, str.length());
			assertEquals(number, x);
		}
	}


	@Test
	public void testFailedInteger() throws Exception {
		String[] numbers = {
				"-",
				"-0z",
				"23x213",
				Long.toString((long)Integer.MAX_VALUE+1),
				Long.toString((long)Integer.MIN_VALUE-1),
		};

		for (String number : numbers) {
			try {
				int x = NumberParser.parseInt(number, 0, number.length());
				assertTrue(number + " parsed to " + x, false);
			} catch (NumberFormatException e) {
				// expected
			}
		}
	}

	@Test
	public void testLong() throws Exception {
		long[] numbers = {
				Integer.MIN_VALUE,
				Integer.MAX_VALUE,
				-1,
				-0,
				0,
				1,
				12345672134L,
				-12345672343L,
		};

		for (long number : numbers) {
			String str = Long.toString(number);
			long x = NumberParser.parseLong(str, 0, str.length());
			assertEquals(number, x);
		}
	}


	@Test
	public void testFailedLong() throws Exception {
		String[] numbers = {
				"-",
				"-0z",
				"23x213",
				Long.toString(Integer.MAX_VALUE) + "1",
				Long.toString(Integer.MIN_VALUE) + "1",
		};

		for (String number : numbers) {
			try {
				int x = NumberParser.parseInt(number, 0, number.length());
				assertTrue(number + " parsed to " + x, false);
			} catch (NumberFormatException e) {
				// expected
			}
		}
	}

}
