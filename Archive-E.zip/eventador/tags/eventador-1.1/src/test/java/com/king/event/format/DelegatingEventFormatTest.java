package com.king.event.format;

import static org.junit.Assert.*;

import org.junit.Test;

import com.king.event.Event;
import com.king.event.format.A.EventFormatA;

public class DelegatingEventFormatTest {

	/*
	"20140505T133335.199+0200\t80017\t9020\t3836886542\tconversion_offer_mobile\t1\t1\t"
	"20140505T133335.200+0200\t80017\t10011\t\tMOID5f99ebe41265c822d8bd8552cfca2019\t1399289610\t1201\t3\t29940\t3\t0\t100\t1399289509\t40\t"
	"20140505T133335.201+0200\t10017\t70000\t1158136186\tIDFV9765547bac6a83dbfeed1df8dfedc377\t1399289611\t11\t"
	"20140505T133335.201+0200\t80017\t9020\t3836886542\trating_popup_mobile\t1\t2\t"
	"20140505T133335.202+0200\t80017\t9020\t3836886542\tpush_notification_mobile\t5\t1\t"
	"20140505T133335.203+0200\t80017\t9020\t3836886542\tccsm_egp_facelift\t1\t1\t"
	"20140505T133335.204+0200\t80017\t1316\t1934582528\tMOIDdb1541888c38e1858f94ee57187224a5\t1399289610\t\tfalse\ta57dae5d419edb12\tsamsung\tGT-S7562\tos_version_android_15\tARMv7 Processor rev 1 (v7l)\t800\t480\t239.059\t239.059\t"
	"20140505T133335.205+0200\t80017\t9020\t3836886542\tccsm_load_time\t0\t0\t"
	"20140505T133335.206+0200\t60017\t9030\t3675496993\tMOIDb12f7f6533828b97cad32f67f125bd7c\tMobilePromo\t4\t1\t"
	"20140505T133335.206+0200\t80017\t9020\t3836886542\tccsx_moonstruck_booster\t0\t1\t"
*/

	@Test
	public void testParseOriginal() throws EventFormatException {
		// Given
		EventFormat format = new DelegatingEventFormat();

		// When
		Event event = format.parse("20140505T133335.204+0200\t80017\t1316\t1934582528\tMOIDdb1541888c38e1858f94ee57187224a5\t1399289610\t\tfalse\ta57dae5d419edb12\tsamsung\tGT-S7562\tos_version_android_15\tARMv7 Processor rev 1 (v7l)\t800\t480\t239.059\t239.059\t");

		// Then
		assertEquals(1316, event.getEventType());
		assertEquals(480, event.getLong(11));
		assertEquals(239.059, event.getDouble(13), 0.0);
		assertEquals(239.059, event.getDouble(13), 0.0);
	}

	@Test
	public void testParseA() throws EventFormatException {
		// Given
		EventFormat format = new DelegatingEventFormat();

		// When
		Event event = format.parse("A\t20131224T143824.247+0200\t25\t2005\t0\tfbweb213\t123\t123456789123\t0.345");

		// Then
        assertEquals("123", event.getString(0));
        assertEquals(123, event.getInt(0));
        assertEquals(123456789123L, event.getLong(1));
        assertEquals(0.345, event.getDouble(2), 0.0);
	}

	@Test
	public void testConvertToA() throws EventFormatException {
		// Given
		EventFormat format = new DelegatingEventFormat();

		// When
		Event event = format.parse("20140505T133335.204+0200\t80017\t1316\t1934582528\tMOIDdb1541888c38e1858f94ee57187224a5\t1399289610\t\tfalse\ta57dae5d419edb12\tsamsung\tGT-S7562\tos_version_android_15\tARMv7 Processor rev 1 (v7l)\t800\t480\t239.059\t239.059\t");
		String eventStr = format.format(event);
        Event event2 = new EventFormatA().parse(eventStr);
		
		// Then
		assertEquals(1316, event2.getEventType());
		assertEquals(480, event2.getLong(11));
		assertEquals(239.059, event2.getDouble(13), 0.0);
		assertEquals(239.059, event2.getDouble(13), 0.0);
	}

}
