package com.king.event;

public interface Event {

	/**
	 * Time of event creation, milliseconds since epoch (1970-01-01 00:00:00 GMT)
	 */
	long getTimeStamp();

	/**
	 * Flavour id of event
	 */
	int getFlavourId();

	/**
	 * Event type of event
	 */
	long getEventType();

	/**
	 * This id is required *together* with the timestamp to render this event globally unique.
	 */
	long getUniqueId();

	/**
	 * The hostname of the server that produced the event.
	 */
	String getHostname();

	/**
	 * Use to iterate over all fields of the event (potentially very efficient).
	 * <br/>
	 * NOTE: Implementations of this method are not required to support concurrent iterators.
	 */
	Iterable<String> fields();

	/**
	 * Get an indexed fields as a String. The field will not be decoded so any HTML entity escape
	 * sequences will still be present in the fields.
	 */
	String getString(int index);

	/**
	 * Get an indexed fields as an int.
	 */
	int getInt(int index);

	/**
	 * Get an indexed fields as a long.
	 */
	long getLong(int index);

	/**
	 * Get an indexed fields as a double.
	 */
	double getDouble(int index);
	

	int get(int[] intIndex);

	long get(int[][] longIndex);

	String get(int[][][] stringIndex);

	double get(int[][][][] doubleIndex);

	Integer get(long[] intIndex);

	Long get(long[][] longIndex);

	Double get(long[][][][] doubleIndex);

}
