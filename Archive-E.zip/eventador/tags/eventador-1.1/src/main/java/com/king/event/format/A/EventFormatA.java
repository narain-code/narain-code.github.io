package com.king.event.format.A;

import com.king.event.Event;
import com.king.event.format.Decoder;
import com.king.event.format.Encoder;
import com.king.event.format.EventFormat;
import com.king.event.format.EventFormatException;
import com.king.event.format.util.FastDateParser;
import com.king.event.format.util.HTMLEntityDecoder;
import com.king.event.format.util.HTMLEntityEncoder;
import com.king.event.format.util.NumberParser;

/**
 * 	New tracking event syntax (roughly expressed in some variant of EBNF)
 *
 * - Future proofed with a version field.
 * - Should we include a host source in the event?
 *
 * event = header, body;
 *
 * header = version, tab,
 *          timestamp, tab,
 *          flavour-id, tab,
 *          event-type, tab,
 *          unique-id, tab;
 *
 * version = 'A';
 *
 * timestamp = ? ISO... i.e. YYYYMMDD'T'HHmmss.SSS'Z' ?;
 *
 * flavour-id = ? natural number ?;
 *
 * event-type = ? natural number ?;
 *
 * unique-id = ? non negative integer no larger than 9223372036854775807, represented in decimal form ?;
 *
 * body = { tab, event-field };
 *
 * tab = "\t" ? single tab character, ASCII 0x9 ?;
 *
 * event-field = ? any sequence of printable US-ASCII characters ?;
 */
public class EventFormatA implements EventFormat {

	static final char FIELD_DELIMITER = '\t';
	private static final char EVENT_VERSION = 'A';
	private static final FastDateParser dateParser = new FastDateParser();

	private final Encoder encoder;
	private final Decoder decoder;

	public EventFormatA() {
		this(new HTMLEntityEncoder(), new HTMLEntityDecoder());
	}

	public EventFormatA(Encoder encoder, Decoder decoder) {
		this.encoder = encoder;
		this.decoder = decoder;
	}

	@Override
	public Event parse(String event) throws EventFormatException {

		int currentHeaderStart = 0;

		// Version
		int currentHeaderEnd = event.indexOf(FIELD_DELIMITER, currentHeaderStart);
		char version = event.charAt(currentHeaderStart);
		if (version != EVENT_VERSION) {
			throw new EventFormatException("Unsupported event version " + version + " in event " + event);
		}
		currentHeaderStart = currentHeaderEnd+1;

		// Date
		currentHeaderEnd = event.indexOf(FIELD_DELIMITER, currentHeaderStart);
		long timeStamp = dateParser.parse(event, currentHeaderStart, currentHeaderEnd);
		currentHeaderStart = currentHeaderEnd+1;

		// Flavour id
		try {
			currentHeaderEnd = event.indexOf(FIELD_DELIMITER, currentHeaderStart);
			if (currentHeaderEnd == -1) {
				throw new EventFormatException("Invalid event format: " + event);
			}
			int flavourId = NumberParser.parseInt(event, currentHeaderStart, currentHeaderEnd);
			currentHeaderStart = currentHeaderEnd+1;

			// Event type
			currentHeaderEnd = event.indexOf(FIELD_DELIMITER, currentHeaderStart);
			if (currentHeaderEnd == -1) {
				throw new EventFormatException("Invalid event format: " + event);
			}
			long eventTypeId = NumberParser.parseLong(event, currentHeaderStart, currentHeaderEnd);
			currentHeaderStart = currentHeaderEnd+1;

			// Unique id
			currentHeaderEnd = event.indexOf(FIELD_DELIMITER, currentHeaderStart);
			if (currentHeaderEnd == -1) {
				throw new EventFormatException("Invalid event format: " + event);
			}
			long uniqeEventId = NumberParser.parseLong(event, currentHeaderStart, currentHeaderEnd);
			currentHeaderStart = currentHeaderEnd+1;

			// Hostname
			currentHeaderEnd = event.indexOf(FIELD_DELIMITER, currentHeaderStart);
			if (currentHeaderEnd == -1) {
				currentHeaderEnd = event.length();
			}
			int hostnameStartIndex = currentHeaderStart;
			int hostnameEndIndex = currentHeaderEnd;

			return new EventA(decoder, event, timeStamp, flavourId, eventTypeId, uniqeEventId, hostnameStartIndex, hostnameEndIndex, currentHeaderEnd);
		}
		catch (NumberFormatException e) {
			throw new EventFormatException(event, e);
		}
	}

	@Override
	public String format(Event event) {
		StringBuilder builder = new StringBuilder(100);

		builder.append('A').append(FIELD_DELIMITER);

		dateParser.format(event.getTimeStamp(), builder);
		builder.append(FIELD_DELIMITER);
		builder.append(event.getFlavourId()).append(FIELD_DELIMITER);
		builder.append(event.getEventType()).append(FIELD_DELIMITER);
		builder.append(event.getUniqueId()).append(FIELD_DELIMITER);
		String hostname = event.getHostname();
		if (hostname != null) {
			builder.append(event.getHostname());
		}

		for (String field : event.fields()) {
			builder.append(FIELD_DELIMITER).append(encoder.encode(field));
		}

		return builder.toString();
	}

}
