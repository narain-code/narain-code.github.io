package com.king.event;

public interface Event {

	/**
	 * Time of event creation, milliseconds since epoch (1970-01-01 00:00:00 GMT)
	 */
	long getTimeStamp();

	/**
	 * Flavour id of event
	 */
	int getFlavourId();

	/**
	 * Event type of event
	 */
	long getEventType();

	/**
	 * This id is required *together* with the timestamp to render this event globally unique.
	 */
	long getUniqueId();

	/**
	 * The hostname of the server that produced the event.
	 */
	String getHostname();

	/**
	 * Use to iterate over all fields of the event (potentially very efficient).
	 * <br/>
	 * NOTE: Implementations of this method are not required to support concurrent iterators.
	 */
	Iterable<String> fields();

	/**
	 * Get an indexed fields as a String. The field will not be decoded so any HTML entity escape
	 * sequences will still be present in the fields.
	 */
	String getString(int index);

	/**
	 * Get an indexed fields as an int.
	 */
	int getInt(int index);

	/**
	 * Get an indexed fields as a long.
	 */
	long getLong(int index);

	/**
	 * Get an indexed fields as a double.
	 */
	double getDouble(int index);
	
	/**
	 * Get an indexed fields as a boolean.
	 */
	boolean getBoolean(int index);

	/**
	 * Based on the {@link EventField} get the data
	 * @param intIndex
	 * @return
	 */
	int get(int[] intIndex);
    
	/**
     * Based on the {@link EventField} get the data
     * @param intIndex
     * @return
     */
	long get(int[][] longIndex);
    
	/**
     * Based on the {@link EventField} get the data
     * @param intIndex
     * @return
     */
	String get(int[][][] stringIndex);
    
	/**
     * Based on the {@link EventField} get the data
     * @param intIndex
     * @return
     */
	double get(int[][][][] doubleIndex);
    
	/**
     * Based on the {@link EventField} get the data
     * @param intIndex
     * @return
     */
	boolean get(int[][][][][] booleanIndex);
    
	/**
     * Based on the {@link EventField} get the data
     * @param intIndex
     * @return
     */
	Integer get(long[] intIndex);
    
	/**
     * Based on the {@link EventField} get the data
     * @param intIndex
     * @return
     */
	Long get(long[][] longIndex);
    
	/**
     * Based on the {@link EventField} get the data
     * @param intIndex
     * @return
     */
	Double get(long[][][][] doubleIndex);
    
	/**
     * Based on the {@link EventField} get the data
     * @param intIndex
     * @return
     */
	Boolean get(long[][][][][] booleanIndex);
}
