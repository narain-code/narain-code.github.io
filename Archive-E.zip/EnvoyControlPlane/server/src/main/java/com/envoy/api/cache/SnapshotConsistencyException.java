package com.envoy.api.cache;

public class SnapshotConsistencyException extends Exception {

	public SnapshotConsistencyException(String message) {
	    super(message);
	  }
}
