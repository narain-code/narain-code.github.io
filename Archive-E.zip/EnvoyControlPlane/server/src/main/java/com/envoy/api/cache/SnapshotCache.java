package com.envoy.api.cache;

public interface SnapshotCache<T> extends Cache<T> {

	void setSnapshot(T group, Snapshot snapshot);
}
