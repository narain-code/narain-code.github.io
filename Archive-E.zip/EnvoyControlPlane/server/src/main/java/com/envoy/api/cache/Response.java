package com.envoy.api.cache;

import java.util.Collection;

import com.google.auto.value.AutoValue;
import com.google.protobuf.Message;

import envoy.api.v2.Discovery.DiscoveryRequest;

@AutoValue
public abstract class Response {
	  public static Response create(DiscoveryRequest request, Collection<? extends Message> resources, String version) {
		    return new AutoValue_Response(request, resources, version);
		  }

		  
		  public abstract DiscoveryRequest request();

		  
		  public abstract Collection<? extends Message> resources();

		  
		  public abstract String version();
}
