package com.envoy.api.cache;

import envoy.api.v2.core.Base.Node;

public interface NodeGroup<T> {

	T hash(Node node);
}
