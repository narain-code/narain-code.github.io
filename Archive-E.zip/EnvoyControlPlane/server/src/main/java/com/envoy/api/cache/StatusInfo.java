package com.envoy.api.cache;

import envoy.api.v2.core.Base.Node;

public interface StatusInfo {

	long lastWatchRequestTime();

	Node node();

	int numWatches();

}
