package com.envoy.api.cache;

import envoy.api.v2.Discovery.DiscoveryRequest;

public interface ConfigWatcher {
	
	 Watch createWatch(DiscoveryRequest request);


}
