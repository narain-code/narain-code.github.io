package com.envoy.api.cache;

public interface Cache<T> extends ConfigWatcher {

	StatusInfo statusInfo(T group);
}