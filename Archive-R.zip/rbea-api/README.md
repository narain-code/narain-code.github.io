# RBEA API

Documentation for the user interfaces (aka "How to use RBea") can be found on the [RBea Wiki](https://github.int.midasplayer.com/SPLAT/rbea/wiki)!
