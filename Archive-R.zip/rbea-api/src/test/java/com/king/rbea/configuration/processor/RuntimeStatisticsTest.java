package com.king.rbea.configuration.processor;

import static org.junit.Assert.assertEquals;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import org.junit.Ignore;
import org.junit.Test;

import com.king.rbea.backend.types.processorinfo.RuntimeStatistics;

/**
 * Tests for {@link RuntimeStatistics}
 */
public class RuntimeStatisticsTest {
	long procId1 = 1;
	long timestamp = System.currentTimeMillis();
	int subtaskIndex1 = 100;
	int subtaskIndex2 = 100;
	long executionCount = 5;
	long executionTimeSum = 50;
	long maxExecutionTime = 15;
	
	private RuntimeStatistics rs1;
	private RuntimeStatistics rs2;
	
	public RuntimeStatisticsTest() {
		rs1 = new RuntimeStatistics(timestamp, procId1, subtaskIndex1, executionCount, executionTimeSum, maxExecutionTime, 0);
		rs2 = new RuntimeStatistics(timestamp, procId1, subtaskIndex2, executionCount, executionTimeSum, maxExecutionTime, 0);
	}

	/**
	 * Tests that the merge to {@link JobSummary} and export cycle works.
	 */
	@Ignore
	@Test
	public void testMergeAndExport() {
		JobSummary js = new JobSummary(procId1);
		rs1.mergeToSummary(js);
		rs2.mergeToSummary(js);
		
		Map<String, Serializable> export = js.export();
		@SuppressWarnings("unchecked")
		List<RuntimeStatistics> exportedRss = (List<RuntimeStatistics>) export.get(RuntimeStatistics.RUNTIME_STATISTICS_KEY);
		
		validate(exportedRss);
	}
	
	/**
	 * Tests removing old entries works by merging old RS and two recent and expecting to only find the two new ones.
	 */	
	@Test
	@Ignore
	public void testRemoveOld() {
		long oldTimestamp = System.currentTimeMillis() - 60 * 60 * 1000;
		
		JobSummary js = new JobSummary(procId1);
		RuntimeStatistics oldRs = new RuntimeStatistics(oldTimestamp, procId1, subtaskIndex1, executionCount, executionTimeSum, maxExecutionTime, 0);
		oldRs.mergeToSummary(js);
		rs1.mergeToSummary(js);
		rs2.mergeToSummary(js);
		
		Map<String, Serializable> export = js.export();
		@SuppressWarnings("unchecked")
		List<RuntimeStatistics> exportedRss = (List<RuntimeStatistics>) export.get(RuntimeStatistics.RUNTIME_STATISTICS_KEY);
		validate(exportedRss);
	}

	private void validate(List<RuntimeStatistics> exportedRss) {
		assertEquals(2, exportedRss.size());

		for (int i = 0; i < 2; i++) {
			RuntimeStatistics runtimeStatistics = exportedRss.get(i);
			RuntimeStatistics expectedRuntimeStatistics = null;
			if (i == 0) {
				expectedRuntimeStatistics = rs1;
			} else if (i == 1) {
				expectedRuntimeStatistics = rs2;
			}
			assertEquals(expectedRuntimeStatistics, runtimeStatistics);			
		}
	}
}
