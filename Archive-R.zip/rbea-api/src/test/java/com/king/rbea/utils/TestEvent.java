package com.king.rbea.utils;

import java.io.Serializable;

public class TestEvent implements com.king.event.Event, Serializable {

	private static final long serialVersionUID = 1L;
	public final String data;
	private long type;

	public TestEvent(String data) {
		this.data = data;
	}

	public TestEvent(String data, long type) {
		this.data = data;
		this.type = type;
	}

	@Override
	public String toString() {
		return "Event( " + data + " )";
	}

	@Override
	public Iterable<String> fields() {
		return null;
	}

	@Override
	public int get(int[] arg0) {
		return 0;
	}

	@Override
	public long get(int[][] arg0) {
		return 0;
	}

	@Override
	public String get(int[][][] arg0) {
		return null;
	}

	@Override
	public double get(int[][][][] arg0) {
		return 0;
	}

	@Override
	public boolean get(int[][][][][] arg0) {
		return false;
	}

	@Override
	public float get(int[][][][][][] arg0) {
		return 0;
	}

	@Override
	public Integer get(long[] arg0) {
		return null;
	}

	@Override
	public Long get(long[][] arg0) {
		return null;
	}

	@Override
	public Double get(long[][][][] arg0) {
		return null;
	}

	@Override
	public Boolean get(long[][][][][] arg0) {
		return null;
	}

	@Override
	public Float get(long[][][][][][] arg0) {
		return null;
	}

	@Override
	public boolean getBoolean(int arg0) {
		return false;
	}

	@Override
	public double getDouble(int arg0) {
		return 0;
	}

	@Override
	public long getEventType() {
		return type;
	}

	@Override
	public int getFlavourId() {
		return 0;
	}

	@Override
	public float getFloat(int arg0) {
		return 0;
	}

	@Override
	public String getHostname() {
		return null;
	}

	@Override
	public int getInt(int arg0) {
		return 0;
	}

	@Override
	public long getLong(int arg0) {
		return 0;
	}

	@Override
	public String getString(int arg0) {
		return null;
	}

	@Override
	public long getTimeStamp() {
		return 0;
	}

	@Override
	public long getUacid() {
		return 0;
	}

	@Override
	public long getUniqueId() {
		return 0;
	}

}