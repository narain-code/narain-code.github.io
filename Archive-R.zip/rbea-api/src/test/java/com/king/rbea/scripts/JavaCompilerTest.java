package com.king.rbea.scripts;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.apache.flink.api.java.tuple.Tuple3;
import org.junit.Test;
import org.mockito.Mockito;

import com.king.event.Event;
import com.king.rbea.Context;
import com.king.rbea.EventProcessor;
import com.king.rbea.Registry;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.scripts.proxy.ProxyExecutorFactory;

public class JavaCompilerTest {

	@Test
	public void test() throws Exception {
		StringWriter writer = new StringWriter();
		PrintWriter out = new PrintWriter(writer);
		out.println("package com.king.rbea;");
		out.println("import com.king.rbea.annotations.ProcessEvent;");
		out.println("import com.king.rbea.annotations.OnTimer;");
		out.println("import com.king.rbea.Context;");
		out.println("import com.king.rbea.TimerContext;");
		out.println("import com.king.rbea.Output;");
		out.println("public class Test {");
		out.println("  @ProcessEvent");
		out.println("  public void process(Context ctx) {");
		out.println("    ctx.getState();");
		out.println("  }");
		out.println("  @OnTimer");
		out.println("  public void onTime(TimerContext ctx, Output out) {");
		out.println("    ctx.getState();");
		out.println("  }");
		out.println("}");
		out.close();

		EventProcessor exec = ProxyExecutorFactory.builder().build().getForJavaCode(0, "", writer.toString());
		exec.initialize(null, null);
		Context ctx = Mockito.mock(Context.class);
		exec.processEvent(Mockito.mock(Event.class), ctx);
		Mockito.verify(ctx, Mockito.times(1)).getState();

		Tuple3<Integer, Boolean, Long> t = Tuple3.of(0, false, 1l);
		t.f1 = true;
	}

	@Test
	public void testArtificalScripts() throws Exception {
		validate("src/test/resources/javaTest1");
		validate("src/test/resources/javaTest2");
		validate("src/test/resources/javaTest4");
	}

	public static void validate(String path) throws IOException, Exception, ProcessorException {
		String code = new String(Files.readAllBytes(Paths.get(path)));
		ProcessorFactory processorFactory = ProxyExecutorFactory.builder().build();
		processorFactory.getForJavaCode(0, "", code).initialize(Mockito.mock(Registry.class), null);
	}

	@Test
	public void test4() throws Exception {
		try {
			validate("src/test/resources/javaTest3");
			fail();
		} catch (ProcessorException e) {
			assertTrue(e.getMessage().contains("single top-level"));
		}
	}
}
