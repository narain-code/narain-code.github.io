package com.king.rbea.configuration.processor;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.Serializable;
import java.util.Collections;
import java.util.HashSet;

import org.junit.Before;
import org.junit.Test;

import com.google.common.collect.Sets;
import com.king.rbea.configuration.Configuration;
import com.king.rbea.exceptions.ProcessorException;

public class ProcessorInfoTest implements Serializable {
	private static final long serialVersionUID = 1L;
	private Deployment deployment;
	private Failure failure;
	private Removal removal;
	private Resume resume;
	private OutputInfo mysqlOutput1;
	private OutputInfo mysqlOutput2;
	private OutputInfo fileOutput1;
	private OutputInfo fileOutput2;
	private JobSummary jobSummary;

	String errorMessage = "ERROR";
	long jobId = 1;
	
	@Before
	public void setup() throws ProcessorException {
		deployment = Deployment.newGroovyProcessor("a", jobId,
				"@ProcessEvent def myMethod(Event e){throw new Exception(\"EXPECTED\")}", "b", 1000);
		failure = new Failure(jobId, new ProcessorException(errorMessage), null, 2000);
		removal = new Removal(jobId, 2000);
		resume = new Resume(jobId, 2000);

		mysqlOutput1 = new OutputInfo(jobId, "mysql_agg1", "MYSQL",
				Collections.<String, Object> singletonMap("a", (Object) "b"));
		mysqlOutput2 = new OutputInfo(jobId, "mysql_agg2", "MYSQL",
				Collections.<String, Object> singletonMap("c", (Object) "d"));
		fileOutput1 = new OutputInfo(jobId, "file_agg1", "FILE",
				Collections.<String, Object> singletonMap("e", (Object) "f"));
		fileOutput2 = new OutputInfo(jobId, "file_agg1", "FILE",
				Collections.<String, Object> singletonMap("g", (Object) "h"));
		
		jobSummary = new JobSummary(jobId);
	}
	
	/**
	 * Tests serialization-deserialization-cycle of different 
	 * ProcessorInfo-subclasses works.
	 */
	@Test
	public void testSerialization() throws Exception {
		testSerialization(deployment);
		testSerialization(failure);
		testSerialization(removal);
		testSerialization(resume);
		testSerialization(mysqlOutput1);
		testSerialization(mysqlOutput1);
		testSerialization(mysqlOutput2);
		testSerialization(fileOutput1);
		testSerialization(fileOutput2);
		testSerialization(jobSummary);
	}

	private void testSerialization(ProcessorInfo proc) throws Exception {
		byte[] bytes = proc.serialize();
		ProcessorInfo info = ProcessorInfo.deserialize(bytes);
		assertEquals(proc, info);
		assertEquals(new Configuration(proc), new Configuration(info));
	}
	
	/**
	 * Tests JobSummary cannot be merged.
	 */
	@Test
	public void testSummaryMerge() throws Exception {
		try {
			jobSummary.mergeToSummary(jobSummary);
			fail();
		} catch (UnsupportedOperationException good) {}
	}
	
	@Test
	public void testDeployment() throws Exception {
		deployment.mergeToSummary(jobSummary);

		assertEquals((Integer) (-1), jobSummary.getInteger(JobSummary.JOB_END_TIME_KEY).get());
		assertEquals("", jobSummary.getString(Failure.FAILURE_CAUSE_KEY).get());
		assertEquals(JobSummary.JOB_STATE_RUNNING, jobSummary.getString(JobSummary.JOB_STATE_KEY).get());
		assertEquals("", jobSummary.getString(JobSummary.JOB_STATE_DESCRIPTION_KEY).get());

		// Legacy
		assertEquals(JobSummary.JOB_STATUS_RUNNING, jobSummary.getString(JobSummary.JOB_STATUS_KEY).get());

		assertEquals(JobSummary.class, jobSummary.getOriginalConfClass().get());
	}

	/**
	 * Tests merging OutputInfos works as expected.
	 */
	@Test
	public void testOutputs() throws Exception {
		// Merge outputs and check
		mysqlOutput1.mergeToSummary(jobSummary);
		assertEquals(1, jobSummary.getAllOutputs().size());
		mysqlOutput2.mergeToSummary(jobSummary);
		assertEquals(2, jobSummary.getAllOutputs().size());
		fileOutput1.mergeToSummary(jobSummary);
		assertEquals(3, jobSummary.getAllOutputs().size());
		fileOutput2.mergeToSummary(jobSummary);
		assertEquals(3, jobSummary.getAllOutputs().size());
		assertEquals(Sets.newHashSet(mysqlOutput1.getOutputParams(), mysqlOutput2.getOutputParams(), fileOutput1.getOutputParams()), new HashSet<>(jobSummary.getAllOutputs()));
	}
	
	/**
	 * Test deployment-fail-update-cycle works.
	 */
	@Test
	public void testFail() throws Exception {
		deployment.mergeToSummary(jobSummary);
		
		// Fail the job and check
		failure.mergeToSummary(jobSummary);
		assertFailedState();
		// Update in the past, won't change state
		Deployment.newGroovyProcessor("a", jobId, "updated", "b", 1000).asUpdate().mergeToSummary(jobSummary);
		assertFailedState();

		// Update in the future and validate running
		Deployment.newGroovyProcessor("a", jobId, "updated2", "b", 4000).asUpdate().mergeToSummary(jobSummary);
		assertEquals(-1, (int) jobSummary.getInteger(JobSummary.JOB_END_TIME_KEY).get());
		assertEquals("", jobSummary.getString(Failure.FAILURE_CAUSE_KEY).get());
		assertEquals(JobSummary.JOB_STATUS_RUNNING, jobSummary.getString(JobSummary.JOB_STATUS_KEY).get());
		assertEquals("", jobSummary.getString(JobSummary.STOP_REASON_KEY).get());
	}
	
	/**
	 * Test Removal cannot be merged.
	 */
	@Test
	public void testRemoval() throws Exception {
		try {
			removal.mergeToSummary(jobSummary);
			fail();
		} catch(UnsupportedOperationException e) {
			// Excepted
		}
	}
	
	@Test
	public void testJobConfig() {
		JobConfig conf = new JobConfig(jobId, "yo");
		assertEquals("yo", conf.getJobConfig());

		conf.mergeToSummary(jobSummary);
		assertEquals("yo", jobSummary.getString(JobConfig.JOB_CONFIG_KEY).get());
	}

	private void assertFailedState() {
		assertStoppedState(JobSummary.STOP_REASON_ERROR, errorMessage);
	}

	private void assertStoppedState(String stopReason, String failureCause) {
		assertEquals((Integer) 2000, jobSummary.getInteger(JobSummary.JOB_END_TIME_KEY).get());
		assertEquals(failureCause, jobSummary.getString(Failure.FAILURE_CAUSE_KEY).get());
		assertEquals(JobSummary.JOB_STATUS_STOPPED, jobSummary.getString(JobSummary.JOB_STATUS_KEY).get());
		assertEquals(stopReason, jobSummary.getString(JobSummary.STOP_REASON_KEY).get());
		assertTrue(!jobSummary.export().get(JobSummary.SCRIPT_HASH).equals(""));
	}

	/**
	 * Tests Deployment-update (Deployment with the same jobId) cycle works.
	 */
	@Test
	public void testUpdate() throws ProcessorException {
		Deployment dep = Deployment.newGroovyProcessor("name", 10, "script", "topic", 1000);
		dep.setString("props", "whatever");

		Deployment update = Deployment.newGroovyProcessor("name2", 10, "script2", "topic2", 2000).asUpdate();
		update.setString("props", "whatever2");

		JobSummary summary = new JobSummary(5);

		dep.mergeToSummary(summary);
		assertEquals("name", summary.getString(Deployment.JOB_NAME_KEY).get());
		assertEquals("script", summary.getString(Deployment.SCRIPT_TEXT_KEY).get());
		assertEquals(1000, (int) summary.getInteger(JobSummary.JOB_CREATED_TIME_KEY).get());
		assertEquals(1000, (int) summary.getInteger(JobSummary.JOB_START_TIME_KEY).get());
		assertEquals("whatever", summary.getString("props").get());

		update.mergeToSummary(summary);
		assertEquals("name2", summary.getString(Deployment.JOB_NAME_KEY).get());
		assertEquals("script2", summary.getString(Deployment.SCRIPT_TEXT_KEY).get());
		assertEquals(1000, (int) summary.getInteger(JobSummary.JOB_CREATED_TIME_KEY).get());
		assertEquals(2000, (int) summary.getInteger(JobSummary.JOB_START_TIME_KEY).get());
		assertEquals("whatever2", summary.getString("props").get());
	}
	
	/**
	 * Tests Deployment-Pause-update cycle works.
	 */
	@Test
	public void testDeploymentPauseDeploymentCycle() throws ProcessorException {
		long time = 1;
		final long createdTime = time;
		long startTime = createdTime;
		JobSummary summary = new JobSummary(10);
		
		// Deploy once
		Deployment dep = Deployment.newGroovyProcessor("name", 10, "script", "topic", time);
		dep.mergeToSummary(summary);
		validateJobSummary(summary, createdTime, startTime, JobSummary.JOB_STATUS_RUNNING, "", JobSummary.JOB_STATE_RUNNING, "");

		// Pause and re-deploy multiple times
		for (int i = 0; i < 10; i++) {
			Pause pause = new Pause(10, ++time);
			pause.mergeToSummary(summary);
			validateJobSummary(summary, createdTime, startTime, JobSummary.JOB_STATUS_STOPPED, JobSummary.STOP_REASON_PAUSE, JobSummary.JOB_STATE_PAUSED, JobSummary.JOB_STATE_DESCRIPTION_PAUSED);

			Deployment update = Deployment.newGroovyProcessor("name", 10, "script", "topic", ++time).asUpdate();
			startTime = time;
			update.mergeToSummary(summary);
			validateJobSummary(summary, createdTime, startTime, JobSummary.JOB_STATUS_RUNNING, "", JobSummary.JOB_STATE_RUNNING, "");
		}
	}
	
	/**
	 * Tests Deployment-Pause-Resume cycle works.
	 */
	@Test
	public void testDeploymentPauseResumeCycle() throws ProcessorException {
		long time = 1;
		final long createdTime = time;
		long startTime = createdTime;
		JobSummary summary = new JobSummary(10);
		
		// Deploy once
		Deployment dep = Deployment.newGroovyProcessor("name", 10, "script", "topic", time);
		dep.mergeToSummary(summary);
		validateJobSummary(summary, createdTime, startTime, JobSummary.JOB_STATUS_RUNNING, "", JobSummary.JOB_STATE_RUNNING, "");

		// Pause and resume multiple times
		for (int i = 0; i < 10; i++) {
			Pause pause = new Pause(10, ++time);
			pause.mergeToSummary(summary);
			validateJobSummary(summary, createdTime, startTime, JobSummary.JOB_STATUS_STOPPED, JobSummary.STOP_REASON_PAUSE, JobSummary.JOB_STATE_PAUSED, JobSummary.JOB_STATE_DESCRIPTION_PAUSED);

			Resume resume = new Resume(10, ++time);
			resume.mergeToSummary(summary);
			startTime = time;
			validateJobSummary(summary, createdTime,  startTime, JobSummary.JOB_STATUS_RUNNING, "", JobSummary.JOB_STATE_RUNNING, "");
		}
	}

	private void validateJobSummary(JobSummary summary, final long createdTime, final long startTime, String jobStatus, String stopReason, String jobState, String jobStateDescription) {
		assertEquals("name", summary.getString(Deployment.JOB_NAME_KEY).get());
		assertEquals("script", summary.getString(Deployment.SCRIPT_TEXT_KEY).get());
		assertEquals(startTime, summary.getLong(JobSummary.JOB_START_TIME_KEY).get().longValue());
		assertEquals(jobStatus, summary.getString(JobSummary.JOB_STATUS_KEY).get());
		assertEquals(stopReason, summary.getString(JobSummary.STOP_REASON_KEY).get());
		assertEquals(jobState, summary.getString(JobSummary.JOB_STATE_KEY).get());
		assertEquals(jobStateDescription, summary.getString(JobSummary.JOB_STATE_DESCRIPTION_KEY).get());
	}
}
