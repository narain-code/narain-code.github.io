package com.king.rbea.configuration.processor;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.io.Serializable;

import org.junit.Test;
import org.mockito.Mockito;

import com.king.event.Event;
import com.king.rbea.Context;
import com.king.rbea.EventProcessor;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.scripts.ProcessorFactory;
import com.king.rbea.scripts.proxy.ProxyExecutorFactory;

/**
 * Tests for deploying essentially the same code multiple different ways (Java, Groovy, EventProcessor)
 * and ensuring that the code throws the expected Exception.
 */
public class DeploymentTest implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Test
	public void testEventProcessorInfo() throws Exception {
		Deployment dep = Deployment.newEventProcessor("a", 10, new EventProcessor() {
			private static final long serialVersionUID = 1L;

			@Override
			public void processEvent(com.king.event.Event arg0, Context arg1) throws Exception {
				throw new Exception("EXPECTED");
			}
		}, "b", 1000, false);
		testDeployment(dep);
	}

	@Test
	public void testJavaProcessorInfo() throws ProcessorException, Exception {
		testDeployment(Deployment.newJavaProcessor("a", 10, new Serializable() {
			private static final long serialVersionUID = 1L;

			@ProcessEvent
			public void process() throws Exception {
				throw new Exception("EXPECTED");
			}
		}, "b", 1000, false));
	}

	@Test
	public void testGroovyProcessorInfo() throws Exception {
		String scriptText = "@ProcessEvent def myMethod(Event e){throw new Exception(\"EXPECTED\")}";
		Deployment dep = Deployment.newGroovyProcessor("a", 10, scriptText, "b", 1000);
		testDeployment(dep);
		assertEquals(scriptText, dep.getString(Deployment.SCRIPT_TEXT_KEY).get());
	}

	private static void testDeployment(Deployment deployment) throws Exception {
		deployment.setString("TestKey", "expected");

		byte[] bytes = deployment.serialize();
		Deployment dep = ProcessorInfo.deserialize(bytes);

		assertEquals(dep.getStartTime(), 1000);
		assertEquals(deployment.getString("TestKey").get(), "expected");

		ProcessorFactory processorFactory = ProxyExecutorFactory.builder().build();
		EventProcessor ep = dep.getProcessor(processorFactory);
		ep.initialize(null, null);
		try {
			ep.processEvent(Mockito.mock(Event.class), Mockito.mock(Context.class));
			fail();
		} catch (Exception e) {
			assertEquals("EXPECTED", e.getMessage());
		}
	}
}
