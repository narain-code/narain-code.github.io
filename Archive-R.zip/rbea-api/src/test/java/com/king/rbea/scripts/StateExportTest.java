package com.king.rbea.scripts;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.flink.api.java.tuple.Tuple3;
import org.junit.Test;
import org.mockito.Mockito;

import com.king.event.Event;
import com.king.flink.utils.CustomEvent;
import com.king.rbea.Context;
import com.king.rbea.Output;
import com.king.rbea.Registry;
import com.king.rbea.State;
import com.king.rbea.annotations.Initialize;
import com.king.rbea.annotations.OnSessionEnd;
import com.king.rbea.annotations.state.ExportColumn;
import com.king.rbea.annotations.state.ExportTable;
import com.king.rbea.annotations.state.ExportType;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.scripts.proxy.ProxyExecutor;
import com.king.rbea.scripts.proxy.ProxyExecutorFactory;
import com.king.rbea.state.LocalState;
import com.king.rbea.state.StateDescriptor;
import com.king.rbea.utils.TestUtils;

public class StateExportTest {

	@SuppressWarnings("unchecked")
	@Test
	public void test() throws Exception {
		ProxyExecutorFactory factory = ProxyExecutorFactory.builder().build();
		Context ctx = TestUtils.getMockContext(0);

		ProxyExecutor tester = (ProxyExecutor) factory.getForJavaObject(0, "", new TestProcessor());

		State state = ctx.getState();
		Output output = ctx.getOutput();

		Mockito.doAnswer(c -> {
			tester.exportStates();
			return null;
		}).when(state).export();

		List<Tuple3<String, byte[], byte[]>> kafkaOutput = new ArrayList<>();

		Mockito.doAnswer(call -> {
			kafkaOutput.add(Tuple3.of(call.getArgument(0), call.getArgument(1), call.getArgument(2)));
			return null;
		}).when(output).writeBytesToKafka(Mockito.any(), Mockito.any(), Mockito.any());

		Mockito.doAnswer(call -> {
			kafkaOutput.add(Tuple3.of(call.getArgument(0), null, ((String) call.getArgument(1)).getBytes()));
			return null;
		}).when(output).writeToKafka(Mockito.any(), Mockito.any());

		Mockito.when(state.get(Mockito.any(StateDescriptor.class))).thenReturn(1);
		Registry reg = Mockito.mock(Registry.class);
		Mockito.when(reg.registerState(Mockito.any())).thenReturn(Mockito.mock(StateDescriptor.class));
		tester.initialize(reg, ctx);

		tester.onSessionEnd(CustomEvent.create(0).withField(0, "yolo"), ctx);

	}

	@ExportTable(value = "myExportTopic", kafka = true)
	public static class TestProcessor implements Serializable {

		private static final long serialVersionUID = 1L;

		@ExportColumn(name = "col1", type = ExportType.INT)
		public StateDescriptor<Integer> intState;

		@ExportColumn(name = "col2", type = ExportType.STRING)
		public String text;

		@ExportColumn(name = "col3", type = ExportType.LONG, nullable = true)
		public Long num;

		@OnSessionEnd
		public void onSessEnd(State state, Event e) throws ProcessorException {
			text = e.getString(0);
			state.export();
		}

		@Initialize
		public void init(Registry reg) throws ProcessorException {
			intState = reg.registerState(LocalState.create("MyState", Integer.class));
			// postProcessedState = intState.postProcess(i -> i.toString());
		}
	}
}
