package com.king.rbea.utils;

import org.mockito.Mockito;

import com.king.event.Event;
import com.king.rbea.Aggregators;
import com.king.rbea.Context;
import com.king.rbea.Output;
import com.king.rbea.State;
import com.king.rbea.Utils;
import com.king.rbea.exceptions.ProcessorException;
import com.king.utils.Bitero;

public class TestUtils {

	public static Context getMockContext(long coreId) {
		return getMockContext(coreId, null);
	}

	public static Context getMockContext(long coreId, Event e) {
		Context context = Mockito.mock(Context.class);
		Output out = Mockito.mock(Output.class);
		Aggregators agg = Mockito.mock(Aggregators.class);
		State state = Mockito.mock(State.class);
		Utils utils = Mockito.spy(new MockUtils());
		Mockito.when(context.getAggregators()).thenReturn(agg);
		Mockito.when(context.getState()).thenReturn(state);
		Mockito.when(context.getUtils()).thenReturn(utils);
		Mockito.when(context.getOutput()).thenReturn(out);
		Mockito.when(context.getServices()).thenCallRealMethod();
		try {
			Mockito.when(context.getCoreUserId()).thenReturn(coreId);
			Mockito.when(context.getEvent()).thenReturn(e);
		} catch (ProcessorException ex) {}
		return context;
	}

	public static class MockUtils implements Utils {

		@Override
		public Bitero getBitero() {
			return null;
		}

	}
}
