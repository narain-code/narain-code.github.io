package com.king.rbea.state.basefields;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.TreeMap;
import java.util.TreeSet;

import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.api.java.typeutils.runtime.TupleSerializer;
import org.junit.Test;

import com.google.common.collect.Lists;
import com.king.flink.utils.types.HashMapSerializer;
import com.king.flink.utils.types.HashSetSerializer;
import com.king.rbea.state.LocalState;

public class FieldTest {

	@Test
	public void testInvalidCollectionStates() throws Exception {
		expectFail(() -> LocalState.create("s", ArrayList.class));
		expectFail(() -> LocalState.create("s", new ArrayList<>()));
		expectFail(() -> LocalState.create("s", LinkedList.class));
		expectFail(() -> LocalState.create("s", new LinkedList<>()));
		expectFail(() -> LocalState.create("s", TreeSet.class));
		expectFail(() -> LocalState.create("s", new HashSet<>()));
		expectFail(() -> LocalState.create("s", new TreeMap<>()));
	}

	private void expectFail(Runnable r) {
		try {
			r.run();
			fail();
		} catch (Exception expected) {
			assertTrue(expected.getMessage().startsWith("Use LocalState"));
		}
	}

	@Test
	public void testTypeHints() throws Exception {
		assertTrue(LocalState.create("ASD", new TypeHint<Tuple3<Integer, Boolean, Long>>() {})
				.getSerializer() instanceof TupleSerializer);

		assertTrue(
				LocalState.createMap("ASD", new TypeHint<Long>() {}, new TypeHint<Tuple3<Integer, Boolean, Long>>() {})
						.getSerializer() instanceof HashMapSerializer);

		assertTrue(LocalState.createSet("ASD", new TypeHint<Tuple3<Integer, Boolean, Long>>() {})
				.getSerializer() instanceof HashSetSerializer);
	}

	/**
	 * 
	 */
	@Test
	public void testLocality() throws Exception {
		// Tests various data types and their properties
		Lists.newArrayList(
				LocalState.create("ls", Long.class),
				LocalState.createBoolean("ls"),
				LocalState.createInt("ls"),
				LocalState.createLong("ls"),
				LocalState.createMap("ls", Long.class, Object.class),
				LocalState.createSet("ls", Long.class));

		assertFalse(LocalState.createMap("ls", Long.class, Object.class).getSerializer().isImmutableType());
		assertFalse(LocalState.createSet("ls", Long.class).getSerializer().isImmutableType());
		assertFalse(LocalState.createList("ls", Long.class).getSerializer().isImmutableType());
	}

}
