
package com.king.rbea.scripts;

import com.king.rbea.exceptions.ProcessorException;

public class ScriptCompileTest {
	
	public static void main(String[] args){
		String code = " aggregationWindow = MINUTES_5 \n"+
				"def processEvent(event, context) {\n " +
				 " def out = context.getOutput() \n"+
				 " def agg = context.getAggregators()\n " +
				 " def sd = context.getState() \n" +
				 "def gemsBalTotal = agg.getSumAggregator(\"GemsBalanceTotal\", aggregationWindow) \n" +
				  "def gemsBalWw = agg.getSumAggregator(\"GemsBalanceWaltersWorkshop\", aggregationWindow) \n"+
				 " def gemsBalLl = agg.getSumAggregator(\"GemsBalanceLuckyLane\", aggregationWindow) \n"+
				 " def entriesPaid = agg.getCounter(\"EntriesPaid\", aggregationWindow) \n"+
				 " def gamesPerTier = agg.getCounter(\"GamesPerTier\", aggregationWindow) \n"+
				 " def gamesLuckyLane = agg.getCounter(\"GamesLuckyLane\", aggregationWindow) \n"+
				  "def gamesLuckyLane5 = agg.getCounter(\"GamesLuckyLane5\", aggregationWindow) \n"+
				  "def gamesLuckyLane6 = agg.getCounter(\"GamesLuckyLane6\", aggregationWindow)\n"+
				 " def gamesLuckyLane7 = agg.getCounter(\"GamesLuckyLane7\", aggregationWindow)\n"+
				 " def numWinsWW = agg.getCounter(\"NumberWinsWaltersWorkshop\", aggregationWindow)\n"+
				 " def numWWRounds = agg.getCounter(\"NumberWaltersWorkshopRounds\", aggregationWindow)\n"+
				 " def numLLRounds = agg.getCounter(\"NumberLuckyLaneRounds\", aggregationWindow)\n"+
				 " def activePlayersCount = agg.getSumAggregator(\"activePlayersCount\", aggregationWindow)\n"+
				  "if(event.getEventType() == EventType.CardKingGameStart3.id){\n"+
				   " coreuserid = event.get(EventField.CardKingGameStart3.coreUserId)\n"+
				   " activePlayersCount.setDimensions(coreuserid).add(0)\n"+
				 " }\n"+
				  "if(event.getEventType() == EventType.ItemTransaction4.id){\n"+
				   " if(event.get(EventField.ItemTransaction4.itemType) == 35101){\n"+
				   "   if(event.get(EventField.ItemTransaction4.transactionType) == 26022 || event.get(EventField.ItemTransaction4.transactionType) == 26024){ \n"+
				   "     long amount = event.get(EventField.ItemTransaction4.amount)\n"+
				   "     gemsBalTotal.add(amount)\n"+
				   "     gemsBalWw.add(amount)\n"+
				  "      if(event.get(EventField.ItemTransaction4.transactionType) == 26022){\n"+
				 "         entriesPaid.increment()\n"+
				  "      }\n"+
				  "    }\n"+
				   "   if(event.get(EventField.ItemTransaction4.transactionType) == 26011){\n"+
				  "      long amount = event.get(EventField.ItemTransaction4.amount)\n"+
				   "     gemsBalTotal.add(amount)\n"+
				   "     gemsBalLl.add(amount)\n"+
				 "     }\n"+
				  "    if(event.get(EventField.ItemTransaction4.transactionType) == 26012){\n"+
			"	        long amount = event.get(EventField.ItemTransaction4.amount)\n"+
			"	        gemsBalTotal.add(amount)\n"+
			"	        gemsBalLl.add(amount)\n"+
			"	      }\n"+
			"	      if(event.get(EventField.ItemTransaction4.transactionType) == 26025 || event.get(EventField.ItemTransaction4.transactionType) == 26026){\n"+
			"	        long amount = event.get(EventField.ItemTransaction4.amount)\n"+
			"	        gemsBalTotal.add(amount)\n"+
			"	        gemsBalWw.add(amount)\n"+
			"	        if(event.get(EventField.ItemTransaction4.transactionType) == 26026){\n"+
			"	          numWinsWW.increment()\n"+
			"	        }\n"+
			"	      }\n"+
			"	    }\n"+
			"	  }\n"+
			"	  if(event.getEventType() == EventType.CardKingMatchStats9.id){\n"+
			"	    if(event.get(EventField.CardKingMatchStats9.gameModeId) == 6){\n"+
			"	      int tier = 0\n"+
			"	      if(event.get(EventField.CardKingMatchStats9.tier) == 1){\n"+
			"	        tier = 1\n"+
			"	      }\n"+
			"	      else if(event.get(EventField.CardKingMatchStats9.endOfGamePosition) == 1){\n"+
			"	        tier = event.get(EventField.CardKingMatchStats9.tier) - 1\n"+
			"	      }\n"+
			"	      else if(event.get(EventField.CardKingMatchStats9.endOfGamePosition) == 2){\n"+
			"	        tier = event.get(EventField.CardKingMatchStats9.tier)\n"+
			"	      }\n"+
			"	      gamesPerTier.setDimensions(tier).increment()\n"+
			"	      if (tier == 1){\n"+
			"	        numWWRounds.increment()\n"+
			"	      }\n"+
			"	    }\n"+
			"	  }\n"+
			"	  if(event.getEventType() == EventType.CardKingMatchStats9.id){\n"+
			"	    if(event.get(EventField.CardKingMatchStats9.gameModeId) == 5){\n"+
			"	      numLLRounds.increment()\n"+
			"	      coreuserid = event.get(EventField.CardKingMatchStats9.coreUserId)\n"+
			"	      gamesLuckyLane.setDimensions(coreuserid).increment()\n"+
			"	      int wagertable = event.get(EventField.CardKingMatchStats9.wagerTableId)\n"+
			"	      def casenum = sd.get(\"CASENUM\")\n"+
			"	      if (casenum < 8){\n"+
			"	        if (wagertable == 5){\n"+
			"	          gamesLuckyLane5.setDimensions(casenum).increment() \n"+
			"	        }\n"+
			"	        else if (wagertable == 6){\n"+
			"	          gamesLuckyLane6.setDimensions(casenum).increment() \n"+
			"	        }\n"+
			"	        else if (wagertable == 7){\n"+
			"	          gamesLuckyLane7.setDimensions(casenum).increment()\n"+
			"	        }\n"+
			"	      }\n"+
			"	      else {\n"+    
			"	        int coreuserid = event.get(EventField.CardKingMatchStats9.coreUserId)\n"+
			"	        if (coreuserid > 0){\n"+
			"	          if (wagertable == 5){\n"+
			"	            gamesLuckyLane5.setDimensions(coreuserid).increment()\n"+
			"	          }\n"+
			"	          else if (wagertable == 6){\n"+
			"	            gamesLuckyLane6.setDimensions(coreuserid).increment()\n"+
			"	          }\n"+
		"		          else if (wagertable == 7){\n"+
			"	            gamesLuckyLane7.setDimensions(coreuserid).increment()\n"+
			"	          }\n"+
			"	        }\n"+
			"	      }\n"+
			"	    }\n"+
			"	  }\n"+
			"}\n"+
			"	def initialize(reg) {\n"+
			"	    def casenum = Field.create(\"CASENUM\", Input.allEvents() , {\n"+
			"	    Integer tg, Event e -> \n"+
			"	    if(e.eventType == EventType.AbTestCaseAssigned.id \n"+
			"	           && e.get(EventField.AbTestCaseAssigned.abTestName) == 'SC_walters_workshop'){\n"+
			"	          return e.get(EventField.AbTestCaseAssigned.caseNum)\n"+
			"	        }\n"+
			"	    else {\n"+
			"	      return tg\n"+
			"	    }\n"+
			"	  }).initializedTo(8)\n"+
			"	  reg.registerField(casenum)\n"+
			"	}";
		
		try {
			ScriptUtils.compile(code);
		} catch (ProcessorException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
