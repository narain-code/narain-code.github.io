package com.king.rbea;

import static org.junit.Assert.assertEquals;

import java.util.Collections;
import java.util.Map;

import org.junit.Test;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import com.king.rbea.aggregators.DimensionType;
import com.king.rbea.aggregators.DimensionalAggregator;
import com.king.rbea.exceptions.ProcessorException;

public class DimensionalAggregatorTest {

	@Test
	public void testUnwrapping() throws ProcessorException {
		test(Collections.singletonMap("0", 1), 1);
		test(Collections.singletonMap("0", null), (Object[]) null);
		test(Collections.singletonMap("0", null), new Object[] { null });
		test(Collections.singletonMap("0", "a"), Lists.newArrayList("a"));
		test(Collections.singletonMap("0", "a"), new Object[] { "a" });
		test(ImmutableMap.of("0", "a", "1", "b"), Lists.newArrayList("a", "b"));
		test(ImmutableMap.of("0", "a", "1", "b"), new Object[] { "a", "b" });
		test(ImmutableMap.of("0", "a", "1", "b"), "a", "b");
		test(ImmutableMap.of("0", "a", "1", "b"), ImmutableMap.of("0", "a", "1", "b"));
	}

	@SuppressWarnings({ "rawtypes", "deprecation" })
	public void test(Map<String, ?> expected, Object... dims) throws ProcessorException {
		new DimensionalAggregator() {

			@Override
			public DimensionalAggregator groupBy(Map dimensions) throws ProcessorException {
				assertEquals(expected, dimensions);
				return null;
			}

			@Override
			public DimensionalAggregator setTableName(String tableName) throws ProcessorException {
				return null;
			}

			@Override
			public DimensionalAggregator setGroupTypes(Map typeMap) {
				return null;
			}

			@Override
			public DimensionalAggregator setDimension(String columnName, DimensionType type, Object value)
					throws ProcessorException {
				return null;
			}
		}.setDimensions(dims);
	}

}
