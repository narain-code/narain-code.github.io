package com.king.rbea.scripts;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.junit.Test;

import com.king.rbea.exceptions.ProcessorException;

public class DeprecatedApisTest {

	@Test
	public void test() throws IOException {
		String script = "@Bind namesToTrack = ['KNN_CTA_SHOWN', 'KNN_AD_PLAY', 'KNN_AD_COMPLETE', 'KNN_AD_REQUEST']\n"
				+ "	@ProcessEvent(eventType=EventType.FawkesKNNVideoAdTrack3)\n" +
				"def onAd(Event event, State state) {\n" +
				"Map localState = state.getLocalState()\n" +
				"def evtName = event.get(EventField.FawkesKNNVideoAdTrack3.eventName)\n" +
				"int key = namesToTrack.indexOf(evtName)\n" +
				"if(key >= 0) {\n" +
				"localState.put(key, localState.getOrDefault(key, 0) + 1)\n" +
				"}\n" +
				"}";
		try {
			ScriptUtils.testDeprecated(script);
			fail();
		} catch (ProcessorException e) {
			assertTrue(e.getMessage().contains("com.king.rbea.State:getLocalState"));
		}

	}

	@Test
	public void testValid() throws IOException, ProcessorException {
		String code = new String(Files.readAllBytes(Paths.get("src/test/resources/groovyTest1")));
		ScriptUtils.testDeprecated(code);
	}

}
