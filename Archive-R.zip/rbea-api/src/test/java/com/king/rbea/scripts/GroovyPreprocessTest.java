package com.king.rbea.scripts;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class GroovyPreprocessTest {

	@Test
	public void test() {
		String processed = ScriptUtils.preProcessGroovyScript("@Bind def a = 2\n@Bind b = 3");
		assertEquals("@groovy.transform.Field @Bind def a = 2\n@groovy.transform.Field @Bind b = 3", processed);
	}

}
