package com.king.rbea.scripts;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;

import org.apache.flink.api.java.tuple.Tuple3;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.king.event.Event;
import com.king.rbea.Context;
import com.king.rbea.EventProcessor;
import com.king.rbea.classloader.ApplicationClassLoader;
import com.king.rbea.scripts.proxy.ProxyExecutorFactory;

/**
 * Jar execution tests.
 */
public class JarCodeTest {
	private URL resource;

	@Before
	public void setup() throws Exception {
		File jarFile = new File("src/test/resources/com/king/rbea/scripts/JarTest/classes.jar");
		assertTrue(jarFile.exists());
		resource = jarFile.toURI().toURL();
	}
	
	/**
	 * Tests that the class can be loaded using {@link URLClassLoader}.
	 * If cannot, loading in the backend won't work.
	 */
	@Test
	public void testURLClassLoader() throws Exception {
		URL[] urls = new URL[] {resource};
		
		try (URLClassLoader urlClassLoader = new URLClassLoader(urls)) {
			String className = "com.king.rbea.test.JarExecutionTest";
			urlClassLoader.loadClass(className);
			urlClassLoader.loadClass("com.king.rbea.Context");
		}
	}
	
	/**
	 * Tests that the class can be loaded using {@link ApplicationClassLoader}.
	 * If cannot, loading in the backend won't work.
	 */
	@Test
	public void testApplicationClassLoader() throws Exception {
		URL[] urls = new URL[] {resource};
		
		try (ApplicationClassLoader applicationClassLoader = new ApplicationClassLoader(urls, Thread.currentThread().getContextClassLoader(), Collections.emptyList())) {
			String className = "com.king.rbea.test.JarExecutionTest";
			applicationClassLoader.loadClass("com.king.rbea.Context");
			applicationClassLoader.loadClass(className);
		}
	}

	
	/**
	 * The source of the file in classes.jar is the same Java code as in JavaCompilerTest.
	 * The JAR has been manually created by copying the class-file from IDE's output
	 * dir and packaging using jar.
	 */
	@Test
	public void testRunFromJar() throws Exception {
		Path jarPath = Paths.get("src/test/resources/com/king/rbea/scripts/JarTest/classes.jar");
		EventProcessor exec = ProxyExecutorFactory.builder().build().getForJar(0, "", jarPath);
		exec.initialize(null, null);
		Context ctx = Mockito.mock(Context.class);
		exec.processEvent(Mockito.mock(Event.class), ctx);
		Mockito.verify(ctx, Mockito.times(1)).getState();

		Tuple3<Integer, Boolean, Long> t = Tuple3.of(0, false, 1l);
		t.f1 = true;
	}
}
