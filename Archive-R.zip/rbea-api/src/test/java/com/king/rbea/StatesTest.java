package com.king.rbea;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import org.junit.Test;

import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.state.LocalState;
import com.king.rbea.state.StateDescriptor;

public class StatesTest {

	@Test
	public void test() {
		String stateName = LocalState.createMap("map", Integer.class, Boolean.class).getStateName();
		stateName.equals("map");
	}

	@Test
	public void testMutate() throws ProcessorException {
		State state = new TestState();
		StateDescriptor<Integer> s = LocalState.createInt("a");
		state.update(s, 1);
		try {
			state.mutate(s, i -> i++);
			fail();
		} catch (ProcessorException pe) {
			assertTrue(pe.getMessage().contains("immutable"));
		}

		StateDescriptor<String> s2 = LocalState.create("b", String.class);
		state.update(s2, "x");
		try {
			state.mutate(s2, x -> x.length());
			fail();
		} catch (ProcessorException pe) {
			assertTrue(pe.getMessage().contains("immutable"));
		}

		StateDescriptor<String> s3 = LocalState.create("c", String.class);
		try {
			state.mutate(s3, x -> x.length());
			fail();
		} catch (ProcessorException pe) {
			assertTrue(pe.getMessage().contains("null"));
		}

		StateDescriptor<AtomicInteger> s4 = LocalState.create("d", AtomicInteger.class);
		state.update(s4, new AtomicInteger(0));
		state.mutate(s4, AtomicInteger::incrementAndGet);
		assertEquals(1, state.get(s4).intValue());
	}

	public static class TestState implements State {

		private Map<String, Object> values = new HashMap<>();

		@SuppressWarnings("unchecked")
		@Override
		public <T> T get(String fieldName) throws ProcessorException {
			return (T) values.get(fieldName);
		}

		@Override
		public void update(String fieldName, Object value) throws ProcessorException {
			values.put(fieldName, value);
		}

		@Override
		public void clearAll() throws ProcessorException {
			values.clear();
		}

		@Override
		public <T> T get(long rbeaJobId, String fieldName) throws ProcessorException {
			throw new UnsupportedOperationException();
		}

		@Override
		public void export(Object... leading) throws ProcessorException {}

	}

}
