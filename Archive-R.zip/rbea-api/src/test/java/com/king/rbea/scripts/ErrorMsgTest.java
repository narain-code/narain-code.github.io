package com.king.rbea.scripts;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.junit.Test;
import org.mockito.Mockito;

import com.king.event.Event;
import com.king.rbea.Context;
import com.king.rbea.EventProcessor;
import com.king.rbea.configuration.processor.Failure;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.scripts.proxy.ProxyExecutorFactory;

public class ErrorMsgTest {

	ProcessorFactory processorFactory = ProxyExecutorFactory.builder().build();

	@Test
	public void testGroovy() throws Exception {
		String s = "@ProcessEvent\n"
				+ "def process(){\n"
				+ "def a = b;\n"
				+ "}";
		EventProcessor ep = processorFactory.getForGroovyScript(0, "", s);
		ep.initialize(null, null);

		try {
			ep.processEvent(Mockito.mock(Event.class), Mockito.mock(Context.class));
		} catch (Throwable e) {
			Failure f = new Failure(1, new ProcessorException(e), s, 0);
			String cause = f.getCause();
			assertTrue(cause.contains("Caused by: def a = b;"));
			assertTrue(cause.contains("Line: 3"));
		}
	}

	@Test
	public void testJava() throws Exception {
		String s = "@ProcessEvent\n"
				+ "def process(){\n"
				+ "String s = null;\n"
				+ "int a = s.size();\n"
				+ "}";
		EventProcessor ep = processorFactory.getForGroovyScript(0, "", s);
		ep.initialize(null, null);

		try {
			ep.processEvent(Mockito.mock(Event.class), Mockito.mock(Context.class));
		} catch (Throwable e) {
			Failure f = new Failure(1, new ProcessorException(e), s, 0);
			String cause = f.getCause();
			assertTrue(cause.contains("int a = s.size();"));
			assertTrue(cause.contains("Line: 4"));
		}
	}

	@Test
	public void testJava2() throws Exception {
		String s = "@ProcessEvent\n"
				+ "def process(){\n"
				+ "throw new RuntimeException(\"Hi!\");\n"
				+ "}";
		EventProcessor ep = processorFactory.getForGroovyScript(0, "", s);
		ep.initialize(null, null);

		try {
			ep.processEvent(Mockito.mock(Event.class), Mockito.mock(Context.class));
		} catch (Throwable e) {
			Failure f = new Failure(1, new ProcessorException(e), s, 0);
			String cause = f.getCause();
			assertTrue(cause.contains("throw new RuntimeException(\"Hi!\")"));
			assertTrue(cause.contains("Line: 3"));
		}
	}

	@Test
	public void testProcException() throws Exception {
		String s = "@ProcessEvent\n"
				+ "def process(){\n"
				+ "throw new com.king.rbea.exceptions.ProcessorException(new Exception()) ;\n"
				+ "}";
		EventProcessor ep = processorFactory.getForGroovyScript(0, "", s);
		ep.initialize(null, null);

		try {
			ep.processEvent(Mockito.mock(Event.class), Mockito.mock(Context.class));
		} catch (Throwable e) {
			Failure f = new Failure(1, (ProcessorException) e, s, 0);
			String cause = f.getCause();
			assertTrue(cause.startsWith("Exception"));
			assertTrue(cause.contains("Line: 3"));
		}
	}

	@Test
	public void testNoSCript() throws Exception {
		Failure f = new Failure(1, new ProcessorException("MSG"), null, 0);
		assertEquals("MSG", f.getCause());
	}

	@Test
	public void testNullCause() throws Exception {
		Failure f = new Failure(1, new ProcessorException(new NullPointerException()), "", 0);
		assertTrue(f.getCause().contains("NullPointerException"));
	}

	@Test
	public void testNoSCript2() throws Exception {
		ProcessorException e = new ProcessorException(new Exception("Hi"));
		Failure f = new Failure(1, e, null, 0);
		assertEquals(ExceptionUtils.getFullStackTrace(e), f.getCause());
	}
}
