package com.king.rbea.scripts;

import static com.king.rbea.annotations.ParamType.TimeStamp;
import static com.king.rbea.annotations.ParamType.TimerId;
import static com.king.rbea.annotations.ParamType.TimerParam;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.Serializable;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.flink.util.InstantiationUtil;
import org.junit.Test;
import org.mockito.Mockito;

import com.google.common.collect.ImmutableMap;
import com.king.constants.Flavour;
import com.king.constants.KingApp;
import com.king.constants.SignInSource;
import com.king.constants.external.EventType;
import com.king.constants.external.event.typed.events.AbTestClose;
import com.king.event.Event;
import com.king.flink.utils.CustomEvent;
import com.king.kgk.SCGameEnd;
import com.king.kgk.SCGameStart;
import com.king.rbea.Aggregators;
import com.king.rbea.Context;
import com.king.rbea.EventProcessor;
import com.king.rbea.Output;
import com.king.rbea.Registry;
import com.king.rbea.State;
import com.king.rbea.TimerContext;
import com.king.rbea.Timers;
import com.king.rbea.Utils;
import com.king.rbea.aggregators.AggregationWindow;
import com.king.rbea.aggregators.Counter;
import com.king.rbea.annotations.Aggregator;
import com.king.rbea.annotations.Async;
import com.king.rbea.annotations.Bind;
import com.king.rbea.annotations.Close;
import com.king.rbea.annotations.ConfigClass;
import com.king.rbea.annotations.OnConfigUpdate;
import com.king.rbea.annotations.OnError;
import com.king.rbea.annotations.OnSessionEnd;
import com.king.rbea.annotations.OnTimer;
import com.king.rbea.annotations.Param;
import com.king.rbea.annotations.ParamType;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.extensions.RBEAExtension;
import com.king.rbea.scripts.proxy.ProxyExecutorFactory;
import com.king.rbea.utils.SCLong;
import com.king.rbea.utils.TestEvent;
import com.king.rbea.utils.TestUtils;
import com.king.utils.AbTestMetaManager;
import com.king.utils.Bitero;
import com.king.utils.CurrencyManager;
import com.king.utils.FlavourInfo;

@SuppressWarnings("serial")
public class ScriptExecutorTest {

	public ProcessorFactory getFactory() {
		return ProxyExecutorFactory.builder().build();
	}

	@Test
	public void testProcInfo() throws Exception {
		ProcessorFactory factory = getFactory();

		assertTrue(testValid(factory, "@ProcessEvent def process(){}\n@Initialize def init(reg){}").getInfo().get()
				.hasInitMethod());
		assertTrue(testValid(factory, "@ProcessEvent def process(){}\n@Initialize def init(Registry reg){}").getInfo()
				.get().hasInitMethod());
		assertTrue(testValid(factory, "@ProcessEvent def process(){}\ndef initialize(Registry reg){}").getInfo().get()
				.hasInitMethod());
		assertTrue(testValid(factory, "@ProcessEvent def process(){}\ndef initialize(reg){}").getInfo().get()
				.hasInitMethod());

		assertTrue(testValid(factory,
				"@ProcessEvent def process(){}\n@OnTimer def ot(TimerContext ctx){}")
						.getInfo().get().hasOnTimerMethod());

		assertTrue(testValid(factory,
				"@ProcessEvent def process(){}\n@OnTimer def ot(){}")
						.getInfo().get().hasOnTimerMethod());

		assertTrue(testValid(factory,
				"@ProcessEvent def process(){}\n@OnTimer def ot(State s, Output out){}")
						.getInfo().get().hasOnTimerMethod());

		assertTrue(testValid(factory, "@Close def onClose() {}").getInfo().get().hasCloseMethod());
		assertTrue(testValid(factory, "def close() {}").getInfo().get().hasCloseMethod());
	}

	@Test
	public void testValidScripts() throws Exception {
		ProcessorFactory factory = getFactory();
		testValid(factory, new Serializable() {
			private static final long serialVersionUID = 1L;

			@ProcessEvent
			public void process() {}
		});
		testValid(factory, "@ProcessEvent def p(Output out, Event e, long l, long l2, Event e2){}");
		testValid(factory, "@ProcessEvent def p(State s){"
				+ "ABTestAssignments ab= s.getABTestAssignments;}");
		testValid(factory, "@ProcessEvent def p(Event e){}");
		testValid(factory, "@ProcessEvent(semanticClass=SCLong.class) def p(SCLong o, Event e){}");
		testValid(factory, "@ProcessEvent(semanticClass=[SCLong.class, SCGameStart.class]) def p(SCLong o, Event e){}");
		testValid(factory, "@ProcessEvent def p(){}");
		testValid(factory, "@ProcessEvent def p(Flavour f, KingApp k, SignInSource ss){}");
		testValid(factory, "@OnSessionEnd def p(Flavour f, KingApp k, SignInSource ss){}");
		testValid(factory, "@ProcessEvent def p(Bitero bit){}");
		testValid(factory, "@Initialize def init(){}");
		testValid(factory, "@ProcessEvent def p(Services serv){}");
		testValid(factory, "@ProcessEvent def p(Flavours flavours){}");
		testValid(factory, "@ProcessEvent def p(@Aggregator(name=\"c\", window=MINUTES_1) Counter c){}");
		testValid(factory, "@ProcessEvent def p(@Aggregator(name=\"c\", window=MINUTES_1) RatioAggregator c){}");
		testValid(factory, "@ProcessEvent def p(@Aggregator(name=\"c\", window=MINUTES_1) AverageAggregator c){}");

		testValid(factory, "@ProcessEvent(eventType=EventType.Saga2GameEnd4) def p(){}");
		testValid(factory,
				"@ProcessEvent def process(Output out){}\n@ProcessEvent(semanticClass=SCLong.class) def process2(Event e, SCLong sc){}");
		testValid(factory,
				"@ProcessEvent(eventType=EventType.Saga2GameStart) def process(Output out){}\n@ProcessEvent(semanticClass=SCLong.class) def process2(Event e, SCLong sc){}");

		testValid(factory,
				"@ProcessEvent(eventType=[EventType.Saga2GameStart,EventType.Saga2GameEnd4]) def process(Output out){}\n@ProcessEvent(semanticClass=SCLong.class) def process2(Event e, SCLong sc){}");

		testValid(factory,
				"@ProcessEvent def process(){}\ndef initialize(reg){reg.registerState(LocalState.create(\"Flag\", new TypeHint<Boolean>(){}))}");
		testValid(factory, "@ProcessEvent def p(Output out, Event e, Long l, long l2, Event e2){}");

		testValid(factory, "@Bind def test = 2\n"
				+ "@ProcessEvent def p(Output out, Event e, long l, long l2, Event e2){"
				+ "def a = test;}");

		testValid(factory, "@Bind int test = 2\n"
				+ "@ProcessEvent def p(Output out, Event e, long l, long l2, Event e2){"
				+ "b = test;"
				+ "test = 3;}");

		testValid(factory, "@Bind test = 2\n"
				+ "@ProcessEvent def p(Output out, Event e, long l, long l2, Event e2){"
				+ "b = test;"
				+ "test = 3;}");

		testValid(factory, "@ProcessEvent def p(){def b = a} \n def initialize(reg){a = 2}");

		testInvalid(factory,
				"@ProcessEvent(eventType=EventType.TournamentSlotFinalized, semanticClass=SCLong.class) def p(SCLong o){}");
		testInvalid(factory, "@ProcessEvent def process(){}\n@Initialize def init(Integer reg){}");
		testInvalid(factory, "@ProcessEvent def process(out, e){}");
		testValid(factory, "def process(Event e){}");
		testInvalid(factory, "@ProcessEvent def process(Integer out, Event e){}");
		testInvalid(factory, "@ProcessEvent(semanticClass=Integer.class) def p(Integer o, Event e){}");
		testInvalid(factory, "@ProcessEvent def process(out, e){}");
		testInvalid(factory,
				"@ProcessEvent def process(){}\n@OnTimer def init(@Param(TimerParam) Integer a, long b, Object c, Context o){}");
		testValid(factory,
				"@ProcessEvent def process(){}\n@OnTimer def init(@Param(TimerParam) Integer a, Context o){}");
		testValid(factory,
				"@ProcessEvent def process(){}\n@OnTimer def init(@Param(CUID) long a, Context o){}");
		testValid(factory,
				"@ProcessEvent def process(){}\n@OnTimer def init(@Param(TimerParam) a, Context o){}");

		testInvalid(factory, "@ProcessEvent def process(){}\ndef initialize(Context o){}");
		testInvalid(factory, "@ProcessEvent def process(){}\ndef initialize(Output o){}");
		testInvalid(factory, "@ProcessEvent def process(){}\ndef initialize(Integer a, long b, Object c, Context o){}");
		testInvalid(factory, "@ProcessEvent def p(@Aggregator(name=\"\", window=MINUTES_1) Counter c){}");

		testInvalid(factory, "int test = 2\n"
				+ "@ProcessEvent def p(Output out, Event e, long l, long l2, Event e2){"
				+ "b = test;"
				+ "test = 3;}");

		testInvalid(factory, "test = 2\n"
				+ "@ProcessEvent def p(Output out, Event e, long l, long l2, Event e2){"
				+ "b = test;"
				+ "test = 3;}");

		testInvalid(factory, "def test = 2\n"
				+ "@ProcessEvent def p(Output out, Event e, long l, long l2, Event e2){"
				+ "b = test;"
				+ "test = 3;}");

		testValid(factory,
				"@ProcessEvent(eventType=EventType.Saga2GameEnd4) def process(Saga2GameEnd4 gs){}");

		testInvalid(factory,
				"@ProcessEvent(eventType=EventType.Saga2GameEnd4, semanticClass=SCGameStart) def process(Saga2GameEnd4 gs){}");

		testValid(factory,
				"@ProcessEvent(eventType=EventType.Saga2GameEnd4, semanticClass=SCGameStart) def process(Event gs){}");

		testValid(factory,
				"@ProcessEvent(eventType=EventType.Saga2GameEnd3) def process(Saga2GameEnd3 gs){}");

		testValid(factory,
				"@OnConfigUpdate def onUpdate(String conf){}");

		testValid(factory,
				"@OnConfigUpdate def onUpdate(Map<String, ?> conf){}");

		testValid(factory,
				"@OnConfigUpdate def onUpdate(Map<String, ?> conf, Context ctx){}");

		testValid(factory,
				"@OnConfigUpdate def onUpdate(Map<String, ?> conf, Output out, Bitero bit){}");

		testValid(factory,
				"@OnConfigUpdate def onUpdate(Map<String, ?> conf, long l){}");

		testValid(factory,
				"@Close def onClose(){}");
		testValid(factory,
				"def close(){}");
	}

	@Test
	public void testMultipleProcessMethod() throws Exception {
		ProcessorFactory factory = getFactory();
		AtomicInteger counter = new AtomicInteger();
		Context ctx = TestUtils.getMockContext(10);

		EventProcessor multiTypeFilter = factory.getForJavaObject(0, "", new MultiTypeFilter(counter));

		multiTypeFilter.initialize(null, null);
		multiTypeFilter.processEvent(new TestEvent("", 7), ctx);
		multiTypeFilter.processEvent(new TestEvent("", 8), ctx);
		multiTypeFilter.processEvent(new TestEvent("", 9), ctx);
		multiTypeFilter.processEvent(new TestEvent("", EventType.Saga2GameEnd4), ctx);
		multiTypeFilter.processEvent(new TestEvent("", EventType.Saga2NewMarker3), ctx);
		multiTypeFilter.processEvent(new TestEvent("", 11), ctx);
		multiTypeFilter.processEvent(new TestEvent("", EventType.Saga2GameStart), ctx);
		multiTypeFilter.processEvent(new TestEvent("", 13), ctx);
		assertEquals(counter.get(), 4);
	}

	@Test
	public void testUtilsUnwrapping() throws Exception {
		ProcessorFactory factory = getFactory();
		Context ctx = TestUtils.getMockContext(0);
		Serializable o = new Serializable() {
			private static final long serialVersionUID = 1L;

			@ProcessEvent
			public void p(AbTestMetaManager ab, CurrencyManager cm, Bitero bitero) {

			}
		};

		EventProcessor utilsTester = factory.getForJavaObject(0, "", o);
		utilsTester.initialize(null, null);
		utilsTester.processEvent(CustomEvent.create(0), ctx);

		Utils utils = ctx.getUtils();
		Mockito.verify(utils, Mockito.times(1)).getAbTestMetaManager();
		Mockito.verify(utils, Mockito.times(1)).getCurrencyManager();
		Mockito.verify(utils, Mockito.times(1)).getBitero();
	}

	@Test
	public void testInputFiltering() throws Exception {
		ProcessorFactory factory = getFactory();
		Context ctx = TestUtils.getMockContext(10);
		AtomicInteger ai = new AtomicInteger();

		EventProcessor typeFilter = factory.getForJavaObject(0, "", new Serializable() {
			private static final long serialVersionUID = 1L;

			@ProcessEvent(eventType = EventType.Saga2GameStart)
			public void proc(Event e) {
				assertEquals(EventType.Saga2GameStart, e.getEventType());
				ai.incrementAndGet();
			}

		});

		typeFilter.initialize(null, null);
		typeFilter.processEvent(new TestEvent("", EventType.Saga2GameStart), ctx);
		typeFilter.processEvent(new TestEvent("", 10), ctx);
		typeFilter.processEvent(new TestEvent("", EventType.Saga2GameStart), ctx);
		assertEquals(ai.get(), 2);

		EventProcessor semClassFilter = factory.getForJavaObject(0, "", new Serializable() {

			private static final long serialVersionUID = 1L;

			@ProcessEvent(semanticClass = SCLong.class)
			public void proc(Event event, SCLong sc, SCLong sc2) {
				TestEvent e = (TestEvent) event;
				assertEquals("2", e.data);
				assertEquals(2, sc.get());
				assertEquals(2, sc2.get());
				ai.incrementAndGet();
			}

		});

		semClassFilter.initialize(null, null);
		semClassFilter.processEvent(new TestEvent("a", 12), ctx);
		semClassFilter.processEvent(new TestEvent("2", 10), ctx);
		semClassFilter.processEvent(new TestEvent("2", 12), ctx);

		assertEquals(ai.get(), 4);
	}

	@Test
	public void testSerialization() throws Exception {
		ProcessorFactory factory = getFactory();
		EventProcessor exec1 = factory.getForJavaObject(0, "", new AggregatorTester());
		exec1.initialize(null, null);
		byte[] bytes1 = InstantiationUtil.serializeObject(exec1);
		EventProcessor exec1D = InstantiationUtil.deserializeObject(bytes1,
				Thread.currentThread().getContextClassLoader());
		exec1D.initialize(null, null);

		EventProcessor exec2 = factory.getForGroovyScript(0, "", "@ProcessEvent def p(){}");
		exec2.initialize(null, null);
		byte[] bytes2 = InstantiationUtil.serializeObject(exec2);
		EventProcessor exec2D = InstantiationUtil.deserializeObject(bytes2,
				Thread.currentThread().getContextClassLoader());
		exec2D.initialize(null, null);
	}

	@Test
	public void testArguments() throws Exception {
		ProcessorFactory factory = getFactory();
		AtomicInteger counter = new AtomicInteger();
		Context ctx = TestUtils.getMockContext(10);
		Event event = new TestEvent("");

		EventProcessor argumentTester = factory.getForJavaObject(0, "", new ArgumentTester(counter, ctx, event));

		argumentTester.initialize(null, null);
		argumentTester.processEvent(event, ctx);
		assertEquals(counter.get(), 1);
	}

	@Test
	public void testConfigUpdate() throws Exception {
		ProcessorFactory factory = getFactory();
		String conf = "{\"a\":10, \"b\":\"test\", \"MyConf\" : {\"a\":10, \"b\":\"test\"}}";

		ConfTester confTester = new ConfTester();
		EventProcessor proc = factory.getForJavaObject(0, "", confTester);
		Context ctx = TestUtils.getMockContext(10);
		proc.initialize(null, null);
		proc.onConfigUpdate(conf, ctx);
		assertEquals(3, confTester.numCalls);
		assertEquals("test", confTester.b);
		assertEquals(10, confTester.a);

		assertEquals("test", confTester.conf.b);
		assertEquals(10, confTester.conf.a);
	}

	@Test
	public void testConfigUpdate2() throws Exception {
		ProcessorFactory factory = getFactory();
		Context ctx = TestUtils.getMockContext(0);
		Serializable o = new Serializable() {
			private static final long serialVersionUID = 1L;

			@OnConfigUpdate
			public void doIt(String s) {
				assertEquals("asd", s);
			}
		};

		EventProcessor proc = factory.getForJavaObject(0, "", o);
		proc.initialize(null, null);

		proc.onConfigUpdate("asd", ctx);
	}

	@Test
	public void testAggregators() throws Exception {
		ProcessorFactory factory = getFactory();
		Context ctx = TestUtils.getMockContext(1);

		EventProcessor proc = factory.getForJavaObject(0, "", new AggregatorTester());

		proc.initialize(null, null);
		proc.processEvent(new TestEvent(""), ctx);

		Mockito.verify(ctx.getAggregators(), Mockito.times(1))
				.getCounter("test1", AggregationWindow.MINUTES_1);
	}

	private void testInvalid(ProcessorFactory factory, String script) throws Exception {
		try {
			testValid(factory, script);
			fail();
		} catch (Exception expected) {}

	}

	private EventProcessor testValid(ProcessorFactory factory, String script) throws Exception {
		EventProcessor exec = factory.getForGroovyScript(0, "", script);
		exec.initialize(Mockito.mock(Registry.class), null);
		exec.processEvent(new TestEvent("a"), TestUtils.getMockContext(1));
		return exec;
	}

	private EventProcessor testValid(ProcessorFactory factory, Serializable obj) throws Exception {
		EventProcessor exec = factory.getForJavaObject(0, "", obj);
		exec.initialize(Mockito.mock(Registry.class), null);
		exec.processEvent(new TestEvent("a"), TestUtils.getMockContext(1));
		return exec;
	}

	@Test
	public void testOnSessionEnd() throws Exception {
		ProcessorFactory factory = getFactory();
		Context ctx = Mockito.mock(Context.class);
		AtomicInteger ai = new AtomicInteger(0);
		EventProcessor exec = factory.getForJavaObject(0, "", new Serializable() {
			private static final long serialVersionUID = 1L;

			@ProcessEvent
			public void process() {};

			@OnSessionEnd
			public void onEnd(State s, Event e, Context ctx, State s2, Output out) {
				ai.incrementAndGet();
				e.getTimeStamp();
			}
		});

		exec.initialize(null, null);
		exec.onSessionEnd(Mockito.mock(Event.class), ctx);
		assertEquals(1, ai.get());

		Mockito.verify(ctx, Mockito.times(1)).getOutput();
		Mockito.verify(ctx, Mockito.times(2)).getState();
	}

	@Test
	public void testClose() throws Exception {
		final AtomicInteger ai = new AtomicInteger(0);

		final EventProcessor exec = getFactory().getForJavaObject(0, "", new Serializable() {
			@Close
			public void onClose() {
				ai.incrementAndGet();
			}
		});

		exec.initialize(null, null);
		exec.close();

		assertEquals(1, ai.get());
	}

	@Test
	public void testOnTimer() throws Exception {
		testOnTimerNew(getFactory());
	}

	public void testOnTimerNew(ProcessorFactory factory) throws Exception {
		TimerContext ctx = Mockito.mock(TimerContext.class);
		Mockito.when(ctx.getTimerParam()).thenReturn(5);
		EventProcessor exec = factory.getForJavaObject(0, "", new Serializable() {
			private static final long serialVersionUID = 1L;

			@ProcessEvent
			public void process() {};

			@OnTimer
			public void onTimer(State s, TimerContext ctx, @Param(TimerParam) Integer params) {
				assertEquals(5, (int) params);
			}
		});

		exec.initialize(null, null);
		exec.onTimer(ctx);
		Mockito.verify(ctx, Mockito.times(1)).getState();
	}

	@Test
	public void testFlavourParam() throws Exception {
		EventProcessor exec = getFactory().getForJavaObject(0, "", new Serializable() {
			private static final long serialVersionUID = 1L;

			@ProcessEvent
			public void process(FlavourInfo flavour, Flavour f, KingApp k, SignInSource ss) {
				assertEquals("candycrush", flavour.getKingAppShortName());
				assertEquals(KingApp.CANDYCRUSH, k);
				assertNotNull(k);
				assertNotNull(ss);
			}

			@OnSessionEnd
			public void onSession(FlavourInfo flavour, Output out, Flavour f, KingApp k, SignInSource ss) {
				assertEquals("candycrush", flavour.getKingAppShortName());
				assertEquals(KingApp.CANDYCRUSH, k);
				assertNotNull(k);
				assertNotNull(ss);
			}
		});

		Context ctx = TestUtils.getMockContext(1);
		exec.initialize(null, null);
		exec.processEvent(CustomEvent.create(0).withFlavourId(290017), ctx);
		exec.onSessionEnd(CustomEvent.create(0).withFlavourId(290017), ctx);

		Mockito.verify(ctx, Mockito.times(2)).getUtils();
	}

	@Test
	public void testTypedEvents() throws Exception {
		EventProcessor exec = getFactory().getForJavaObject(0, "", new Serializable() {
			private static final long serialVersionUID = 1L;

			@ProcessEvent(eventType = EventType.AbTestClose)
			public void process(AbTestClose testClose) {
				assertEquals("yo", testClose.getAbTestName());
			}
		});

		Context ctx = TestUtils.getMockContext(1);
		exec.initialize(null, null);
		exec.processEvent(Event.from(AbTestClose.of("yo")), ctx);
	}

	@Test
	public void testCombinedFilters() throws Exception {
		AtomicInteger numCalls1 = new AtomicInteger(0);
		AtomicInteger numCalls2 = new AtomicInteger(0);
		EventProcessor exec = getFactory().getForJavaObject(0, "", new Serializable() {
			private static final long serialVersionUID = 1L;

			@ProcessEvent(semanticClass = { SCGameStart.class, SCGameEnd.class }, eventType = 1)
			public void process() {
				numCalls1.incrementAndGet();
			}

			@ProcessEvent(semanticClass = { SCGameStart.class, SCGameEnd.class }, eventType = { 1, 2 })
			public void proces2() {
				numCalls2.incrementAndGet();
			}
		});

		Context ctx = TestUtils.getMockContext(1);
		exec.initialize(null, null);
		exec.processEvent(CustomEvent.create(EventType.Saga2GameEnd), ctx);
		exec.processEvent(CustomEvent.create(-1), ctx);
		exec.processEvent(CustomEvent.create(EventType.Saga2GameStart), ctx);
		exec.processEvent(CustomEvent.create(1), ctx);
		exec.processEvent(CustomEvent.create(2), ctx);
		exec.processEvent(CustomEvent.create(3), ctx);

		assertEquals(3, numCalls1.get());
		assertEquals(4, numCalls2.get());
	}

	@Test
	public void testParamParsing() throws Exception {
		EventProcessor exec = getFactory().getForJavaObject(0, "", new Serializable() {
			private static final long serialVersionUID = 1L;

			@ProcessEvent
			public void process(@Param(ParamType.CUID) long cuid) {
				assertEquals(1, cuid);
			}

			@OnTimer
			public void onT(@Param(TimeStamp) long ts, @Param(TimerId) int tid3,
					@Param(TimerId) Integer tid4, @Param(ParamType.CUID) long cuid,
					@Param(TimerParam) boolean tp) {
				assertEquals(1, ts);
				assertEquals(2, cuid);
				assertEquals(3, tid3);
				assertEquals(3, (int) tid4);
				assertEquals(false, tp);
			}
		});

		Context ctx = TestUtils.getMockContext(1);
		exec.initialize(null, null);
		exec.processEvent(Mockito.mock(Event.class), ctx);

		TimerContext tctx = Mockito.mock(TimerContext.class);
		Mockito.when(tctx.getTimerParam()).thenReturn(false);
		Mockito.when(tctx.getTimeStamp()).thenReturn(1l);
		Mockito.when(tctx.getCoreUserId()).thenReturn(2l);
		Mockito.when(tctx.getTimerId()).thenReturn(3);

		exec.onTimer(tctx);
	}

	@Test
	public void extensionBindingTest() throws Exception {
		EventProcessor exec = getFactory().getForJavaObject(0, "", new Serializable() {
			private static final long serialVersionUID = 1L;

			@ProcessEvent
			public void process(TestExtension ext, TestExtension2 ext2) {
				ext.yaay();
				ext2.yaay();
			}

		});

		Context ctx = TestUtils.getMockContext(1);
		exec.initialize(null, null);
		exec.processEvent(CustomEvent.create(0).withFlavourId(290017), ctx);
		Mockito.verify(ctx, Mockito.times(1)).getOutput();
	}

	@Test
	public void testOnErr() throws Exception {
		EventProcessor exec = getFactory().getForJavaObject(0, "", new Serializable() {
			private static final long serialVersionUID = 1L;

			@OnError(maxErrorsPerMin = 1)
			public void onErr(Throwable err, Aggregators agg, Event e) {
				err.getStackTrace();
			}

		});

		Context ctx = TestUtils.getMockContext(1);
		exec.initialize(null, null);
		Throwable t = Mockito.spy(new RuntimeException());
		exec.onError(t, ctx);
		Mockito.verify(ctx, Mockito.times(1)).getAggregators();
		Mockito.verify(t, Mockito.times(1)).getStackTrace();
	}

	@Test
	public void asyncTest1() throws Exception {
		EventProcessor exec = getFactory().getForJavaObject(0, "", new AsyncProc1());

		AtomicInteger ai = new AtomicInteger(0);

		Context ctx = TestUtils.getMockContext(1);
		exec.setAsyncExecutor(r -> {
			ai.incrementAndGet();
			r.run();
		});
		exec.initialize(null, null);
		exec.processEvent(CustomEvent.create(0), ctx);
		assertEquals(1, ai.get());
	}

	public static class AsyncProc1 implements Serializable {
		private static final long serialVersionUID = 1L;

		@ProcessEvent
		public void process(TestExtension ext, TestExtension2 ext2) {
			async();
		}

		@Async
		public void async() {}

	}

	public static class TestExtension implements RBEAExtension {
		private Context ctx;

		public TestExtension(Context ctx) {
			this.ctx = ctx;
		}

		public void yaay() {
			ctx.getOutput();
		}
	}

	public static class TestExtension2 implements RBEAExtension {

		private static final TestExtension2 INSTANCE = new TestExtension2(null);

		private TestExtension2(Context ctx) {

		}

		public void yaay() {}

		public static TestExtension2 get(Context ctx) {
			return INSTANCE;
		}
	}

	public static class ConfTester implements Serializable {
		private static final long serialVersionUID = 1L;

		public int numCalls = 0;

		@Bind
		int a;

		@Bind
		String b;

		@Bind
		MyConf conf;

		@ConfigClass
		public static class MyConf {
			public int a;
			public String b;
		}

		@OnConfigUpdate
		public void onUpdate1(String raw) {
			assertEquals("{\"a\":10, \"b\":\"test\", \"MyConf\" : {\"a\":10, \"b\":\"test\"}}", raw);
			numCalls++;
		}

		@OnConfigUpdate
		public void onUpdate3(Map<String, ?> confMap) {
			assertEquals(ImmutableMap.of("a", 10, "b", "test", "MyConf", ImmutableMap.of("a", 10, "b", "test")),
					confMap);
			numCalls++;
		}

		@OnConfigUpdate
		public void onUpdate4(String raw, Map<String, ?> confMap, MyConf conf) {
			assertEquals("{\"a\":10, \"b\":\"test\", \"MyConf\" : {\"a\":10, \"b\":\"test\"}}", raw);
			assertEquals(ImmutableMap.of("a", 10, "b", "test", "MyConf", ImmutableMap.of("a", 10, "b", "test")),
					confMap);
			assertTrue(conf != null);
			numCalls++;
		}
	}

	public static final class AggregatorTester implements Serializable {
		private static final long serialVersionUID = 1L;

		Integer state;

		@ProcessEvent
		public void proc(
				@Aggregator(name = "test1", window = AggregationWindow.MINUTES_1) Counter c) {}
	}

	public static final class ArgumentTester implements Serializable {
		private static final long serialVersionUID = 1L;

		AtomicInteger counter;
		Context ctx;
		Event event;

		public ArgumentTester(AtomicInteger counter, Context ctx, Event event) {
			this.counter = counter;
			this.ctx = ctx;
			this.event = event;
		}

		@ProcessEvent
		public void proc(Event e, Context c, Event e2, State s, Output out, Timers t, Utils u, long cuid,
				Long cuid2) throws ProcessorException {
			assertEquals(event, e);
			assertEquals(event, e2);
			assertEquals(ctx, c);
			assertEquals(ctx.getState(), s);
			assertEquals(ctx.getOutput(), out);
			assertEquals(ctx.getTimers(), t);
			assertEquals(ctx.getUtils(), u);
			assertEquals(10, cuid);
			assertEquals(ctx.getCoreUserId(), cuid2);
			counter.incrementAndGet();
		}
	}

	public class MultiTypeFilter implements Serializable {
		private static final long serialVersionUID = 1L;

		AtomicInteger counter;

		public MultiTypeFilter(AtomicInteger counter) {
			this.counter = counter;
		}

		@ProcessEvent(eventType = EventType.Saga2GameEnd4)
		public void proc1(Event e, Output out) {
			assertEquals(EventType.Saga2GameEnd4, e.getEventType());
			counter.incrementAndGet();
		}

		@ProcessEvent(eventType = EventType.Saga2GameStart)
		public void pro2(@Aggregator(name = "asd", window = AggregationWindow.MINUTES_5) Counter c, Event e) {
			assertEquals(EventType.Saga2GameStart, e.getEventType());
			counter.incrementAndGet();
		}

		@ProcessEvent(eventType = { EventType.Saga2NewMarker3, EventType.Saga2GameStart })
		public void pro3(Event e, State s, Utils u) {
			assertTrue(e.getEventType() == EventType.Saga2NewMarker3
					|| e.getEventType() == EventType.Saga2GameStart);
			counter.incrementAndGet();
		}

		public void processEvent(Event e, Context ctx) {
			fail();
		}
	}
}
