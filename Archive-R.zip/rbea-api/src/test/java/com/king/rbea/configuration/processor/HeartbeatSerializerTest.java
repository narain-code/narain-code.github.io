package com.king.rbea.configuration.processor;

import static org.junit.Assert.assertEquals;

import org.apache.flink.api.java.tuple.Tuple2;
import org.junit.Test;

/**
 * Tests for {@link HeartbeatSerializer}.
 */
public class HeartbeatSerializerTest {
	/**
	 * Tests serialization-deserialization cycle works.
	 */
	@Test
	public void testSerialization() throws Exception {
		Heartbeat heartbeat = new Heartbeat(123);

		String backendId = "be1";
		Tuple2<String, Heartbeat> tuple = Tuple2.of(backendId, heartbeat);
		Tuple2<String, Heartbeat> deserializedTuple= HeartbeatSerializer.INSTANCE
				.deserialize(HeartbeatSerializer.INSTANCE.serialize(tuple));

		assertEquals(tuple, deserializedTuple);
	}
}
