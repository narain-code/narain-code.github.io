package com.king.rbea.scripts;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.king.rbea.scripts.proxy.ProxyExecutor;
import com.king.rbea.scripts.proxy.ProxyExecutorFactory;

public class ClassNamingTest {

	@Test
	public void test() throws Exception {
		String s = "@ProcessEvent\n"
				+ "def process(){\n"
				+ "def a = b;\n"
				+ "}";
		ProcessorFactory processorFactory = ProxyExecutorFactory.builder().build();
		ProxyExecutor ep = (ProxyExecutor) processorFactory.getForGroovyScript(999,
				"MyJob", s);
		ep.initialize(null, null);

		assertTrue(ep.getGeneratedProcessor().getClass().getSimpleName().contains("MyJob_999"));
	}
}
