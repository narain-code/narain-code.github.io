package com.king.rbea.configuration.processor;

import static org.junit.Assert.assertEquals;

import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.types.Either;
import org.junit.Test;

/**
 * Tests for {@link JobSummarySerializer}
 */
public class JobSummarySerializerTest {
	/**
	 * Tests the serialization-deserialization cycle of {@link JobSummary}-objects works.
	 */
	@Test
	public void summarySerializerTest() throws Exception {
		JobSummary summary = new JobSummary(5);

		JobSummarySerializer s = JobSummarySerializer.INSTANCE;

		Tuple2<String, Either<JobSummary, Either<JobSummariesStart, JobSummariesEnd>>> in1 = Tuple2.of("a",
				Either.Left(summary));
		Tuple2<String, Either<JobSummary, Either<JobSummariesStart, JobSummariesEnd>>> in2 = Tuple2.of("a",
				Either.Right(Either.Left(new JobSummariesStart())));
		Tuple2<String, Either<JobSummary, Either<JobSummariesStart, JobSummariesEnd>>> in3 = Tuple2.of("a",
				Either.Right(Either.Right(new JobSummariesEnd())));
		Tuple2<String, Either<JobSummary, Either<JobSummariesStart, JobSummariesEnd>>> out1 = s
				.deserialize(s.serialize(in1));
		Tuple2<String, Either<JobSummary, Either<JobSummariesStart, JobSummariesEnd>>> out2 = s
				.deserialize(s.serialize(in2));
		Tuple2<String, Either<JobSummary, Either<JobSummariesStart, JobSummariesEnd>>> out3 = s
				.deserialize(s.serialize(in3));

		assertEquals(in1, out1);
		assertEquals(in2, out2);
		assertEquals(in3, out3);
	}
}
