package com.king.rbea.scripts;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.Serializable;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.Test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.king.rbea.Context;
import com.king.rbea.EventProcessor;
import com.king.rbea.Registry;
import com.king.rbea.annotations.Bind;
import com.king.rbea.annotations.ConfigClass;
import com.king.rbea.annotations.Initialize;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.annotations.config.ConfigField;
import com.king.rbea.annotations.config.Meta;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.scripts.info.ConfigClassSchema.ScriptConfigInfo;
import com.king.rbea.scripts.info.StateInfo;
import com.king.rbea.scripts.proxy.ProxyExecutorFactory;
import com.king.rbea.state.LocalState;
import com.king.rbea.state.StateDescriptor;
import com.king.rbea.utils.TestUtils;

public class ConfigurationTest {

	@Test
	public void test() throws Exception {
		ProcessorFactory factory = ProxyExecutorFactory.builder().build();
		// String conf = "{\"payloadLiveOps2\": 1, \"groupUID\": 2}";
		String conf = "{\"conf\" : {\"payloadLiveOps2\": 1, \"groupUID\": 2}}";

		ConfTester confTester = new ConfTester();
		EventProcessor proc = factory.getForJavaObject(0, "", confTester);
		Context ctx = TestUtils.getMockContext(10);
		proc.initialize(null, null);
		proc.onConfigUpdate(conf, ctx);

		assertEquals("1", confTester.conf.payloadLiveOps2);
		assertEquals(2, confTester.conf.groupUID);

		ScriptConfigInfo configInfo = proc.getInfo().get().getConfigSchema();
		assertTrue(configInfo.definitions.containsKey("LiveOpsConf"));
		assertTrue(configInfo.definitions.containsKey("TestConf"));
		assertFalse(configInfo.definitions.containsKey("UnusedConf"));
		assertTrue(configInfo.properties.containsKey("conf"));
		assertTrue(configInfo.properties.containsKey("conf2"));

		List<StateDescriptor<?>> states = proc.getInfo().get().getStates();
		assertEquals(1, states.size());
		assertEquals(ConfTester.TEST_STATE, states.get(0));

		System.err.println(new ObjectMapper().writerWithDefaultPrettyPrinter()
				.writeValueAsString(states.stream().map(StateInfo::fromStateDescriptor).collect(Collectors.toList())));
		System.err.println(new ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(configInfo));
	}

	public static class ConfTester implements Serializable {
		public static final LocalState<Integer> TEST_STATE = LocalState.createInt("TestState");

		private static final long serialVersionUID = 1L;

		@Bind
		LiveOpsConf conf;

		@Bind
		TestConf conf2;

		@ConfigField(description = "NumField", required = true)
		@Bind
		long numField;

		@ProcessEvent
		public void process() {}

		@ConfigClass
		public static class LiveOpsConf {

			@ConfigField(description = "Live ops payload", label = "myPayload", required = false, meta = {
					@Meta(key = "type", value = "payload"),
					@Meta(key = "group", value = "group1") })
			public String payloadLiveOps2 = "defaultPayload";

			@ConfigField(description = "UID for group1", meta = {
					@Meta(key = "type", value = "UID"),
					@Meta(key = "group", value = "group1") })
			public long groupUID;
		}

		@ConfigClass
		public static class UnusedConf {

		}

		@Initialize
		public void init(Registry reg) throws ProcessorException {
			reg.registerState(TEST_STATE);
		}

	}

	@ConfigClass
	public static class TestConf {

		@ConfigField(description = "Some test field", label = "field", required = false)
		public String testField = "defaultPayload";

	}

}
