package com.king.utils;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.util.Map;

import org.junit.Test;

public class FlavourUtilTest {

	@SuppressWarnings("deprecation")
	@Test
	public void test() throws Exception {
		Flavours flavours = Flavours.INSTANCE;
		assertNotNull(flavours.getInfo(100012));

		Map<Integer, FlavourInfo> all = flavours.getInfoMap();
		try {
			all.remove(100012);
			fail();
		} catch (Exception e) {}
	}

}
