package com.king.utils;

import com.king.splat.AbTestMetaManagerImpl;
import com.king.splat.AbTestProviderTracking;

public class AbTestMetaManagerSingleton {

    private static final com.king.utils.AbTestMetaManager AB_TEST_META_MANAGER = new com.king.utils.AbTestMetaManager(new AbTestMetaManagerImpl(new AbTestProviderTracking()));
    
    public static com.king.utils.AbTestMetaManager getInstance() {
        return AB_TEST_META_MANAGER;
    }

}
