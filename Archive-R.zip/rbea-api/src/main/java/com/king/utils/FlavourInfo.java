package com.king.utils;

import com.king.rbea.documenting.RbeaDocumentedClass;
import com.king.rbea.documenting.RbeaDocumentedMethod;

@RbeaDocumentedClass(summary = "Contains info about a flavour based on referenciador.")
public class FlavourInfo {

	private int id;
	private int kingAppId;
	private String kingAppShortName;
	private String kingAppLabel;
	private String kingAppDescription;
	private int signinSourceId;
	private String signinSourceName;
	private int signinGroupId;
	private String authenticationMethod;
	private String clientImplementation;
	private int variant;
	private String kingAppType;
	private String clientPlatform;
	private String clientBuildConfiguration;

	@RbeaDocumentedMethod
	public int getId() {
		return id;
	}

	@RbeaDocumentedMethod
	public int getKingAppId() {
		return kingAppId;
	}

	@RbeaDocumentedMethod
	public String getKingAppShortName() {
		return kingAppShortName;
	}

	@RbeaDocumentedMethod
	public String getKingAppLabel() {
		return kingAppLabel;
	}

	@RbeaDocumentedMethod
	public String getKingAppDescription() {
		return kingAppDescription;
	}

	@RbeaDocumentedMethod
	public int getSigninSourceId() {
		return signinSourceId;
	}

	@RbeaDocumentedMethod
	public String getSigninSourceName() {
		return signinSourceName;
	}

	@RbeaDocumentedMethod
	public int getSigninGroupId() {
		return signinGroupId;
	}

	@RbeaDocumentedMethod
	public String getAuthenticationMethod() {
		return authenticationMethod;
	}

	@RbeaDocumentedMethod
	public String getClientImplementation() {
		return clientImplementation;
	}

	@RbeaDocumentedMethod
	public int getVariant() {
		return variant;
	}

	@RbeaDocumentedMethod
	public String getKingAppType() {
		return kingAppType;
	}

	@RbeaDocumentedMethod
	public String getClientPlatform() {
		return clientPlatform;
	}

	@RbeaDocumentedMethod
	public String getClientBuildConfiguration() {
		return clientBuildConfiguration;
	}

	@Override
	public String toString() {
		return "Flavour [id=" + id + ", kingAppId=" + kingAppId + ", kingAppShortName=" + kingAppShortName
				+ ", kingAppLabel=" + kingAppLabel + ", kingAppDescription=" + kingAppDescription
				+ ", signinSourceId=" + signinSourceId + ", signinSourceName=" + signinSourceName
				+ ", signinGroupId=" + signinGroupId + ", authenticationMethod=" + authenticationMethod
				+ ", clientImplementation=" + clientImplementation + ", variant=" + variant + ", kingAppType="
				+ kingAppType + ", clientPlatform=" + clientPlatform + ", clientBuildConfiguration="
				+ clientBuildConfiguration + "]";
	}

}