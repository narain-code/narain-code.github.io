package com.king.utils;

import java.util.Map;
import java.util.Set;

import com.king.constants.KingApp;
import com.king.rbea.documenting.RbeaDocumentedClass;
import com.king.rbea.documenting.RbeaDocumentedMethod;
import com.king.splat.AbTestInfo;
import com.king.splat.AbTestInfo.AbTestType;

@RbeaDocumentedClass(summary = "Utility for getting metadata about AB-tests")
public class AbTestMetaManager {

    private final com.king.splat.AbTestMetaManager abTestMetaManager;

    public AbTestMetaManager(com.king.splat.AbTestMetaManager abTestMetaManager) {
        super();
        this.abTestMetaManager = abTestMetaManager;
    }

    @RbeaDocumentedMethod(summary = "Get all active AB-tests based on event timestamp and KingApp (timestamp, kingapp)")
    public Map<AbTestType, Set<AbTestInfo>> getAllActiveAbTests(KingApp kingApp, long msts) {
        return abTestMetaManager.getAllActiveAbTests(kingApp, msts);
    }
     
    
}
