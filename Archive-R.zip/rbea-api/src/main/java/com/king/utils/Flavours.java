package com.king.utils;

import java.net.URL;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Supplier;
import com.google.common.base.Suppliers;
import com.king.event.Event;
import com.king.flink.utils.Unchecked;
import com.king.rbea.documenting.RbeaDocumentedMethod;
import com.king.rbea.exceptions.BackendException;

@Deprecated
public enum Flavours {

	INSTANCE;

	public static final Logger LOG = LoggerFactory.getLogger(Flavours.class);

	private static final String FLAVOUR_URL = "http://referenciador.int.midasplayer.com/king_constants/latest/FlavourInfo.json";
	private static final String DEFAULT_FLAVOUR_INFO_JSON = "default_flavour_info.json";

	private static final ObjectMapper MAPPER = new ObjectMapper();

	private final Supplier<Map<Integer, FlavourInfo>> cache;
	private Map<Integer, FlavourInfo> last;

	private ExecutorService exec = Executors.newSingleThreadExecutor();

	private Flavours() {
		cache = Suppliers.memoizeWithExpiration(this::downloadInfo, 6, TimeUnit.HOURS);
	}

	private Map<Integer, FlavourInfo> downloadInfo() {

		String json = null;
		try {
			json = exec.submit(() -> IOUtils.toString(new URL(FLAVOUR_URL))).get(15, TimeUnit.SECONDS);
		} catch (Exception e) {
			LOG.error("Error while downloading flavour info.", e);
			if (last == null) {
				try {
					LOG.info("Falling back to default info.");
					json = IOUtils.toString(getClass().getClassLoader().getResource(DEFAULT_FLAVOUR_INFO_JSON));
				} catch (Exception ex) {}
			} else {
				LOG.error("Falling back to last info.");
				return last;
			}
		}

		if (json == null) {
			Unchecked.throwSilently(new BackendException("Cannot load flavour info file."));
			return null;
		}

		try {
			List<FlavourInfo> parsed = MAPPER.readValue(json, new TypeReference<List<FlavourInfo>>() {});

			Map<Integer, FlavourInfo> map = Collections.unmodifiableMap(parsed
					.stream()
					.collect(Collectors.toMap(i -> i.getId(), i -> i)));

			last = map;
		} catch (Exception e) {
			LOG.error("Error while parsing flavour info.", e);
		}

		if (last != null) {
			return last;
		} else {
			Unchecked.throwSilently(new BackendException("Cannot parse flavour info file."));
			return null;
		}
	}

	@RbeaDocumentedMethod
	public FlavourInfo getInfo(int flavourId) {
		return cache.get().get(flavourId);
	}

	@RbeaDocumentedMethod
	public FlavourInfo getInfo(Event event) {
		return getInfo(event.getFlavourId());
	}

	@RbeaDocumentedMethod
	public Map<Integer, FlavourInfo> getInfoMap() {
		return cache.get();
	}
}
