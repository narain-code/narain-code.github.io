package com.king.utils;

import com.king.rbea.documenting.RbeaDocumentedClass;
import com.king.rbea.documenting.RbeaDocumentedMethod;
import com.king.rbea.exceptions.ProcessorException;

@RbeaDocumentedClass(summary = "Utility for managing segmentation membership")
public interface Bitero {

	@RbeaDocumentedMethod(summary = "Adds the given player to an specific Bitero segment id")
	void addPlayerToSegment(long cuid, long segmentId) throws ProcessorException;

	@RbeaDocumentedMethod(summary = "Removed the given player from an specific Bitero segment id")
	void removePlayerFromSegment(long cuid, long segmentId) throws ProcessorException;

}
