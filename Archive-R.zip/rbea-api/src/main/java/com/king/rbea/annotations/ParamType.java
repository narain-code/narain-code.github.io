package com.king.rbea.annotations;

public enum ParamType {

	TimeStamp, TimerId, TimerParam, CUID;

}