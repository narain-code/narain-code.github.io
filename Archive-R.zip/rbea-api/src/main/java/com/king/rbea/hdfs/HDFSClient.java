package com.king.rbea.hdfs;

import java.io.IOException;
import java.io.InputStream;

/**
 * Implementation provides storage of byte[] in a HDFS filesystem.
 * When running in Flink, Flink's internal mechanism can be used
 * (which in the end uses Hahoop's library),
 * and when outside of Flink (standalone JVM), Hadoop's native
 * library can be used.
 */
public interface HDFSClient {
	/**
	 * Checks if file in path {@code fileName} exists.
	 *  
	 * @param fileName the absolute file name to check
	 * @return whether exists
	 * @throws IOException if fails
	 */
	boolean exists(String fileName) throws IOException;
	
	/**
	 * Stores the {@code content} to a path specified by {@code fileName}.
	 * 
	 * @param fileName the absolute file name to store to
	 * @param content the content
	 * @throws IOException if fails 
	 */
	void storeFile(String fileName, byte[] content) throws IOException;

	/**
	 * Opens {@link InputStream} for {@code fileName}.
	 * 
	 * @param fileName the absolute file name 
	 * @return the stream
	 */
	InputStream getInputStream(String fileName) throws IOException;

	/**
	 * Deletes the file {@code fileName}.
	 * 
	 * @param fileName the absolute file name to delete
	 * @throws IOException if fails
	 */
	void delete(String fileName) throws IOException;
	
	void rename(String fromFileName, String toFileName) throws IOException;
	
	void mkdirs(String dir) throws IOException;
}
