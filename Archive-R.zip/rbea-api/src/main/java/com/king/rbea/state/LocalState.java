package com.king.rbea.state;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.commons.lang3.Validate;
import org.apache.flink.api.common.ExecutionConfig;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeutils.TypeSerializer;
import org.apache.flink.api.java.typeutils.TypeExtractor;
import org.apache.flink.util.InstantiationUtil;

import com.king.flink.utils.Unchecked;
import com.king.flink.utils.types.ArrayListTypeInfo;
import com.king.flink.utils.types.HashMapTypeInfo;
import com.king.flink.utils.types.HashSetTypeInfo;
import com.king.flink.utils.types.TreeMapTypeInfo;
import com.king.rbea.documenting.RbeaDocumentedClass;
import com.king.rbea.documenting.RbeaDocumentedMethod;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.state.internal.InternalState;
import com.king.rbea.state.internal.StateArrayList;
import com.king.rbea.state.internal.StateHashMap;
import com.king.rbea.state.internal.StateHashSet;
import com.king.rbea.state.internal.StateTreeMap;

@RbeaDocumentedClass(summary = "A LocalState contains arbitrary user state that can be updates using a get/update interface from the State.")
public class LocalState<T> implements Serializable, StateDescriptor<T> {

	private static final long serialVersionUID = -85592290611220128L;

	private final String name;
	private StateInitializer<T> initializer = coreId -> null;

	private TypeSerializer<T> serializer;
	private TypeInformation<T> typeInfo;

	protected LocalState(String name) {
		this.name = name;
	}

	@Override
	public String getStateName() {
		return name;
	}

	@SuppressWarnings("unchecked")
	public T getValue(long coreId, InternalState state) throws Exception {
		Object value = state.readValue();
		if (value == null) {
			value = initializer.initialize(coreId);
		}
		return (T) value;
	}

	public void setValue(long coreId, InternalState state, T value) throws Exception {
		state.writeValue(value);
	}

	public LocalState<T> withType(TypeInformation<T> typeInfo) {
		this.typeInfo = typeInfo;
		serializer = typeInfo.createSerializer(new ExecutionConfig());
		return this;
	}

	@RbeaDocumentedMethod(summary = "Sets the type information for the field for efficient serialization.")
	public LocalState<T> withType(Class<T> clazz) {
		if (List.class.isAssignableFrom(clazz)) {
			Unchecked.throwSilently(new ProcessorException("Use LocalState.createList for list states"));
		} else if (Map.class.isAssignableFrom(clazz)) {
			Unchecked.throwSilently(new ProcessorException("Use LocalState.createMap or createTreeMap for map states"));
		} else if (Set.class.isAssignableFrom(clazz)) {
			Unchecked.throwSilently(new ProcessorException("Use LocalState.createSet for set states"));
		}
		return withType(TypeExtractor.getForClass(clazz));
	}

	public LocalState<T> withType(TypeHint<T> type) {
		return withType(type.getTypeInfo());
	}

	@RbeaDocumentedMethod(summary = "Sets the field initalizer function that will be called for each new user.")
	public LocalState<T> withInitializer(StateInitializer<T> initializer) {
		this.initializer = initializer;
		return this;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RbeaDocumentedMethod(summary = "Sets the initial value for the field for all core users.")
	public LocalState<T> initializedTo(T value) {
		if (value == null) {
			return this;
		}
		if (getSerializer() == null) {
			withType((Class) value.getClass());
		}
		byte[] serializedVal;
		try {
			serializedVal = InstantiationUtil.serializeToByteArray(getSerializer(), value);
		} catch (IOException e) {
			Unchecked.throwSilently(new IOException("Initial value not serializable", e));
			throw new RuntimeException("Never thrown");
		}

		return withInitializer(new StateInitializer<T>() {
			private static final long serialVersionUID = 1L;
			TypeSerializer<T> initialValueSerializer = getSerializer();

			@Override
			public T initialize(long coreId) throws Exception {
				return InstantiationUtil.deserializeFromByteArray(initialValueSerializer, serializedVal);
			}
		});
	}

	public TypeSerializer<T> getSerializer() {
		return serializer;
	}

	public TypeInformation<T> getTypeInfo() {
		return typeInfo;
	}

	@Override
	public String toString() {
		return getStateName();
	}

	@RbeaDocumentedMethod(summary = "Create a new Long local state with the given name.")
	public static LocalState<Long> createLong(String name) {
		return create(name, Long.class);
	}

	@RbeaDocumentedMethod(summary = "Create a new Integer local state with the given name.")
	public static LocalState<Integer> createInt(String name) {
		return create(name, Integer.class);
	}

	@RbeaDocumentedMethod(summary = "Create a new Boolean local state with the given name.")
	public static LocalState<Boolean> createBoolean(String name) {
		return create(name, Boolean.class);
	}

	@RbeaDocumentedMethod(summary = "Create a new local state with the give non null initial value.")
	public static <T> LocalState<T> create(String name, T initialValue) {
		return new LocalState<T>(name).initializedTo(Validate.notNull(initialValue));
	}

	@RbeaDocumentedMethod(summary = "Create a new local state with the given type.")
	public static <T> LocalState<T> create(String name, Class<T> type) {
		return new LocalState<T>(name).withType(type);
	}

	@RbeaDocumentedMethod(summary = "Create a new local state with the given type.")
	public static <T> LocalState<T> create(String name, TypeHint<T> type) {
		return new LocalState<T>(name).withType(type.getTypeInfo());
	}

	@RbeaDocumentedMethod(summary = "Create a new tree map state with the given key and value types. Updates made to this map are autmatically saved to the state.")
	public static <K, V> LocalState<TreeMap<K, V>> createTreeMap(String name, Class<K> keyType, Class<V> valueType) {
		return createTreeMap(name, TypeExtractor.getForClass(keyType), TypeExtractor.getForClass(valueType));
	}

	@RbeaDocumentedMethod(summary = "Create a new tree map state with the given key and value types. Updates made to this map are autmatically saved to the state.")
	public static <K, V> LocalState<TreeMap<K, V>> createTreeMap(String name, TypeHint<K> keyType,
			TypeHint<V> valueType) {
		return createTreeMap(name, keyType.getTypeInfo(), valueType.getTypeInfo());
	}

	@RbeaDocumentedMethod(summary = "Create a new map state with the given key and value types. Updates made to this map are autmatically saved to the state.")
	public static <K, V> LocalState<HashMap<K, V>> createMap(String name, TypeHint<K> keyType, TypeHint<V> valueType) {
		return createMap(name, keyType.getTypeInfo(), valueType.getTypeInfo());
	}

	@RbeaDocumentedMethod(summary = "Create a new map state with the given key and value types. Updates made to this map are autmatically saved to the state.")
	public static <K, V> LocalState<HashMap<K, V>> createMap(String name, Class<K> keyType, Class<V> valueType) {
		return createMap(name, TypeExtractor.getForClass(keyType), TypeExtractor.getForClass(valueType));
	}

	@RbeaDocumentedMethod(summary = "Create a new set state with the given type. Updates made to this set are autmatically saved to the state.")
	public static <T> LocalState<HashSet<T>> createSet(String name, Class<T> elementType) {
		return createSet(name, TypeExtractor.createTypeInfo(elementType));
	}

	@RbeaDocumentedMethod(summary = "Create a new set state with the given type. Updates made to this set are autmatically saved to the state.")
	public static <T> LocalState<HashSet<T>> createSet(String name, TypeHint<T> elementType) {
		return createSet(name, elementType.getTypeInfo());
	}

	@RbeaDocumentedMethod(summary = "Create a new list state with the given type. Updates made to this list are autmatically saved to the state.")
	public static <T> LocalState<ArrayList<T>> createList(String name, Class<T> elementType) {
		return createList(name, TypeExtractor.createTypeInfo(elementType));
	}

	@RbeaDocumentedMethod(summary = "Create a new list state with the given type. Updates made to this list are autmatically saved to the state.")
	public static <T> LocalState<ArrayList<T>> createList(String name, TypeHint<T> elementType) {
		return createList(name, elementType.getTypeInfo());
	}

	private static <K, V> LocalState<HashMap<K, V>> createMap(String name, TypeInformation<K> keyType,
			TypeInformation<V> valueType) {
		return new StateHashMap.State<K, V>(name).withType(new HashMapTypeInfo<>(keyType, valueType));
	}

	private static <K, V> LocalState<TreeMap<K, V>> createTreeMap(String name, TypeInformation<K> keyType,
			TypeInformation<V> valueType) {
		return new StateTreeMap.State<K, V>(name).withType(new TreeMapTypeInfo<>(keyType, valueType));
	}

	private static <T> LocalState<HashSet<T>> createSet(String name, TypeInformation<T> elementType) {
		return new StateHashSet.State<T>(name).withType(new HashSetTypeInfo<>(elementType));
	}

	private static <T> LocalState<ArrayList<T>> createList(String name, TypeInformation<T> elementType) {
		return new StateArrayList.State<T>(name).withType(new ArrayListTypeInfo<>(elementType));
	}
}
