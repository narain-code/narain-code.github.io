package com.king.rbea.annotations.state;

public enum ExportType {
	BOOLEAN(Boolean.class), DOUBLE(Double.class), INT(Integer.class), LONG(Long.class), STRING(String.class);

	private final Class<?> target;

	private ExportType(Class<?> target) {
		this.target = target;
	}

	public Class<?> getTargetClass() {
		return target;
	}
}
