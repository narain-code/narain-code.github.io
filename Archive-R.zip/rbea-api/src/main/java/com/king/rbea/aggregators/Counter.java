package com.king.rbea.aggregators;

import com.king.rbea.documenting.RbeaDocumentedClass;
import com.king.rbea.documenting.RbeaDocumentedMethod;

@RbeaDocumentedClass(summary = "Counter aggregator.")
public interface Counter extends DimensionalAggregator<Counter> {
	
	@RbeaDocumentedMethod(summary = "Increments the counter by 1.")
	void increment();

	@RbeaDocumentedMethod(summary = "Decrements the counter by 1.")
	void decrement();
}
