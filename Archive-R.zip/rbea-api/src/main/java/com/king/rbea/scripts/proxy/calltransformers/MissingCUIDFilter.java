package com.king.rbea.scripts.proxy.calltransformers;

import java.lang.reflect.Method;

import com.king.proxy.methods.MethodCallTransformer;
import com.king.rbea.Context;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.annotations.ProcessingPolicy;

import net.bytebuddy.description.method.MethodDescription;
import net.bytebuddy.implementation.bytecode.StackManipulation;
import net.bytebuddy.implementation.bytecode.member.MethodInvocation;
import net.bytebuddy.implementation.bytecode.member.MethodVariableAccess;
import net.bytebuddy.jar.asm.Label;
import net.bytebuddy.jar.asm.MethodVisitor;
import net.bytebuddy.jar.asm.Opcodes;

public class MissingCUIDFilter implements MethodCallTransformer {
	private static final long serialVersionUID = 1L;

	@Override
	public StackManipulation transform(Method targetMethod, StackManipulation sm) throws Exception {

		ProcessEvent pe = targetMethod.getAnnotation(ProcessEvent.class);
		ProcessingPolicy policy = pe.missingCUID();
		if (policy == ProcessingPolicy.PROCESS) {
			return sm;
		}

		StackManipulation getCUID = MethodInvocation.invoke(new MethodDescription.ForLoadedMethod(
				Context.class.getMethod("getCoreUserId")));

		return new StackManipulation() {

			@Override
			public Size apply(MethodVisitor methodVisitor,
					net.bytebuddy.implementation.Implementation.Context implementationContext) {

				Label noMatch = new Label();

				MethodVariableAccess.REFERENCE.loadFrom(2).apply(methodVisitor, implementationContext);
				getCUID.apply(methodVisitor, implementationContext);
				methodVisitor.visitJumpInsn(
						policy == ProcessingPolicy.IGNORE ? Opcodes.IFNULL : Opcodes.IFNONNULL, noMatch);

				Size methodSize = sm.apply(methodVisitor, implementationContext);
				methodVisitor.visitLabel(noMatch);
				methodVisitor.visitFrame(Opcodes.F_SAME, 0, null, 0, null);
				return new Size(methodSize.getSizeImpact(), methodSize.getMaximalSize());
			}

			@Override
			public boolean isValid() {
				return true;
			}

		};
	}

}