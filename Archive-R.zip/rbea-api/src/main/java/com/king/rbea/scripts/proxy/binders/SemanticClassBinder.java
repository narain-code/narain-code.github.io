package com.king.rbea.scripts.proxy.binders;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import com.king.event.Event;
import com.king.proxy.parameters.ParameterBinding;
import com.king.proxy.parameters.SingleParameterBinder;
import com.king.rbea.annotations.ProcessEvent;

import net.bytebuddy.description.method.MethodDescription;
import net.bytebuddy.implementation.bytecode.StackManipulation;
import net.bytebuddy.implementation.bytecode.member.MethodInvocation;
import net.bytebuddy.implementation.bytecode.member.MethodVariableAccess;

public class SemanticClassBinder implements SingleParameterBinder {
	private static final long serialVersionUID = 1L;

	@Override
	public Optional<ParameterBinding> bind(Method sm, Method targetMethod, Class<?> targetParamClass,
			List<Annotation> paramAnnotations, List<ParameterBinding> defaultBindings) throws Exception {

		// We only care about methods that are annotated with ProcessEvent
		ProcessEvent pe = targetMethod.getAnnotation(ProcessEvent.class);
		if (pe == null) {
			return Optional.empty();
		}

		Class<?>[] semClass = pe.semanticClass();

		if (!Arrays.asList(semClass).contains(targetParamClass)) {
			return Optional.empty();
		} else {
			MethodDescription scProcess = new MethodDescription.ForLoadedMethod(
					targetParamClass.getMethod("process", Event.class));

			// We bind the parameter by calling the static parses method:
			// semClass.process(event)
			return Optional.of(new ParameterBinding(targetParamClass,
					new StackManipulation.Compound(
							MethodVariableAccess.REFERENCE.loadFrom(1),
							MethodInvocation.invoke(scProcess))));
		}

	}

}