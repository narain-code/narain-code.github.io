package com.king.rbea.configuration.processor;

import java.io.IOException;
import java.io.Serializable;
import java.util.Map;
import java.util.Optional;

import org.apache.flink.api.common.typeutils.TypeSerializer;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.util.InstantiationUtil;

import com.king.rbea.configuration.Configuration;

/**
 * {@code DeploymentWithFields} wraps an {@link Deployment} object 
 * and attaches to it its fieldMappings, i.e. information
 * of the state.
 */
public class DeploymentWithFields extends ProcessorInfo {

	private static final long serialVersionUID = 1L;
	private final Deployment deployment;
	
	/**
	 * Mapping from field names to info of the field
	 * <p>
	 * <ul>
	 * <li>Key: field.name + procId
	 * <li>Value: Tuple of field id (1, 2, 3... unique within this key) and the TypeSerializer if the field.
	 * </ul> 
	 */
	private Map<String, Tuple2<Short, TypeSerializer<?>>> fieldMapping;

	public DeploymentWithFields(Deployment deployment, Map<String, Tuple2<Short, TypeSerializer<?>>> fieldMapping) {
		super(new Configuration());
		this.deployment = deployment;
		this.fieldMapping = fieldMapping;
	}

	public void updateFieldMapping(Map<String, Tuple2<Short, TypeSerializer<?>>> mapping) {
		this.fieldMapping = mapping;
	}

	public Map<String, Tuple2<Short, TypeSerializer<?>>> getFieldMapping() {
		return fieldMapping;
	}

	public Deployment getDeployment() {
		return deployment;
	}

	public Optional<Serializable> getRawValue(String key) {
		return getDeployment().getRawValue(key);
	}

	public void setRawValue(String key, Serializable value) {
		getDeployment().setRawValue(key, value);
	}

	public Tuple2<byte[], byte[]> createCheckpoint() throws IOException {
		byte[] depBytes = getDeployment().serialize();
		byte[] mappingBytes = InstantiationUtil.serializeObject(fieldMapping);
		return Tuple2.of(depBytes, mappingBytes);
	}

	public static DeploymentWithFields restoreFromCheckpoint(Tuple2<byte[], byte[]> cp)
			throws ClassNotFoundException, IOException, Exception {
		return new DeploymentWithFields(
				Configuration.deserialize(cp.f0),
				InstantiationUtil.deserializeObject(cp.f1, DeploymentWithFields.class.getClassLoader()));
	}

	public static DeploymentWithFields restoreFromCheckpoint(Tuple3<byte[], byte[], byte[]> cp)
			throws ClassNotFoundException, IOException, Exception {
		return new DeploymentWithFields(
				Configuration.deserialize(cp.f0),
				InstantiationUtil.deserializeObject(cp.f1, DeploymentWithFields.class.getClassLoader()));
	}

	@Override
	public byte[] serialize() {
		throw new UnsupportedOperationException(
				"This is an internal object, should not be serialized with this method.");
	}

	@Override
	protected boolean mergeToSummaryInternal(JobSummary summary) {
		return deployment.mergeToSummary(summary);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((deployment == null) ? 0 : deployment.hashCode());
		result = prime * result + ((fieldMapping == null) ? 0 : fieldMapping.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		DeploymentWithFields other = (DeploymentWithFields) obj;
		if (deployment == null) {
			if (other.deployment != null)
				return false;
		} else if (!deployment.equals(other.deployment))
			return false;
		if (fieldMapping == null) {
			if (other.fieldMapping != null)
				return false;
		} else if (!fieldMapping.equals(other.fieldMapping))
			return false;
		return true;
	}
}
