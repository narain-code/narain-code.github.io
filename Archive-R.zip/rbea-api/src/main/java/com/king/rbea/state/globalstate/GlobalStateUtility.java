package com.king.rbea.state.globalstate;

import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.regex.Pattern;

import org.apache.commons.lang.exception.ExceptionUtils;

import com.king.rbea.Output;
import com.king.rbea.exceptions.ProcessorException;

public class GlobalStateUtility {

    public final static int msPerHour = 3600000;
    public final static int msPerDay = 86400000;
    public final static int bytesPerGb = 1073741824;
    public final static int hrsPer30Days = 720;

    public final static Integer maxCountryNum = 64;
    public final static Integer maxSpendNum = 256;

    public final static String[] isoCountryCodes = Locale.getISOCountries();

    public final static Pattern regexHcItermType = Pattern.compile("2305|2400|2410|2420|3280|328011|328012|3520|4010|4011|4012|4013|4014|5000|5002|6000|6050|6051|6052|6053|7000|7007|7008|7009|7010|8000|8050|8051|8052|8053|9000|9050|11000|11007|11008|11009|11010|11500|12100|13000|14000|14007|14008|14009|14010|14400|15000|16100|16101|16102|16103|16104|16105|16106|16107|16108|16109|16110|16111|16112|20000|30010|31100|32010|32600|32602|32603|32604|32605|32700|32710|32711|32712|32713|32714|33010|34010|35100|37000|37001|37002|37003|37004|39000|39002|40100|40123|40210|40211|40212|40213|40214|50000|51010|52000|53000|53001|53002|53003|53004|53005|53006|54000|56000|60018|61000|62000|65001|65253|66000|66010|66020");

    public final static Pattern regexFid6HeadAndroid = Pattern.compile("76|75|73|68|66|64|61|42|39|36|33|31|27|26|19|18|17|13|10");
    public final static Pattern regexFid6HeadIos = Pattern.compile("76|75|73|68|66|64|61|42|39|36|33|31|27|26|19|18|17|13|10");
    public final static Pattern regexFid6HeadFlash = Pattern.compile("71|29|20|16|15|11");
    public final static Pattern regexFid6HeadWinPlatform = Pattern.compile("57|56|55|54");
    public final static Pattern regexFid6HeadWinPhone = Pattern.compile("53|52|51|50");
    public final static Pattern regexFid5HeadAndroid = Pattern.compile("80|30");
    public final static Pattern regexFid5HeadIos = Pattern.compile("90|70|10");
    public final static Pattern regexFid5HeadFlash = Pattern.compile("60|50|40|20");

    public final static String urlLatestKingConstants = "http://referenciador.int.midasplayer.com/king_constants/latest/";

    public final static String resourcePathKingConstants = "default_king_constants/";

    public static final class JuegoLevelMetadata {
        public int kingAppId;
        public int level;
        public int ordinal;
        public String description;
        public String releaseDate;

        @Override
        public String toString() {
            return "JuegoLevelMeta [kingAppId=" + kingAppId + ", level=" + level + ", ordinal=" + ordinal
                    + ", description=" + description + ", releaseDate=" + releaseDate + "]";
        }

        public static String getUrl() {
            return urlLatestKingConstants + "JuegoLevelMetadata.json";
        }

        public static String getResourcePath() {
            return resourcePathKingConstants + "JuegoLevelMetadata.json";
        }
    }

    public static final class SagaLevelMetadata {
        public int kingAppId;
        public int episode;
        public int level;
        public int ordinal;
        public String description;

        @Override
        public String toString() {
            return "JuegoLevelMeta [kingAppId=" + kingAppId + ", episode=" + episode
                    + ", level=" + level + ", ordinal=" + ordinal + ", description=" + description + "]";
        }

        public static String getUrl() {
            return urlLatestKingConstants + "SagaLevelMetadata.json";
        }

        public static String getResourcePath() {
            return resourcePathKingConstants + "SagaLevelMetadata.json";
        }
    }

    public enum Platforms {
        UNKNOWN("unknown"),
        ANDROID("android"),
        IOS("ios"),
        FLASH_HTML("flash/html"),
        WIN_PLATFORM("windows platform (uwp)"),
        WIN_PHONE("windows phone");

        private final String str;

        private Platforms(String s) {
            str = s;
        }

        @Override
        public String toString() {
            return this.str;
        }
    }


    private final static String LOG_TOPIC = "rbea.globalstate.log";
    
	public static void log(String msg, Throwable e, Output out) throws ProcessorException {
		log(msg + "\n" + ExceptionUtils.getStackTrace(e), out);
	}

	public static void log(String msg, Output out) throws ProcessorException {
		out.writeToKafka(LOG_TOPIC, msg);
	}

    public static <T> void historyCleanup(TreeMap<Long, T> inputTreeMap, Long now, Integer hrs2keep, Integer maxTreeMapElements) {
        if (inputTreeMap.size() > 1) {
            Set<Long> MstsToRemove = new HashSet<>();
            Long previousKey = null;
            for (Map.Entry<Long, T> entry : inputTreeMap.entrySet()) {
                if (previousKey != null) {
                    if (GlobalStateUtility.elapsedHours(entry.getKey(), now) >= hrs2keep) {
                        MstsToRemove.add(previousKey);
                    } else {
                        break;
                    }
                }
                previousKey = entry.getKey();
            }
            // Remove the entries that is totally outside of specified days (but not the partially ones)
            for (Long msts : MstsToRemove) {
                inputTreeMap.remove(msts);
            }
            // Apply limit of the treemap capacity
            int tmSize = inputTreeMap.size();
            if (tmSize > maxTreeMapElements) {
                for (int i = 0; i < tmSize - maxTreeMapElements; i ++) {
                    inputTreeMap.remove(inputTreeMap.firstKey());
                }
            }
        }
    }

    public static <T> Double historySum(TreeMap<Long, T> inputTreeMap, Long limitMsts) {
        Double spendWindowSum = 0d;
        if (inputTreeMap.size() > 0) {
            try {
                for (Map.Entry<Long, T> entry : inputTreeMap.entrySet()) {
                    if (entry.getKey() >= limitMsts) {
                        spendWindowSum += (Double) entry.getValue();
                    }
                }
            } catch (Exception e) {}
        }
        return spendWindowSum;
    }

    public static <T> Integer historyCount(TreeMap<Long, T> inputTreeMap, Long limitMsts) {
        Integer spendWindowCount = 0;
        if (inputTreeMap.size() > 0) {
            try {
                for (Map.Entry<Long, T> entry : inputTreeMap.entrySet()) {
                    if (entry.getKey() >= limitMsts) {
                        spendWindowCount += 1;
                    }
                }
            } catch (Exception e) {}
        }
        return spendWindowCount;
    }

    public static String getPlatformFromFid(Integer flavourId) {
        String platform = Platforms.UNKNOWN.toString();
        
		if (flavourId == null) {
			return platform;
		}

        if (flavourId >= 0 && flavourId < 1e6) {
            String flavourStr = String.valueOf(flavourId);
            int fidLen = flavourStr.length();

            if (fidLen == 6) {
                String fidHead = flavourStr.substring(0, 2);
                if (regexFid6HeadAndroid.matcher(fidHead).matches()) {
                    platform = Platforms.ANDROID.toString();
                } else if (regexFid6HeadIos.matcher(fidHead).matches()) {
                    platform = Platforms.IOS.toString();
                } else if (regexFid6HeadFlash.matcher(fidHead).matches()) {
                    platform = Platforms.FLASH_HTML.toString();
                } else if (regexFid6HeadWinPlatform.matcher(fidHead).matches()) {
                    platform = Platforms.WIN_PLATFORM.toString();
                } else if (regexFid6HeadWinPhone.matcher(fidHead).matches()) {
                    platform = Platforms.WIN_PHONE.toString();
                }
            } else if (fidLen == 5) {
                String fidHead = flavourStr.substring(0, 2);
                if (regexFid5HeadAndroid.matcher(fidHead).matches()) {
                    platform = Platforms.ANDROID.toString();
                } else if (regexFid5HeadIos.matcher(fidHead).matches()) {
                    platform = Platforms.IOS.toString();
                } else if (regexFid5HeadFlash.matcher(fidHead).matches()) {
                    platform = Platforms.FLASH_HTML.toString();
                }
            } else if (fidLen <= 3) {
                platform = Platforms.FLASH_HTML.toString();
            }
        }

        return platform;
    }

    public static boolean isHcItemType(Long type) {
	    if (type == null) {
	        return false;
        }
	    return regexHcItermType.matcher(String.valueOf(type)).matches() ? true : false;
    }

    public static double elapsedHours(long st, long et) {
        if(et <= st){
            return 0.0;
        }else{
            return Double.valueOf(et - st) / msPerHour;
        }
    }
}
