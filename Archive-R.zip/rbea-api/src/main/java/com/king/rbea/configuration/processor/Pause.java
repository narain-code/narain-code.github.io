package com.king.rbea.configuration.processor;

import com.king.rbea.configuration.Configuration;

/**
 * {@code Pause} is a {@link ProcessorInfo} a pausing processor,
 * i.e. removing it from processors that are processing events,
 * but not removing it completely, e.g. state remains.
 * Such a job can later be resumed using {@link Resume}.
 */
public class Pause extends ProcessorInfo {
	private static final long serialVersionUID = 1L;

	public Pause(long procId, long pauseTime) {
		super(procId);
		
		setLong(JobSummary.JOB_END_TIME_KEY, pauseTime);
	}
	
	public Pause(Configuration conf) {
		super(conf);
	}
	
	@Override
	protected boolean mergeToSummaryInternal(JobSummary summary) {
		boolean alreadyPaused = summary.getString(JobSummary.JOB_STATE_KEY).orElse("").equals(JobSummary.JOB_STATE_PAUSED);
		
		// Job status update
		summary.setString(JobSummary.JOB_STATE_KEY, JobSummary.JOB_STATE_PAUSED);
		summary.setString(JobSummary.JOB_STATE_DESCRIPTION_KEY, JobSummary.JOB_STATE_DESCRIPTION_PAUSED);
		summary.setLong(JobSummary.JOB_END_TIME_KEY, getLong(JobSummary.JOB_END_TIME_KEY).get());

		// Legacy
		summary.setString(JobSummary.JOB_STATUS_KEY, JobSummary.JOB_STATUS_STOPPED);
		summary.setString(JobSummary.STOP_REASON_KEY, JobSummary.STOP_REASON_PAUSE);
		return !alreadyPaused;
	}
	
	@Override
	public String toString() {
		return "Pause(" + getProcessorId() + ")";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		long processorId = super.getProcessorId();
		result = prime * result + (int) (processorId ^ (processorId >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Pause other = (Pause) obj;
		long processorId = super.getProcessorId();
		if (processorId != other.getProcessorId())
			return false;
		return true;
	}
}
