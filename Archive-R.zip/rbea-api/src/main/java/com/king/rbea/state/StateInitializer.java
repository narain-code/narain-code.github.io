package com.king.rbea.state;

import java.io.Serializable;

import com.king.rbea.documenting.RbeaDocumentedClass;

@RbeaDocumentedClass(summary = "State initializer function that is called for each core user the first time the state is accessed.")
public interface StateInitializer<S> extends Serializable {
	S initialize(long coreId) throws Exception;
}
