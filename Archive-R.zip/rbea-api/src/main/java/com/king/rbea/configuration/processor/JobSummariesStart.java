package com.king.rbea.configuration.processor;

import com.king.rbea.configuration.Configuration;

/**
 * {@code JobSummariesStart} indicates start of {@link JobSummary}-objects.
 */
public class JobSummariesStart extends Configuration {
	private static final long serialVersionUID = 1L;

	public JobSummariesStart() {
		super();
	}

	public JobSummariesStart(Configuration conf) {
		super(conf);
	}
	
	@Override
	public String toString() {
		return "JobSummariesStart()";
	}
}
