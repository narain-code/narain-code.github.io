package com.king.rbea.scripts.info;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import com.king.rbea.scripts.info.ConfigClassSchema.ScriptConfigInfo;
import com.king.rbea.state.StateDescriptor;

public interface EventProcessorInfo extends Serializable {

	boolean hasInitMethod();

	boolean hasCloseMethod();

	Optional<Integer> getMaxErrorsPerMin();

	boolean hasOnTimerMethod();

	boolean hasOnSessionEndMethod();

	boolean hasProcessEventMethod();

	boolean hasAsyncMethods();

	ScriptConfigInfo getConfigSchema();

	List<StateDescriptor<?>> getStates();

}
