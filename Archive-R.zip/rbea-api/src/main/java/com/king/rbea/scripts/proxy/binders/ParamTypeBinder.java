package com.king.rbea.scripts.proxy.binders;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Optional;

import com.king.proxy.parameters.DefaultParameterBinder;
import com.king.proxy.parameters.ParameterBinding;
import com.king.proxy.parameters.SingleParameterBinder;
import com.king.rbea.TimerContext;
import com.king.rbea.annotations.Param;
import com.king.rbea.annotations.ParamType;

import net.bytebuddy.description.method.MethodDescription;
import net.bytebuddy.implementation.bytecode.StackManipulation;
import net.bytebuddy.implementation.bytecode.member.MethodInvocation;
import net.bytebuddy.implementation.bytecode.member.MethodVariableAccess;

public class ParamTypeBinder implements SingleParameterBinder {
	private static final long serialVersionUID = 1L;
	private int contextParamPos;

	public ParamTypeBinder(int contextParamPos) {
		this.contextParamPos = contextParamPos;
	}

	@Override
	public Optional<ParameterBinding> bind(Method sm, Method tm, Class<?> targetParamClass,
			List<Annotation> paramAnnotations,
			List<ParameterBinding> bindings) throws Exception {

		Optional<Annotation> paramAnnot = paramAnnotations.stream()
				.filter(a -> a instanceof Param).findAny();

		if (paramAnnot.isPresent()) {
			ParamType pt = ((Param) paramAnnot.get()).value();

			switch (pt) {
			case CUID:
				return selectBindingByName("getCoreUserId", bindings);
			case TimeStamp:
				return selectBindingByName("getTimeStamp", bindings);
			case TimerId:
				return selectBindingByName("getTimerId", bindings);
			case TimerParam:
				StackManipulation getter = new StackManipulation.Compound(
						MethodVariableAccess.REFERENCE.loadFrom(contextParamPos),
						MethodInvocation.invoke(new MethodDescription.ForLoadedMethod(
								TimerContext.class.getMethod("getTimerParam"))));
				getter = DefaultParameterBinder.load(Object.class, targetParamClass, getter);
				return Optional.of(new ParameterBinding(Object.class, getter));
			default:
				throw new RuntimeException();
			}
		}

		return Optional.empty();
	}

	private Optional<ParameterBinding> selectBindingByName(String name, List<ParameterBinding> defaultBindings) {
		for (ParameterBinding pb : defaultBindings) {
			if (pb.getMethod().isPresent() && pb.getMethod().get().getName().equals(name)) {
				return Optional.of(pb);
			}
		}
		return Optional.empty();
	}

}