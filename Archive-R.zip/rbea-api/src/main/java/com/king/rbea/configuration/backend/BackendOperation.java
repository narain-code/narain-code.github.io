package com.king.rbea.configuration.backend;

import org.apache.commons.lang3.Validate;

import com.king.rbea.configuration.Configuration;

public abstract class BackendOperation extends Configuration {

	private static final long serialVersionUID = 1L;

	public static final String TIMESTAMP = "timestamp";
	public static final String VALID_BEFORE = "validBefore";
	public static final String TOPIC_KEY = "topic";
	public static final String OPERATION_ID = "operationId";

	protected BackendOperation(long operationId, String topic, long timestamp, long validBefore) {
		super();
		setLong(OPERATION_ID, operationId);
		setLong(TIMESTAMP, timestamp);
		setLong(VALID_BEFORE, validBefore);
		setString(TOPIC_KEY, Validate.notNull(topic, "Topic cannot be null for backend operations"));
	}

	protected BackendOperation(Configuration conf) {
		super(conf);
	}

	public long getTimestamp() {
		return getLong(TIMESTAMP).get();
	}

	public boolean isValid(long currentTime) {
		return getLong(VALID_BEFORE).get() < currentTime;
	}

	public boolean isValid() {
		return isValid(System.currentTimeMillis());
	}

	public String getTopic() {
		return getString(TOPIC_KEY).get();
	}

	public long getOperationId() {
		return getLong(OPERATION_ID).get();
	}
}