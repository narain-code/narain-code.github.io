package com.king.rbea.state.export;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Optional;

import org.apache.avro.Schema;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.io.BinaryDecoder;
import org.apache.avro.io.DatumReader;
import org.apache.avro.io.DecoderFactory;
import org.apache.flink.api.java.tuple.Tuple2;

public interface StateExportDeserializer {

	public Optional<DatumReader<GenericRecord>> getReader(String schemaName);

	default public Optional<GenericRecord> deserializeRecord(Tuple2<String, byte[]> t) throws Exception {
		ByteArrayInputStream bis = new ByteArrayInputStream(t.f1);
		BinaryDecoder decoder = DecoderFactory.get().binaryDecoder(bis, null);
		Optional<DatumReader<GenericRecord>> opt = getReader(t.f0);
		if (opt.isPresent()) {
			return Optional.of(opt.get().read(null, decoder));
		} else {
			return Optional.empty();
		}
	}

	public static Tuple2<String, byte[]> extractSchemaName(byte[] bytes) throws Exception {
		ByteArrayInputStream bis = new ByteArrayInputStream(bytes);
		DataInputStream in = new DataInputStream(bis);
		byte[] nb = new byte[in.readInt()];
		in.read(nb, 0, nb.length);
		byte[] recordBytes = new byte[bytes.length - (Integer.BYTES + nb.length)];
		in.read(recordBytes, 0, recordBytes.length);
		return Tuple2.of(new String(nb, StandardCharsets.UTF_8), recordBytes);

	}

	public static Tuple2<Long, Schema> deserializeSchema(byte[] bytes) throws Exception {
		ByteArrayInputStream bis = new ByteArrayInputStream(bytes);

		byte[] procIdBytes = new byte[Long.BYTES];
		bis.read(procIdBytes, 0, Long.BYTES);
		ByteBuffer buffer = ByteBuffer.allocate(Long.BYTES).put(procIdBytes);
		buffer.flip();
		long procId = buffer.getLong();

		byte[] schemaBytes = new byte[bytes.length - Long.BYTES];
		bis.read(schemaBytes, 0, schemaBytes.length);
		String schema = new String(schemaBytes, StandardCharsets.UTF_8);
		return Tuple2.of(procId, new Schema.Parser().parse(schema));
	}
}