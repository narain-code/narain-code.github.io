package com.king.rbea.state.util;

import java.io.Serializable;
import java.time.ZoneId;
import java.util.Optional;
import java.util.function.Function;

@SuppressWarnings("serial")
public class TimeZoneMapper implements Function<String, ZoneId>, Serializable {

    @Override
    public ZoneId apply(String rawTimeZone) {
        return Optional.ofNullable(rawTimeZone)
            .map(String::trim)
            .map(tz -> {
                try {
                    return ZoneId.of(tz).normalized();
                } catch (Exception e) {
                    return null;
                }
            })
            .orElse(null);
    }

}
