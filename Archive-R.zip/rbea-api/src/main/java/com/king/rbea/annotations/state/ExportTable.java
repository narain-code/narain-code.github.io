package com.king.rbea.annotations.state;

import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
@Inherited
public @interface ExportTable {
	String value() default "";
	
	String name() default "";

	boolean kafka() default false;

	ExportColumn[] leadingColumns() default {};
}
