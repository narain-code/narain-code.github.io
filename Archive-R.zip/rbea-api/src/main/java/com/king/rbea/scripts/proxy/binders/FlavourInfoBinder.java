package com.king.rbea.scripts.proxy.binders;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Optional;

import com.king.event.Event;
import com.king.proxy.parameters.ParameterBinding;
import com.king.proxy.parameters.SingleParameterBinder;
import com.king.rbea.Context;
import com.king.rbea.Utils;
import com.king.utils.FlavourInfo;
import com.king.utils.Flavours;

import net.bytebuddy.description.method.MethodDescription;
import net.bytebuddy.implementation.bytecode.StackManipulation;
import net.bytebuddy.implementation.bytecode.member.MethodInvocation;
import net.bytebuddy.implementation.bytecode.member.MethodVariableAccess;

@SuppressWarnings("deprecation")
public class FlavourInfoBinder implements SingleParameterBinder {
	private static final long serialVersionUID = 1L;

	public int eventOffset;
	public int ctxOffset;

	public FlavourInfoBinder() {
		this(1, 2);
	}

	public FlavourInfoBinder(int eventOffset, int ctxOffset) {
		this.eventOffset = eventOffset;
		this.ctxOffset = ctxOffset;
	}

	@Override
	public Optional<ParameterBinding> bind(Method sourceMethod, Method targetMethod,
			Class<?> targetParamType, List<Annotation> paramAnnotations,
			List<ParameterBinding> possibleBindings)
			throws Exception {

		if (!targetParamType.equals(FlavourInfo.class)) {
			return Optional.empty();
		}

		MethodDescription utilsGetter = new MethodDescription.ForLoadedMethod(Context.class.getMethod("getUtils"));
		MethodDescription flavoursGetter = new MethodDescription.ForLoadedMethod(Utils.class.getMethod("getFlavours"));
		MethodDescription flavourInfoGetter = new MethodDescription.ForLoadedMethod(
				Flavours.class.getMethod("getInfo", Event.class));

		return Optional.of(new ParameterBinding(
				targetParamType,
				new StackManipulation.Compound(
						MethodVariableAccess.REFERENCE.loadFrom(ctxOffset),
						MethodInvocation.invoke(utilsGetter),
						MethodInvocation.invoke(flavoursGetter),
						MethodVariableAccess.REFERENCE.loadFrom(eventOffset),
						MethodInvocation.invoke(flavourInfoGetter))));
	}
}