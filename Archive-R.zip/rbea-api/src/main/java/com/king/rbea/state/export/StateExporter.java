package com.king.rbea.state.export;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.BiFunction;

import org.apache.avro.Schema;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.generic.GenericRecordBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.king.rbea.Context;
import com.king.rbea.annotations.state.ExportColumn;
import com.king.rbea.exceptions.ProcessorException;

public class StateExporter {
	
	private static final Logger LOG = LoggerFactory.getLogger(StateExporter.class);

	private final ExportColumn[] leadingFields;
	private final Map<String, BiFunction<Object, Context, ?>> instanceFieldAccessors;
	private final GenericRecordBuilder builder;

	private final String topic;
	private final StateExportSerializer serializer;

	public StateExporter(Schema schema, ExportColumn[] leadingFields,
			Map<String, BiFunction<Object, Context, ?>> instanceFieldAccessors, String exportTopic) {
		this.leadingFields = leadingFields;
		this.instanceFieldAccessors = instanceFieldAccessors;
		this.builder = new GenericRecordBuilder(schema);
		this.topic = exportTopic;
		this.serializer = new StateExportSerializer(schema);
	}

	public void exportStates(Object instance, Object[] leadingFields, Context ctx) throws Exception {
		ctx.getOutput()
				.writeBytesToKafka(topic,
						// Set Kafka msg key to core user id
						ByteBuffer.allocate(Long.BYTES).putLong(ctx.getCoreUserId()).array(),
						// Export state bytes as avro
						serializer.serializeRecord(buildExportRecord(instance, leadingFields, ctx)));
	}

	private GenericRecord buildExportRecord(Object instance, Object[] leadingFieldValues, Context ctx)
			throws ProcessorException {

		if (leadingFields.length != leadingFieldValues.length) {
			throw new ProcessorException(
					"Number of arguments passed to state.export(...) doesn't match number of leading ExportFields");
		}

		for (int i = 0; i < leadingFields.length; i++) {
			builder.set(leadingFields[i].name(), leadingFieldValues[i]);
		}

		for (Entry<String, BiFunction<Object, Context, ?>> e : instanceFieldAccessors.entrySet()) {
			Object exportedVal = e.getValue().apply(instance, ctx);
			builder.set(e.getKey(), exportedVal);
		}
		return builder.build();
	}

	public static StateExporter getFor(long procId, Object scriptInstance, Context ctx) throws ProcessorException {
		final ExportMetadata metadata = ExportMetadata.extract(scriptInstance.getClass());

		if (metadata == null) {
			return null;
		}

		if (metadata.isEmpty()) {
			throw new ProcessorException("Doesn't seem to be (Export)ing any state. Weird...");
		}

		final Schema schema = metadata.schema();

		if (ctx != null) {
			ctx.getOutput().writeBytesToKafka(ctx.getOutput().getStateSchemaExportTopic(),
					schema.getFullName().getBytes(StandardCharsets.UTF_8),
					StateExportSerializer.serializeSchema(schema, procId));
		}
		
		if(ctx !=null && ctx.getOutput()!=null)
		return new StateExporter(schema, metadata.leadingColumns(), metadata.exportFunctions(),
				metadata.kafka() ? metadata.tableName() : ctx.getOutput().getStateExportTopic());
		else{
			return new StateExporter(schema, metadata.leadingColumns(), metadata.exportFunctions(),
					metadata.kafka() ? metadata.tableName() : "rbea.exportstate.test.log");
		}
	}
}
