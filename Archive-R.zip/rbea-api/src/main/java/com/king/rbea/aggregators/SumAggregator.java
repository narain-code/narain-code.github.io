package com.king.rbea.aggregators;

import com.king.rbea.documenting.RbeaDocumentedClass;
import com.king.rbea.documenting.RbeaDocumentedMethod;

@RbeaDocumentedClass(summary = "Sum aggregators.")
public interface SumAggregator extends DimensionalAggregator<SumAggregator> {

	@RbeaDocumentedMethod(summary = "Adds the given value to the aggregator.")
	void add(long num);
}
