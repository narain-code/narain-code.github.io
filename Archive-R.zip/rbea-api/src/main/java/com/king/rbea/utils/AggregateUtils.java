package com.king.rbea.utils;

import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.sling.commons.json.JSONObject;

import com.king.rbea.aggregators.DimensionType;
import com.king.rbea.exceptions.ProcessorException;

public class AggregateUtils {

	@SuppressWarnings("unchecked")
	public static String createDimJSON(Map<String, ?> dimensions, Set<String> longDims)
			throws ProcessorException {
		if (dimensions == null || dimensions.isEmpty()) {
			return "{}";
		}

		for (Entry<String, Object> entry : ((Map<String, Object>) dimensions).entrySet()) {
			String key = entry.getKey();
			Object value = entry.getValue();

			if (key == null || key.equals("")) {
				throw new ProcessorException("Cannot have empty dimension name");
			}

			if (value == null) {
				throw new ProcessorException("Dimension cannot be null");
			}

			DimensionType type = longDims == null || !longDims.contains(key) ? DimensionType.STRING
					: DimensionType.LONG;

			if (type == DimensionType.LONG) {
				if (!(value instanceof Number)) {
					throw new ProcessorException("Dimension value must be a number if type is set to LONG");
				}
				Number num = ((Number) value);
				long longValue = num.longValue();
				if (longValue != num.doubleValue()) {
					throw new ProcessorException("Number dimensions must be long values");
				} else {
					entry.setValue(longValue);
				}
			} else {
				String stringVal = value.toString();
				if (stringVal.length() > 255) {
					throw new ProcessorException("String dimension (encoded) longer than 255 chars.");
				} else {
					entry.setValue(stringVal);
				}
			}
		}

		return new JSONObject(dimensions).toString();
	}

}
