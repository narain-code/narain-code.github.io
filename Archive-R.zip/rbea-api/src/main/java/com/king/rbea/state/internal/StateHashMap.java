package com.king.rbea.state.internal;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Function;

import com.king.flink.utils.Unchecked;
import com.king.rbea.state.LocalState;

public class StateHashMap<K, V> extends HashMap<K, V> {
	public static final class State<K, V> extends LocalState<HashMap<K, V>> {
		private static final long serialVersionUID = 1L;

		public State(String name) {
			super(name);
		}

		@Override
		public HashMap<K, V> getValue(long coreId, InternalState state) throws Exception {
			return new StateHashMap<>(state);
		}
	}

	private static final long serialVersionUID = 1L;
	private HashMap<K, V> localState = null;
	private final InternalState state;

	public StateHashMap(InternalState state) {
		this.state = state;
	}

	@SuppressWarnings("unchecked")
	private void loadState() {
		try {
			if (localState == null) {
				Object val = state.readValue();
				localState = (HashMap<K, V>) (val != null ? val : new HashMap<>());
			}
		} catch (Exception ex) {
			Unchecked.throwSilently(ex);
		}
	}

	private void updateState() {
		try {
			state.writeValue(localState.isEmpty() ? null : localState);
		} catch (Exception ex) {
			Unchecked.throwSilently(ex);
		}
	}

	@Override
	public int size() {
		loadState();
		return localState.size();
	}

	@Override
	public boolean isEmpty() {
		loadState();
		return localState.isEmpty();
	}

	@Override
	public boolean containsKey(Object key) {
		loadState();
		return localState.containsKey(key);
	}

	@Override
	public boolean containsValue(Object value) {
		loadState();
		return localState.containsValue(value);
	}

	@Override
	public V get(Object key) {
		loadState();
		return localState.get(key);
	}

	@Override
	public V put(K key, V value) {
		loadState();
		V removed = localState.put(key, value);
		updateState();
		return removed;
	}

	@Override
	public V remove(Object key) {
		loadState();
		V removed = localState.remove(key);
		updateState();
		return removed;
	}

	@Override
	public void putAll(Map<? extends K, ? extends V> m) {
		loadState();
		localState.putAll(m);
		updateState();
	}

	@Override
	public void clear() {
		loadState();
		localState.clear();
		updateState();
	}

	@Override
	public Set<K> keySet() {
		loadState();
		return localState.keySet();
	}

	@Override
	public Collection<V> values() {
		loadState();
		return localState.values();
	}

	@Override
	public Set<Entry<K, V>> entrySet() {
		loadState();
		return localState.entrySet();
	}

	@Override
	public boolean equals(Object o) {
		loadState();
		return localState.equals(o);
	}

	@Override
	public int hashCode() {
		loadState();
		return localState.hashCode();
	}

	@Override
	public V getOrDefault(Object key, V defaultValue) {
		loadState();
		return localState.getOrDefault(key, defaultValue);
	}

	@Override
	public void forEach(BiConsumer<? super K, ? super V> action) {
		loadState();
		localState.forEach(action);
	}

	@Override
	public void replaceAll(BiFunction<? super K, ? super V, ? extends V> function) {
		loadState();
		localState.replaceAll(function);
		updateState();
	}

	@Override
	public V putIfAbsent(K key, V value) {
		loadState();
		V removed = localState.putIfAbsent(key, value);
		updateState();
		return removed;
	}

	@Override
	public boolean remove(Object key, Object value) {
		loadState();
		boolean removed = localState.remove(key, value);
		updateState();
		return removed;
	}

	@Override
	public boolean replace(K key, V oldValue, V newValue) {
		loadState();
		boolean replaced = localState.replace(key, oldValue, newValue);
		updateState();
		return replaced;
	}

	@Override
	public V replace(K key, V value) {
		loadState();
		V replaced = localState.replace(key, value);
		updateState();
		return replaced;
	}

	@Override
	public V computeIfAbsent(K key, Function<? super K, ? extends V> mappingFunction) {
		loadState();
		V replaced = localState.computeIfAbsent(key, mappingFunction);
		updateState();
		return replaced;
	}

	@Override
	public V computeIfPresent(K key, BiFunction<? super K, ? super V, ? extends V> remappingFunction) {
		loadState();
		V replaced = localState.computeIfPresent(key, remappingFunction);
		updateState();
		return replaced;
	}

	@Override
	public V compute(K key, BiFunction<? super K, ? super V, ? extends V> remappingFunction) {
		loadState();
		V replaced = localState.compute(key, remappingFunction);
		updateState();
		return replaced;
	}

	@Override
	public V merge(K key, V value, BiFunction<? super V, ? super V, ? extends V> remappingFunction) {
		loadState();
		V replaced = localState.merge(key, value, remappingFunction);
		updateState();
		return replaced;
	}
}
