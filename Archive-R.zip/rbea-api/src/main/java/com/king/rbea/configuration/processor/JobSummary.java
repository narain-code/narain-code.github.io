package com.king.rbea.configuration.processor;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.codec.digest.DigestUtils;

import com.king.rbea.configuration.Configuration;
import com.king.rbea.manager.types.ParameterSet;

/**
 * {@code JobSummary} is a storage for summary information such as whether it
 * has failed of a single processor.
 * <p>
 * {@link #export(boolean)} method is used to read the information of
 * {@code JobSummary}.
 * <p>
 * {@link ProcessorInfo#mergeToSummaryInternal(JobSummary)} is used to update a
 * {@code JobSummary} based on an a {@link ProcessorInfo}. Typical
 * implementation such as {@code {@link
 * Deployment#mergeToSummaryInternal(JobSummary)}} eventually calls
 * {@link #addAll(Map)} to update the instance.
 */
public class JobSummary extends ProcessorInfo {
	private static final long serialVersionUID = 1L;

	public static final String ALL_OUTPUTS_KEY = "outputs";
	public static final String SCRIPT_HASH = "scriptMD5";

	/**
	 * The key the UI uses to illustrate the state of the job.
	 */
	public static final String JOB_STATE_KEY = "state";
	
	/**
	 * A value of {@link #JOB_STATE_KEY} of a job that
	 * is running normally.
	 */
	public static final String JOB_STATE_RUNNING = "RUNNING";

	/**
	 * A value of {@link #JOB_STATE_KEY} of a job that
	 * has been paused with a {@link Pause}.
	 */
	public static final String JOB_STATE_PAUSED = "PAUSED";

	/**
	 * A value of {@link #JOB_STATE_KEY} of a job that
	 * has been failed.
	 */
	public static final String JOB_STATE_FAILED = "FAILED";
	
	/**
	 * The key the UI uses to illustrate the description of the state of the job.
	 */
	public static final String JOB_STATE_DESCRIPTION_KEY = "description";

	/**
	 * A value of {@link #JOB_STATE_DESCRIPTION_KEY} of a job that
	 * has been paused with a {@link Pause}.
	 */
	public static final String JOB_STATE_DESCRIPTION_PAUSED = "Paused";

	/**
	 * The time the job last time entered {@link #JOB_STATE_RUNNING}.
	 * If failed ({@link Failure} before was running, the time when failed.
	 * -1 initially.
	 */
	public static final String JOB_START_TIME_KEY = "startTime";

	/**
	 * The first time the job last entered {@link #JOB_STATE_RUNNING}.
	 * If failed ({@link Failure} before was running, the time when failed.
	 * -1 initially.
	 */
	public static final String JOB_CREATED_TIME_KEY = "createdTime";
		
	/**
	 * If the job is not running (JOB_STATE_KEY != JOB_STATE_RUNNING),
	 * the time when the stopping took place, otherwise -1.
	 */
	public static final String JOB_END_TIME_KEY = "endTime";

	/**
	 * If JOB_STATE_KEY == JOB_STATE_FAILED, the stacktrace if available.
	 * Otherwise empty.
	 */
	public static final String JOB_STACK_TRACE_KEY = "error_stacktrace";
	
	/**
	 * LEGACY. Indicates the running status of the job.
	 */
	public static final String JOB_STATUS_KEY = "status";
	
	/**
	 * A initial value for JOB_STATUS_KEY. Indicates the job is running.
	 */
	public static final String JOB_STATUS_RUNNING = "RUNNING";

	/**
	 * A value for JOB_STATUS_KEY. Indicates the job is not 
	 * currently running, set in {@link Failure}, {@link Pause}.
	 */
	public static final String JOB_STATUS_STOPPED = "STOPPED";

	/**
	 * LEGACY. Indicates in case JOB_STATUS_KEY is not RUNNING_KEY,
	 * why so. If job is running, an empty String.
	 */
	public static final String STOP_REASON_KEY = "stopReason";
	
	/**
	 * A value for STOP_REASON_KEY indicating the job failed.
	 * Used in {@link Failure}.
	 */
	public static final String STOP_REASON_ERROR = "ERROR";

	/**
	 * A value for STOP_REASON_KEY indicating the job is paused.
	 * Used in {@link Pause}.
	 */
	public static final String STOP_REASON_PAUSE = "PAUSE";

	/**
	 * The key that contains tags information, as a map
	 * family -> innerMap, innermap: tag -> value.
	 */
	public static final String TAGS_JOB_PROPERTY_KEY = "tags";
	
	/**
	 * LEGACY. A shortcut/view: Indicates whether STOP_REASON_KEY is STOP_REASON_ERROR.
	 */
	public static final String FAILED_KEY = "failed";
	
	/**
	 * LEGACY. A shortcut/view Indicates whether JOB_STATUS_KEY is JOB_STATUS_RUNNING.
	 */
	public static final String RUNNING_KEY = "running";

	/**
	 * Constructs a {@code JobSummary} for {@code procId} with default values.
	 * 
	 * @param procId the id of the processor
	 */
	public JobSummary(long procId) {
		super(procId);

		setString(JOB_STATE_KEY, JOB_STATE_RUNNING);
		setString(JOB_STATE_DESCRIPTION_KEY, "");
		
		setLong(JobSummary.JOB_CREATED_TIME_KEY, -1);
		setLong(JobSummary.JOB_START_TIME_KEY, -1);
		setLong(JobSummary.JOB_END_TIME_KEY, -1);
		setString(Failure.FAILURE_CAUSE_KEY, "");
		setString(Deployment.TOPIC_KEY, "");
		setRawValue(ALL_OUTPUTS_KEY, new ArrayList<>());

		// Legacy
		setString(JOB_STATUS_KEY, JOB_STATUS_RUNNING);
		setString(STOP_REASON_KEY, "");
	}

	/**
	 * Constructs a {@link JobSummary} without setting values. This constructor is
	 * called using reflection e.g. in {@link ProcessorInfo#deserialize(byte[])}.
	 * 
	 * @param conf
	 */
	public JobSummary(Configuration conf) {
		super(conf);
	}

	/**
	 * Creates a new {@link Map} with the contents of self, excluding some fields
	 * and adding a some fields.
	 * 
	 * @param runtimeStatistics
	 *            whether to include RuntimeStatistics in the response
	 * @return the created {@link Map}
	 */
	public Map<String, Serializable> export() {
		Map<String, Serializable> map = toMap();
		map.remove(Configuration.CONFIG_CLASS_KEY);
		map.remove(Deployment.SCRIPT_TEXT_KEY);
		map.put(SCRIPT_HASH, getScriptMD5());
		
		map.put(FAILED_KEY, getString(STOP_REASON_KEY).get().equals(STOP_REASON_ERROR));
		map.put(RUNNING_KEY, getString(JOB_STATUS_KEY).get().equals(JOB_STATUS_RUNNING));
		return map;
	}

	@Override
	public String toString() {
		return "JobSummary: " + super.toString();
	}

	@SuppressWarnings("unchecked")
	public List<ParameterSet> getAllOutputs() {
		return (List<ParameterSet>) getRawValue(ALL_OUTPUTS_KEY).get();
	}

	@Override
	public void addAll(Map<String, ? extends Serializable> map) {
		lock();
		try {
			map.forEach((k, v) -> {
				if (!k.equals(Configuration.CONFIG_CLASS_KEY)) {
					setRawValue(k, v);
				}
			});
		} finally {
			unlock();
		}
	}

	private String getScriptMD5() {
		return getString(Deployment.SCRIPT_TEXT_KEY).map(s -> DigestUtils.md5Hex(s)).orElse("");
	}

	@Override
	protected boolean mergeToSummaryInternal(JobSummary summary) {
		throw new UnsupportedOperationException("JobSummaries should never be merged");
	}
}