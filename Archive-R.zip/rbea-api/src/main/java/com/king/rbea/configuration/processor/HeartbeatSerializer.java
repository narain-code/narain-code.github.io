package com.king.rbea.configuration.processor;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import org.apache.commons.io.output.ByteArrayOutputStream;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeutils.base.LongSerializer;
import org.apache.flink.api.common.typeutils.base.StringSerializer;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.core.memory.DataInputView;
import org.apache.flink.core.memory.DataInputViewStreamWrapper;
import org.apache.flink.core.memory.DataOutputView;
import org.apache.flink.core.memory.DataOutputViewStreamWrapper;
import org.apache.flink.streaming.util.serialization.DeserializationSchema;
import org.apache.flink.streaming.util.serialization.SerializationSchema;

/**
 * {@code HeartbeatSerializer} is a Flink {@link SerializationSchema} and {@link DeserializationSchema} for a specific
 * {@link Tuple2} containing {@link Heartbeat}-object.
 */
@SuppressWarnings("deprecation")
public final class HeartbeatSerializer implements SerializationSchema<Tuple2<String, Heartbeat>>, DeserializationSchema<Tuple2<String, Heartbeat>> {
	private static final long serialVersionUID = 1L;

	public static final HeartbeatSerializer INSTANCE = new HeartbeatSerializer();

	@Override
	public byte[] serialize(Tuple2<String, Heartbeat> tuple2) {
		ByteArrayOutputStream os = new ByteArrayOutputStream();
		DataOutputView out = new DataOutputViewStreamWrapper(os);

		try {
			StringSerializer.INSTANCE.serialize(tuple2.f0, out);
			LongSerializer.INSTANCE.serialize(tuple2.f1.getTime(), out);
			return os.toByteArray();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public TypeInformation<Tuple2<String, Heartbeat>> getProducedType() {
		return null;
	}

	@Override
	public Tuple2<String, Heartbeat> deserialize(byte[] input) throws IOException {
		ByteArrayInputStream is = new ByteArrayInputStream(input);
		DataInputView in = new DataInputViewStreamWrapper(is);

		String topic = StringSerializer.INSTANCE.deserialize(in);
		return Tuple2.of(topic, new Heartbeat(LongSerializer.INSTANCE.deserialize(in)));
	}

	@Override
	public boolean isEndOfStream(Tuple2<String, Heartbeat> arg0) {
		return false;
	}
}