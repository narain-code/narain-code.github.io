package com.king.rbea.utils;

/**
 * Container class for various {@link String} constants used in RBEA.
 */
public class Constants {
	public static final String JOB_DEPLOYMENT_TOPIC = "jobDeploymentTopic";
	
	/**
	 * The name of the Kafka topic where wrapped JobSummary-messages
	 * are published and consumed. In practise the topic has a suffix.
	 */
	public static final String JOB_INFO_OUTPUT_TOPIC = "jobInfoOutputTopic";

	/**
	 * The name of key of the Kafka topic where wrapped Heartbeat-messages
	 * are published. In practise the topic has a suffix.
	 */
	public static final String HEARTBEAT_OUTPUT_TOPIC = "heartbeatOutputTopic";

	/**
	 * The default value of HEARTBEAT_OUTPUT_TOPIC.
	 */
	public static final String DEFAULT_HEARTBEAT_OUTPUT_TOPIC = "rbeaHeartbeatOutput";
	
	public static final String KAFKA_BROKER = "kafkaBroker";
	
	/**
	 * The suffix of Kafka topics (JOB_DEPLOYMENT_TOPIC and JOB_INFO_OUTPUT_TOPIC).
	 * Also defines the Kafka consumer group id.
	 */
	public static final String TOPIC_SUFFIX = "topicSuffix";
	public static final String GROUP_ID = "groupId";
	public static final String ZOOKEEPER_HOST = "zkHost";

	public static final String MYSQL_URL = "mySqlUrl";
	public static final String PROCESSOR_ID_KEY = "processorId";
	public static final String OUTPUT_TYPE_KEY = "outputType";

	public static final String FAILURE = "Failure";
	public static final String MYSQL = "MySQL";
	public static final String FILE = "TextFile";
	public static final String KAFKA = "Kafka";
	public static final String ELASTIC = "Elastic";

	public static final String AGGREGATOR_NAME = "Name";
	public static final String MYSQL_TABLE_NAME = "tableName";
	public static final String FILE_PATH = "filePath";
	public static final String FAILURE_CAUSE = "failureCause";
	public static final String KAFKA_OUTPUT_TOPIC = "kafkaTopic";
}
