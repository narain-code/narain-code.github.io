package com.king.rbea.annotations;

public enum ProcessingPolicy {
	IGNORE, PROCESS, PROCESS_ONLY
}
