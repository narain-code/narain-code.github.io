package com.king.rbea.scripts.proxy;

import java.net.URL;
import java.nio.file.Path;
import java.util.Collections;
import java.util.Enumeration;
import java.util.jar.Manifest;

import com.king.rbea.Context;
import com.king.rbea.Registry;
import com.king.rbea.classloader.ApplicationClassLoader;
import com.king.rbea.exceptions.BackendException;

/**
 * Class loader using a single JAR entity with class to load in its Manifest.
 */
public class JarCodeExecutor extends ProxyExecutor {
	private static final long serialVersionUID = 1L;

	/**
	 * In the Manifest, the key that identifies the class name of the script.
	 */
	public static final String RBEA_MANIFEST = "RBEA-Class";

	/**
	 * The classloader that loads the classes 1st from the {@link #jarPath}.
	 */
	private ApplicationClassLoader applicationClassLoader;

	/**
	 * The JAR.
	 */
	private Path jarPath;

	public JarCodeExecutor(long jobId, String jobName) {
		this(jobId, jobName, null);
	}

	public JarCodeExecutor(long jobId, String jobName, Path jarPath) {
		super(jobId, jobName);
	
		this.jarPath = jarPath;
	}

	public void setJarPath(Path jarPath) {
		if (this.jarPath != null) {
			throw new IllegalStateException("jarPath already set " + this.jarPath);
		}
		this.jarPath = jarPath;
	}
	
	public Path getJarPath() {
		return this.jarPath;
	}
	
	@Override
	public void initialize(Registry reg, Context ctx) throws Exception {
		if (this.jarPath == null) {
			throw new IllegalStateException("jarPath not set");
		}
		
		applicationClassLoader = new ApplicationClassLoader(new URL[] { jarPath.toUri().toURL() }, Thread.currentThread().getContextClassLoader(), Collections.emptyList());

		super.initialize(reg, ctx);
	}

	@Override
	public Object getScriptInstance() throws Exception {
		Enumeration<URL> resources = applicationClassLoader.getResources("META-INF/MANIFEST.MF");
		if (!resources.hasMoreElements()) {
			throw new BackendException("No manifest found");
		}
		while (resources.hasMoreElements()) {
			Manifest manifest = new Manifest(resources.nextElement().openStream());
			String rbeaClass = manifest.getMainAttributes().getValue(RBEA_MANIFEST);
			if (rbeaClass != null) {
				return applicationClassLoader.loadClass(rbeaClass).newInstance();
			}
		}
		throw new BackendException("Jar doesn't contain manifest with record " + RBEA_MANIFEST);
	}

	@Override
	public void close() throws Exception {
		if (applicationClassLoader != null) {
			applicationClassLoader.close();
		}
	}
}
