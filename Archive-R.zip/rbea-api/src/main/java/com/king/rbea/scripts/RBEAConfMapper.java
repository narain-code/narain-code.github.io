package com.king.rbea.scripts;

import java.lang.reflect.Field;
import java.util.Map;

import org.apache.commons.lang3.reflect.FieldUtils;
import org.apache.flink.api.java.utils.ParameterTool;

import com.king.rbea.annotations.config.ConfigField;

public class RBEAConfMapper {

	public final ParameterTool params;

	public RBEAConfMapper(Map<String, String> map) {
		this.params = ParameterTool.fromMap(map);
	}

	public <T> T read(Class<T> clazz) throws Exception {
		T instance = clazz.newInstance();

		for (Field field : FieldUtils.getAllFields(clazz)) {
			ConfigField cf = field.getAnnotation(ConfigField.class);
			field.setAccessible(true);
			String fieldName = field.getName();

			boolean required = cf != null && cf.required();
			if (required && !params.has(fieldName)) {
				throw new Exception("Required param " + fieldName + " is missing.");
			}

			if (!params.has(fieldName)) {
				continue;
			}

			field.set(instance, getFromParams(fieldName, field.getType()));
		}

		return instance;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private Object getFromParams(String name, Class<?> type) {
		if (type.isAssignableFrom(String.class)) {
			return params.getRequired(name);
		} else if (type.isAssignableFrom(Integer.TYPE)) {
			return params.getInt(name);
		} else if (type.isAssignableFrom(Long.TYPE)) {
			return params.getLong(name);
		} else if (type.isAssignableFrom(Boolean.TYPE)) {
			return params.getBoolean(name);
		} else if (type.isAssignableFrom(Double.TYPE)) {
			return params.getDouble(name);
		} else if (type.isAssignableFrom(Float.TYPE)) {
			return params.getFloat(name);
		} else if (type.isAssignableFrom(Short.TYPE)) {
			return params.getShort(name);
		} else if (type.isAssignableFrom(Byte.TYPE)) {
			return params.getByte(name);
		} else if (type.isEnum()) {
			return Enum.valueOf((Class) type, params.getRequired(name));
		} else {
			throw new RuntimeException("Unsupported field type");
		}
	}
}