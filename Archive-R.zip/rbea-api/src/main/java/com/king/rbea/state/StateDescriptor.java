package com.king.rbea.state;

import java.io.Serializable;
import java.util.function.Function;

import org.apache.flink.api.common.typeinfo.TypeInformation;

import com.king.rbea.State;
import com.king.rbea.exceptions.ProcessorException;

public interface StateDescriptor<Type> extends Serializable {

	String getStateName();

	TypeInformation<Type> getTypeInfo();

	default Type getState(State state) throws ProcessorException {
		return state.get(getStateName());
	}

	default void updateState(State state, Type value) throws ProcessorException {
		state.update(getStateName(), value);
	}

	default Type getState(long procId, State state) throws ProcessorException {
		return state.get(procId, getStateName());
	}

	default <TransformedType> StateDescriptor<TransformedType> postProcess(Function<Type, TransformedType> f) {
		return postProcess(this, f);
	}

	public static <Type, TransformedType> StateDescriptor<TransformedType> postProcess(StateDescriptor<Type> sd,
			Function<Type, TransformedType> f) {

		return new StateDescriptor<TransformedType>() {
			private static final long serialVersionUID = 1L;

			public TransformedType getState(State state) throws ProcessorException {
				return f.apply(sd.getState(state));
			}

			public void updateState(State state, TransformedType value) throws ProcessorException {
				throw new UnsupportedOperationException("Cannot update using the postProcessed descriptor.");
			}

			public TransformedType getState(long procId, State state) throws ProcessorException {
				return f.apply(sd.getState(procId, state));
			}

			@Override
			public String getStateName() {
				return "PostProcessed(" + sd.getStateName() + ")";
			}

			@Override
			public TypeInformation<TransformedType> getTypeInfo() {
				return null;
			}
		};
	}

}
