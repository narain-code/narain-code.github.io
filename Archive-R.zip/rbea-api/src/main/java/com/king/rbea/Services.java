package com.king.rbea;

import com.king.rbea.services.TFPredictionService;

import tensorflow.serving.PredictionServiceGrpc.PredictionServiceBlockingStub;

public interface Services {

	default PredictionServiceBlockingStub getTFPredictionService() {
		return TFPredictionService.getBlockingStub();
	}

}
