package com.king.rbea.scripts.proxy;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import com.king.rbea.annotations.OnError;
import com.king.rbea.scripts.info.ConfigClassSchema;
import com.king.rbea.scripts.info.ConfigClassSchema.ScriptConfigInfo;
import com.king.rbea.scripts.info.EventProcessorInfo;
import com.king.rbea.state.StateDescriptor;

public class ProxyProcInfo implements EventProcessorInfo {
	private static final long serialVersionUID = 1L;

	private boolean hasInit = false;
	private boolean hasClose = false;
	private boolean hasProcess = false;
	private boolean hasOnTimer = false;
	private boolean hasOnSessionEnd = false;
	private Integer maxErrorsPerMin = null;
	private boolean hasAsyncMethods;
	private final ScriptConfigInfo configSchema;

	private List<StateDescriptor<?>> stateInfo;

	public ProxyProcInfo(Object scriptInstance, boolean hasAsyncMethods, List<StateDescriptor<?>> stateInfo)
			throws Exception {
		this.hasAsyncMethods = hasAsyncMethods;
		this.stateInfo = stateInfo;
		hasInit = ProxyExecutor.initializeBinding.matchesAny(scriptInstance);
		hasClose = ProxyExecutor.closeBinding.matchesAny(scriptInstance);
		hasOnTimer = ProxyExecutor.onTimerBinding.matchesAny(scriptInstance);
		hasOnSessionEnd = ProxyExecutor.onSessionBinding.matchesAny(scriptInstance);
		hasProcess = ProxyExecutor.processEventBinding.matchesAny(scriptInstance);
		Set<Method> targetMethods = ProxyExecutor.onErrorBinding.getTargetMethods(scriptInstance);
		if (!targetMethods.isEmpty()) {
			int minEPM = Integer.MAX_VALUE;
			for (Method m : targetMethods) {
				OnError onErr = m.getAnnotation(OnError.class);
				if (onErr != null) {
					minEPM = Math.min(minEPM, onErr.maxErrorsPerMin());
				}
			}
			maxErrorsPerMin = minEPM;
		}
		this.configSchema = ConfigClassSchema.getAllConfigurableFields(scriptInstance.getClass());
	}

	@Override
	public boolean hasInitMethod() {
		return hasInit;
	}

	@Override
	public boolean hasCloseMethod() {
		return hasClose;
	}

	@Override
	public boolean hasOnTimerMethod() {
		return hasOnTimer;
	}

	@Override
	public boolean hasOnSessionEndMethod() {
		return hasOnSessionEnd;
	}

	@Override
	public boolean hasProcessEventMethod() {
		return hasProcess;
	}

	@Override
	public Optional<Integer> getMaxErrorsPerMin() {
		return Optional.ofNullable(maxErrorsPerMin);
	}

	@Override
	public boolean hasAsyncMethods() {
		return hasAsyncMethods;
	}

	@Override
	public ScriptConfigInfo getConfigSchema() {
		return configSchema;
	}

	@Override
	public List<StateDescriptor<?>> getStates() {
		return stateInfo;
	}
}