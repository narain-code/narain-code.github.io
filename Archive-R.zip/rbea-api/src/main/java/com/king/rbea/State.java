package com.king.rbea;

import org.apache.commons.lang3.ClassUtils;

import com.king.flink.utils.Unchecked;
import com.king.flink.utils.Unchecked.ThrowingConsumer;
import com.king.rbea.documenting.RbeaDocumentedClass;
import com.king.rbea.documenting.RbeaDocumentedMethod;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.state.StateDescriptor;
import com.king.rbea.state.basefields.ABTestAssignments;

@RbeaDocumentedClass(summary = "State for the current core user. It can be used to read the values of different Fields and LocalStates. "
		+ "Fields can be defined either maunually in the initialize method of scripts or can be globally predefined for all scripts (such as last semantic class instances).")
public interface State {

	@RbeaDocumentedMethod(summary = "Returns the value of a field or local state.")
	<T> T get(String fieldName) throws ProcessorException;

	@RbeaDocumentedMethod(summary = "Returns the value of a field or local state.")
	default <T> T get(StateDescriptor<T> descriptor) throws ProcessorException {
		return descriptor.getState(this);
	}

	@RbeaDocumentedMethod(summary = "Sets the value of a local state.")
	void update(String fieldName, Object value) throws ProcessorException;

	void export(Object... leadingFields) throws ProcessorException;
	
	@RbeaDocumentedMethod(summary = "Sets the value of a local state.")
	default <T> void update(StateDescriptor<T> descriptor, T value) throws ProcessorException {
		descriptor.updateState(this, value);
	}

	@RbeaDocumentedMethod(summary = "Deletes the value of a local state.")
	default void clear(String fieldName) throws ProcessorException {
		update(fieldName, null);
	}

	@RbeaDocumentedMethod(summary = "Mutates the value of a local state.")
	default <T> void mutate(StateDescriptor<T> descriptor, ThrowingConsumer<T> mutator) throws ProcessorException {
		T val = get(descriptor);

		if (val == null) {
			throw new ProcessorException("Cannot mutate null objects.");
		}

		Class<?> clazz = val.getClass();
		if (ClassUtils.isPrimitiveWrapper(clazz) || clazz.equals(String.class)) {
			throw new ProcessorException(clazz.getSimpleName() + " is immutable.");
		}

		try {
			mutator.accept(val);
		} catch (Throwable e) {
			Unchecked.throwSilently(e);
		}
		update(descriptor, val);
	}

	@RbeaDocumentedMethod(summary = "Deletes the value of a local state.")
	default void clear(StateDescriptor<?> descriptor) throws ProcessorException {
		update(descriptor, null);
	}

	@RbeaDocumentedMethod(summary = "Deletes all the state for the current user.")
	void clearAll() throws ProcessorException;


	@RbeaDocumentedMethod(summary = "Get AB-Test assignments for the current user.")
	default ABTestAssignments getABTestAssignments() throws ProcessorException {
		throw new UnsupportedOperationException();
	}

	@RbeaDocumentedMethod(summary = "Returns the value of a field that has been defined by another RBEA script (with the given job id).")
	<T> T get(long rbeaJobId, String fieldName) throws ProcessorException;

	@RbeaDocumentedMethod(summary = "Returns the value of a field that has been defined by another RBEA script (with the given job id).")
	default <T> T get(long rbeaJobId, StateDescriptor<T> descriptor) throws ProcessorException {
		return descriptor.getState(rbeaJobId, this);
	}
}
