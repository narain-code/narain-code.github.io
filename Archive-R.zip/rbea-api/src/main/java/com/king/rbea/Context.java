package com.king.rbea;

import com.king.event.Event;
import com.king.proxy.IgnoreOnConflict;
import com.king.rbea.documenting.RbeaDocumentedClass;
import com.king.rbea.documenting.RbeaDocumentedMethod;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.services.ServicesImpl;

@RbeaDocumentedClass(summary = "The Context gives access to the core RBEA functionality and also exposes information about the event currently being processed.")
public interface Context {

	@RbeaDocumentedMethod(summary = "Core user id for the current event.")
	Long getCoreUserId() throws ProcessorException;

	@IgnoreOnConflict
	@RbeaDocumentedMethod(summary = "Current event being processed.")
	Event getEvent();

	@RbeaDocumentedMethod(summary = "State for the current core user which gives access to Field values and local states.")
	State getState();

	@RbeaDocumentedMethod(summary = "Aggregators can be used to create global window aggregates across all users.")
	Aggregators getAggregators();

	@RbeaDocumentedMethod(summary = "Output can be used to generate script outputs.")
	Output getOutput();

	@RbeaDocumentedMethod(summary = "Timers can be used to register event time callbacks.")
	Timers getTimers();

	@RbeaDocumentedMethod(summary = "Utils contains built-in utility functions for RBEA programs, such as the currency converter.")
	Utils getUtils();

	@RbeaDocumentedMethod(summary = "Container for the available services.")
	default Services getServices() {
		return ServicesImpl.INSTANCE;
	}
}
