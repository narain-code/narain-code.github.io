package com.king.rbea.scripts.proxy.binders;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Optional;

import com.king.constants.Flavour;
import com.king.constants.KingApp;
import com.king.constants.SignInSource;
import com.king.constants.event.typed.EventHeader;
import com.king.proxy.parameters.ParameterBinding;
import com.king.proxy.parameters.SingleParameterBinder;

import net.bytebuddy.description.method.MethodDescription;
import net.bytebuddy.implementation.bytecode.StackManipulation;
import net.bytebuddy.implementation.bytecode.StackManipulation.Compound;
import net.bytebuddy.implementation.bytecode.member.MethodInvocation;
import net.bytebuddy.implementation.bytecode.member.MethodVariableAccess;

public class EventInfoBinder implements SingleParameterBinder {
	private static final long serialVersionUID = 1L;

	public int eventOffset;
	public int ctxOffset;

	public EventInfoBinder() {
		this(1, 2);
	}

	public EventInfoBinder(int eventOffset, int ctxOffset) {
		this.eventOffset = eventOffset;
		this.ctxOffset = ctxOffset;
	}

	@Override
	public Optional<ParameterBinding> bind(Method sourceMethod, Method targetMethod,
			Class<?> targetParamType, List<Annotation> paramAnnotations,
			List<ParameterBinding> possibleBindings)
			throws Exception {

		if (targetParamType.equals(Flavour.class)) {
			return Optional.of(new ParameterBinding(targetParamType, getFlavour()));
		} else if (targetParamType.equals(KingApp.class)) {
			return Optional.of(new ParameterBinding(targetParamType, new Compound(getFlavour(),
					MethodInvocation.invoke(new MethodDescription.ForLoadedMethod(
							Flavour.class.getMethod("getKingApp"))))));
		} else if (targetParamType.equals(SignInSource.class)) {
			return Optional.of(new ParameterBinding(targetParamType, new Compound(getFlavour(),
					MethodInvocation.invoke(new MethodDescription.ForLoadedMethod(
							Flavour.class.getMethod("getSignInSource"))))));
		} else {
			return Optional.empty();
		}

	}

	private Compound getFlavour() throws NoSuchMethodException {
		return new StackManipulation.Compound(
				MethodVariableAccess.REFERENCE.loadFrom(eventOffset),
				MethodInvocation.invoke(new MethodDescription.ForLoadedMethod(
						EventHeader.class.getMethod("getFlavour"))));
	}
}