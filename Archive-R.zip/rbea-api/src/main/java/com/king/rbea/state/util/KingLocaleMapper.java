package com.king.rbea.state.util;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.function.Function;

import com.king.locale.i18n.LocaleAvailabilityCheck;
import com.king.locale.i18n.Locales;

@SuppressWarnings("serial")
public class KingLocaleMapper implements Function<String, Locale>, Serializable {

    private final AvailableLocales available;

    public KingLocaleMapper() {
        this(AvailableLocales.ANY);
    }

    public KingLocaleMapper(AvailableLocales available) {
        this.available = available;
    }

    @Override
    public Locale apply(String rawLocale) {
        return Optional.ofNullable(rawLocale)
            .map(Locales::from)
            .map(locale -> Locales.narrowWithChineseFix(locale, true).getPreferredLocale(available.check()))
            .orElse(null);
    }

    public static final class AvailableLocales {

        public static final AvailableLocales ANY = new AvailableLocales(locale -> true);

        private final LocaleAvailabilityCheck check;

        public AvailableLocales(String... availableLocales) {
            this(Arrays.asList(availableLocales));
        }

        public AvailableLocales(List<String> availableLocales) {
            this(availableLocales::contains);
        }

        AvailableLocales(LocaleAvailabilityCheck check) {
            this.check = check;
        }

        LocaleAvailabilityCheck check() {
            return check;
        }

    }

}
