package com.king.rbea.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.king.rbea.annotations.config.Meta;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
@Inherited
public @interface ConfigClass {

	String label() default "";

	String description() default "";

	boolean required() default true;

	Meta[] meta() default {};

}
