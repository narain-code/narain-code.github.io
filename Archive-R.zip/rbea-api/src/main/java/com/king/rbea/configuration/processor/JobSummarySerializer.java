package com.king.rbea.configuration.processor;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import org.apache.commons.io.output.ByteArrayOutputStream;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeutils.base.StringSerializer;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.core.memory.DataInputView;
import org.apache.flink.core.memory.DataInputViewStreamWrapper;
import org.apache.flink.core.memory.DataOutputView;
import org.apache.flink.core.memory.DataOutputViewStreamWrapper;
import org.apache.flink.streaming.util.serialization.DeserializationSchema;
import org.apache.flink.streaming.util.serialization.SerializationSchema;
import org.apache.flink.types.Either;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * {@code JobSummarySerializer} is a Flink {@link SerializationSchema} and
 * {@link DeserializationSchema} for a specific {@link Tuple2} containing
 * {@link JobSummary}-object or other info.
 */
@SuppressWarnings("deprecation")
public final class JobSummarySerializer
		implements SerializationSchema<Tuple2<String, Either<JobSummary, Either<JobSummariesStart, JobSummariesEnd>>>>,
		DeserializationSchema<Tuple2<String, Either<JobSummary, Either<JobSummariesStart, JobSummariesEnd>>>> {
	private static final long serialVersionUID = 1L;

	private final Logger LOG = LoggerFactory.getLogger(JobSummarySerializer.class);

	public static final JobSummarySerializer INSTANCE = new JobSummarySerializer();

	private static final int TYPE_JOB_SUMMARY = 1;
	private static final int TYPE_START = 2;
	private static final int TYPE_END = 3;

	@Override
	public byte[] serialize(Tuple2<String, Either<JobSummary, Either<JobSummariesStart, JobSummariesEnd>>> job) {
		ByteArrayOutputStream os = new ByteArrayOutputStream();
		DataOutputView out = new DataOutputViewStreamWrapper(os);

		try {
			StringSerializer.INSTANCE.serialize(job.f0, out);

			if (job.f1.isLeft()) {
				out.writeInt(TYPE_JOB_SUMMARY);

				byte[] bytes = job.f1.left().serialize();
				if (bytes.length > 1_000_000) {
					LOG.error("JobSummary too large: {}", job.f1.left());
				}
				out.writeInt(bytes.length);
				out.write(bytes);
			} else if (job.f1.right().isLeft()) {
				out.writeInt(TYPE_START);
			} else {
				out.writeInt(TYPE_END);
			}

			return os.toByteArray();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public TypeInformation<Tuple2<String, Either<JobSummary, Either<JobSummariesStart, JobSummariesEnd>>>> getProducedType() {
		return null;
	}

	@Override
	public Tuple2<String, Either<JobSummary, Either<JobSummariesStart, JobSummariesEnd>>> deserialize(byte[] input)
			throws IOException {
		ByteArrayInputStream is = new ByteArrayInputStream(input);
		DataInputView in = new DataInputViewStreamWrapper(is);

		String topic = StringSerializer.INSTANCE.deserialize(in);

		int type = in.readInt();
		switch (type) {
		case TYPE_JOB_SUMMARY:
			byte[] bytes = new byte[in.readInt()];
			in.readFully(bytes);
			try {
				return Tuple2.of(topic, Either.Left(ProcessorInfo.deserialize(bytes)));
			} catch (Exception e) {
				throw new IOException(e);
			}
		case TYPE_START:
			return Tuple2.of(topic, Either.Right(Either.Left(new JobSummariesStart())));
		case TYPE_END:
			return Tuple2.of(topic, Either.Right(Either.Right(new JobSummariesEnd())));
		default:
			throw new IOException("Unknown type " + type);
		}
	}

	@Override
	public boolean isEndOfStream(Tuple2<String, Either<JobSummary, Either<JobSummariesStart, JobSummariesEnd>>> arg0) {
		return false;
	}
}