package com.king.rbea.scripts;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Pattern;

import org.apache.flink.api.java.tuple.Tuple2;
import org.codehaus.groovy.ast.expr.ConstantExpression;
import org.codehaus.groovy.ast.expr.Expression;
import org.codehaus.groovy.ast.expr.MethodCallExpression;
import org.codehaus.groovy.control.CompilerConfiguration;
import org.codehaus.groovy.control.MultipleCompilationErrorsException;
import org.codehaus.groovy.control.customizers.ImportCustomizer;
import org.codehaus.groovy.control.customizers.SecureASTCustomizer;
import org.codehaus.groovy.control.customizers.SecureASTCustomizer.ExpressionChecker;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import com.king.event.Event;
import com.king.flink.utils.Unchecked;
import com.king.rbea.Context;
import com.king.rbea.Registry;
import com.king.rbea.aggregators.DimensionalAggregator;
import com.king.rbea.annotations.Aggregator;
import com.king.rbea.annotations.Bind;
import com.king.rbea.annotations.ConfigClass;
import com.king.rbea.annotations.Initialize;
import com.king.rbea.annotations.OnSessionEnd;
import com.king.rbea.annotations.OnTimer;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.exceptions.ProcessorException;

import groovy.lang.Binding;
import groovy.lang.GroovyShell;
import groovy.lang.Script;

public class ScriptUtils {

	public static void testDeprecated(String code) throws ProcessorException {
		DeprecateCallDetector visitor = new DeprecateCallDetector();

		try {
			CompilerConfiguration conf = getCompilerConfig();
			SecureASTCustomizer cz = new SecureASTCustomizer();
			cz.addExpressionCheckers(visitor);
			conf.addCompilationCustomizers(cz);
			compile(code, conf);
		} catch (MultipleCompilationErrorsException ex) {
			if (visitor.error != null) {
				throw visitor.error;
			}
		} catch (Throwable ignored) {}
	}

	public static Script compile(String code) throws ProcessorException {
		return compile(code, getCompilerConfig());
	}

	public static final Pattern BindAnnot = Pattern.compile("@Bind\\s");

	public static String preProcessGroovyScript(String code) {
		return BindAnnot.matcher(code).replaceAll("@groovy.transform.Field @Bind ");
	}

	public static Script compile(String code, CompilerConfiguration conf) throws ProcessorException {
		final GroovyShell shell = new GroovyShell(getBinding(), conf);
		Script script = shell.parse(preProcessGroovyScript(code));
		script.run();

		Map<?, ?> bindings = script.getBinding().getVariables();
		if (!bindings.isEmpty()) {
			throw new ProcessorException("Unbound variables found: " + bindings
					+ "\n Use the @Bind annotation when declaring these variables.\nUsage:\n"
					+ "@Bind variableName = value\n"
					+ "@Bind def variableName = value\n"
					+ "@Bind Type variableName = value\n");
		}

		return script;
	}

	public static class DeprecateCallDetector implements ExpressionChecker {

		public final String[] detectCalls = { "com.king.rbea.State:getLocalState" };
		public ProcessorException error = null;

		@Override
		public boolean isAuthorized(Expression expression) {
			if (expression instanceof MethodCallExpression) {
				MethodCallExpression mthExpr = (MethodCallExpression) expression;
				Expression calledMethod = mthExpr.getMethod();
				String type = mthExpr.getObjectExpression().getType().getName();

				if (calledMethod instanceof ConstantExpression) {
					String methodCall = type + ":" + ((ConstantExpression) calledMethod).getText();
					for (String call : detectCalls) {
						if (call.equals(methodCall)) {
							error = new ProcessorException("Deprecated method used: " + methodCall);
							return false;
						}
					}
				}
			}
			return true;
		}

	}

	public static CompilerConfiguration getCompilerConfig() {
		CompilerConfiguration config = new CompilerConfiguration();
		ImportCustomizer icz = new ImportCustomizer();
		icz.addStarImports(
				"com.king.rbea",
				"com.king.rbea.globalstate",
				"com.king.rbea.extensions",
				"com.king.rbea.aggregators",
				"com.king.rbea.state",
				"com.king.rbea.state.basefields",
				"com.king.rbea.annotations",
				"com.king.constants.external.event.typed.events",
				"com.king.constants.external.event.typed.events.deprecated",
				"com.king.rbea.utils",
				"com.king.rbea.services",
				"com.king.utils",
				"com.king.event",
				"com.king.constants",
				"com.king.constants.external",
				"com.king.kgk");

		icz.addImports(
				"com.king.utils.CurrencyManager",
				"org.apache.flink.api.common.typeinfo.TypeHint");

		// icz.addImport("Bind", "groovy.transform.Field");

		icz.addStaticStars(
				"com.king.rbea.aggregators.AggregationWindow",
				"com.king.rbea.annotations.ProcessingPolicy",
				"com.king.rbea.annotations.ParamType");

		config.addCompilationCustomizers(icz);

		return config;
	}

	public static Binding getBinding() {
		return new Binding();
	}

	public static void validateAggregatorAnnotation(Aggregator annot) throws ProcessorException {
		if (annot.name().equals("")) {
			throw new ProcessorException("Aggregator name cannot be empty.");
		}
		if (annot.window() == null) {
			throw new ProcessorException("Window size cannot be null");
		}
	}

	@SuppressWarnings("unchecked")
	public static <T> T getParamAnnotation(Method processMethod, int j, Class<T> annotationClass) {
		Annotation[][] paramAnnotations = processMethod.getParameterAnnotations();
		Annotation[] annotations = paramAnnotations[j];
		for (Annotation a : annotations) {
			if (a.annotationType().equals(annotationClass)) {
				return (T) a;
			}
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	public static <A extends Annotation> List<Tuple2<Method, A>> getMethodsAnnotatedWith(final Class<?> type,
			final Class<A> annotation) {
		final List<Tuple2<Method, A>> methods = new ArrayList<Tuple2<Method, A>>();
		Class<?> klass = type;
		while (klass != Object.class) {
			final List<Method> allMethods = new ArrayList<Method>(Arrays.asList(klass.getDeclaredMethods()));
			for (final Method method : allMethods) {
				for (Annotation a : method.getAnnotations()) {
					if (a.annotationType().equals(annotation)) {
						methods.add(Tuple2.of(method, (A) a));
					}
				}
			}
			klass = klass.getSuperclass();
		}
		return methods;
	}

	public static List<Tuple2<Method, ProcessEvent>> getProcessMethods(Class<?> javaClass) throws ProcessorException {
		List<Tuple2<Method, ProcessEvent>> methods = ScriptUtils.getMethodsAnnotatedWith(javaClass, ProcessEvent.class);

		if (methods.isEmpty()) {
			boolean foundDeprecated = false;
			for (Method m : javaClass.getDeclaredMethods()) {
				if (m.getName().equals("processEvent") && parametersAssignableFrom(m, Event.class, Context.class)) {
					foundDeprecated = true;
				}
			}
			if (foundDeprecated) {
				throw new ProcessorException(
						"Class doesn't contain any method annotated with @ProcessEvent. You seem to be using the old \"def processEvent(event, ctx)\" api.");
			}
		}
		return methods;
	}

	public static Tuple2<Method, OnTimer> getOnTimerMethod(Class<?> javaClass) throws ProcessorException {
		List<Tuple2<Method, OnTimer>> onTimerMethods = ScriptUtils.getMethodsAnnotatedWith(javaClass, OnTimer.class);
		Method onTimerMethod = null;

		if (onTimerMethods.size() > 1) {
			throw new ProcessorException("Class contains more than one method annotated with @Initialize");
		} else if (onTimerMethods.size() == 1) {
			return onTimerMethods.get(0);
		} else {
			for (Method m : javaClass.getDeclaredMethods()) {
				if (m.getName().equals("onTimer")) {
					onTimerMethod = m;
					break;
				}
			}
		}

		if (onTimerMethod != null
				&& !parametersAssignableFrom(onTimerMethod, long.class, long.class, Object.class, Context.class)) {
			throw new ProcessorException(
					"OnTimer method must have exactly the following 4 parameters: long timerId, long timestamp, Object params, Context ctx");
		}
		return Tuple2.of(onTimerMethod, null);
	}

	public static Tuple2<Method, OnSessionEnd> getOnSessionEndMethod(Class<?> javaClass) throws ProcessorException {
		List<Tuple2<Method, OnSessionEnd>> onSessionEndMethods = ScriptUtils.getMethodsAnnotatedWith(javaClass,
				OnSessionEnd.class);

		if (onSessionEndMethods.size() > 1) {
			throw new ProcessorException("Class contains more than one method annotated with @OnSessionEnd");
		} else if (onSessionEndMethods.size() == 1) {
			return onSessionEndMethods.get(0);
		} else {
			return Tuple2.of(null, null);
		}
	}

	public static boolean parametersAssignableFrom(Method m, Class<?>... params) {

		Class<?>[] mParams = m.getParameterTypes();
		if (mParams.length != params.length) {
			return false;
		}

		for (int i = 0; i < mParams.length; i++) {
			if ((params[i].equals(long.class) || params[i].equals(Long.class))
					&& !(mParams[i].isAssignableFrom(Long.class) || mParams[i].isAssignableFrom(long.class))) {
				return false;
			} else if ((params[i].equals(int.class) || params[i].equals(Integer.class))
					&& !(mParams[i].isAssignableFrom(Integer.class) || mParams[i].isAssignableFrom(int.class))) {
				return false;
			} else if (params[i].equals(long.class)
					|| params[i].equals(Long.class)
					|| params[i].equals(Integer.class)
					|| params[i].equals(int.class)) {
				continue;
			} else if (!mParams[i].isAssignableFrom(params[i])) {
				return false;
			}
		}

		return true;
	}

	public static Method getInitMethod(Class<?> javaClass) throws ProcessorException {
		List<Tuple2<Method, Initialize>> initMethods = ScriptUtils.getMethodsAnnotatedWith(javaClass, Initialize.class);
		Method initMethod = null;

		if (initMethods.size() > 1) {
			throw new ProcessorException("Class contains more than one method annotated with @Initialize");
		} else if (initMethods.size() == 1) {
			initMethod = initMethods.get(0).f0;
		} else {
			for (Method m : javaClass.getDeclaredMethods()) {
				if (m.getName().equals("initialize")) {
					initMethod = m;
					break;
				}
			}
		}

		if (initMethod != null && !parametersAssignableFrom(initMethod, Registry.class)) {
			throw new ProcessorException("Initialize method must have exactly one Registry parameter.");
		}

		return initMethod;
	}

	private static boolean isSemanticClass(Class<?> paramClass) {
		try {
			paramClass.getDeclaredMethod("process", Event.class);
			return true;
		} catch (NoSuchMethodException e) {
			return false;
		}
	}

	public static Optional<Class<?>> checkAssignableFromAny(Class<?> clazz, Class<?>... assignable) {
		for (Class<?> t : assignable) {
			if (t.isAssignableFrom(clazz)) {
				return Optional.of(t);
			}
		}
		return Optional.empty();
	}

	public static ProcessorException getParameterException(Class<?> paramClass, ProcessEvent processEventAnnotation) {
		if (paramClass.equals(Object.class)) {
			return new ProcessorException(
					"Detected Object as the parameter type in the process event method. "
							+ "Maybe you forgot to specify the type arguments in Groovy (process(Output out, State state...)) ");
		} else if (DimensionalAggregator.class.isAssignableFrom(paramClass)) {
			return new ProcessorException(
					"Detected aggregator as a parameter (" + paramClass.getSimpleName()
							+ ") without using the @Aggregator(name=\"...\", window=\"...\") annotation.");
		} else if (isSemanticClass(paramClass)) {
			if (!(processEventAnnotation.semanticClass().length == 0)) {
				return new ProcessorException("Semantic class parameter type (" + paramClass.getSimpleName()
						+ ") does not match semantic class detected in the input filter ("
						+ Arrays.toString(processEventAnnotation.semanticClass()) + ").");
			} else {
				return new ProcessorException("Detected semantic class parameter type (" + paramClass.getSimpleName()
						+ ") without semantic class filter annotation: @ProcessEvent(semanticClass="
						+ paramClass.getSimpleName() + ".class)");
			}
		} else {
			return new ProcessorException(
					"Invalid parameter type in the process event method: " + paramClass.getSimpleName());
		}
	}

	public static final ObjectMapper objectMapper = new ObjectMapper();

	public static <T> T readConfig(String raw, Class<T> clazz) throws ProcessorException {
		try {
			if (clazz.getAnnotation(ConfigClass.class) != null) {
				Map<String, Object> m = objectMapper.readValue(raw,
						new TypeReference<Map<String, Object>>() {});
				if (m.containsKey(clazz.getSimpleName())) {
					RBEAConfMapper mapper = new RBEAConfMapper(
							objectMapper.readValue(objectMapper.writeValueAsString(m.get(clazz.getSimpleName())),
									new TypeReference<Map<String, String>>() {}));
					return mapper.read(clazz);
				} else {
					throw new ProcessorException("To read ConfigClasses, you must have a json field named: "
							+ clazz.getSimpleName() + "\nAlternatively use @Bind on a field with appropriate type.");
				}
			} else {
				return objectMapper.readValue(raw, clazz);
			}
		} catch (Exception e) {
			throw new ProcessorException(e);
		}
	}

	public static void setConfigBindings(String raw, Object processor) throws ProcessorException {
		Class<?> clazz = processor.getClass();
		Field[] declaredFields = clazz.getDeclaredFields();

		Map<String, String> confMap = null;
		for (Field field : declaredFields) {
			try {
				if (field.getAnnotation(Bind.class) != null) {
					field.setAccessible(true);

					if (confMap == null) {
						Map<String, Object> m = objectMapper.readValue(raw,
								new TypeReference<Map<String, Object>>() {});

						confMap = Maps.transformValues(m,
								o -> {
									try {
										return objectMapper.writeValueAsString(o);
									} catch (Throwable e) {
										Unchecked.throwSilently(e);
										return null;
									}
								});
					}

					String name = field.getName();
					Class<?> type = field.getType();
					if (type.getAnnotation(ConfigClass.class) != null) {
						RBEAConfMapper mapper;
						if (confMap.containsKey(name)) {
							mapper = new RBEAConfMapper(objectMapper.readValue(confMap.get(name),
									new TypeReference<Map<String, String>>() {}));
						} else if (confMap.containsKey(type.getSimpleName())) {
							mapper = new RBEAConfMapper(objectMapper.readValue(confMap.get(type.getSimpleName()),
									new TypeReference<Map<String, String>>() {}));
						} else {
							continue;
						}
						field.set(processor, mapper.read(type));
					} else {
						String val = confMap.get(name);
						if (val != null) {
							field.set(processor, objectMapper.readValue(val, field.getType()));
						}
					}
				}
			} catch (Throwable e) {
				throw new ProcessorException(e);
			}
		}

	}

	@SuppressWarnings("unchecked")
	public static <T> Class<T> wrap(Class<T> c) {
		return c.isPrimitive() ? (Class<T>) PRIMITIVES_TO_WRAPPERS.get(c) : c;
	}

	private static final Map<Class<?>, Class<?>> PRIMITIVES_TO_WRAPPERS = new ImmutableMap.Builder<Class<?>, Class<?>>()
			.put(boolean.class, Boolean.class)
			.put(byte.class, Byte.class)
			.put(char.class, Character.class)
			.put(double.class, Double.class)
			.put(float.class, Float.class)
			.put(int.class, Integer.class)
			.put(long.class, Long.class)
			.put(short.class, Short.class)
			.put(void.class, Void.class)
			.build();
}