package com.king.rbea.manager.backends;

/**
 * Represents the desired state of a backend that is e.g. stored in the
 * RBEA Metadata Storage.
 */
public enum BackendState {
	/**
	 * Exists, but not running, i.e. deployed but not running.
	 */
	STOPPED,
	
	/**
	 * Moving from {@link #RUNNING} to {@link #STOPPED}.
	 */
	STOPPING,
	
	/**
	 * Up and running, i.e. deployed and processing events.
	 */
	RUNNING,

	/**
	 * Moving from {@link #STOPPED} to {@link #RUNNING}.
	 */
	RESUMING;
}
