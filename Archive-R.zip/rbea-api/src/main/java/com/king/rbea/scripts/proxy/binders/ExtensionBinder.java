package com.king.rbea.scripts.proxy.binders;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.king.proxy.parameters.ParameterBinding;
import com.king.proxy.parameters.SingleParameterBinder;
import com.king.rbea.Context;
import com.king.rbea.extensions.RBEAExtension;

import net.bytebuddy.description.method.MethodDescription;
import net.bytebuddy.description.type.TypeDescription;
import net.bytebuddy.description.type.TypeDescription.ForLoadedType;
import net.bytebuddy.implementation.bytecode.Duplication;
import net.bytebuddy.implementation.bytecode.StackManipulation;
import net.bytebuddy.implementation.bytecode.TypeCreation;
import net.bytebuddy.implementation.bytecode.member.MethodInvocation;
import net.bytebuddy.implementation.bytecode.member.MethodVariableAccess;

public class ExtensionBinder implements SingleParameterBinder {
	private static final long serialVersionUID = 1L;

	public int ctxOffset;

	public ExtensionBinder(int ctxOffset) {
		this.ctxOffset = ctxOffset;
	}

	@Override
	public Optional<ParameterBinding> bind(Method sourceMethod, Method targetMethod,
			Class<?> targetParamType, List<Annotation> paramAnnotations,
			List<ParameterBinding> possibleBindings)
			throws Exception {

		if (!RBEAExtension.class.isAssignableFrom(targetParamType)) {
			return Optional.empty();
		}

		ForLoadedType target = new TypeDescription.ForLoadedType(targetParamType);

		try {
			MethodDescription ctxConstructor = new MethodDescription.ForLoadedConstructor(
					targetParamType.getConstructor(Context.class));

			return Optional.of(new ParameterBinding(targetParamType,
					new StackManipulation.Compound(
							TypeCreation.of(target),
							Duplication.of(target),
							MethodVariableAccess.REFERENCE.loadFrom(ctxOffset),
							MethodInvocation.invoke(ctxConstructor))));
		} catch (Throwable err) {
			List<Method> statics = Arrays.stream(targetParamType.getDeclaredMethods())
					.filter(m -> Modifier.isStatic(m.getModifiers()))
					.filter(m -> m.getReturnType().equals(targetParamType))
					.filter(m -> {
						Class<?>[] params = m.getParameterTypes();
						return params.length == 1 && params[0].equals(Context.class);
					}).collect(Collectors.toList());

			if (statics.size() != 1) {
				return Optional.empty();
			} else {
				MethodDescription staticCall = new MethodDescription.ForLoadedMethod(statics.get(0));
				return Optional.of(new ParameterBinding(targetParamType,
						new StackManipulation.Compound(
								MethodVariableAccess.REFERENCE.loadFrom(ctxOffset),
								MethodInvocation.invoke(staticCall))));
			}
		}
	}
}