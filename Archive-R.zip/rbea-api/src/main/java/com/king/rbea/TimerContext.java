package com.king.rbea;

import com.king.event.Event;
import com.king.rbea.exceptions.ProcessorException;

public class TimerContext implements Context {

	private final Context ctx;
	private final long ts;
	private final int id;
	private final Object params;

	public TimerContext(Context ctx, Long ts, int id, Object params) {
		this.ctx = ctx;
		this.ts = ts.longValue();
		this.id = id;
		this.params = params;
	}

	public long getTimeStamp() {
		return ts;
	}

	public int getTimerId() {
		return id;
	}

	@SuppressWarnings("unchecked")
	public <T> T getTimerParam() {
		return (T) params;
	}

	@Override
	public Long getCoreUserId() throws ProcessorException {
		return ctx.getCoreUserId();
	}

	@Override
	public State getState() {
		return ctx.getState();
	}

	@Override
	public Aggregators getAggregators() {
		return ctx.getAggregators();
	}

	@Override
	public Output getOutput() {
		return ctx.getOutput();
	}

	@Override
	public Timers getTimers() {
		return ctx.getTimers();
	}

	@Override
	public Utils getUtils() {
		return ctx.getUtils();
	}

	@Override
	public Event getEvent() {
		return ctx.getEvent();
	}
}
