package com.king.rbea.services;

import tensorflow.serving.PredictionServiceGrpc;
import tensorflow.serving.PredictionServiceGrpc.PredictionServiceBlockingStub;

public class TFPredictionService {

	private static final String TF_SERVICE_HOST = "splat34.sto.midasplayer.com";
	private static final int TF_SERVICE_PORT = 4001;

	private static class ServiceLoader {
		private static final PredictionServiceBlockingStub INSTANCE = PredictionServiceGrpc
				.newBlockingStub(new ForceDeadlineChannel(TF_SERVICE_HOST, TF_SERVICE_PORT, 5000));
	}

	public static PredictionServiceBlockingStub getBlockingStub() {
		return ServiceLoader.INSTANCE;
	}

}
