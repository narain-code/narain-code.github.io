package com.king.rbea.aggregators;

import com.king.rbea.documenting.RbeaDocumentedClass;
import com.king.rbea.documenting.RbeaDocumentedMethod;

@RbeaDocumentedClass(summary = "Ratio aggregators.")
public interface RatioAggregator extends DimensionalAggregator<RatioAggregator> {

	@RbeaDocumentedMethod(summary = "Adds the given value to numerator (top) of the ratio.")
	void addToNumerator(long num);

	@RbeaDocumentedMethod(summary = "Adds the given value to denominator (bottom) of the ratio.")
	void addToDenominator(long num);
}
