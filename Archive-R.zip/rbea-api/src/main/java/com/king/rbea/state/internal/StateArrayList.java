package com.king.rbea.state.internal;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Spliterator;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.UnaryOperator;
import java.util.stream.Stream;

import com.king.flink.utils.Unchecked;
import com.king.rbea.state.LocalState;

public class StateArrayList<T> extends ArrayList<T> {

	public static final class State<T> extends LocalState<ArrayList<T>> {
		private static final long serialVersionUID = 1L;

		public State(String name) {
			super(name);
		}

		@Override
		public ArrayList<T> getValue(long coreId, InternalState state) throws Exception {
			return new StateArrayList<>(state);
		}
	}

	private static final long serialVersionUID = 1L;
	private ArrayList<T> localState = null;
	private final InternalState state;

	public StateArrayList(InternalState state) {
		this.state = state;
	}

	@SuppressWarnings("unchecked")
	private void loadState() {
		try {
			if (localState == null) {
				Object val = state.readValue();
				localState = (ArrayList<T>) (val != null ? val : new ArrayList<>());
			}
		} catch (Exception ex) {
			Unchecked.throwSilently(ex);
		}
	}

	private void updateState() {
		try {
			state.writeValue(localState.isEmpty() ? null : localState);
		} catch (Exception ex) {
			Unchecked.throwSilently(ex);
		}
	}

	@Override
	public Stream<T> stream() {
		loadState();
		return localState.stream();
	}

	@Override
	public Stream<T> parallelStream() {
		loadState();
		return localState.parallelStream();
	}

	@Override
	public int size() {
		loadState();
		return localState.size();
	}

	@Override
	public boolean isEmpty() {
		loadState();
		return localState.isEmpty();
	}

	@Override
	public boolean contains(Object o) {
		loadState();
		return localState.contains(o);
	}

	@Override
	public int indexOf(Object o) {
		loadState();
		return localState.indexOf(o);
	}

	@Override
	public int lastIndexOf(Object o) {
		loadState();
		return localState.lastIndexOf(o);
	}

	@Override
	public Object clone() {
		loadState();
		return localState.clone();
	}

	@Override
	public Object[] toArray() {
		loadState();
		return localState.toArray();
	}

	@Override
	public <X> X[] toArray(X[] a) {
		loadState();
		return localState.toArray(a);
	}

	@Override
	public T get(int index) {
		loadState();
		return localState.get(index);
	}

	@Override
	public T set(int index, T element) {
		loadState();
		T set = localState.set(index, element);
		updateState();
		return set;
	}

	@Override
	public boolean add(T e) {
		loadState();
		boolean added = localState.add(e);
		updateState();
		return added;
	}

	@Override
	public void add(int index, T element) {
		loadState();
		localState.add(index, element);
		updateState();
	}

	@Override
	public T remove(int index) {
		loadState();
		T removed = localState.remove(index);
		updateState();
		return removed;
	}

	@Override
	public boolean remove(Object o) {
		loadState();
		boolean removed = localState.remove(o);
		updateState();
		return removed;
	}

	@Override
	public void clear() {
		loadState();
		localState.clear();
		updateState();
	}

	@Override
	public boolean addAll(Collection<? extends T> c) {
		loadState();
		boolean addAll = localState.addAll(c);
		updateState();
		return addAll;
	}

	@Override
	public boolean addAll(int index, Collection<? extends T> c) {
		loadState();
		boolean addAll = localState.addAll(index, c);
		updateState();
		return addAll;
	}

	@Override
	public boolean removeAll(Collection<?> c) {
		loadState();
		boolean removed = localState.removeAll(c);
		updateState();
		return removed;
	}

	@Override
	public boolean retainAll(Collection<?> c) {
		loadState();
		boolean retainAll = localState.retainAll(c);
		updateState();
		return retainAll;
	}

	@Override
	public ListIterator<T> listIterator(int index) {
		loadState();
		return localState.listIterator(index);
	}

	@Override
	public ListIterator<T> listIterator() {
		loadState();
		return localState.listIterator();
	}

	@Override
	public Iterator<T> iterator() {
		loadState();
		return localState.iterator();
	}

	@Override
	public List<T> subList(int fromIndex, int toIndex) {
		loadState();
		return localState.subList(fromIndex, toIndex);
	}

	@Override
	public void forEach(Consumer<? super T> action) {
		localState.forEach(action);
	}

	@Override
	public Spliterator<T> spliterator() {
		loadState();
		return localState.spliterator();
	}

	@Override
	public boolean removeIf(Predicate<? super T> filter) {
		loadState();
		boolean removeIf = localState.removeIf(filter);
		updateState();
		return removeIf;
	}

	@Override
	public void replaceAll(UnaryOperator<T> operator) {
		loadState();
		localState.replaceAll(operator);
		updateState();
	}

	@Override
	public void sort(Comparator<? super T> c) {
		loadState();
		localState.sort(c);
	}

	@Override
	public boolean equals(Object o) {
		loadState();
		return localState.equals(o);
	}

	@Override
	public int hashCode() {
		loadState();
		return localState.hashCode();
	}

	@Override
	public boolean containsAll(Collection<?> c) {
		loadState();
		return localState.containsAll(c);
	}

	@Override
	public String toString() {
		loadState();
		return localState.toString();
	}

}
