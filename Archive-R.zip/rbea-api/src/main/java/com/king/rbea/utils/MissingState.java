package com.king.rbea.utils;

import com.king.rbea.State;
import com.king.rbea.exceptions.ProcessorException;

public enum MissingState implements State {

	INSTANCE;

	@Override
	public <T> T get(long rbeaJobId, String fieldName) throws ProcessorException {
		throw new ProcessorException("Cannot access state on events without a core user id.");
	}

	@Override
	public <T> T get(String fieldName) throws ProcessorException {
		throw new ProcessorException("Cannot access state on events without a core user id.");
	}

	@Override
	public void update(String arg0, Object arg1) throws ProcessorException {
		throw new ProcessorException("Cannot access state on events without a core user id.");
	}

	@Override
	public void clearAll() throws ProcessorException {
		throw new ProcessorException("Cannot access state on events without a core user id.");
	}

	@Override
	public void export(Object... leading) throws ProcessorException {
		throw new ProcessorException("Cannot access state on events without a core user id.");
	}

}
