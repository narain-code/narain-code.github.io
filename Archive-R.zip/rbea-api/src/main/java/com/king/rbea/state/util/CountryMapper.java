package com.king.rbea.state.util;

import static org.apache.commons.lang3.ArrayUtils.contains;

import java.io.Serializable;
import java.util.Locale;
import java.util.Optional;
import java.util.function.Function;

import com.king.rbea.state.util.types.Country;

@SuppressWarnings("serial")
public final class CountryMapper implements Function<String, Country>, Serializable {

    private static final String[] ISO_COUNTRY_CODES = Locale.getISOCountries();

    @Override
    public Country apply(String rawCountry) {
        return Optional.ofNullable(rawCountry)
            .map(String::trim)
            .map(String::toUpperCase)
            .filter(this::isIsoCode)
            .map(Country::of)
            .orElse(null);
    }

    private boolean isIsoCode(String countryCode) {
        return contains(ISO_COUNTRY_CODES, countryCode);
    }

}
