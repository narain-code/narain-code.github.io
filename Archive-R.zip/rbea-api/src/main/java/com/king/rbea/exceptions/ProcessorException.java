package com.king.rbea.exceptions;

public class ProcessorException extends Exception {

	private static final long serialVersionUID = 1L;

	private static final long UNKNOWN = Long.MAX_VALUE;

	private long processorId;

	private final String customMessage;

	private boolean nonRecoverable = false;

	public ProcessorException(long processorId, Throwable e, String cause) {
		super(cause, e);
		this.processorId = processorId;
		this.customMessage = cause;
	}

	public ProcessorException(Throwable e, String cause) {
		this(UNKNOWN, e, cause);
	}

	public ProcessorException(Throwable e) {
		this(UNKNOWN, e);
	}

	public ProcessorException(long processorId, Throwable e) {
		super(e);
		this.processorId = processorId;
		this.customMessage = null;
	}

	public ProcessorException(String cause) {
		this(UNKNOWN, cause);
	}

	public ProcessorException(long processorId, String cause) {
		super(cause);
		this.processorId = processorId;
		this.customMessage = cause;
	}

	public String getCustomMessage() {
		return customMessage;
	}

	public boolean isRecoverable() {
		return !nonRecoverable;
	}

	public void setNotRecoverable() {
		this.nonRecoverable = true;
	}

	public void setProcessorId(long processorId) {
		this.processorId = processorId;
	}

	public long getProcessorId() {
		if (processorId == UNKNOWN) {
			throw new RuntimeException(
					"Processor id not set for exception, this indicates a bug in the error propagation logic");
		}
		return processorId;
	}
}
