package com.king.rbea.scripts.proxy;

import com.king.rbea.scripts.ScriptUtils;

public class GroovyScriptExecutor extends ProxyExecutor {

	private static final long serialVersionUID = 1L;
	private String groovyCode;

	private transient Class<?> javaClass;
	private transient Object javaObj;

	public GroovyScriptExecutor(long jobId, String jobName, String groovyCode) {
		super(jobId, jobName);
		this.groovyCode = groovyCode;
	}

	private void compile() throws Exception {
		if (javaClass == null) {
			javaClass = ScriptUtils.compile(groovyCode).getMetaClass().getTheClass();
			javaObj = javaClass.newInstance();
		}
	}

	@Override
	public Object getScriptInstance() throws Exception {
		compile();
		return javaObj;
	}
}
