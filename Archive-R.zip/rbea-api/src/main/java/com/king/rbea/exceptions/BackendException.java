package com.king.rbea.exceptions;

public class BackendException extends Exception {
	private static final long serialVersionUID = 1L;

	public BackendException(Throwable e, String cause) {
		super(cause, e);
	}

	public BackendException(Throwable e) {
		super(e);
	}

	public BackendException(String cause) {
		super(cause);
	}
}
