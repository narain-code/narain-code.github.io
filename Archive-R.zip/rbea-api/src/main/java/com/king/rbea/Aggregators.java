package com.king.rbea;

import com.king.rbea.aggregators.AggregationWindow;
import com.king.rbea.aggregators.ApproximateDistinctCounter;
import com.king.rbea.aggregators.AverageAggregator;
import com.king.rbea.aggregators.Counter;
import com.king.rbea.aggregators.RatioAggregator;
import com.king.rbea.aggregators.SumAggregator;
import com.king.rbea.documenting.RbeaDocumentedClass;
import com.king.rbea.documenting.RbeaDocumentedMethod;
import com.king.rbea.exceptions.ProcessorException;

@RbeaDocumentedClass(summary = "Use the Aggregators to define global windowed aggregates (counters, sum-aggregators) that are computed across all players. "
		+ "The name of each aggregator is used as a unique identifier so different aggregators should have different names inside one script.")
public interface Aggregators {

	@RbeaDocumentedMethod(summary = "Creates a windowed counter with a given name.")
	Counter getCounter(String name, AggregationWindow windowSize) throws ProcessorException;

	@RbeaDocumentedMethod(summary = "Creates a windowed sum aggregator with a given name.")
	SumAggregator getSumAggregator(String name, AggregationWindow windowSize) throws ProcessorException;

	@RbeaDocumentedMethod(summary = "Creates a windowed ratio aggregator with a given name.")
	RatioAggregator getRatioAggregator(String name, AggregationWindow windowSize) throws ProcessorException;

	@RbeaDocumentedMethod(summary = "Creates a windowed ratio aggregator with a given name.")
	AverageAggregator getAverageAggregator(String name, AggregationWindow windowSize) throws ProcessorException;

	@RbeaDocumentedMethod(summary = "Creates a windowed approximate distinct counter with a given name.")
	ApproximateDistinctCounter getApproximateDistinctCounter(String name, AggregationWindow windowSize) throws ProcessorException;
}
