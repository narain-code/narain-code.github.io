package com.king.rbea.scripts.info;

import java.util.ArrayList;
import java.util.List;

import com.king.rbea.Registry;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.state.LocalState;
import com.king.rbea.state.StateDescriptor;

public class InfoCollectorRegistry implements Registry {

	private final Registry reg;
	private final List<StateDescriptor<?>> registeredStates = new ArrayList<>();

	public InfoCollectorRegistry(Registry reg) {
		this.reg = reg;
	}

	@Override
	public <T> StateDescriptor<T> registerState(LocalState<T> state) throws ProcessorException {
		registeredStates.add(state);
		if (reg != null) {
			return reg.registerState(state);
		} else {
			return null;
		}
	}

	@Override
	public void registerStateDependency(long rbeaJobId, String stateName) throws ProcessorException {
		reg.registerStateDependency(rbeaJobId, stateName);
	}

	public List<StateDescriptor<?>> getInfo() {
		return registeredStates;
	}

}