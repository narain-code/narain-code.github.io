package com.king.rbea;

import com.king.rbea.documenting.RbeaDocumentedClass;
import com.king.rbea.documenting.RbeaDocumentedMethod;
import com.king.utils.AbTestMetaManager;
import com.king.utils.AbTestMetaManagerSingleton;
import com.king.utils.Bitero;
import com.king.utils.CurrencyManager;
import com.king.utils.CurrencyManagerSingleton;
import com.king.utils.Flavours;

@SuppressWarnings("deprecation")
@RbeaDocumentedClass(summary = "Contains built-in utility functions for RBEA programs, such as the currency converter.")
public interface Utils {

	@RbeaDocumentedMethod(summary = "Returns the currency converter.")
	default CurrencyManager getCurrencyManager() {
		return CurrencyManagerSingleton.getInstance();
	}

	@RbeaDocumentedMethod(summary = "Returns the abtestmetamanager converter.")
	default AbTestMetaManager getAbTestMetaManager() {
		return AbTestMetaManagerSingleton.getInstance();
	}

	@RbeaDocumentedMethod(summary = "Returns Bitero segments repository.")
	Bitero getBitero();

	@Deprecated
	default Flavours getFlavours() {
		return Flavours.INSTANCE;
	}

}
