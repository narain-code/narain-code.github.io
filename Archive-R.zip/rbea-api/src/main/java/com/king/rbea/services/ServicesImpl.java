package com.king.rbea.services;

import com.king.rbea.Services;

public enum ServicesImpl implements Services {
	INSTANCE
}
