package com.king.rbea;

import com.king.rbea.documenting.RbeaDocumentedClass;
import com.king.rbea.documenting.RbeaDocumentedMethod;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.state.LocalState;
import com.king.rbea.state.StateDescriptor;

@RbeaDocumentedClass(summary = "The Registry can be used to register new Fields and Callbacks.")
public interface Registry {

	@RbeaDocumentedMethod(summary = "Registers a new field or local state.")
	<T> StateDescriptor<T> registerState(LocalState<T> state) throws ProcessorException;

	@RbeaDocumentedMethod(summary = "Registers dependency on a field defined by another rbea script. This is a pre-requisite for accesing the field value.")
	void registerStateDependency(long rbeaJobId, String stateName) throws ProcessorException;

	@RbeaDocumentedMethod(summary = "Registers dependency on a field defined by another rbea script. This is a pre-requisite for accesing the field value.")
	default <T> void registerStateDependency(long rbeaJobId, StateDescriptor<T> descriptor) throws ProcessorException {
		registerStateDependency(rbeaJobId, descriptor.getStateName());
	}
}
