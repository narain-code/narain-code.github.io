package com.king.rbea.scripts.proxy.binders;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Optional;

import org.apache.flink.api.java.tuple.Tuple2;

import com.king.proxy.parameters.DefaultParameterBinder;
import com.king.proxy.parameters.ParameterBinding;
import com.king.proxy.parameters.SingleParameterBinder;
import com.king.rbea.Aggregators;
import com.king.rbea.Context;
import com.king.rbea.aggregators.AggregationWindow;
import com.king.rbea.annotations.Aggregator;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.scripts.ScriptUtils;

import net.bytebuddy.description.field.FieldDescription;
import net.bytebuddy.description.method.MethodDescription;
import net.bytebuddy.implementation.bytecode.StackManipulation;
import net.bytebuddy.implementation.bytecode.constant.TextConstant;
import net.bytebuddy.implementation.bytecode.member.FieldAccess;
import net.bytebuddy.implementation.bytecode.member.MethodInvocation;
import net.bytebuddy.implementation.bytecode.member.MethodVariableAccess;

public class AggregatorBinder implements SingleParameterBinder {
	private static final long serialVersionUID = 1L;
	private int contextOffset;

	public AggregatorBinder(int contextOffset) {
		this.contextOffset = contextOffset;
	}

	@Override
	public Optional<ParameterBinding> bind(Method sourceMethod, Method targetMethod, Class<?> targetParamType,
			List<Annotation> paramAnnotations, List<ParameterBinding> possibleBindings) throws Exception {

		Optional<Annotation> aggAnnotation = paramAnnotations.stream()
				.filter(a -> a instanceof Aggregator).findAny();

		if (aggAnnotation.isPresent()) {
			Aggregator agg = (Aggregator) aggAnnotation.get();
			try {
				ScriptUtils.validateAggregatorAnnotation(agg);
			} catch (ProcessorException e) {
				throw new RuntimeException(e);
			}
			Tuple2<Class<?>, MethodDescription> getter = getAggGetter(targetParamType);
			Class<?> sourceClass = getter.f0;
			StackManipulation sm = new StackManipulation.Compound(
					// Push context
					MethodVariableAccess.REFERENCE.loadFrom(contextOffset),
					// Call getAggregators()
					MethodInvocation.invoke(
							new MethodDescription.ForLoadedMethod(
									Context.class.getMethod("getAggregators"))),
					// Push aggregator name
					new TextConstant(agg.name()),
					// Push aggregator window size enum
					FieldAccess.forField(new FieldDescription.ForLoadedField(
							AggregationWindow.class.getDeclaredField(agg.window().name()))).read(),
					// Call appropriate aggregate getter on Aggregators
					MethodInvocation.invoke(getter.f1));

			sm = DefaultParameterBinder.load(sourceClass, targetParamType, sm);

			return Optional.of(new ParameterBinding(sourceClass, sm));
		}

		return Optional.empty();
	}

	private Tuple2<Class<?>, MethodDescription> getAggGetter(Class<?> targetParamClass) {
		for (Method m : Aggregators.class.getDeclaredMethods()) {
			if (m.getName().startsWith("get")) {
				if (targetParamClass.isAssignableFrom(m.getReturnType())) {
					return Tuple2.of(m.getReturnType(), new MethodDescription.ForLoadedMethod(m));
				}
			}
		}
		return null;
	}
}