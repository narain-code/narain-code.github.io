package com.king.rbea.aggregators;

public enum DimensionType {
	STRING, LONG
}
