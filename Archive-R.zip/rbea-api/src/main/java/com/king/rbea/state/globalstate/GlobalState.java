package com.king.rbea.state.globalstate;

import java.time.Clock;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import com.king.rbea.Context;
import com.king.rbea.State;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.extensions.RBEAExtension;
import com.king.rbea.state.LocalState;
import com.king.rbea.state.StateDescriptor;
import com.king.rbea.state.util.KingLocaleMapper;

public class GlobalState implements RBEAExtension {

	private final State state;

	protected static Clock clock = Clock.systemDefaultZone();

	public static void setClock(Clock newClock) {
		clock = newClock;
	}

	public static Clock getClock() {
		return clock;
	}

	public GlobalState(Context ctx) {
		state = ctx.getState();
	}

	/**
	 * Universal (General): FIRST_ACTIVITY_MSTS Desc.: the time stamp for the first
	 * activity
	 */
	public static final LocalState<Long> FIRST_ACTIVITY_MSTS = LocalState.create("FIRST_ACTIVITY_MSTS", 0l);

	public Long getFirstActivityMsts() throws ProcessorException {
		return state.get(FIRST_ACTIVITY_MSTS);
	}

	/**
	 * Universal (General): DAYS_FROM_FIRST_ACTIVITY Derived fr.:
	 * FIRST_ACTIVITY_MSTS Desc.: the number of days elapsed from the first activity
	 */
	public static final StateDescriptor<Double> DAYS_FROM_FIRST_ACTIVITY = FIRST_ACTIVITY_MSTS.postProcess(x -> {
		long now = clock.millis();
		if (x < 1 || x >= now) {
			return .0d;
		} else {
			return GlobalStateUtility.elapsedHours(x, now) / 24.d;
		}

	});

	public Double getDaysFromFirstActivity() throws ProcessorException {
		return state.get(DAYS_FROM_FIRST_ACTIVITY);
	}

	/*****************
	 * General: APP_BUILD_STRING Desc.:
	 */
	public static final LocalState<String> APP_BUILD_STRING = LocalState.create("APP_BUILD_STRING", "");

	public String getAppBuildString() throws ProcessorException {
		return state.get(APP_BUILD_STRING);
	}

	/**
	 * General: LATEST_APP_UPDATE_MSTS Relate to: APP_BUILD_STRING Desc.: the time
	 * stamp of the latest update of application
	 */
	public static final LocalState<Long> LATEST_APP_UPDATE_MSTS = LocalState.create("LATEST_APP_UPDATE_MSTS", 0l);

	public Long getLatestAppUpdateMsts() throws ProcessorException {
		return state.get(LATEST_APP_UPDATE_MSTS);
	}

	/**
	 * General: DEVICE_OS Desc.: the string of the client OS identifier
	 */
	public static final LocalState<String> DEVICE_OS = LocalState.create("DEVICE_OS", "");

	public String getDeviceOs() throws ProcessorException {
		return state.get(DEVICE_OS);
	}

	/**
	 * General: DEVICE_MODEL Desc.: the string of the client device model
	 */
	public static final LocalState<String> DEVICE_MODEL = LocalState.create("DEVICE_MODEL", "");

	public String getDeviceModel() throws ProcessorException {
		return state.get(DEVICE_MODEL);
	}

	/**
	 * General: DEVICE_RAM Desc.: the RAM capacity in bytes of client device
	 */
	public static final LocalState<Long> DEVICE_RAM = LocalState.create("DEVICE_RAM", 0l);

	public Long getDeviceRam() throws ProcessorException {
		return state.get(DEVICE_RAM);
	}

	/**
	 * General: DISPLAY_FRAME_RATE Desc.: the most recent logged display frame rate
	 * of game rendering
	 */
	public static final LocalState<Double> DISPLAY_FRAME_RATE = LocalState.create("DISPLAY_FRAME_RATE", 0.0d);

	public Double getDisplayFrameRate() throws ProcessorException {
		return state.get(DISPLAY_FRAME_RATE);
	}

	/**
	 * General: DEVICE_MANUFACTURER Desc.: the string of manufacturer of client
	 * device
	 */
	public static final LocalState<String> DEVICE_MANUFACTURER = LocalState.create("DEVICE_MANUFACTURER", "");

	public String getDeviceManufacturer() throws ProcessorException {
		return state.get(DEVICE_MANUFACTURER);
	}

	/**
	 * General: CLIENT_PLATFORM Desc.: the platform type: android, ios, flash/html,
	 * windows platform (uwp), windows phone
	 */
	public static final LocalState<String> CLIENT_PLATFORM = LocalState.create("CLIENT_PLATFORM", "");

	public String getClientPlatform() throws ProcessorException {
		return state.get(CLIENT_PLATFORM);
	}

	/**
	 * General: COUNTRY_CHANGE_HISTORY_30DAYS Desc.: the device country change
	 * history over the past 30 days.
	 */
	protected static final LocalState<TreeMap<Long, String>> COUNTRY_CHANGE_HISTORY_30DAYS = LocalState
			.createTreeMap("COUNTRY_CHANGE_HISTORY", Long.class, String.class);

	public TreeMap<Long, String> getcountryChangeHistory30days() throws ProcessorException {
		TreeMap<Long, String> countryChangeHistory = state.get(COUNTRY_CHANGE_HISTORY_30DAYS);
		long now = clock.millis();
		GlobalStateUtility.historyCleanup(countryChangeHistory, now, GlobalStateUtility.hrsPer30Days,
				GlobalStateUtility.maxCountryNum);
		return countryChangeHistory;
	}

	/**
	 * General: COUNTRY Derived fr.: COUNTRY_CHANGE_HISTORY_30DAYS Desc.: the
	 * current device country of the client
	 */
	public static final StateDescriptor<String> COUNTRY = COUNTRY_CHANGE_HISTORY_30DAYS.postProcess(
			x -> (x.size() > 0) ? x.lastEntry().getValue() : "");

	public String getCountry() throws ProcessorException {
		TreeMap<Long, String> countryChangeHistory = state.get(COUNTRY_CHANGE_HISTORY_30DAYS);
		long now = clock.millis();
		GlobalStateUtility.historyCleanup(countryChangeHistory, now, GlobalStateUtility.hrsPer30Days,
				GlobalStateUtility.maxCountryNum);
		return state.get(COUNTRY);
	}

	/**
	 * General: NUM_ACTIVE_COUNTRIES_30DAYS Derived fr.:
	 * COUNTRY_CHANGE_HISTORY_30DAYS Desc.: the number of distinct device countries
	 * that appeared over the past 30 days
	 */
	public static final StateDescriptor<Integer> NUM_ACTIVE_COUNTRIES_30DAYS = COUNTRY_CHANGE_HISTORY_30DAYS
			.postProcess(
					x -> (int) (long) x.values().stream().distinct().count());

	public Integer getNumActiveCountries30Days() throws ProcessorException {
		TreeMap<Long, String> countryChangeHistory = state.get(COUNTRY_CHANGE_HISTORY_30DAYS);
		long now = clock.millis();
		GlobalStateUtility.historyCleanup(countryChangeHistory, now, GlobalStateUtility.hrsPer30Days,
				GlobalStateUtility.maxCountryNum);
		return state.get(NUM_ACTIVE_COUNTRIES_30DAYS);
	}

	/**
	 * General: MOST_ACTIVE_COUNTRY_30DAYS Derived fr.:
	 * COUNTRY_CHANGE_HISTORY_30DAYS Desc.: the country that client stays in for the
	 * longest period of time
	 */
	public static final StateDescriptor<String> MOST_ACTIVE_COUNTRY_30DAYS = COUNTRY_CHANGE_HISTORY_30DAYS
			.postProcess(x -> {
				if (x.size() == 0) {
					return "";
				}
				TreeMap<Long, String> iterateCopy = new TreeMap<>(x);
				Long xFirstKey = x.firstKey();
				long now = clock.millis();
				Long msts30daysAgo = now - GlobalStateUtility.msPerDay * 30l;
				// Act: adjust the first timestamp
				if (xFirstKey < msts30daysAgo) {
					iterateCopy.remove(xFirstKey);
					iterateCopy.put(msts30daysAgo, x.get(xFirstKey));
				}
				// Act: append the last dummy timestamp identifying current time
				iterateCopy.put(now, "");
				// Act: accumulate the elapsed time of each country
				Map<String, Long> countryTimeMap = new HashMap<>();
				Map.Entry<Long, String> previousEntry = null;
				for (Map.Entry<Long, String> entry : iterateCopy.entrySet()) {
					if (previousEntry != null) {
						Long timeDiff = entry.getKey() - previousEntry.getKey();
						if (timeDiff > 0) {
							String country = previousEntry.getValue();
							if (countryTimeMap.containsKey(country)) {
								countryTimeMap.put(country, countryTimeMap.get(country) + timeDiff);
							} else {
								countryTimeMap.put(country, timeDiff);
							}
						}
					}
					previousEntry = entry;
				}
				// Act: find out the country that elapsed the longest time
				Map.Entry<String, Long> maxEntry = null;
				for (Map.Entry<String, Long> entry : countryTimeMap.entrySet()) {
					if (maxEntry == null || entry.getValue().compareTo(maxEntry.getValue()) > 0) {
						maxEntry = entry;
					}
				}
				return maxEntry == null ? "" : maxEntry.getKey();
			});

	public String getMostActiveCountry30days() throws ProcessorException {
		TreeMap<Long, String> countryChangeHistory = state.get(COUNTRY_CHANGE_HISTORY_30DAYS);
		long now = clock.millis();
		GlobalStateUtility.historyCleanup(countryChangeHistory, now, GlobalStateUtility.hrsPer30Days,
				GlobalStateUtility.maxCountryNum);
		return state.get(MOST_ACTIVE_COUNTRY_30DAYS);
	}

	/**
	 * General: DEVICE_LOCALE Desc.: the cleaned device locale
	 */
	public static final LocalState<String> DEVICE_LOCALE = LocalState.create("DEVICE_LOCALE", "");

	public String getDeviceLocale() throws ProcessorException {
		return state.get(DEVICE_LOCALE);
	}

	/**
	 * General: DEVICE_LANGUAGE Derived fr.: DEVICE_LOCALE Desc.: the device
	 * language
	 */
	public static final StateDescriptor<String> DEVICE_LANGUAGE = DEVICE_LOCALE.postProcess(
			new KingLocaleMapper()).postProcess(x -> x.getLanguage());

	public String getDeviceLanguage() throws ProcessorException {
		return state.get(DEVICE_LANGUAGE);
	}

	/**
	 * General: NUM_SIGNIN Desc.: the number of signins
	 */
	public static final LocalState<Integer> NUM_SIGNIN = LocalState.create("NUM_SIGNIN", 0);

	public Integer getNumSignin() throws ProcessorException {
		return state.get(NUM_SIGNIN);
	}

	/**
	 * General: FIRST_INSTALL_MSTS Desc.: the timestamp of first app installation
	 */
	public static final LocalState<Long> FIRST_INSTALL_MSTS = LocalState.create("FIRST_INSTALL_MSTS", 0l);

	public Long getFirstInstallMsts() throws ProcessorException {
		return state.get(FIRST_INSTALL_MSTS);
	}

	/**
	 * General: HAS_PLAYED_ON_IOS Desc.:
	 */
	public static final LocalState<Boolean> HAS_PLAYED_ON_IOS = LocalState.create("HAS_PLAYED_ON_IOS", false);

	public Boolean getHasPlayedOnIos() throws ProcessorException {
		return state.get(HAS_PLAYED_ON_IOS);
	}

	/**
	 * General: HAS_PLAYED_ON_ANDROID Desc.:
	 */
	public static final LocalState<Boolean> HAS_PLAYED_ON_ANDROID = LocalState.create("HAS_PLAYED_ON_ANDROID", false);

	public Boolean getHasPlayedOnAndroid() throws ProcessorException {
		return state.get(HAS_PLAYED_ON_ANDROID);
	}

	/**
	 * General: DEVICE_TIMEZONE Desc.: the device timezone
	 */
	public static final LocalState<String> DEVICE_TIMEZONE = LocalState.create("DEVICE_TIMEZONE", "");

	public String getDeviceTimezone() throws ProcessorException {
		return state.get(DEVICE_TIMEZONE);
	}

	/**
	 * General: IS_STRONG_ACCOUNT Desc.: whether it is a strong account
	 */
	public static final LocalState<Boolean> IS_STRONG_ACCOUNT = LocalState.create("IS_STRONG_ACCOUNT", false);

	public Boolean getIsStrongAccount() throws ProcessorException {
		return state.get(IS_STRONG_ACCOUNT);
	}

	/**********************
	 * Level: HIGHEST_LEVEL Desc.: highest level
	 */
	public static final LocalState<Integer> HIGHEST_LEVEL = LocalState.create("HIGHEST_LEVEL", 0);

	public Integer getHighestLevel() throws ProcessorException {
		return state.get(HIGHEST_LEVEL);
	}

	/**
	 * Level: FAILED_ATTEMPTS_HIGHEST_LEVEL Desc.: highest level
	 */
	public static final LocalState<Integer> FAILED_ATTEMPTS_HIGHEST_LEVEL = LocalState.create(
			"FAILED_ATTEMPTS_HIGHEST_LEVEL", 0);

	public Integer getFailedAttemptsHighestLevel() throws ProcessorException {
		return state.get(FAILED_ATTEMPTS_HIGHEST_LEVEL);
	}

	/**
	 * Level: HIGHEST_SUCCESS_LEVEL Desc.: highest level that has been successfully
	 * fulfilled
	 */
	public static final LocalState<Integer> HIGHEST_SUCCESS_LEVEL = LocalState.create("HIGHEST_SUCCESS_LEVEL", 0);

	public Integer getHighestSuccessLevel() throws ProcessorException {
		return state.get(HIGHEST_SUCCESS_LEVEL);
	}

	/**********************
	 * Spend: TOTAL_SPEND_USD Desc.: the total amount of US dollars that has been
	 * spent by the corresponding user
	 */
	public static final LocalState<Double> TOTAL_SPEND_USD = LocalState.create("TOTAL_SPEND_USD", 0.0d);

	public Double getTotalSpendUsd() throws ProcessorException {
		return state.get(TOTAL_SPEND_USD);
	}

	/**
	 * Spend: IS_PAID_USER Derived fr.: TOTAL_SPEND_USD Desc.: has the user ever
	 * paid?
	 */
	public static final StateDescriptor<Boolean> IS_PAID_USER = TOTAL_SPEND_USD.postProcess(x -> x > 0);

	public Boolean getIsPaidUser() throws ProcessorException {
		return state.get(IS_PAID_USER);
	}

	/**
	 * Spend: LAST_STORE_OPEN_MSTS Desc.: the timestamp of the latest StoreOpen
	 * action
	 */
	public static final LocalState<Long> LAST_STORE_OPEN_MSTS = LocalState.create("LAST_STORE_OPEN_MSTS", 0l);

	public Long getLastStoreOpenMsts() throws ProcessorException {
		return state.get(LAST_STORE_OPEN_MSTS);
	}

	/**
	 * Spend: FIRST_SPEND_MSTS Desc.: the timestamp of the earliest known spend
	 */
	public static final LocalState<Long> FIRST_SPEND_MSTS = LocalState.create("FIRST_SPEND_MSTS", 0l);

	public Long getFirstSpendMsts() throws ProcessorException {
		return state.get(FIRST_SPEND_MSTS);
	}

	/**
	 * Spend: SPEND_USD_HISTORY_30DAYS Desc.: The history of purchase (measured in
	 * US dollars) over the past 30 days.
	 */
	protected static final LocalState<TreeMap<Long, Double>> SPEND_USD_HISTORY_30DAYS = LocalState.createTreeMap(
			"SPEND_USD_HISTORY_30DAYS", Long.class, Double.class);

	private TreeMap<Long, Double> cleanupSpendUsdHistory30Days() throws ProcessorException {
		TreeMap<Long, Double> spendUsdHistory = state.get(SPEND_USD_HISTORY_30DAYS);
		long now = clock.millis();
		GlobalStateUtility.historyCleanup(spendUsdHistory, now, GlobalStateUtility.hrsPer30Days,
				GlobalStateUtility.maxSpendNum);
		return spendUsdHistory;
	}

	public TreeMap<Long, Double> getSpendUsdHistory30days() throws ProcessorException {
		return cleanupSpendUsdHistory30Days();
	}

	/**
	 * Spend: LAST_SPEND_MSTS Derived fr.: SPEND_USD_HISTORY_30DAYS Desc.: the time
	 * stamp of the latest spend
	 */
	public static final StateDescriptor<Long> LAST_SPEND_MSTS = SPEND_USD_HISTORY_30DAYS.postProcess(
			x -> x.size() > 0 ? x.lastKey() : 0l);

	public Long getLastSpendMsts() throws ProcessorException {
		return state.get(LAST_SPEND_MSTS);
	}

	/**
	 * Spend: DAYS_SINCE_LAST_PAYMENT Derived fr.: LAST_SPEND_MSTS Desc.: the time
	 * stamp of the latest spend
	 */
	public static final StateDescriptor<Double> DAYS_SINCE_LAST_PAYMENT = LAST_SPEND_MSTS.postProcess(x -> {
		if (x < 1)
			return 0d;
		return GlobalStateUtility.elapsedHours(x, clock.millis()) / 24.d;
	});

	public Double getDaysSinceLastPayment() throws ProcessorException {
		return state.get(DAYS_SINCE_LAST_PAYMENT);
	}

	/**
	 * Spend: SPEND_USD_LAST_30DAYS Derived fr.: SPEND_USD_HISTORY_30DAYS Desc.: the
	 * total spend (measured in US dollars) over the past 30 days
	 */
	public static final StateDescriptor<Double> SPEND_USD_LAST_30DAYS = SPEND_USD_HISTORY_30DAYS.postProcess(
			x -> GlobalStateUtility.historySum(x, 0l));

	public Double getSpendUsdLast30days() throws ProcessorException {
		cleanupSpendUsdHistory30Days();
		return state.get(SPEND_USD_LAST_30DAYS);
	}

	/**
	 * Spend: SPEND_USD_LAST_7DAYS Derived fr.: SPEND_USD_HISTORY_30DAYS Desc.: the
	 * total spend (measured in US dollars) over the past 7 days
	 */
	public static final StateDescriptor<Double> SPEND_USD_LAST_7DAYS = SPEND_USD_HISTORY_30DAYS.postProcess(x -> {
		long now = clock.millis();
		return GlobalStateUtility.historySum(x, now - GlobalStateUtility.msPerDay * 7l);
	});

	public Double getSpendUsdLast7days() throws ProcessorException {
		cleanupSpendUsdHistory30Days();
		return state.get(SPEND_USD_LAST_7DAYS);
	}

	/**
	 * Spend: SPEND_USD_LAST_24HOURS Derived fr.: SPEND_USD_HISTORY_30DAYS Desc.:
	 * the total spend (measured in US dollars) over the past 24 hours
	 */
	public static final StateDescriptor<Double> SPEND_USD_LAST_24HOURS = SPEND_USD_HISTORY_30DAYS.postProcess(x -> {
		long now = clock.millis();
		return GlobalStateUtility.historySum(x, now - GlobalStateUtility.msPerDay);
	});

	public Double getSpendUsdLast24hrs() throws ProcessorException {
		cleanupSpendUsdHistory30Days();
		return state.get(SPEND_USD_LAST_24HOURS);
	}

	/**
	 * Spend: NUM_PAYMENT_LAST_7DAYS Derived fr.: SPEND_USD_HISTORY_30DAYS Desc.:
	 * the number of payments over the past 7 days
	 */
	public static final StateDescriptor<Integer> NUM_PAYMENT_LAST_7DAYS = SPEND_USD_HISTORY_30DAYS.postProcess(x -> {
		long now = clock.millis();
		return GlobalStateUtility.historyCount(x, now - GlobalStateUtility.msPerDay * 7l);
	});

	public Integer getNumPaymentLast7days() throws ProcessorException {
		cleanupSpendUsdHistory30Days();
		return state.get(NUM_PAYMENT_LAST_7DAYS);
	}

	/**
	 * Spend: NUM_PAYMENT_LAST_30DAYS Derived fr.: SPEND_USD_HISTORY_30DAYS Desc.:
	 * the number of payments over the past 7 days
	 */
	public static final StateDescriptor<Integer> NUM_PAYMENT_LAST_30DAYS = SPEND_USD_HISTORY_30DAYS.postProcess(x -> {
		long now = clock.millis();
		return GlobalStateUtility.historyCount(x, now - GlobalStateUtility.msPerDay * 30l);
	});

	public Integer getNumPaymentLast30days() throws ProcessorException {
		cleanupSpendUsdHistory30Days();
		return state.get(NUM_PAYMENT_LAST_30DAYS);
	}
}
