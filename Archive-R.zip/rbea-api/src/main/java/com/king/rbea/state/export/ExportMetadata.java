// (C) king.com Ltd 2018
package com.king.rbea.state.export;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.function.BiFunction;

import org.apache.avro.Schema;
import org.apache.avro.SchemaBuilder;
import org.apache.avro.SchemaBuilder.ArrayDefault;
import org.apache.avro.SchemaBuilder.BaseFieldTypeBuilder;
import org.apache.avro.SchemaBuilder.BaseTypeBuilder;
import org.apache.avro.SchemaBuilder.FieldAssembler;
import org.apache.avro.SchemaBuilder.FieldTypeBuilder;
import org.apache.avro.SchemaBuilder.TypeBuilder;

import com.king.flink.utils.Unchecked;
import com.king.rbea.Context;
import com.king.rbea.annotations.state.ExportColumn;
import com.king.rbea.annotations.state.ExportNested;
import com.king.rbea.annotations.state.ExportTable;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.scripts.ScriptUtils;
import com.king.rbea.state.StateDescriptor;

class ExportMetadata {

	private final ExportColumn[] leadingColumns;
	private final Map<String, BiFunction<Object, Context, ?>> exportFunctions = new HashMap<>();
	private final Set<String> allExportedNames = new HashSet<>();
	private final boolean kafka;
	private final String tableName;

	private FieldAssembler<Schema> fields;

	private ExportMetadata(final ExportTable exports) {
		this.leadingColumns = exports.leadingColumns();
		this.tableName = !exports.name().equals("") ? exports.name() : exports.value();
		this.kafka = exports.kafka();
	}

	public static ExportMetadata extract(Class<?> clazz) throws ProcessorException {

		final ExportTable exports = clazz.getAnnotation(ExportTable.class);
		if (exports == null) {
			return null;
		}

		final ExportMetadata metadata = new ExportMetadata(exports);

		if (metadata.tableName == null || metadata.tableName.equals("")) {
			throw new ProcessorException("Exported name cannot be empty");
		}

		if (!metadata.kafka() && metadata.tableName().chars().filter(c -> c == '.').count() != 1) {
			throw new ProcessorException("Table name must contain schema: myschema.TableName");
		}

		metadata.fields = SchemaBuilder.record(metadata.tableName()).fields();

		for (ExportColumn leadingColumn : metadata.leadingColumns) {
			if (leadingColumn.name().equals("")) {
				throw new ProcessorException("Name must be defined for leadingColumns");
			}
			metadata.addColumn(leadingColumn, false, leadingColumn.name());
		}

		metadata.addColumnsFromType(clazz);

		return metadata;
	}

	public final ExportColumn[] leadingColumns() {
		return leadingColumns;
	}

	public final Schema schema() {
		return fields.endRecord();
	}

	public final boolean isEmpty() {
		return allExportedNames.isEmpty();
	}

	public final Map<String, BiFunction<Object, Context, ?>> exportFunctions() {
		return exportFunctions;
	}

	public final boolean kafka() {
		return kafka;
	}

	public final String tableName() {
		return tableName;
	}

	private static BiFunction<Object, Context, ?> getFunction(Field field, Class<?> targetClazz, boolean array)
			throws ProcessorException {
		final Class<?> fieldClazz = ScriptUtils.wrap(field.getType());

		if (StateDescriptor.class.isAssignableFrom(fieldClazz)) {
			return Unchecked.bifunction((instance, ctx) -> ctx.getState().get((StateDescriptor<?>) field.get(instance)));
		}

		if (array) {
			if (Collection.class.isAssignableFrom(fieldClazz)) {
				return getter(field);
			} else {
				throw new ProcessorException(
						"Invalid field type for array export. Should either be collection type or a StateDescriptor.");
			}
		} else {
			if (targetClazz.isAssignableFrom(fieldClazz)) {
				return getter(field);
			} else {
				throw new ProcessorException("Invalid field type for export. Should either be "
						+ targetClazz.getSimpleName() + " or a StateDescriptor.");
			}
		}
	}

	private void addColumnsFromType(Class<?> clazz) throws ProcessorException {
		addColumnsFromType(clazz, "", null);
	}

	private void addColumnsFromType(Class<?> clazz, String currentPrefix, BiFunction<Object, Context, ?> currentAccessor) throws ProcessorException {
		// Check for any non-public exported field and throw error if found
		for (Field field : clazz.getDeclaredFields()) {
			if (field.getAnnotation(ExportColumn.class) != null 
				&& field.getAnnotation(ExportNested.class) != null 
				&& !Modifier.isPublic(field.getModifiers())) {
				throw new ProcessorException("Cannot export non public field");
			}
		}
	
		for (Field field : clazz.getFields()) {
			final ExportColumn column = field.getAnnotation(ExportColumn.class);
			if (column != null) {
				final String columnName = currentPrefix + (column.name().equals("") ? field.getName() : column.name());

				addColumn(column, field.getType().isPrimitive(), columnName);

				final Class<?> exportTarget = column.type().getTargetClass();
				exportFunctions.put(columnName, compose(currentAccessor, getFunction(field, exportTarget, column.array())));

				continue;
			}

			final ExportNested nested = field.getAnnotation(ExportNested.class);
			if (nested != null) {
				if (nested.prefix().equals("")) {
					throw new ProcessorException("Prefix must be provided");
				}
				addColumnsFromType(field.getType(), currentPrefix + nested.prefix(), compose(currentAccessor, getter(field)));

				continue;
			}
		}
	}

	private static BiFunction<Object, Context, ?> compose(BiFunction<Object, Context, ?> before, BiFunction<Object, Context, ?> after) {
			return before == null ? after : (obj, ctx) -> after.apply(before.apply(obj, ctx), ctx);
	}

	private static BiFunction<Object, Context, ?> getter(final Field field) {
		return Unchecked.bifunction((obj, ctx) -> field.get(obj));
	}

	private void addColumn(ExportColumn column, boolean primitive, String columnName) throws ProcessorException {

		if (!allExportedNames.add(columnName)) {
			throw new ProcessorException("Column name " + columnName + " is not unique");
		}

		final boolean nullable = !primitive && column.nullable();

		final FieldTypeBuilder<Schema> ftb = fields.name(columnName).type();
		final BaseFieldTypeBuilder<Schema> type = nullable ? ftb.nullable() : ftb;

		if (column.array()) {
			final TypeBuilder<ArrayDefault<Schema>> items = type.array().items();
			final BaseTypeBuilder<ArrayDefault<Schema>> itemType = nullable ? items.nullable() : items;
			fields = typedColumn(column, itemType);
		} else {
			fields = typedColumn(column, type);
		}
	}

	private FieldAssembler<Schema> typedColumn(ExportColumn column, BaseFieldTypeBuilder<Schema> type)
			throws ProcessorException {
		switch (column.type()) {
		case BOOLEAN:
			return type.booleanType().noDefault();
		case DOUBLE:
			return type.doubleType().noDefault();
		case INT:
			return type.intType().noDefault();
		case LONG:
			return type.longType().noDefault();
		case STRING:
			return type.stringType().noDefault();
		default:
			throw new ProcessorException("Unsupported type: " + column.type());
		}
	}

	private FieldAssembler<Schema> typedColumn(ExportColumn column, BaseTypeBuilder<ArrayDefault<Schema>> itemType)
			throws ProcessorException {
		switch (column.type()) {
		case BOOLEAN:
			return itemType.booleanType().noDefault();
		case DOUBLE:
			return itemType.doubleType().noDefault();
		case INT:
			return itemType.intType().noDefault();
		case LONG:
			return itemType.longType().noDefault();
		case STRING:
			return itemType.stringType().noDefault();
		default:
			throw new ProcessorException("Unsupported type: " + column.type());
		}
	}

}
