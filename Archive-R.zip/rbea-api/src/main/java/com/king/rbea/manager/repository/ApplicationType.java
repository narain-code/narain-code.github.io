package com.king.rbea.manager.repository;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Types of applications we can store in the repository.
 */
public enum ApplicationType {
	GROOVY, JAVA, JAR;

	/**
	 * Parsing of old JSONs might contain empty values, here we set a default in such case.
	 */
	@JsonCreator
	public static ApplicationType forValue(String value) {
		for (ApplicationType applicationType : ApplicationType.values()) {
			if (applicationType.getLanguage().equals(value)) {
				return applicationType;
			}
		}
		// Default
		return GROOVY;
	}

	/**
	 * @return value to be used during JSON serialization;
	 */
	@JsonValue
	public String getLanguage() {
		return this.name().toLowerCase();
	}

	/**
	 * Checks whether stored in HDFS.
	 * 
	 * @return whether stored in HDFS
	 */
	public boolean isStoredInHDFS() {
		return this.equals(JAR);
	}
}
