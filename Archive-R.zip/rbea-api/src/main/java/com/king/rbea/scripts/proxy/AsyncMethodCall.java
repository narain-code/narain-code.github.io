package com.king.rbea.scripts.proxy;

import com.king.flink.utils.Unchecked;

public final class AsyncMethodCall implements Runnable {
	private final Runnable asyncCall;
	private final long procId;

	AsyncMethodCall(Runnable asyncCall, long procId) {
		this.asyncCall = asyncCall;
		this.procId = procId;
	}

	@Override
	public void run() {
		try {
			asyncCall.run();
		} catch (Throwable t) {
			Unchecked.throwSilently(new ExceptionWrapper(t));
		}
	}

	public long getProcessorId() {
		return procId;
	}

	public static class ExceptionWrapper extends Exception {

		private static final long serialVersionUID = 1L;

		public ExceptionWrapper(Throwable t) {
			super(t);
		}
	}
}