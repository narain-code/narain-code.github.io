package com.king.rbea.manager.types;

import java.io.Serializable;
import java.util.Map;

import com.king.rbea.utils.Constants;

public class ParameterSet implements Serializable {
	private static final long serialVersionUID = 1L;
	public final String type;
	public final String source;
	public final Map<String, Object> parameters;

	public ParameterSet(String type, String source, Map<String, Object> parameters) {
		this.type = type;
		this.source = source;
		this.parameters = parameters;
	}

	ParameterSet() {
		this(null, null, null);
	}

	public String getOutputName() {
		return parameters.get(Constants.AGGREGATOR_NAME).toString();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((parameters == null) ? 0 : parameters.hashCode());
		result = prime * result + ((source == null) ? 0 : source.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof ParameterSet)) {
			return false;
		}
		ParameterSet other = (ParameterSet) obj;
		if (parameters == null) {
			if (other.parameters != null) {
				return false;
			}
		} else if (!parameters.equals(other.parameters)) {
			return false;
		}
		if (source == null) {
			if (other.source != null) {
				return false;
			}
		} else if (!source.equals(other.source)) {
			return false;
		}
		if (type == null) {
			if (other.type != null) {
				return false;
			}
		} else if (!type.equals(other.type)) {
			return false;
		}
		return true;
	}
}
