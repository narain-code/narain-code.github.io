package com.king.rbea;

import java.util.Random;

import com.king.rbea.documenting.RbeaDocumentedClass;
import com.king.rbea.documenting.RbeaDocumentedMethod;
import com.king.rbea.exceptions.ProcessorException;

@RbeaDocumentedClass(summary = "Timers can be used to register event time callbacks for the current user.")
public interface Timers {

	Random rnd = new Random();

	@RbeaDocumentedMethod(summary = "Registers a callback that will trigger the onTimer method at the given event time timestamp with the specified id and parameter object.")
	void registerTimerWithId(int timerId, long timestamp, Object params) throws ProcessorException;

	@RbeaDocumentedMethod(summary = "Registers a callback that will trigger the onTimer method at the given event time timestamp with the specified id without parameter.")
	default void registerTimerWithId(int timerId, long timestamp) throws ProcessorException {
		registerTimerWithId(timerId, timestamp, null);
	}

	@RbeaDocumentedMethod(summary = "Registers a callback that will trigger the onTimer method at the given event time timestamp with the specified parameter object. Returns an id that can be used to remove the timer before it fires.")
	default int registerTimer(long timestamp, Object params) throws ProcessorException {
		int id = rnd.nextInt();
		registerTimerWithId(id, timestamp, params);
		return id;
	}

	@RbeaDocumentedMethod(summary = "Registers a callback that will trigger the onTimer method at the given event time timestamp without parameters. Returns an id that can be used to remove the timer before it fires.")
	default int registerTimer(long timestamp) throws ProcessorException {
		return registerTimer(timestamp, null);
	}

	@RbeaDocumentedMethod(summary = "Removes the callback registered with the given id.")
	void removeTimer(int id) throws ProcessorException;

	@RbeaDocumentedMethod(summary = "Removes all registered callbacks for the current user.")
	void removeAllTimers() throws ProcessorException;
}
