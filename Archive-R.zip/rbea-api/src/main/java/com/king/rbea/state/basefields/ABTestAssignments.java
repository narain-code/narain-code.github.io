package com.king.rbea.state.basefields;

public interface ABTestAssignments {
	
	Integer getCaseNum(String abTestName, Integer version);

	Integer getLastCaseNum(String abTestName);

	Integer getLastVersion(String abTestName);
	
}