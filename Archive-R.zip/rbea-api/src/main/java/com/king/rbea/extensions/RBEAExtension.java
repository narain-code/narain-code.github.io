package com.king.rbea.extensions;

public interface RBEAExtension {

}
