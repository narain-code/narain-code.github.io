package com.king.rbea.state.internal;

import java.util.Collection;
import java.util.Comparator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.NavigableMap;
import java.util.NavigableSet;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Function;

import com.king.flink.utils.Unchecked;
import com.king.rbea.state.LocalState;

public class StateTreeMap<K, V> extends TreeMap<K, V> {

	public static final class State<K, V> extends LocalState<TreeMap<K, V>> {
		private static final long serialVersionUID = 1L;

		public State(String name) {
			super(name);
		}

		@Override
		public TreeMap<K, V> getValue(long coreId, InternalState state) throws Exception {
			return new StateTreeMap<>(state);
		}
	}

	private static final long serialVersionUID = 1L;
	private TreeMap<K, V> localState = null;
	private final InternalState state;

	public StateTreeMap(InternalState state) {
		this.state = state;
	}

	@SuppressWarnings("unchecked")
	private void loadState() {
		try {
			if (localState == null) {
				Object val = state.readValue();
				localState = (TreeMap<K, V>) (val != null ? val : new TreeMap<>());
			}
		} catch (Exception ex) {
			Unchecked.throwSilently(ex);
		}
	}

	private void updateState() {
		try {
			state.writeValue(localState.isEmpty() ? null : localState);
		} catch (Exception ex) {
			Unchecked.throwSilently(ex);
		}
	}

	@Override
	public int size() {
		loadState();
		return localState.size();
	}

	@Override
	public boolean isEmpty() {
		loadState();
		return localState.isEmpty();
	}

	@Override
	public boolean containsKey(Object key) {
		loadState();
		return localState.containsKey(key);
	}

	@Override
	public boolean containsValue(Object value) {
		loadState();
		return localState.containsValue(value);
	}

	@Override
	public V get(Object key) {
		loadState();
		return localState.get(key);
	}

	@Override
	public V put(K key, V value) {
		loadState();
		V removed = localState.put(key, value);
		updateState();
		return removed;
	}

	@Override
	public V remove(Object key) {
		loadState();
		V removed = localState.remove(key);
		updateState();
		return removed;
	}

	@Override
	public void putAll(Map<? extends K, ? extends V> m) {
		loadState();
		localState.putAll(m);
		updateState();
	}

	@Override
	public void clear() {
		loadState();
		localState.clear();
		updateState();
	}

	@Override
	public Set<K> keySet() {
		loadState();
		return localState.keySet();
	}

	@Override
	public Collection<V> values() {
		loadState();
		return localState.values();
	}

	@Override
	public Set<Entry<K, V>> entrySet() {
		loadState();
		return localState.entrySet();
	}

	@Override
	public boolean equals(Object o) {
		loadState();
		return localState.equals(o);
	}

	@Override
	public int hashCode() {
		loadState();
		return localState.hashCode();
	}

	@Override
	public V getOrDefault(Object key, V defaultValue) {
		loadState();
		return localState.getOrDefault(key, defaultValue);
	}

	@Override
	public void forEach(BiConsumer<? super K, ? super V> action) {
		loadState();
		localState.forEach(action);
	}

	@Override
	public void replaceAll(BiFunction<? super K, ? super V, ? extends V> function) {
		loadState();
		localState.replaceAll(function);
		updateState();
	}

	@Override
	public V putIfAbsent(K key, V value) {
		loadState();
		V removed = localState.putIfAbsent(key, value);
		updateState();
		return removed;
	}

	@Override
	public boolean remove(Object key, Object value) {
		loadState();
		boolean removed = localState.remove(key, value);
		updateState();
		return removed;
	}

	@Override
	public boolean replace(K key, V oldValue, V newValue) {
		loadState();
		boolean replaced = localState.replace(key, oldValue, newValue);
		updateState();
		return replaced;
	}

	@Override
	public V replace(K key, V value) {
		loadState();
		V replaced = localState.replace(key, value);
		updateState();
		return replaced;
	}

	@Override
	public V computeIfAbsent(K key, Function<? super K, ? extends V> mappingFunction) {
		loadState();
		V replaced = localState.computeIfAbsent(key, mappingFunction);
		updateState();
		return replaced;
	}

	@Override
	public V computeIfPresent(K key, BiFunction<? super K, ? super V, ? extends V> remappingFunction) {
		loadState();
		V replaced = localState.computeIfPresent(key, remappingFunction);
		updateState();
		return replaced;
	}

	@Override
	public V compute(K key, BiFunction<? super K, ? super V, ? extends V> remappingFunction) {
		loadState();
		V replaced = localState.compute(key, remappingFunction);
		updateState();
		return replaced;
	}

	@Override
	public V merge(K key, V value, BiFunction<? super V, ? super V, ? extends V> remappingFunction) {
		loadState();
		V replaced = localState.merge(key, value, remappingFunction);
		updateState();
		return replaced;
	}

	@Override
	public Comparator<? super K> comparator() {
		loadState();
		return localState.comparator();
	}

	@Override
	public K firstKey() {
		loadState();
		return localState.firstKey();
	}

	@Override
	public K lastKey() {
		loadState();
		return localState.lastKey();
	}

	@Override
	public java.util.Map.Entry<K, V> firstEntry() {
		loadState();
		return localState.firstEntry();
	}

	@Override
	public java.util.Map.Entry<K, V> lastEntry() {
		loadState();
		return localState.lastEntry();
	}

	@Override
	public java.util.Map.Entry<K, V> pollFirstEntry() {
		loadState();
		return localState.pollFirstEntry();
	}

	@Override
	public java.util.Map.Entry<K, V> pollLastEntry() {
		loadState();
		return localState.pollLastEntry();
	}

	@Override
	public java.util.Map.Entry<K, V> lowerEntry(K key) {
		loadState();
		return localState.lowerEntry(key);
	}

	@Override
	public K lowerKey(K key) {
		loadState();
		return localState.lowerKey(key);
	}

	@Override
	public java.util.Map.Entry<K, V> floorEntry(K key) {
		loadState();
		return localState.floorEntry(key);
	}

	@Override
	public K floorKey(K key) {
		loadState();
		return localState.floorKey(key);
	}

	@Override
	public java.util.Map.Entry<K, V> ceilingEntry(K key) {
		loadState();
		return localState.ceilingEntry(key);
	}

	@Override
	public K ceilingKey(K key) {
		loadState();
		return localState.ceilingKey(key);
	}

	@Override
	public java.util.Map.Entry<K, V> higherEntry(K key) {
		loadState();
		return localState.higherEntry(key);
	}

	@Override
	public K higherKey(K key) {
		loadState();
		return localState.higherKey(key);
	}

	@Override
	public NavigableSet<K> navigableKeySet() {
		loadState();
		return localState.navigableKeySet();
	}

	@Override
	public NavigableSet<K> descendingKeySet() {
		loadState();
		return localState.descendingKeySet();
	}

	@Override
	public NavigableMap<K, V> descendingMap() {
		loadState();
		return localState.descendingMap();
	}

	@Override
	public NavigableMap<K, V> subMap(K fromKey, boolean fromInclusive, K toKey, boolean toInclusive) {
		loadState();
		return localState.subMap(fromKey, fromInclusive, toKey, toInclusive);
	}

	@Override
	public NavigableMap<K, V> headMap(K toKey, boolean inclusive) {
		loadState();
		return localState.headMap(toKey, inclusive);
	}

	@Override
	public NavigableMap<K, V> tailMap(K fromKey, boolean inclusive) {
		loadState();
		return localState.tailMap(fromKey, inclusive);
	}

	@Override
	public SortedMap<K, V> subMap(K fromKey, K toKey) {
		loadState();
		return localState.subMap(fromKey, toKey);
	}

	@Override
	public SortedMap<K, V> headMap(K toKey) {
		loadState();
		return localState.headMap(toKey);
	}

	@Override
	public SortedMap<K, V> tailMap(K fromKey) {
		loadState();
		return localState.tailMap(fromKey);
	}

}
