package com.king.rbea.aggregators;

import com.king.rbea.documenting.RbeaDocumentedClass;
import com.king.rbea.documenting.RbeaDocumentedMethod;

@RbeaDocumentedClass(summary = "Cardinality estimator using HyperLogLog")
public interface ApproximateDistinctCounter extends DimensionalAggregator<ApproximateDistinctCounter> {

	@RbeaDocumentedMethod(summary = "Offers the object to the estimator.")
	void offer(Object o);
}
