package com.king.rbea.configuration.processor;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Optional;

import org.apache.commons.lang3.Validate;
import org.apache.flink.api.java.ClosureCleaner;
import org.apache.flink.util.InstantiationUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.king.rbea.EventProcessor;
import com.king.rbea.configuration.Configuration;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.scripts.ProcessorFactory;
import com.king.rbea.scripts.info.EventProcessorInfo;
import com.king.rbea.scripts.info.StateInfo;
import com.king.rbea.state.StateDescriptor;

public abstract class Deployment extends ProcessorInfo {
	private static final long serialVersionUID = 1L;

	public static final String JOB_NAME_KEY = "name";
	public static final String TOPIC_KEY = "topic";

	public static final String SCRIPT_TEXT_KEY = "jobCode";
	public static final String SCRIPT_REFERENCE = "jobReference";
	public static final String PROCESSOR_OBJECT_KEY = "processorObject";

	public static final String IS_UPDATE_KEY = "isUpdate";
	public static final String DISABLED_KEY = "disabled";
	public static final String TEST_KEY = "test";

	public static final String MAX_ERRORS_PER_MINUTE = "maxErrorsPerMin";

	public static final String CONFIG_SCHEMAS = "configInfo";
	public static final String STATE_INFO = "states";

	public static final String CLONE_PROC_ON_GET = "cloneProcOnGet";

	private static final Logger LOG = LoggerFactory.getLogger(Deployment.class);

	public Deployment(String jobName, long procId, String topic, long startTime) {
		super(procId);
		setString(JOB_NAME_KEY, Validate.notNull(jobName, "Job name cannot be null"));
		setString(TOPIC_KEY, Validate.notNull(topic, "Topic cannot be null"));
		setLong(JobSummary.JOB_START_TIME_KEY, Validate.notNull(startTime, "Start time time cannot be null"));
		setLong(JobSummary.JOB_CREATED_TIME_KEY, Validate.notNull(startTime, "Start time time cannot be null"));
	}

	public Deployment(Configuration conf) {
		super(conf);
	}

	public Deployment setTopic(String topic) {
		setString(TOPIC_KEY, Validate.notNull(topic, "Topic cannot be null"));
		return this;
	}

	public Deployment withErrorTolerance(int maxErrorsPerMin) {
		if (maxErrorsPerMin > 1000) {
			throw new RuntimeException("Cannot tolerate more than 1000 errors per min");
		}
		this.setInteger(MAX_ERRORS_PER_MINUTE, maxErrorsPerMin);
		return this;
	}

	public Optional<Integer> getMaxErrorsPerMin() {
		return this.getInteger(MAX_ERRORS_PER_MINUTE);
	}

	public Deployment asUpdate() {
		this.setBoolean(IS_UPDATE_KEY, true);
		return this;
	}

	public Deployment withInitialConfig(String json) {
		this.setString(JobConfig.JOB_CONFIG_KEY, json);
		return this;
	}

	public Deployment disable() {
		this.setBoolean(DISABLED_KEY, true);
		return this;
	}

	public Deployment enable() {
		this.setBoolean(DISABLED_KEY, false);
		return this;
	}

	public boolean isDisabled() {
		return getBoolean(DISABLED_KEY).orElse(false);
	}

	public Optional<String> getJobConfig() {
		return getString(JobConfig.JOB_CONFIG_KEY);
	}

	public boolean isUpdate() {
		return getBoolean(IS_UPDATE_KEY).orElse(false);
	}

	public boolean isTest() {
		return getBoolean(TEST_KEY).orElse(false);
	}

	public String getJobName() {
		return getString(JOB_NAME_KEY).get();
	}

	@Deprecated
	public String getTopic() {
		return getBackendId();
	}

	public String getBackendId() {
		return getString(TOPIC_KEY).get();
	}

	public long getStartTime() {
		return getLong(JobSummary.JOB_START_TIME_KEY).get();
	}

	public Optional<String> getScriptText() {
		return getString(SCRIPT_TEXT_KEY);
	}

	public Optional<String> getConfigSchemas() {
		return getString(CONFIG_SCHEMAS);
	}

	public Optional<String> getStateInfo() {
		return getString(STATE_INFO);
	}

	public void updateWithProcInfo(EventProcessorInfo info) {
		try {
			setRawValue(CONFIG_SCHEMAS, info.getConfigSchema());

			ArrayList<StateInfo> stateInfos = new ArrayList<StateInfo>();
			for (StateDescriptor<?> stateDescriptor : info.getStates()) {
				stateInfos.add(StateInfo.fromStateDescriptor(stateDescriptor));
			}
			setRawValue(STATE_INFO, stateInfos);
		} catch (Throwable t) {
			LOG.error("Error while accessing state and config schemas", t);
		}
	}

	public static EventProcessorDeployment newEventProcessor(String name, long procId, EventProcessor proc,
			String topic, long deployTs, boolean clone) {
		ClosureCleaner.clean(proc, true);
		return new Deployment.EventProcessorDeployment(name, procId, proc, topic, deployTs, clone);
	}

	public static EventProcessorDeployment newEventProcessor(String name, long procId, EventProcessor proc,
			String topic, long deployTs) {
		return newEventProcessor(name, procId, proc, topic, deployTs, true);
	}

	public static JavaProcessorDeployment newJavaProcessor(String name, long procId, Serializable proc, String topic,
			long deployTs) {
		return newJavaProcessor(name, procId, proc, topic, deployTs, true);
	}

	public static JavaProcessorDeployment newJavaProcessor(String name, long procId, Serializable proc, String topic,
			long deployTs, boolean clone) {
		ClosureCleaner.clean(proc, true);
		return new Deployment.JavaProcessorDeployment(name, procId, proc, topic, deployTs, clone);
	}

	public static JavaCodeDeployment newJavaCodeProcessor(String name, long procId, String script, String topic,
			long deployTs) {
		return new Deployment.JavaCodeDeployment(name, procId, script, topic, deployTs);
	}

	public static GroovyProcessorDeployment newGroovyProcessor(String name, long procId, String script, String topic,
			long deployTs) throws ProcessorException {
		return new Deployment.GroovyProcessorDeployment(name, procId, script, topic, deployTs);
	}

	public static JarProcessorDeployment newJarProcessor(String name, long procId, String jarReference, String topic,
			long deployTs) throws ProcessorException {
		return new Deployment.JarProcessorDeployment(name, procId, jarReference, topic, deployTs);
	}

	/**
	 * Creates a new event processor using the provided factory.
	 */
	public abstract EventProcessor getProcessor(ProcessorFactory executorFactory) throws ProcessorException;

	@Override
	public String toString() {
		return "Deployment(" + getJobName() + ", " + getProcessorId() + ", " + getBackendId() + ")";
	}

	@Override
	protected boolean mergeToSummaryInternal(JobSummary summary) {

		if (isUpdate()) {
			Optional<Long> prevCreatedTime = summary.getLong(JobSummary.JOB_CREATED_TIME_KEY);

			if (summary.getLong(JobSummary.JOB_END_TIME_KEY).orElse(Long.MIN_VALUE) < getStartTime()) {
				// If the job is failed or paused, we need to make sure to only restart (from
				// the summary's perspective) if it happened before the update
				Failure.clearFailureInfo(summary);

				summary.setString(JobSummary.JOB_STATE_KEY, JobSummary.JOB_STATE_RUNNING);
				summary.setString(JobSummary.JOB_STATE_DESCRIPTION_KEY, "");
				summary.setLong(JobSummary.JOB_END_TIME_KEY, -1);

				// Legacy
				summary.setString(JobSummary.JOB_STATUS_KEY, JobSummary.JOB_STATUS_RUNNING);
				summary.setString(JobSummary.STOP_REASON_KEY, "");
			}

			summary.addAll(this);
			prevCreatedTime.ifPresent(t -> summary.setLong(JobSummary.JOB_CREATED_TIME_KEY, t));
		} else if (summary.getLong(JobSummary.JOB_START_TIME_KEY).get().equals(-1l)) {
			// We only add the deployment info once
			summary.addAll(this);
			summary.removeKey(PROCESSOR_OBJECT_KEY);
		}
		return true;
	}

	public static class EventProcessorDeployment extends Deployment {
		private static final long serialVersionUID = 1L;

		public EventProcessorDeployment(String processorName, long processorId, EventProcessor processor, String topic,
				long deployTs, boolean clone) {
			super(processorName, processorId, topic, deployTs);
			setRawValue(PROCESSOR_OBJECT_KEY, processor);
			setBoolean(CLONE_PROC_ON_GET, clone);
		}

		public EventProcessorDeployment(Configuration conf) {
			super(conf);
		}

		@Override
		public EventProcessor getProcessor(ProcessorFactory executorFactory) throws ProcessorException {
			try {
				EventProcessor proc = (EventProcessor) getRawValue(PROCESSOR_OBJECT_KEY).get();
				if (getBoolean(CLONE_PROC_ON_GET).orElse(false)) {
					proc = InstantiationUtil.clone(proc);
				}
				return proc;
			} catch (Throwable e) {
				throw new ProcessorException(e);
			}
		}
	}

	public static class JavaProcessorDeployment extends Deployment {
		private static final long serialVersionUID = 1L;

		public JavaProcessorDeployment(String processorName, long processorId, Serializable processorObject,
				String topic, long deployTs, boolean clone) {
			super(processorName, processorId, topic, deployTs);
			setRawValue(PROCESSOR_OBJECT_KEY, processorObject);
			setBoolean(CLONE_PROC_ON_GET, clone);
		}

		public JavaProcessorDeployment(Configuration conf) {
			super(conf);
		}

		@Override
		public EventProcessor getProcessor(ProcessorFactory executorFactory) throws ProcessorException {
			try {
				Serializable proc = getRawValue(PROCESSOR_OBJECT_KEY).get();
				if (getBoolean(CLONE_PROC_ON_GET).orElse(false)) {
					proc = InstantiationUtil.clone(proc);
				}
				return executorFactory.getForJavaObject(getProcessorId(), getJobName(), proc);
			} catch (Throwable e) {
				throw new ProcessorException(e);
			}
		}
	}

	public static class JavaCodeDeployment extends Deployment {
		private static final long serialVersionUID = 1L;

		public JavaCodeDeployment(String processorName, long processorId, String javaCode,
				String topic,
				long deployTs) {
			super(processorName, processorId, topic, deployTs);
			setString(SCRIPT_TEXT_KEY, Validate.notNull(javaCode, "Script cannot be null"));
		}

		public JavaCodeDeployment(Configuration conf) {
			super(conf);
		}

		@Override
		public EventProcessor getProcessor(ProcessorFactory executorFactory) throws ProcessorException {
			return executorFactory.getForJavaCode(getProcessorId(), getJobName(),
					getString(Deployment.SCRIPT_TEXT_KEY).get());
		}
	}

	public static class GroovyProcessorDeployment extends Deployment {
		private static final long serialVersionUID = 1L;

		public GroovyProcessorDeployment(String processorName, long processorId, String script, String topic,
				long deployTs) throws ProcessorException {
			super(processorName, processorId, topic, deployTs);
			setString(SCRIPT_TEXT_KEY, Validate.notNull(script, "Script cannot be null"));
		}

		public GroovyProcessorDeployment(Configuration conf) {
			super(conf);
		}

		@Override
		public EventProcessor getProcessor(ProcessorFactory executorFactory) throws ProcessorException {
			return executorFactory.getForGroovyScript(getProcessorId(), getJobName(),
					getString(Deployment.SCRIPT_TEXT_KEY).get());
		}
	}

	public static class JarProcessorDeployment extends Deployment {
		private static final long serialVersionUID = 1L;

		public JarProcessorDeployment(String processorName, long processorId, String script, String topic,
				long deployTs) throws ProcessorException {
			super(processorName, processorId, topic, deployTs);
			setString(SCRIPT_REFERENCE, Validate.notNull(script, "Jar reference in HDFS cannot be null"));
		}

		public JarProcessorDeployment(Configuration conf) {
			super(conf);
		}

		@Override
		public EventProcessor getProcessor(ProcessorFactory executorFactory) throws ProcessorException {
			return executorFactory.getForHDFSJar(getProcessorId(), getJobName(),
					getString(Deployment.SCRIPT_REFERENCE).get());
		}
	}

	public static class TestDeployment extends Deployment {

		public static TestDeployment INSTANCE = new TestDeployment();

		private static final long serialVersionUID = 1L;

		public TestDeployment() {
			super("TestDeployment", 0, "test.deployment", System.currentTimeMillis());
		}

		public TestDeployment(Configuration conf) {
			super(conf);
		}

		@Override
		public EventProcessor getProcessor(ProcessorFactory executorFactory) throws ProcessorException {
			throw new UnsupportedOperationException();
		}

	}

}
