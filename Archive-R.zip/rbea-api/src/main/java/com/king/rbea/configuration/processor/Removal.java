package com.king.rbea.configuration.processor;

import com.king.rbea.configuration.Configuration;

public class Removal extends ProcessorInfo {
	private static final long serialVersionUID = 1L;
	public static final String DELETE_STATE_KEY = "delete";

	public Removal(long procId, long removalTime) {
		super(procId);
		
		setLong(JobSummary.JOB_END_TIME_KEY, removalTime);
	}

	public Removal(Configuration conf) {
		super(conf);
	}

	@Override
	public String toString() {
		return "Removal(" + getProcessorId() + ")";
	}

	public Removal keepStateAfterRemoval() {
		this.setBoolean(DELETE_STATE_KEY, false);
		return this;
	}

	public boolean shouldDeleteState() {
		return this.getBoolean(DELETE_STATE_KEY).orElse(true);
	}

	@Override
	protected boolean mergeToSummaryInternal(JobSummary summary) {
		throw new UnsupportedOperationException("Removal should never be merged");
	}
}