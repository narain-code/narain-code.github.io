package com.king.rbea.backend.hdfs;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;

import org.apache.flink.core.fs.FSDataOutputStream;
import org.apache.flink.core.fs.FileSystem;
import org.apache.flink.core.fs.FileSystem.WriteMode;
import org.apache.flink.core.fs.Path;

import com.king.rbea.hdfs.HDFSClient;

/**
 * {@code FlinkHDFSClient} is a client able to load files from HDFS using Flink's configuration mechanisms.
 */
public class FlinkHDFSClient implements HDFSClient {
	private final Path rootPath;
	private final FileSystem fileSystem;
	
	public FlinkHDFSClient(String root) throws IOException {
		this.rootPath = new Path(root);
		this.fileSystem = FileSystem.get(URI.create("hdfs:///"));
	}

	@Override
	public boolean exists(String fileName) throws IOException {
		return fileSystem.exists(getPath(fileName));
	}

	@Override
	public void storeFile(String fileName, byte[] content) throws IOException {
		FSDataOutputStream fsDataOutputStream = fileSystem.create(getPath(fileName), WriteMode.OVERWRITE);
		fsDataOutputStream.write(content);
		fsDataOutputStream.close();
	}

	@Override
	public InputStream getInputStream(String fileName) throws IOException {
		return fileSystem.open(getPath(fileName));
	}

	@Override
	public void delete(String fileName) throws IOException {
		fileSystem.delete(getPath(fileName), false);
	}

	@Override
	public void rename(String from, String to) throws IOException {
		throw new IllegalStateException("Not supported"); // Right now not needed
	}
	
	@Override
	public void mkdirs(String dir) throws IOException {
		fileSystem.mkdirs(getPath(dir));
	}
	
	protected Path getPath(String fileName) {
		return new Path(rootPath, fileName);
	}
}
