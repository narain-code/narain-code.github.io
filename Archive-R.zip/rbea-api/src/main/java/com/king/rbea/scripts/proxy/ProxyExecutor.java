package com.king.rbea.scripts.proxy;

import java.lang.reflect.Method;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.stream.Stream;

import com.king.event.Event;
import com.king.proxy.MethodBinding;
import com.king.proxy.ProxyGenerator;
import com.king.rbea.Context;
import com.king.rbea.EventProcessor;
import com.king.rbea.Registry;
import com.king.rbea.Services;
import com.king.rbea.TimerContext;
import com.king.rbea.Utils;
import com.king.rbea.annotations.Async;
import com.king.rbea.annotations.Close;
import com.king.rbea.annotations.Initialize;
import com.king.rbea.annotations.OnConfigUpdate;
import com.king.rbea.annotations.OnError;
import com.king.rbea.annotations.OnSessionEnd;
import com.king.rbea.annotations.OnTimer;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.exceptions.BackendException;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.scripts.ScriptUtils;
import com.king.rbea.scripts.info.EventProcessorInfo;
import com.king.rbea.scripts.info.InfoCollectorRegistry;
import com.king.rbea.scripts.proxy.binders.AggregatorBinder;
import com.king.rbea.scripts.proxy.binders.ConfigMappingBinder;
import com.king.rbea.scripts.proxy.binders.EventInfoBinder;
import com.king.rbea.scripts.proxy.binders.ExtensionBinder;
import com.king.rbea.scripts.proxy.binders.FlavourInfoBinder;
import com.king.rbea.scripts.proxy.binders.InitBinder;
import com.king.rbea.scripts.proxy.binders.ParamTypeBinder;
import com.king.rbea.scripts.proxy.binders.SemanticClassBinder;
import com.king.rbea.scripts.proxy.binders.TypedEventBinder;
import com.king.rbea.scripts.proxy.calltransformers.MissingCUIDFilter;
import com.king.rbea.scripts.proxy.calltransformers.TypeAndSCFilter;
import com.king.rbea.state.export.StateExporter;

import net.bytebuddy.ByteBuddy;
import net.bytebuddy.implementation.MethodDelegation;
import net.bytebuddy.implementation.bind.annotation.SuperCall;
import net.bytebuddy.matcher.ElementMatchers;

/**
 * Class for generating and executing {@link EventProcessor}s defined with user
 * annotations.
 */
public abstract class ProxyExecutor implements EventProcessor {
	private static final long serialVersionUID = 1L;

	static final ProxyGenerator<EventProcessor> processorGenerator;
	static final MethodBinding<?> processEventBinding;
	static final MethodBinding<?> onSessionBinding;
	static final MethodBinding<?> onTimerBinding;
	static final MethodBinding<?> initializeBinding;
	static final MethodBinding<?> closeBinding;
	static final MethodBinding<?> onConfigUpdateBinding;
	static final MethodBinding<?> onErrorBinding;

	static {
		processorGenerator = ProxyGenerator.forClass(EventProcessor.class);

		processEventBinding = processorGenerator
				.bindingMethod("processEvent")
				.toAnnotation(ProcessEvent.class)
				.withCompositeParameters(Context.class, Utils.class, Services.class)
				.withParameterBinder(new SemanticClassBinder())
				.withParameterBinder(new TypedEventBinder())
				.withParameterBinder(new AggregatorBinder(2))
				.withParameterBinder(new ParamTypeBinder(2))
				.withParameterBinder(new FlavourInfoBinder())
				.withParameterBinder(new EventInfoBinder())
				.withParameterBinder(new ExtensionBinder(2))
				.withMethodCallTransformer(new TypeAndSCFilter())
				.withMethodCallTransformer(new MissingCUIDFilter());

		onSessionBinding = processorGenerator
				.bindingMethod("onSessionEnd")
				.toAnnotation(OnSessionEnd.class)
				.withCompositeParameters(Context.class, Utils.class, Services.class)
				.withParameterBinder(new AggregatorBinder(2))
				.withParameterBinder(new FlavourInfoBinder())
				.withParameterBinder(new EventInfoBinder())
				.withParameterBinder(new ExtensionBinder(2))
				.withParameterBinder(new ParamTypeBinder(2));

		onTimerBinding = processorGenerator
				.bindingMethod("onTimer")
				.toAnnotation(OnTimer.class)
				.withCompositeParameters(TimerContext.class, Utils.class, Services.class)
				.withParameterBinder(new AggregatorBinder(1))
				.withParameterBinder(new ExtensionBinder(1))
				.withParameterBinder(new ParamTypeBinder(1));

		initializeBinding = processorGenerator
				.bindingMethod("initialize")
				.toAnnotation(Initialize.class)
				.toName("initialize")
				.withParameterBinder(new InitBinder());

		closeBinding = processorGenerator
				.bindingMethod("close")
				.toName("close")
				.toAnnotation(Close.class);

		onConfigUpdateBinding = processorGenerator
				.bindingMethod("onConfigUpdate")
				.toAnnotation(OnConfigUpdate.class)
				.withCompositeParameters(Context.class, Utils.class, Services.class)
				.withParameterBinder(new ConfigMappingBinder())
				.withParameterBinder(new ExtensionBinder(2));

		onErrorBinding = processorGenerator
				.bindingMethod("onError")
				.toAnnotation(OnError.class)
				.withCompositeParameters(Context.class, Utils.class, Services.class)
				.withParameterBinder(new AggregatorBinder(2))
				.withParameterBinder(new FlavourInfoBinder())
				.withParameterBinder(new EventInfoBinder())
				.withParameterBinder(new ExtensionBinder(2))
				.withParameterBinder(new ParamTypeBinder(2));
	}

	protected final String jobName;
	protected final long procId;

	private transient EventProcessor generatedProcessor;
	private transient Consumer<AsyncMethodCall> asyncExecutor;
	private transient EventProcessorInfo info;

	private transient Object scriptInstance;

	private transient Context currentCtx;
	private transient StateExporter exporter;

	private boolean hasAsyncMethods;

	public ProxyExecutor(long jobId, String jobName) {
		this.procId = jobId;
		this.jobName = jobName;
	}

	public EventProcessor getGeneratedProcessor() {
		return generatedProcessor;
	}

	public abstract Object getScriptInstance() throws Exception;

	@Override
	public void initialize(Registry reg, Context ctx) throws Exception {
		generateProcessor(ctx);
		InfoCollectorRegistry collectorReg = new InfoCollectorRegistry(reg);
		generatedProcessor.initialize(collectorReg, ctx);
		exporter = StateExporter.getFor(procId, scriptInstance, ctx);
		info = new ProxyProcInfo(scriptInstance, hasAsyncMethods, collectorReg.getInfo());
	}

	@Override
	public void processEvent(Event event, Context ctx) throws Exception {
		currentCtx = ctx;
		generatedProcessor.processEvent(event, ctx);
		currentCtx = null;
	}

	@Override
	public void onTimer(TimerContext ctx) throws Exception {
		currentCtx = ctx;
		generatedProcessor.onTimer(ctx);
		currentCtx = null;
	}

	@Override
	public void onSessionEnd(Event e, Context ctx) throws Exception {
		currentCtx = ctx;
		generatedProcessor.onSessionEnd(e, ctx);
		currentCtx = null;
	}

	@Override
	public void close() throws Exception {
		if(generatedProcessor != null) {
			generatedProcessor.close();
		}
	}

	@Override
	public void onError(Throwable err, Context ctx) throws Exception {
		currentCtx = ctx;
		generatedProcessor.onError(err, ctx);
		currentCtx = null;
	}

	@Override
	public void onConfigUpdate(String conf, Context ctx) throws Exception {
		currentCtx = ctx;
		ScriptUtils.setConfigBindings(conf, getScriptInstance());
		generatedProcessor.onConfigUpdate(conf, ctx);
		currentCtx = null;
	}

	@Override
	public void exportStates(Object... leadingFields) throws Exception {
		if (exporter == null) {
			throw new ProcessorException(
					"Must use the ExportsState annotation on the script in order to use this functionality.");
		}
		exporter.exportStates(scriptInstance, leadingFields, currentCtx);
	}

	@Override
	public Optional<EventProcessorInfo> getInfo() throws Exception {
		return Optional.ofNullable(info);
	}

	@Override
	public void setAsyncExecutor(Consumer<AsyncMethodCall> executor) {
		this.asyncExecutor = executor;
	}

	private void generateProcessor(Context ctx) throws ProcessorException {
		if (generatedProcessor != null) {
			return;
		}
		try {
			scriptInstance = privateGetScriptInstance();
			generatedProcessor = processorGenerator.generateProxy(scriptInstance,
					jobName + "_" + procId);
		} catch (Exception e) {
			throw new ProcessorException(e);
		}
	}

	private Object privateGetScriptInstance() throws Exception {
		Object scriptInstance = getScriptInstance();

		hasAsyncMethods = false;
		for (Method m : scriptInstance.getClass().getMethods()) {
			if (m.getAnnotation(Async.class) != null) {
				hasAsyncMethods = true;
				if (!m.getReturnType().equals(void.class)) {
					throw new ProcessorException("Asynchronous methods cannot return any value");
				}
			}
		}

		if (hasAsyncMethods) {
			Class<?> scriptClass = scriptInstance.getClass();
			if (hasParameterlessConstructor(scriptClass)) {
				scriptInstance = new ByteBuddy().subclass(scriptClass)
						.method(ElementMatchers.isAnnotatedWith(Async.class))
						.intercept(MethodDelegation.to(new AsyncInterceptor()))
						.make()
						.load(scriptClass.getClassLoader())
						.getLoaded()
						.newInstance();
			} else {
				throw new ProcessorException(
						"Could not subclass script class for async operations without public empty constructor.");
			}

		}
		return scriptInstance;
	}

	private boolean hasParameterlessConstructor(Class<?> clazz) {
		return Stream.of(clazz.getConstructors())
				.anyMatch((c) -> c.getParameterCount() == 0);
	}

	public class AsyncInterceptor {
		public void runAsync(@SuperCall Runnable zuper) throws Exception {
			if (asyncExecutor == null) {
				throw new BackendException("Async processing hasn't been enabled for this backend.");
			}

			asyncExecutor.accept(new AsyncMethodCall(zuper, procId));
		}
	}
}
