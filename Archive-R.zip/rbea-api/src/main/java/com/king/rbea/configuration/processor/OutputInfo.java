package com.king.rbea.configuration.processor;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.king.rbea.configuration.Configuration;
import com.king.rbea.manager.types.ParameterSet;
import com.king.rbea.utils.Constants;

public class OutputInfo extends ProcessorInfo {
	private static final long serialVersionUID = 1L;
	public static final String PARAMSET_KEY = "parameterSet";

	public OutputInfo(long procId, String name, String type, Map<String, Object> params) {
		super(procId);
		Map<String, Object> parameters = new HashMap<>(params);
		parameters.put(Constants.AGGREGATOR_NAME, name);
		setRawValue(PARAMSET_KEY, new ParameterSet("Output", type, parameters));
	}

	public OutputInfo(Configuration conf) {
		super(conf);
	}

	public ParameterSet getOutputParams() {
		return (ParameterSet) getRawValue(PARAMSET_KEY).get();
	}

	@Override
	public String toString() {
		return "Output(" + getProcessorId() + ", " + getOutputParams() + ")";
	}

	@Override
	protected boolean mergeToSummaryInternal(JobSummary summary) {
		List<ParameterSet> allOutputs = summary.getAllOutputs();

		ParameterSet params = getOutputParams();

		boolean found = false;
		for (ParameterSet p : allOutputs) {
			if (p.getOutputName().equals(params.getOutputName()) && p.source.equals(params.source)) {
				found = true;
			}
		}

		if (!found) {
			allOutputs.add(getOutputParams());
		}

		Map<String, Serializable> map = this.toMap();
		map.remove(OutputInfo.PARAMSET_KEY);
		summary.addAll(map);
		return !found;
	}
}