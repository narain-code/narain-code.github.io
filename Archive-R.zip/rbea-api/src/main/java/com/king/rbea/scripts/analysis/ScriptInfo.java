package com.king.rbea.scripts.analysis;

import java.io.IOException;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import org.apache.flink.api.java.tuple.Tuple2;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.github.javaparser.JavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.expr.FieldAccessExpr;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.resolution.declarations.ResolvedMethodDeclaration;
import com.github.javaparser.resolution.types.ResolvedType;
import com.github.javaparser.symbolsolver.JavaSymbolSolver;
import com.github.javaparser.symbolsolver.core.resolution.Context;
import com.github.javaparser.symbolsolver.javaparsermodel.JavaParserFacade;
import com.github.javaparser.symbolsolver.javaparsermodel.JavaParserFactory;
import com.github.javaparser.symbolsolver.model.resolution.TypeSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.CombinedTypeSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.JarTypeSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.ReflectionTypeSolver;

public class ScriptInfo {

	protected static final Logger LOG = LoggerFactory.getLogger(ScriptInfo.class);

	private final Map<String, Set<String>> methodsCalled;
	private final Map<String, Set<String>> fieldsAccessed;

	private ScriptInfo(Map<String, Set<String>> methodsCalled,
			Map<String, Set<String>> fieldsAccessed) {
		this.methodsCalled = methodsCalled;
		this.fieldsAccessed = fieldsAccessed;

	}

	public Set<String> getAccessedEventTypes() {
		return fieldsAccessed.getOrDefault("com.king.constants.EventType", new TreeSet<>());
	}

	public Set<Tuple2<String, String>> getAccessedEventFields() {
		Set<Tuple2<String, String>> all = new HashSet<>();
		fieldsAccessed.getOrDefault("com.king.constants.EventField", new TreeSet<>()).forEach(ef -> {
			fieldsAccessed.getOrDefault("com.king.constants.EventField." + ef, new TreeSet<>()).forEach(f -> {
				all.add(Tuple2.of(ef, f));
			});
		});
		return all;
	}

	public Map<String, Set<String>> getMethodsCalled() {
		return methodsCalled;
	}

	public Map<String, Set<String>> getFieldsAccessed() {
		return fieldsAccessed;
	}

	public static ScriptInfo getFor(String script, String... jars) throws IOException {
		TypeSolver[] allSolvers = new TypeSolver[jars.length + 1];
		allSolvers[0] = new ReflectionTypeSolver();
		for (int i = 0; i < jars.length; i++) {
			allSolvers[i + 1] = new JarTypeSolver(jars[i]);
		}

		CombinedTypeSolver solver = new CombinedTypeSolver(allSolvers);
		JavaParser.setStaticConfiguration(JavaParser.getStaticConfiguration()
				.setSymbolResolver(new JavaSymbolSolver(solver)));

		Map<String, Set<String>> methodsCalled = new TreeMap<>();
		Map<String, Set<String>> fieldsAccessed = new TreeMap<>();

		CompilationUnit cu = JavaParser.parse(script);

		cu.findAll(MethodCallExpr.class).forEach(call -> {
			String clazzName = null;
			String methodSignature = null;

			try {
				ResolvedMethodDeclaration calledMethodDecl = JavaParserFacade.get(solver).solve(call)
						.getCorrespondingDeclaration();
				clazzName = calledMethodDecl.getPackageName() + "." + calledMethodDecl.getClassName();
				methodSignature = calledMethodDecl.getSignature();
			} catch (Throwable err) {
				String errMsg = err.getMessage() != null ? err.getMessage() : "";
				if (err.getCause() != null) {
					errMsg += err.getCause().getMessage();
				}
				if (errMsg.contains("com.king.rbea.aggregators.DimensionalAggregator")
						|| errMsg.contains("LocalState.create")) {
					return;
				} else {
					LOG.debug("Failed to resolve method declaration for: " + call.getScope(), err);
				}
			}

			if (clazzName != null && methodSignature != null) {
				addAccess(methodsCalled, clazzName, methodSignature);
			}
		});

		cu.findAll(FieldAccessExpr.class).forEach(fieldAccess -> {
			String accessedFieldName = fieldAccess.getNameAsString();
			String qualifiedClassName;
			try {
				Context context = JavaParserFactory.getContext(fieldAccess.getScope(), solver);
				qualifiedClassName = context.solveType(fieldAccess.getScope().toString(), solver)
						.getCorrespondingDeclaration().getQualifiedName();
			} catch (Throwable ignore) {
				try {
					ResolvedType calculatedType = fieldAccess.getScope().calculateResolvedType();
					qualifiedClassName = getQualifiedClassName(calculatedType);
				} catch (Throwable err) {
					LOG.debug("Failed to resolve field access for: " + fieldAccess.getScope(), err);
					return;
				}
			}

			if (qualifiedClassName != null) {
				addAccess(fieldsAccessed, qualifiedClassName, accessedFieldName);
			}

		});

		return new ScriptInfo(methodsCalled, fieldsAccessed);
	}

	private static String getQualifiedClassName(ResolvedType t) {
		if (t.isReferenceType()) {
			return t.asReferenceType().getQualifiedName();
		} else if (t.isArray()) {
			return getQualifiedClassName(t.asArrayType().getComponentType()) + "[]";
		} else if (t.isPrimitive()) {
			return t.asPrimitive().getBoxTypeQName();
		} else {
			throw new RuntimeException("Couldn't find qualified name for " + t);
		}
	}

	private static void addAccess(Map<String, Set<String>> fieldsAccessed, String className, String fieldName) {
		Set<String> set = fieldsAccessed.getOrDefault(className, new TreeSet<>());
		set.add(fieldName);
		fieldsAccessed.put(className, set);
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("=================\n");
		builder.append("Methods:\n");
		builder.append("=================\n");

		methodsCalled.forEach((clazz, set) -> {
			builder.append(clazz + "\n");
			set.forEach(s -> builder.append("\t" + s + "\n"));
		});

		builder.append("\n=================\n");
		builder.append("Fields:\n");
		builder.append("=================\n");

		fieldsAccessed.forEach((clazz, set) -> {
			builder.append(clazz + "\n");
			set.forEach(s -> builder.append("\t" + s + "\n"));
		});
		return builder.toString();
	}

}
