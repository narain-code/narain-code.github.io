package com.king.rbea.manager.types;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.lang3.Validate;

import com.king.rbea.configuration.processor.Deployment;
import com.king.rbea.configuration.processor.Deployment.TestDeployment;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.manager.repository.ApplicationType;
import com.king.rbea.scripts.ProcessorFactory;

public class RBeaJobDefinition {
	public String name = null;
	public String jobCode = null;
	public String topic = null;

	// This is used to update a running job
	public Long jobId = null;
	
	/**
	 * Whether a test deployment
	 */
	public boolean test = false;

	public Map<String, Object> properties;
	public String language = "groovy";

	public RBeaJobDefinition() {
		super();
		this.properties = new HashMap<>();
	}

	public RBeaJobDefinition(String name, String jobCode, String topic) {
		this();
		this.name = name;
		this.jobCode = jobCode;
		this.topic = topic;		
	}

	public String getName() {
		return name;
	}

	public String getJobCode() {
		return jobCode;
	}

	public String getTopic() {
		return topic;
	}

	public Map<String, Object> getProperties() {
		return properties;
	}

	public Long getJobId() {
		return jobId;
	}

	public String getLanguage() {
		return language;
	}

	public Deployment toDeployment(ProcessorFactory executorFactory, Optional<Long> newJobId) throws ProcessorException {
		if (language.toLowerCase().equals("test")) {
			return TestDeployment.INSTANCE;
		}

		boolean update = jobId != null;
		if (update) {
			if (newJobId.isPresent()) {
				throw new ProcessorException("Update (jobId: " + jobId + ") and new job id (" + newJobId.get() + ") specified");
			}
		} else {
			if (newJobId.isPresent()) {
				jobId = newJobId.get();
			} else {
				throw new ProcessorException("Not an update and no job id specified");
			}
		}
		if (jobId == 0) {
			throw new ProcessorException("JobId = 0 is reserved for testing, sorry.");
		}

		Validate.notNull(name, "Name cannot be null");
		Validate.notNull(topic, "Topic cannot be null");
		Validate.notNull(language, "Language cannot be null");
		Validate.notNull(jobCode, "JobCode cannot be null");

		Deployment dep;
		ApplicationType lang = ApplicationType.forValue(language.toLowerCase());

		switch (lang) {
		case GROOVY:
			dep = Deployment.newGroovyProcessor(
					name,
					jobId,
					jobCode,
					topic,
					System.currentTimeMillis());
			break;
			case JAVA:
			dep = Deployment.newJavaCodeProcessor(
					name,
					jobId,
					jobCode,
					topic,
					System.currentTimeMillis());
			break;
			case JAR:
			dep = Deployment.newJarProcessor(
					name,
					jobId,
					jobCode,
					topic,
					System.currentTimeMillis());
			break;
		default:
			throw new ProcessorException("Unsupported language: " + lang);
		}

		dep.setRawValue("properties", (Serializable) properties);
	    dep.setBoolean(Deployment.TEST_KEY, test);

		return update ? dep.asUpdate() : dep;
	}
}