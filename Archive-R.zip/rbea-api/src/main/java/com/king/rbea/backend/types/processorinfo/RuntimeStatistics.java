package com.king.rbea.backend.types.processorinfo;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.king.rbea.configuration.Configuration;
import com.king.rbea.configuration.processor.JobSummary;
import com.king.rbea.configuration.processor.ProcessorInfo;

/**
 * {@code RuntimeStatistics} is a {@link ProcessorInfo} containing info of
 * runtime statistics of a processor, such as times executed and accumulated
 * execution time.
 * 
 * TODO: Should be moved to com.king.rbea.configuration.processor package but
 * can't at the moment as states hold reference to this class due to the merging
 * logic 
 */
public class RuntimeStatistics extends ProcessorInfo implements Serializable {
	private static final long serialVersionUID = 1L;
	
	/**
	 * Key with a {@link List} of with statistics.
	 */
	public static final String RUNTIME_STATISTICS_KEY = "runtime_statistics";

	/**
	 * How old (milliseconds) instances to keep in {@link JobSummary}. 
	 */
	public static final int MAX_LIFETIME = 15 * 60 * 1000;
	
	/**
	 * Epoch timestamp (ms) when created.
	 */
	private long timestamp;
	
	/**
	 * The Flink operator index.
	 */
	private int subtaskIndex;	
	
	/**
	 * The count of executions.
	 */
	private long executionCount;
	
	/**
	 * Sum of execution times (ns).
	 */
	private long executionTimeSum;
	
	/**
	 * Max execution time (ns).
	 */
	private long maxExecutionTime;

	/**
	 * Window of stats collections (ns).
	 */
	private long measurementWindow;

	public RuntimeStatistics(long timestamp, long procId, int subtaskIndex, long executionCount, long executionTimeSum, long maxExecutionTime, long measurementWindow) {
		this(procId);
		
		this.timestamp = timestamp;		
		this.subtaskIndex = subtaskIndex;
		this.executionCount = executionCount;
		this.executionTimeSum = executionTimeSum;
		this.maxExecutionTime = maxExecutionTime;
		this.measurementWindow = measurementWindow;
	}

	public RuntimeStatistics(long procId) {
		super(procId);
	}

	protected RuntimeStatistics(Configuration conf) {
		super(conf);
	}

	@Override
	public boolean mergeToSummaryInternal(JobSummary summary) {
		return false;
	}

	public long getTimestamp() {
		return timestamp;
	}
	
	public int getSubtaskIndex() {
		return subtaskIndex;
	}
	
	public long getExecutionCount() {
		return executionCount;
	}

	public long getExecutionTimeSum() {
		return executionTimeSum;
	}

	public long getMaxExecutionTime() {
		return maxExecutionTime;
	}
	
	public long getMeasurementWindow() {
		return measurementWindow;
	}
	
	@Override
	public String toString() {
		return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE).append("subtaskIndex", subtaskIndex)
				.append("executionCount", executionCount).append("executionTimeSum", executionTimeSum)
				.append("maxExecutionTime", maxExecutionTime).appendSuper(super.toString()).toString();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + (int) (executionCount ^ (executionCount >>> 32));
		result = prime * result + (int) (executionTimeSum ^ (executionTimeSum >>> 32));
		result = prime * result + (int) (maxExecutionTime ^ (maxExecutionTime >>> 32));
		result = prime * result + subtaskIndex;
		result = prime * result + (int) (timestamp ^ (timestamp >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		RuntimeStatistics other = (RuntimeStatistics) obj;
		if (executionCount != other.executionCount)
			return false;
		if (executionTimeSum != other.executionTimeSum)
			return false;
		if (maxExecutionTime != other.maxExecutionTime)
			return false;
		if (subtaskIndex != other.subtaskIndex)
			return false;
		if (timestamp != other.timestamp)
			return false;
		return true;
	}
}
