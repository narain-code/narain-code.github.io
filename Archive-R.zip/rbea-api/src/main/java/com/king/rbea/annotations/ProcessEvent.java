package com.king.rbea.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.king.rbea.documenting.RbeaDocumentedClass;
import com.king.rbea.documenting.RbeaDocumentedMethod;

@RbeaDocumentedClass(summary = "Annotation for marking methods that are called on the incoming events.")
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@Inherited
public @interface ProcessEvent {

	@RbeaDocumentedMethod(summary = "Filter condition, only the specified EventTypes will be processed by the annotated method.")
	long[] eventType() default {};

	@RbeaDocumentedMethod(summary = "Filter condition, only the specified semantic class instances will be processed by the annotated metod. Additionally now you can use this semantic class type as a method argument.")
	Class<?>[] semanticClass() default {};

	@RbeaDocumentedMethod(summary = "Specifies how events without core user id are handled. The default behavior (IGNORE) drops these event, PROCESS allows events with and without core user id and PROCESS_ONLY allows events only without core user id. Note that trying to access core user based features such as states leads to an exception when processing events without core user id.")
	ProcessingPolicy missingCUID() default ProcessingPolicy.IGNORE;
}
