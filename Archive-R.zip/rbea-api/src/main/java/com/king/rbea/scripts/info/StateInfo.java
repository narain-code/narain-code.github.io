package com.king.rbea.scripts.info;

import java.io.Serializable;

import com.king.rbea.state.StateDescriptor;

public class StateInfo implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private final String name;
	private final String type;

	public StateInfo(String name, String type) {
		this.name = name;
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public String getType() {
		return type;
	}
	
	public static StateInfo fromStateDescriptor(StateDescriptor<?> sd) {
		return new StateInfo(sd.getStateName(), sd.getTypeInfo() != null ? sd.getTypeInfo().toString() : "Unknown type");
	}

	@Override
	public String toString() {
		return "StateInfo [name=" + name + ", type=" + type + "]";
	}
}
