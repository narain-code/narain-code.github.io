package com.king.rbea.hdfs;

/**
 * {@code HDFSRootProvider} is used to be able to set a root for HDFS operations, e.e. to isolate the directory tests
 * touch from the directories production touched if working in the same HDFS cluster.
 */
public class HDFSRootProvider {
	private static HDFSRootProvider instance;

	private static String _root;
	private final String root;

	private HDFSRootProvider(String root) {
		this.root = root;
	}

	public static synchronized HDFSRootProvider getInstance() {
		if (instance == null) {
			instance = new HDFSRootProvider(_root);
		}
		return instance;
	}

	public static void setup(String _root) {
		HDFSRootProvider._root = _root;
	}

	/**
	 * Gets the prefix for HDFS paths.
	 * 
	 * @return
	 */
	public String getRoot() {
		return root == null || root.equals("") ? "/": root;
	}
}
