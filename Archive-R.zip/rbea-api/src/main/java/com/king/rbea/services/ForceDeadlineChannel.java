package com.king.rbea.services;

import java.util.concurrent.TimeUnit;

import io.grpc.CallOptions;
import io.grpc.Channel;
import io.grpc.ClientCall;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.MethodDescriptor;

public class ForceDeadlineChannel extends Channel {

	private ManagedChannel wrappedChannel;
	private long deadLineMillis;

	public ForceDeadlineChannel(String host, int port, long deadLineMillis) {
		this.deadLineMillis = deadLineMillis;
		wrappedChannel = ManagedChannelBuilder
				.forAddress(host, port)
				.usePlaintext(true)
				.build();
		Runtime.getRuntime().addShutdownHook(new Thread(wrappedChannel::shutdownNow));
	}

	@Override
	public <RequestT, ResponseT> ClientCall<RequestT, ResponseT> newCall(
			MethodDescriptor<RequestT, ResponseT> methodDescriptor, CallOptions callOptions) {
		return wrappedChannel.newCall(methodDescriptor,
				callOptions.withDeadlineAfter(deadLineMillis, TimeUnit.MILLISECONDS));
	}

	@Override
	public String authority() {
		return wrappedChannel.authority();
	}

}
