package com.king.rbea.scripts.info;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.reflect.FieldUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableMap;
import com.king.rbea.annotations.Bind;
import com.king.rbea.annotations.ConfigClass;
import com.king.rbea.annotations.config.ConfigField;
import com.king.rbea.annotations.config.Meta;

public class ConfigClassSchema implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private static final ObjectMapper mapper = new ObjectMapper();

	private String type = "object";
	private String label;
	private String description;
	private Map<String, ConfigFieldInfo> properties;
	private List<String> required;
	private Map<String, String> meta;
	
	public ConfigClassSchema() {}

	public ConfigClassSchema(String label, String description, Map<String, ConfigFieldInfo> properties,
			List<String> required, Map<String, String> meta) {
		this.label = label;
		this.description = description;
		this.meta = new HashMap<>();
		this.meta.putAll(meta);
		this.required = required;
		this.properties = new HashMap<>();
		this.properties.putAll(properties);
	}

	public ConfigClassSchema(Class<?> configClass) {
		ConfigClass cc = configClass.getAnnotation(ConfigClass.class);
		this.label = cc.label();
		this.description = cc.description();
		this.meta = Arrays.stream(cc.meta()).collect(Collectors.toMap(Meta::key, Meta::value));
		this.properties = new HashMap<>();
		this.required = new ArrayList<>();

		for (java.lang.reflect.Field field : FieldUtils.getAllFields(configClass)) {
			ConfigField cf = field.getAnnotation(ConfigField.class);
			String fieldName = field.getName();
			if (cf != null) {
				if (cf.required()) {
					required.add(fieldName);
				}
				properties.put(fieldName, getConfigField(field));
			}
		}
	}

	private static ConfigFieldInfo getConfigField(Field field) {
		ConfigField cf = field.getAnnotation(ConfigField.class);
		String label = cf != null ? cf.label() : "";
		String description = cf != null ? cf.description() : "";
		Meta[] meta = cf != null ? cf.meta() : new Meta[] {};
		String type = getJsonType(field);
		return new ConfigFieldInfo(type, label, description,
				Arrays.stream(meta).collect(Collectors.toMap(Meta::key, Meta::value)));
	}

	private static String getJsonType(Field field) {
		return isNumberClass(field.getType()) ? "number" : String.class.equals(field.getType()) ? "string" : "object";
	}

	private static boolean isNumberClass(Class<?> clazz) {
		return Number.class.isAssignableFrom(clazz) || clazz.equals(int.class) || clazz.equals(long.class)
				|| clazz.equals(short.class) || clazz.equals(float.class) || clazz.equals(double.class);
	}
	
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Map<String, ConfigFieldInfo> getProperties() {
		return properties;
	}

	public void setProperties(Map<String, ConfigFieldInfo> properties) {
		this.properties = properties;
	}

	public List<String> getRequired() {
		return required;
	}

	public void setRequired(List<String> required) {
		this.required = required;
	}

	public Map<String, String> getMeta() {
		return meta;
	}

	public void setMeta(Map<String, String> meta) {
		this.meta = meta;
	}

	@Override
	public String toString() {
		try {
			return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(this);
		} catch (JsonProcessingException e) {
			throw new RuntimeException(e);
		}
	}

	public static class ScriptConfigInfo implements Serializable {
		private static final long serialVersionUID = 1L;
		
		public String type = "object";
		public Map<String, Map<String, Object>> properties;
		public Map<String, ConfigClassSchema> definitions;
		public List<String> required;

		public ScriptConfigInfo() {
			super();
		}

		public ScriptConfigInfo(Map<String, Map<String, Object>> properties,
				Map<String, ConfigClassSchema> definitions, List<String> required) {
			super();
			this.properties = new HashMap<>();
			properties.entrySet().forEach(e -> {
				Map<String, Object> innerMap = new HashMap<>();
				innerMap.putAll(properties.get(e.getKey()));
				this.properties.put(e.getKey(), innerMap);
			});
			
			this.definitions = new HashMap<>();
			this.definitions.putAll(definitions);
			this.required = new ArrayList<>();
			this.required.addAll(required);
		}

		public void setType(String type) {
			this.type = type;
		}

		public void setProperties(Map<String, Map<String, Object>> properties) {
			this.properties = properties;
		}

		public void setDefinitions(Map<String, ConfigClassSchema> definitions) {
			this.definitions = definitions;
		}

		public void setRequired(List<String> required) {
			this.required = required;
		}
	}

	public static class ConfigFieldInfo implements Serializable {
		private static final long serialVersionUID = 1L;
		
		private String type;
		private String label;
		private String description;
		private Map<String, String> meta;

		public ConfigFieldInfo() {}

		public ConfigFieldInfo(String type, String label, String description,
				Map<String, String> meta) {
			this.type = type;
			this.label = label;
			this.description = description;
			this.meta = new HashMap<>();
			this.meta.putAll(meta);
		}

		public Map<String, Object> toMap() {
			Map<String, Object> map = new HashMap<>();
			map.put("type", type);
			map.put("label", label);
			map.put("description", description);
			map.put("meta", meta);
			return map;
		}

		public String getType() {
			return type;
		}

		public void setType(String type) {
			this.type = type;
		}

		public String getLabel() {
			return label;
		}

		public void setLabel(String label) {
			this.label = label;
		}

		public String getDescription() {
			return description;
		}

		public void setDescription(String description) {
			this.description = description;
		}

		public Map<String, String> getMeta() {
			return meta;
		}

		public void setMeta(Map<String, String> meta) {
			this.meta = meta;
		}

		public static long getSerialversionuid() {
			return serialVersionUID;
		}

		@Override
		public String toString() {
			return "ConfigFieldInfo [type=" + type + ", label=" + label + ", description=" + description + ", meta=" + meta + "]";
		}
	}

	public static ScriptConfigInfo getAllConfigurableFields(Class<?> scriptClass)
			throws JsonProcessingException {
		Map<String, ConfigClassSchema> schemas = new HashMap<>();
		Map<String, Map<String, Object>> fieldBindings = new HashMap<>();
		List<String> allReq = new ArrayList<>();

		Field[] fields = scriptClass.getDeclaredFields();
		for (Field field : fields) {
			if (field.getAnnotation(Bind.class) != null) {
				Class<?> clazz = field.getType();
				ConfigClass cc = clazz.getAnnotation(ConfigClass.class);
				ConfigField cf = field.getAnnotation(ConfigField.class);
				boolean required = false;
				if (cc != null) {
					schemas.put(clazz.getSimpleName(), new ConfigClassSchema(clazz));
					fieldBindings.put(field.getName(),
							ImmutableMap.of("$ref", "#/definitions/" + field.getType().getSimpleName()));
					required = cc.required();
				} else if (cf != null) {
					fieldBindings.put(field.getName(), getConfigField(field).toMap());
					required = cf.required();
				} else {
					fieldBindings.put(field.getName(), ImmutableMap.of("type", getJsonType(field)));
				}
				if (required) {
					allReq.add(field.getName());
				}
			}

		}

		return new ScriptConfigInfo(fieldBindings, schemas, allReq);

	}
}
