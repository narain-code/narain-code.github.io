package com.king.rbea.scripts.proxy.binders;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Optional;

import com.king.flink.utils.Unchecked;
import com.king.proxy.parameters.ParameterBinding;
import com.king.proxy.parameters.SingleParameterBinder;
import com.king.rbea.Registry;
import com.king.rbea.exceptions.ProcessorException;

import net.bytebuddy.implementation.bytecode.member.MethodVariableAccess;

public final class InitBinder implements SingleParameterBinder {
	private static final long serialVersionUID = 1L;

	@Override
	public Optional<ParameterBinding> bind(Method sourceMethod, Method targetMethod,
			Class<?> targetParamType, List<Annotation> paramAnnotations,
			List<ParameterBinding> possibleBindings)
			throws Exception {
		if (targetParamType.equals(Registry.class) || targetParamType.equals(Object.class)) {
			return Optional.of(
					new ParameterBinding(Registry.class, MethodVariableAccess.REFERENCE.loadFrom(1)));
		} else {
			Unchecked.throwSilently(new ProcessorException("Initialize methods can only use the Registry"));
			return null;
		}
	}
}