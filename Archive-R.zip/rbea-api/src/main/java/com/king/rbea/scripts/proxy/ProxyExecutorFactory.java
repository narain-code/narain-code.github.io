package com.king.rbea.scripts.proxy;

import java.io.Serializable;
import java.nio.file.Path;

import com.king.rbea.EventProcessor;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.hdfs.HDFSRootProvider;
import com.king.rbea.scripts.ProcessorFactory;

public class ProxyExecutorFactory implements ProcessorFactory {
	private ProxyExecutorFactory() {
	}

	@Override
	public EventProcessor getForGroovyScript(long jobId, String jobName, String scriptText) {
		return new GroovyScriptExecutor(jobId, jobName, scriptText);
	}

	@Override
	public EventProcessor getForJavaObject(long jobId, String jobName, Serializable scriptInstance) {
		return new JavaObjectExecutor(jobId, jobName, scriptInstance);
	}

	@Override
	public EventProcessor getForClass(long jobId, String jobName, Class<?> scriptClass) {
		return new JavaClassExecutor(jobId, jobName, scriptClass);
	}

	@Override
	public EventProcessor getForJavaCode(long jobId, String jobName, String javaCode) throws ProcessorException {
		return new JavaCodeExecutor(jobId, jobName, javaCode);
	}
	
	@Override
	public EventProcessor getForJar(long jobId, String jobName, Path jarFile) throws ProcessorException {
		return new JarCodeExecutor(jobId, jobName, jarFile);
	}

	@Override
	public EventProcessor getForHDFSJar(long jobId, String jobName, String hdfsReference) throws ProcessorException {
		return new HDFSJarCodeExecutor(HDFSRootProvider.getInstance().getRoot(), jobId, jobName, hdfsReference);
	}
	
	public static Builder builder() {
		return new Builder();
	}

	public static class Builder {
		boolean hdfs;
		
		public Builder() {
		}
		
		public ProxyExecutorFactory build() {
			return new ProxyExecutorFactory();
		}
	}
}
