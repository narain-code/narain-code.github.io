package com.king.rbea.configuration.processor;

import com.king.rbea.configuration.Configuration;

/**
 * {@code Heartbeat} is the message indicating a backend is
 * alive. It's created in the backend and pushed to a Kafka
 * topic for consumption e.g. in the RBEA Manager.
 */
public class Heartbeat extends Configuration {
	private static final long serialVersionUID = 1L;

	private long time;

	public Heartbeat(long time) {
		super();
		
		this.time = time;
	}

	public Heartbeat(Configuration conf) {
		super(conf);
	}
	
	public long getTime() {
		return time;
	}

	@Override
	public String toString() {
		long now = System.currentTimeMillis();
		return "Heartbeat(" + time + " / " + (now - time) + " ms. ago)";
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + (int) (time ^ (time >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Heartbeat other = (Heartbeat) obj;
		if (time != other.time)
			return false;
		return true;
	}
}
