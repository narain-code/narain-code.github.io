/*
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.king.rbea.configuration;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.Serializable;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock.ReadLock;
import java.util.concurrent.locks.ReentrantReadWriteLock.WriteLock;

import org.apache.commons.io.output.ByteArrayOutputStream;
import org.apache.flink.core.io.IOReadableWritable;
import org.apache.flink.core.memory.DataInputView;
import org.apache.flink.core.memory.DataInputViewStreamWrapper;
import org.apache.flink.core.memory.DataOutputView;
import org.apache.flink.core.memory.DataOutputViewStreamWrapper;
import org.apache.flink.types.StringValue;
import org.apache.flink.util.InstantiationUtil;

import com.king.flink.utils.Unchecked;

/**
 * Lightweight configuration object which stores key/value pairs.
 */
public class Configuration implements IOReadableWritable, java.io.Serializable, Cloneable {

	private static final long serialVersionUID = 1L;

	private static final byte TYPE_STRING = 0;
	private static final byte TYPE_INT = 1;
	private static final byte TYPE_LONG = 2;
	private static final byte TYPE_BOOLEAN = 3;
	private static final byte TYPE_DOUBLE = 5;
	private static final byte TYPE_BYTES = 6;
	private static final byte TYPE_SERIALIZABLE = 7;

	/** Stores the concrete key/value pairs of this configuration object. */
	private final HashMap<String, Serializable> confData;

	/**
	 * Mutating operations on {@link #confData} need to be protected using this
	 * lock.
	 */
	private final WriteLock writeLock;

	/**
	 * Read-only operations on {@link #confData} need to be protected using this
	 * lock.
	 */
	private final ReadLock readLock;

	public static final String CONFIG_CLASS_KEY = "class";

	// --------------------------------------------------------------------------------------------

	/**
	 * Creates a new empty configuration.
	 */
	public Configuration() {
		this(new HashMap<String, Serializable>());
	}

	/**
	 * Creates a new configuration with the copy of the given configuration.
	 * 
	 * @param other
	 *            The configuration to copy the entries from.
	 */
	public Configuration(Configuration other) {
		this(new HashMap<String, Serializable>(other.confData));
	}

	public Configuration(Map<String, Serializable> entries) {
		this(new HashMap<String, Serializable>(entries));
	}

	private Configuration(HashMap<String, Serializable> confData) {
		this.confData = confData;
		ReentrantReadWriteLock readWriteLock = new ReentrantReadWriteLock();
		this.writeLock = readWriteLock.writeLock();
		this.readLock = readWriteLock.readLock();

		if (containsKey(CONFIG_CLASS_KEY)) {
			return;
		}

		setClass(CONFIG_CLASS_KEY, getClass());
	}

	// --------------------------------------------------------------------------------------------

	public void removeKey(String key) {
		writeLock.lock();
		try {
			confData.remove(key);
		} finally {
			writeLock.unlock();
		}
	}

	public Optional<Class<?>> getClass(String key, ClassLoader classLoader)
			throws ClassNotFoundException {

		return getString(key).map(s -> {
			try {
				return Class.forName(s, true, classLoader);
			} catch (ClassNotFoundException e1) {
				// Try for moved package
				if (s.contains("com.king.rbea.backend.types.processorinfo")) {
					s = s.replaceFirst("com.king.rbea.backend.types.processorinfo",
							"com.king.rbea.configuration.processor");
					try {
						return Class.forName(s, true, classLoader);
					} catch (ClassNotFoundException ignored) {}
				}

				Unchecked.throwSilently(e1);
				return null;
			}
		});
	}

	public void setClass(String key, Class<?> klazz) {
		setRawValue(key, klazz.getName());
	}

	public Optional<String> getString(String key) {
		return getRawValue(key).map(Object::toString);
	}

	public void setString(String key, String value) {
		setRawValue(key, value);
	}

	public Optional<Integer> getInteger(String key) {
		return getRawValue(key).flatMap(o -> {
			if (o.getClass() == Integer.class) {
				return Optional.of((Integer) o);
			} else if (o.getClass() == Long.class) {
				long value = (Long) o;
				if (value <= Integer.MAX_VALUE && value >= Integer.MIN_VALUE) {
					return Optional.of((int) value);
				} else {
					return Optional.empty();
				}
			} else {
				try {
					return Optional.of(Integer.parseInt(o.toString()));
				} catch (NumberFormatException e) {
					return Optional.empty();
				}
			}
		});
	}

	public void setInteger(String key, int value) {
		setRawValue(key, value);
	}

	public Optional<Long> getLong(String key) {
		return getRawValue(key).flatMap(o -> {
			if (o.getClass() == Long.class) {
				return Optional.of((Long) o);
			} else if (o.getClass() == Integer.class) {
				return Optional.of(((Integer) o).longValue());
			} else {
				try {
					return Optional.of(Long.parseLong(o.toString()));
				} catch (NumberFormatException e) {
					return Optional.empty();
				}
			}
		});
	}

	public void setLong(String key, long value) {
		setRawValue(key, value);
	}

	public Optional<Boolean> getBoolean(String key) {
		return getRawValue(key).flatMap(o -> {
			if (o.getClass() == Boolean.class) {
				return Optional.of((Boolean) o);
			} else {
				return Optional.of(Boolean.parseBoolean(o.toString()));
			}
		});
	}

	public void setBoolean(String key, boolean value) {
		setRawValue(key, value);
	}

	public Optional<Double> getDouble(String key) {
		return getRawValue(key).flatMap(o -> {
			if (o.getClass() == Double.class) {
				return Optional.of((Double) o);
			} else if (o.getClass() == Float.class) {
				return Optional.of(((Float) o).doubleValue());
			} else {
				try {
					return Optional.of(Double.parseDouble(o.toString()));
				} catch (NumberFormatException e) {
					return Optional.empty();
				}
			}
		});

	}

	public void setDouble(String key, double value) {
		setRawValue(key, value);
	}

	public Optional<byte[]> getBytes(String key) {
		return getRawValue(key).flatMap(o -> {

			if (o.getClass().equals(byte[].class)) {
				return Optional.of((byte[]) o);
			} else {
				return Optional.empty();
			}
		});
	}

	public void setBytes(String key, byte[] bytes) {
		setRawValue(key, bytes);
	}

	// --------------------------------------------------------------------------------------------

	/**
	 * Returns the keys of all key/value pairs stored inside this configuration
	 * object.
	 * 
	 * @return the keys of all key/value pairs stored inside this configuration
	 *         object
	 */
	public Set<String> keySet() {
		readLock.lock();
		try {
			return new HashSet<String>(this.confData.keySet());
		} finally {
			readLock.unlock();
		}
	}

	public void addAll(Configuration other) {
		addAll(other.confData);
	}

	public void addAll(Map<String, ? extends Serializable> map) {
		writeLock.lock();
		try {
			this.confData.putAll(map);
		} finally {
			writeLock.unlock();
		}
	}

	@Override
	public Configuration clone() {
		readLock.lock();
		try {
			Configuration config = new Configuration();
			config.addAll(this);
			return config;
		} finally {
			readLock.unlock();
		}
	}

	/**
	 * Checks whether there is an entry with the specified key
	 *
	 * @param key
	 *            key of entry
	 * @return true if the key is stored, false otherwise
	 */
	public boolean containsKey(String key) {
		readLock.lock();
		try {
			return this.confData.containsKey(key);
		} finally {
			readLock.unlock();
		}
	}

	// --------------------------------------------------------------------------------------------

	public Map<String, Serializable> toMap() {
		readLock.lock();
		try {
			Map<String, Serializable> ret = new HashMap<String, Serializable>(this.confData.size());
			for (Map.Entry<String, Serializable> entry : confData.entrySet()) {
				ret.put(entry.getKey(), entry.getValue());
			}
			return ret;
		} finally {
			readLock.unlock();
		}
	}

	// --------------------------------------------------------------------------------------------

	public void setRawValue(String key, Serializable value) {
		if (key == null) {
			throw new NullPointerException("Key must not be null.");
		}
		if (value == null) {
			throw new NullPointerException("Value must not be null.");
		}

		writeLock.lock();
		try {
			this.confData.put(key, value);
		} finally {
			writeLock.unlock();
		}
	}

	public Optional<Serializable> getRawValue(String key) {
		if (key == null) {
			throw new NullPointerException("Key must not be null.");
		}

		readLock.lock();
		try {
			return Optional.ofNullable(this.confData.get(key));
		} finally {
			readLock.unlock();
		}
	}

	/**
	 * Locks the lock that protects the {@link #confData}-map.
	 */
	protected void lock() {
		writeLock.lock();
	}

	/**
	 * Unlocks the lock that protects the {@link #confData}-map.
	 */
	protected void unlock() {
		writeLock.unlock();
	}

	// --------------------------------------------------------------------------------------------

	public byte[] serialize() throws IOException {
		ByteArrayOutputStream os = new ByteArrayOutputStream();
		DataOutputView ov = new DataOutputViewStreamWrapper(os);
		write(ov);
		os.close();
		return os.toByteArray();
	}

	@Override
	public void read(DataInputView in) throws IOException {
		writeLock.lock();
		try {
			final int numberOfProperties = in.readInt();

			for (int i = 0; i < numberOfProperties; i++) {
				String key = StringValue.readString(in);
				Object value;

				byte type = in.readByte();
				switch (type) {
				case TYPE_STRING:
					value = StringValue.readString(in);
					break;
				case TYPE_INT:
					value = in.readInt();
					break;
				case TYPE_LONG:
					value = in.readLong();
					break;
				case TYPE_DOUBLE:
					value = in.readDouble();
					break;
				case TYPE_BOOLEAN:
					value = in.readBoolean();
					break;
				case TYPE_BYTES:
					byte[] bytes = new byte[in.readInt()];
					in.readFully(bytes);
					value = bytes;
					break;
				case TYPE_SERIALIZABLE:
					byte[] b = new byte[in.readInt()];
					in.readFully(b);
					try {
						value = InstantiationUtil.deserializeObject(b, Configuration.class.getClassLoader());
					} catch (ClassNotFoundException e) {
						throw new RuntimeException(e);
					}
					break;
				default:
					throw new IOException("Unrecognized type: " + type);
				}

				this.confData.put(key, (Serializable) value);
			}
		} finally {
			writeLock.unlock();
		}
	}

	@Override
	public void write(final DataOutputView out) throws IOException {
		readLock.lock();
		try {
			out.writeInt(this.confData.size());

			for (Map.Entry<String, Serializable> entry : this.confData.entrySet()) {
				String key = entry.getKey();
				Object val = entry.getValue();

				StringValue.writeString(key, out);
				Class<?> clazz = val.getClass();

				if (clazz == String.class) {
					out.write(TYPE_STRING);
					StringValue.writeString((String) val, out);
				} else if (clazz == Integer.class) {
					out.write(TYPE_INT);
					out.writeInt((Integer) val);
				} else if (clazz == Long.class) {
					out.write(TYPE_LONG);
					out.writeLong((Long) val);
				} else if (clazz == Double.class) {
					out.write(TYPE_DOUBLE);
					out.writeDouble((Double) val);
				} else if (clazz == byte[].class) {
					out.write(TYPE_BYTES);
					byte[] bytes = (byte[]) val;
					out.writeInt(bytes.length);
					out.write(bytes);
				} else if (clazz == Boolean.class) {
					out.write(TYPE_BOOLEAN);
					out.writeBoolean((Boolean) val);
				} else {
					out.write(TYPE_SERIALIZABLE);
					try {
						byte[] bytes = InstantiationUtil.serializeObject(val);
						out.writeInt(bytes.length);
						out.write(bytes);
					} catch (IOException e) {
						throw new IOException("Error while serializing: " + val, e);
					}
				}
			}
		} finally {
			readLock.unlock();
		}
	}

	public static Configuration deserializeRaw(byte[] bytes) throws Exception {
		ByteArrayInputStream is = new ByteArrayInputStream(bytes);
		DataInputView in = new DataInputViewStreamWrapper(is);

		Configuration conf = new Configuration();
		conf.read(in);
		return conf;
	}

	@SuppressWarnings("unchecked")
	public static <T extends Configuration> T deserialize(byte[] bytes) throws Exception {
		Configuration conf = deserializeRaw(bytes);
		Optional<Class<?>> classOption = conf.getOriginalConfClass();

		return (T) classOption
				.orElseThrow(() -> new Exception(CONFIG_CLASS_KEY + " must be defined to use deserialization."))
				.getConstructor(Configuration.class)
				.newInstance(conf);
	}

	public Optional<Class<?>> getOriginalConfClass() throws ClassNotFoundException {
		return getClass(CONFIG_CLASS_KEY, Configuration.class.getClassLoader());
	}

	// --------------------------------------------------------------------------------------------

	@Override
	public int hashCode() {
		readLock.lock();
		try {
			int hash = 0;
			for (String s : this.confData.keySet()) {
				hash ^= s.hashCode();
			}
			return hash;
		} finally {
			readLock.unlock();
		}
	}

	@Override
	public boolean equals(Object obj) {
		readLock.lock();
		try {
			if (this == obj) {
				return true;
			} else if (obj instanceof Configuration) {
				Map<String, Serializable> otherConf = ((Configuration) obj).confData;

				for (Map.Entry<String, Serializable> e : this.confData.entrySet()) {
					Object thisVal = e.getValue();
					Object otherVal = otherConf.get(e.getKey());

					if (!thisVal.getClass().equals(byte[].class)) {
						if (!thisVal.equals(otherVal)) {
							return false;
						}
					} else if (otherVal.getClass().equals(byte[].class)) {
						if (!Arrays.equals((byte[]) thisVal, (byte[]) otherVal)) {
							return false;
						}
					} else {
						return false;
					}
				}

				return true;
			} else {
				return false;
			}
		} finally {
			readLock.unlock();
		}
	}

	@Override
	public String toString() {
		readLock.lock();
		try {
			return this.confData.toString();
		} finally {
			readLock.unlock();
		}
	}

	public static class MissingConfigValueException extends RuntimeException {

		private static final long serialVersionUID = 1L;

	}
}