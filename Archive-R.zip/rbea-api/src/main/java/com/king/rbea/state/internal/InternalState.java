package com.king.rbea.state.internal;

import com.king.rbea.exceptions.BackendException;
import com.king.rbea.exceptions.ProcessorException;

public interface InternalState {

	void writeValue(Object value) throws ProcessorException, BackendException;

	Object readValue() throws ProcessorException, BackendException;

}
