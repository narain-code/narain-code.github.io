package com.king.rbea.scripts;

import java.io.Serializable;
import java.util.Optional;

import com.king.event.Event;
import com.king.rbea.Context;

public interface InputTransformerWithContext extends Serializable {
	Optional<?> transform(Event input, Context ctx) throws Exception;
}
