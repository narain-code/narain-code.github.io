package com.king.rbea.utils;

import com.king.rbea.Timers;
import com.king.rbea.exceptions.ProcessorException;

public enum MissingTimers implements Timers {

	INSTANCE;

	@Override
	public void removeAllTimers() throws ProcessorException {
		throw new ProcessorException("Cannot access timers on events without a core user id.");
	}

	@Override
	public void removeTimer(int arg0) throws ProcessorException {
		throw new ProcessorException("Cannot access timers on events without a core user id.");
	}

	@Override
	public void registerTimerWithId(int timerId, long timestamp, Object params) throws ProcessorException {
		throw new ProcessorException("Cannot access timers on events without a core user id.");
	}

}
