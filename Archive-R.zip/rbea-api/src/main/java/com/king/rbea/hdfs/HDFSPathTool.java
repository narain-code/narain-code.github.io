package com.king.rbea.hdfs;

/**
 * {@code HDFSPathTool} is used to get paths to HDFS.
 */
public class HDFSPathTool {
	public static final String JAR_DEPLOY_ROOT = "/flink/deploy";

	private static HDFSPathTool instance;

	public synchronized static HDFSPathTool getInstance() {
		if (instance == null) {
			instance = new HDFSPathTool();
		}
		return instance;
	}
	
	/**
	 * Gets the relative path where RBEA Manager can upload JARs for staging.
	 * 
	 * @return the path
	 */
	public String getStagingFilePath() {
		return JAR_DEPLOY_ROOT + "/staging";
	}
	
	/**
	 * Gets the relative path where RBEA backend can fetch JARs for deployment,
	 * and where RBEA Manager stored the deployable JARs
	 * 
	 * @return the path
	 */
	public String getApplicationFilePath() {
		return JAR_DEPLOY_ROOT + "/applications";
	}
}
