package com.king.rbea.scripts.proxy;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;

import org.apache.commons.io.IOUtils;

import com.king.rbea.Context;
import com.king.rbea.Registry;
import com.king.rbea.backend.hdfs.FlinkHDFSClient;
import com.king.rbea.hdfs.HDFSPathTool;

/**
 * {@code HDFSJarCodeExecutor} is a {@link JarCodeExecutor} that gets the JAR file from HDFS.
 */
public class HDFSJarCodeExecutor extends JarCodeExecutor {
	private static final long serialVersionUID = 1L;

	private final String hdfsRoot;
	private final String hdfsReference;

	public HDFSJarCodeExecutor(String hdfsRoot, long jobId, String jobName, String hdfsReference) {
		super(jobId, jobName);

		this.hdfsRoot = hdfsRoot;
		this.hdfsReference = hdfsReference;
	}

	@Override
	public void initialize(Registry reg, Context ctx) throws Exception {
		// The Flink HDFS client is instantiated only when actually needed.
		// This way tests and Manager and other code that don't have the class available
		// will work even when instantiating this class (unless this method is called):
		FlinkHDFSClient flinkHDFSClient = new FlinkHDFSClient(hdfsRoot);
		String applicationJarFileName = HDFSPathTool.getInstance().getApplicationFilePath() + "/" + hdfsReference;
		if (!flinkHDFSClient.exists(applicationJarFileName)) {
			throw new IllegalArgumentException("File doesn't exist: " + applicationJarFileName);
		}
	
		Path jarPath = writeToLocalFile(flinkHDFSClient, applicationJarFileName);
		super.setJarPath(jarPath);

		super.initialize(reg, ctx);
	}

	/**
	 * Copies from HDFS to a local temp file that will be deleted latest on JVM exit. See also {@link #close()}.
	 * 
	 * @param flinkHDFSClient
	 * @param applicationJarFileName
	 * @return
	 * @throws IOException
	 */
	private Path writeToLocalFile(FlinkHDFSClient flinkHDFSClient, String applicationJarFileName) throws IOException {
		Path jarPath = Files.createTempFile(jobName + "-" + procId + "-", ".jar");
		try (InputStream is = new BufferedInputStream(flinkHDFSClient.getInputStream(applicationJarFileName))) {
			try (OutputStream os = new BufferedOutputStream(Files.newOutputStream(jarPath))) {
				IOUtils.copy(is, os);
			}
		}
		jarPath.toFile().deleteOnExit();
		return jarPath;
	}

	/**
	 * Deletes the temp jar file, no longer needed.
	 */
	@Override
	public void close() throws IOException {
		Path jarPath = getJarPath();
		if (jarPath != null) {
			Files.delete(jarPath);
		}
	}
}
