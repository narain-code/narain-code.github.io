package com.king.rbea;

import java.io.Serializable;
import java.util.Optional;
import java.util.function.Consumer;

import com.king.event.Event;
import com.king.rbea.scripts.info.EventProcessorInfo;
import com.king.rbea.scripts.proxy.AsyncMethodCall;

public interface EventProcessor extends Serializable {

	void processEvent(Event event, Context ctx) throws Exception;

	default void initialize(Registry registry, Context ctx) throws Exception {}

	default void close() throws Exception {}

	default void onTimer(TimerContext ctx) throws Exception {}

	default void onConfigUpdate(String rawConf, Context ctx) throws Exception {}

	default void onError(Throwable err, Context ctx) throws Exception {}

	default void onSessionEnd(Event event, Context ctx) throws Exception {}

	default Optional<EventProcessorInfo> getInfo() throws Exception {
		return Optional.empty();
	}

	default void setAsyncExecutor(Consumer<AsyncMethodCall> executor) {};

	default void exportStates(Object... leadingFields) throws Exception {
		throw new UnsupportedOperationException();
	};
}
