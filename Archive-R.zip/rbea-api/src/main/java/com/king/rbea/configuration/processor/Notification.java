package com.king.rbea.configuration.processor;

import org.apache.commons.lang3.Validate;

import com.king.rbea.configuration.Configuration;

public class Notification extends ProcessorInfo {

	private static final long serialVersionUID = 1L;
	private static final String NOTIFICATION_TEXT_KEY = "notification";

	public Notification(long procId, String text) {
		super(procId);
		setString(NOTIFICATION_TEXT_KEY, Validate.notNull(text));
	}

	public Notification(Configuration conf) {
		super(conf);
	}

	public String getText() {
		return getString(NOTIFICATION_TEXT_KEY)
				.orElseThrow(() -> new RuntimeException("Notifications must contain a text. This indicates a bug."));
	}

	@Override
	public String toString() {
		return "Notification(" + getProcessorId() + ", " + getText() + ")";
	}

	@Override
	protected boolean mergeToSummaryInternal(JobSummary summary) {
		// Information about the failure
		summary.setString(NOTIFICATION_TEXT_KEY, getText());
		summary.setString(Failure.FAILURE_CAUSE_KEY, getText());
		return true;
	}
}