package com.king.rbea.scripts.proxy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.github.javaparser.JavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.ImportDeclaration;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.PackageDeclaration;
import com.github.javaparser.ast.body.TypeDeclaration;
import com.github.javaparser.ast.expr.SimpleName;
import com.github.javaparser.printer.lexicalpreservation.LexicalPreservingPrinter;
import com.javax0.jscc.Compiler;
import com.king.rbea.exceptions.ProcessorException;

public class JavaCodeExecutor extends ProxyExecutor {

	protected static final Logger LOG = LoggerFactory.getLogger(JavaCodeExecutor.class);

	private static final long serialVersionUID = 1L;
	private static final Object lock = new Object();

	private String javaCode;

	private transient Class<?> javaClass;
	private transient Object javaObj;

	static {
		JavaParser.getStaticConfiguration().setLexicalPreservationEnabled(true);
	}

	public JavaCodeExecutor(long jobId, String jobName, String javaCode) {
		super(jobId, jobName);
		this.javaCode = javaCode;
	}

	public static final String[] migratedPackages = {
			"com.king.constants.EventType",
			"com.king.constants.EventField",
			"com.king.constants.event.typed.events"
	};

	private void compile() throws Exception {
		if (javaClass == null) {
			CompilationUnit cu;
			synchronized (lock) {
				cu = JavaParser.parse(javaCode);
			}

			// Change to default package
			cu.setPackageDeclaration((PackageDeclaration) null);
			cu.findAll(ImportDeclaration.class).forEach(i -> {
				String name = i.getNameAsString();
				for (String s : migratedPackages) {
					if (name.startsWith(s)) {
						String newName = name.replace("com.king.constants", "com.king.constants.external");
						LOG.error("Migrating import from {} to {}", name, newName);
						i.setName(newName);
					}
				}
			});

			// Make sure there is a single top level class in the provided code
			NodeList<TypeDeclaration<?>> types = cu.getTypes();
			if (types.size() != 1) {
				throw new ProcessorException("Java code must contain a single top-level java class.");
			}

			// Append the proc id to the name of the top-level class
			TypeDeclaration<?> topLevelType = types.get(0);
			String modifiedClassName = topLevelType.getNameAsString() + "_" + procId;
			topLevelType.setName(new SimpleName(modifiedClassName));

			Compiler compiler = new Compiler();
			javaClass = compiler.compile(LexicalPreservingPrinter.print(cu), modifiedClassName);

			if (javaClass != null) {
				javaObj = javaClass.newInstance();
			} else {
				throw new ProcessorException("Compilation error: " + compiler.getCompilerErrorOutput());
			}
		}

	}

	@Override
	public Object getScriptInstance() throws Exception {
		compile();
		return javaObj;
	}
}
