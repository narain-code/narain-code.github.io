package com.king.rbea.scripts.proxy.binders;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Optional;

import com.king.proxy.parameters.ParameterBinding;
import com.king.proxy.parameters.SingleParameterBinder;
import com.king.rbea.scripts.ScriptUtils;

import net.bytebuddy.description.method.MethodDescription;
import net.bytebuddy.description.type.TypeDescription;
import net.bytebuddy.implementation.bytecode.StackManipulation;
import net.bytebuddy.implementation.bytecode.assign.TypeCasting;
import net.bytebuddy.implementation.bytecode.constant.ClassConstant;
import net.bytebuddy.implementation.bytecode.member.MethodInvocation;
import net.bytebuddy.implementation.bytecode.member.MethodVariableAccess;

public class ConfigMappingBinder implements SingleParameterBinder {
	private static final long serialVersionUID = 1L;

	@Override
	public Optional<ParameterBinding> bind(Method sourceMethod, Method targetMethod,
			Class<?> targetParamType, List<Annotation> paramAnnotations,
			List<ParameterBinding> possibleBindings)
			throws Exception {

		if (possibleBindings.size() == 1) {
			return Optional.of(possibleBindings.get(0));
		} else if (targetParamType.equals(String.class)) {
			return Optional.of(new ParameterBinding(targetParamType, MethodVariableAccess.REFERENCE.loadFrom(1)));
		} else if (possibleBindings.size() > 1) {
			return Optional.empty();
		} else {
			TypeDescription td = new TypeDescription.ForLoadedType(targetParamType);
			MethodDescription md = new MethodDescription.ForLoadedMethod(
					ScriptUtils.class.getMethod("readConfig", String.class, Class.class));

			return Optional.of(new ParameterBinding(
					targetParamType,
					new StackManipulation.Compound(
							MethodVariableAccess.REFERENCE.loadFrom(1),
							ClassConstant.of(td),
							MethodInvocation.invoke(md),
							TypeCasting.to(td))));
		}
	}
}