package com.king.rbea.state.export;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;

import org.apache.avro.Schema;
import org.apache.avro.generic.GenericDatumWriter;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.io.BinaryEncoder;
import org.apache.avro.io.EncoderFactory;

import com.king.flink.utils.Unchecked;

public class StateExportSerializer {

	private final GenericDatumWriter<Object> writer;
	private final Schema schema;

	public StateExportSerializer(Schema schema) {
		this.schema = schema;
		this.writer = new GenericDatumWriter<>(schema);
	}

	public byte[] serializeRecord(GenericRecord record) {
		try {
			ByteArrayOutputStream stream = new ByteArrayOutputStream();
			DataOutputStream dataOutputStream = new DataOutputStream(stream);
			byte[] schemaName = schema.getFullName().getBytes(StandardCharsets.UTF_8);
			dataOutputStream.writeInt(schemaName.length);
			dataOutputStream.write(schemaName);
			BinaryEncoder binaryEncoder = EncoderFactory.get().binaryEncoder(dataOutputStream, null);
			writer.write(record, binaryEncoder);
			binaryEncoder.flush();

			return stream.toByteArray();
		} catch (Exception e) {
			Unchecked.throwSilently(e);
			return null;
		}
	}

	public static byte[] serializeSchema(Schema schema, long procId) {
		byte[] schemaBytes = schema.toString(true).getBytes(StandardCharsets.UTF_8);
		ByteBuffer buffer = ByteBuffer.allocate(Long.BYTES + schemaBytes.length);
		return buffer.putLong(procId).put(schemaBytes).array();
	}
}