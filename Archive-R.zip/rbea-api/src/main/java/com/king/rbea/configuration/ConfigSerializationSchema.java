package com.king.rbea.configuration;

import java.io.IOException;

import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.typeutils.EitherTypeInfo;
import org.apache.flink.api.java.typeutils.TypeExtractor;
import org.apache.flink.streaming.util.serialization.DeserializationSchema;
import org.apache.flink.streaming.util.serialization.SerializationSchema;
import org.apache.flink.types.Either;

@SuppressWarnings("deprecation")
public enum ConfigSerializationSchema
		implements DeserializationSchema<Either<Configuration, Throwable>>, SerializationSchema<Configuration> {

	INSTANCE;

	@Override
	public TypeInformation<Either<Configuration, Throwable>> getProducedType() {
		TypeInformation<Configuration> pi = new TypeHint<Configuration>() {}.getTypeInfo();
		return new EitherTypeInfo<>(pi, TypeExtractor.getForClass(Throwable.class));
	}

	@Override
	public Either<Configuration, Throwable> deserialize(byte[] bytes) throws IOException {
		try {
			return Either.Left(Configuration.deserialize(bytes));
		} catch (Throwable e) {
			return Either.Right(e);
		}
	}

	@Override
	public boolean isEndOfStream(Either<Configuration, Throwable> configOrError) {
		return false;
	}

	@Override
	public byte[] serialize(Configuration config) {
		try {
			return config.serialize();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
}