package com.king.rbea.aggregators;

import com.king.rbea.documenting.RbeaDocumentedClass;

@RbeaDocumentedClass(summary = "Defines the output type of the aggregator.")
public enum OutputType {
	MYSQL, PRINT, KAFKA
}
