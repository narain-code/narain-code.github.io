package com.king.rbea.scripts.proxy;

public class JavaClassExecutor extends ProxyExecutor {

	private static final long serialVersionUID = 1L;
	private Class<?> javaClass = null;

	public JavaClassExecutor(long jobId, String jobName, Class<?> scriptClass) {
		super(jobId, jobName);
		this.javaClass = scriptClass;
	}

	@Override
	public Object getScriptInstance() throws Exception {
		return javaClass.newInstance();
	}
}
