package com.king.rbea.aggregators;

import java.lang.reflect.Array;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.king.rbea.documenting.RbeaDocumentedClass;
import com.king.rbea.documenting.RbeaDocumentedMethod;
import com.king.rbea.exceptions.ProcessorException;

@RbeaDocumentedClass(summary = "")
public interface DimensionalAggregator<T extends DimensionalAggregator<T>> {

	@Deprecated
	default T setDimensions(Object... dimensions) throws ProcessorException {
		return groupBy(dimensions);
	}
	
	@RbeaDocumentedMethod(summary = "Sets a string aggregator dimension with a given name and value (calls .toString() on the value)")
	default T setStringDimension(String columnName, Object value) throws ProcessorException {
		return setDimension(columnName, DimensionType.STRING, value);
	}

	@RbeaDocumentedMethod(summary = "Sets a long aggregator dimension with a given name and value (calls .toString() on the value)")
	default T setLongDimension(String columnName, long value) throws ProcessorException {
		return setDimension(columnName, DimensionType.LONG, value);
	}

	T setDimension(String columnName, DimensionType type, Object value) throws ProcessorException;
	
	T groupBy(Map<String, ?> dimensions) throws ProcessorException;

	@SuppressWarnings("unchecked")
	@Deprecated
	default T groupBy(Object... dimensions) throws ProcessorException {
		if (dimensions == null) {
			return groupBy(Collections.singletonMap("0", null));
		}

		if (dimensions.length == 1) {
			Object dim = dimensions[0];
			if (dim == null) {
				return groupBy((Map<String, ?>) Collections.singletonMap("0", null));
			} else if (dim instanceof Map) {
				return groupBy((Map<String, ?>) dim);
			} else if (dim instanceof List) {
				List<?> listDim = (List<?>) dim;
				if (listDim.isEmpty()) {
					return groupBy((Map<String, ?>) null);
				} else {
					Map<String, Object> dims = new HashMap<>();
					int index = 0;
					for (Object o : listDim) {
						dims.put(Integer.toString(index++), o);
					}
					return groupBy((Map<String, ?>) dims);
				}
			} else if (dim.getClass().isArray()) {
				int len = Array.getLength(dim);
				if (len == 0) {
					return groupBy((Map<String, ?>) null);
				} else {
					Map<String, Object> dims = new HashMap<>();
					for (int i = 0; i < len; i++) {
						dims.put(Integer.toString(i), Array.get(dim, i));
					}
					return groupBy((Map<String, ?>) dims);
				}
			} else {
				return groupBy((Map<String, ?>) Collections.singletonMap("0", dim));
			}
		} else {
			Map<String, Object> dims = new HashMap<>();
			for (int i = 0; i < dimensions.length; i++) {
				dims.put(Integer.toString(i), dimensions[i]);
			}
			return groupBy((Map<String, ?>) dims);
		}
	}

	default T setGroupTypes(DimensionType... types) throws ProcessorException {
		Map<String, DimensionType> tmap = new HashMap<>();
		for (int i = 0; i < types.length; i++) {
			tmap.put(Integer.toString(i), types[i]);
		}
		return setGroupTypes(tmap);
	}

	T setGroupTypes(Map<String, DimensionType> typeMap) throws ProcessorException;

	default T setLongGroups(String... groupNames) throws ProcessorException {
		if (groupNames.length > 0) {
			Map<String, DimensionType> tmap = new HashMap<>();
			for (String name : groupNames) {
				tmap.put(name, DimensionType.LONG);
			}
			return setGroupTypes(tmap);
		} else {
			return setGroupTypes((Map<String, DimensionType>) null);
		}
	}

	@RbeaDocumentedMethod(summary = "Sets the table name where the aggregator results are written.")
	T setTableName(String tableName) throws ProcessorException;
}
