package com.king.rbea.scripts.proxy.calltransformers;

import java.lang.reflect.Method;

import com.king.event.Event;
import com.king.proxy.methods.MethodCallTransformer;
import com.king.rbea.annotations.ProcessEvent;

import net.bytebuddy.description.method.MethodDescription;
import net.bytebuddy.implementation.bytecode.StackManipulation;
import net.bytebuddy.implementation.bytecode.constant.LongConstant;
import net.bytebuddy.implementation.bytecode.member.MethodInvocation;
import net.bytebuddy.implementation.bytecode.member.MethodVariableAccess;
import net.bytebuddy.jar.asm.Label;
import net.bytebuddy.jar.asm.MethodVisitor;
import net.bytebuddy.jar.asm.Opcodes;

public class TypeAndSCFilter implements MethodCallTransformer {
	private static final long serialVersionUID = 1L;

	@Override
	public StackManipulation transform(Method targetMethod, StackManipulation sm) throws Exception {

		ProcessEvent pe = targetMethod.getAnnotation(ProcessEvent.class);
		Class<?>[] semClasses = pe.semanticClass();
		if (semClasses.length == 0 && pe.eventType().length == 0) {
			return sm;
		}

		StackManipulation[] semClassProcessMethods = new StackManipulation[semClasses.length];

		for (int i = 0; i < semClasses.length; i++) {
			Class<?> semClass = semClasses[i];
			semClassProcessMethods[i] = MethodInvocation
					.invoke(new MethodDescription.ForLoadedMethod(semClass.getMethod("process", Event.class)));
		}

		MethodDescription eventTypeGetter = new MethodDescription.ForLoadedMethod(
				Event.class.getMethod("getEventType"));

		return new StackManipulation() {

			@Override
			public Size apply(MethodVisitor methodVisitor,
					net.bytebuddy.implementation.Implementation.Context implementationContext) {

				Label noMatch = new Label();
				Label anyMatch = new Label();

				// First check for the event type conditions
				for (long et : pe.eventType()) {
					// Calls event.getEventType()
					MethodVariableAccess.REFERENCE.loadFrom(1).apply(methodVisitor, implementationContext);
					MethodInvocation.invoke(eventTypeGetter).apply(methodVisitor, implementationContext);

					// Push the filtered type on the stack
					LongConstant.forValue(et).apply(methodVisitor, implementationContext);

					// If equal branch to user code execution
					methodVisitor.visitInsn(Opcodes.LCMP);
					methodVisitor.visitJumpInsn(Opcodes.IFEQ, anyMatch);
				}

				// Check for the semantic class conditions
				for (StackManipulation scProcess : semClassProcessMethods) {
					// Calls SemClass.process(event)
					MethodVariableAccess.REFERENCE.loadFrom(1).apply(methodVisitor, implementationContext);
					scProcess.apply(methodVisitor, implementationContext);
					// If not null branch to user code execution
					methodVisitor.visitJumpInsn(Opcodes.IFNONNULL, anyMatch);
				}

				methodVisitor.visitJumpInsn(Opcodes.GOTO, noMatch);

				methodVisitor.visitLabel(anyMatch);
				methodVisitor.visitFrame(Opcodes.F_SAME, 0, null, 0, null);

				Size methodSize = sm.apply(methodVisitor, implementationContext);

				methodVisitor.visitLabel(noMatch);
				methodVisitor.visitFrame(Opcodes.F_SAME, 0, null, 0, null);

				if (pe.eventType().length == 0) {
					return new Size(methodSize.getSizeImpact(), methodSize.getMaximalSize());
				} else {
					return new Size(
							Math.max(4, methodSize.getSizeImpact()),
							Math.max(4, methodSize.getMaximalSize()));
				}
			}

			@Override
			public boolean isValid() {
				return true;
			}

		};
	}

}