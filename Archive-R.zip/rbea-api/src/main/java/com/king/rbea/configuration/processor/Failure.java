package com.king.rbea.configuration.processor;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.InvocationTargetException;
import java.util.Optional;

import org.apache.commons.lang.exception.ExceptionUtils;

import com.king.rbea.configuration.Configuration;
import com.king.rbea.exceptions.ProcessorException;

/**
 * {@code Failure} is a {@link ProcessorInfo} indicating a failed/crashed
 * processor.
 */
public class Failure extends ProcessorInfo {
	private static final long serialVersionUID = 1L;

	public static final String FAILURE_CAUSE_KEY = "error";

	public Deployment deployment = null;

	public Failure(long procId, ProcessorException pe, String script, long failureTime) {
		super(procId);
		Throwable cause = pe.getCause() != null ? pe.getCause() : pe;
		String msg = pe.getCustomMessage();
		String stackTrace = ExceptionUtils.getFullStackTrace(pe);
		if (cause instanceof InvocationTargetException) {
			cause = cause.getCause();
		}

		setString(FAILURE_CAUSE_KEY, getErroMsg(msg, cause, script).orElse(stackTrace));
		setLong(JobSummary.JOB_END_TIME_KEY, failureTime);
		setString(JobSummary.JOB_STACK_TRACE_KEY, stackTrace);
	}

	public Failure(Configuration conf) {
		super(conf);
	}

	public Failure withDeployment(Deployment dep) {
		this.deployment = dep;
		return this;
	}

	public static Optional<String> getErroMsg(String msg, Throwable ex, String script) {

		if (script == null) {
			return Optional.ofNullable(msg);
		}

		try {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw, true);

			String lmsg = ex.getLocalizedMessage();
			pw.println(msg != null ? msg : lmsg != null ? lmsg : ex.getClass().getSimpleName());
			for (StackTraceElement e : ex.getStackTrace()) {
				if (e.getClassName() == "Script1") {
					int line = e.getLineNumber();
					if (script != null) {
						String code = script.split("\n")[line - 1].trim();
						pw.println("Caused by: " + code);
					}
					pw.println("Line: " + line);
					return Optional.of(sw.getBuffer().toString());
				}
			}
		} catch (Throwable ignored) {}
		return Optional.empty();
	}

	public String getCause() {
		return getString(FAILURE_CAUSE_KEY).get();
	}

	@Override
	public String toString() {
		return "Failure(" + getProcessorId() + ", " + getCause() + ")";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long procId = getProcessorId();
		String cause = getCause();
		result = prime * result + ((cause == null) ? 0 : cause.hashCode());
		result = prime * result + (int) (procId ^ (procId >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Failure)) {
			return false;
		}
		Failure other = (Failure) obj;
		if (getCause() == null) {
			if (other.getCause() != null) {
				return false;
			}
		} else if (!getCause().equals(other.getCause())) {
			return false;
		}
		if (getProcessorId() != other.getProcessorId()) {
			return false;
		}
		return true;
	}

	@Override
	protected boolean mergeToSummaryInternal(JobSummary summary) {
		boolean alreadyFailed = summary.getString(JobSummary.STOP_REASON_KEY).orElse("").equals(JobSummary.STOP_REASON_ERROR);

		if (!alreadyFailed && deployment != null) {
			deployment.mergeToSummary(summary);
		}

		// Information about the failure
		summary.setString(JobSummary.JOB_STATE_KEY, JobSummary.JOB_STATE_FAILED);
		summary.setString(JobSummary.JOB_STATE_DESCRIPTION_KEY, getString(FAILURE_CAUSE_KEY).get());
		if (summary.getLong(JobSummary.JOB_CREATED_TIME_KEY).orElse(-1l) == -1) {
			summary.setLong(JobSummary.JOB_CREATED_TIME_KEY, getLong(JobSummary.JOB_CREATED_TIME_KEY).orElse(System.currentTimeMillis()));
		}
		if (summary.getLong(JobSummary.JOB_START_TIME_KEY).orElse(-1l) == -1) {
			summary.setLong(JobSummary.JOB_START_TIME_KEY, getLong(JobSummary.JOB_END_TIME_KEY).orElse(-1l));
		}
		summary.setLong(JobSummary.JOB_END_TIME_KEY, getLong(JobSummary.JOB_END_TIME_KEY).orElse(-1l));
		summary.setString(JobSummary.JOB_STACK_TRACE_KEY, getString(FAILURE_CAUSE_KEY).get());

		// Legacy
		summary.setString(FAILURE_CAUSE_KEY, getString(FAILURE_CAUSE_KEY).get());
		summary.setString(JobSummary.JOB_STATUS_KEY, JobSummary.JOB_STATUS_STOPPED);
		summary.setString(JobSummary.STOP_REASON_KEY, JobSummary.STOP_REASON_ERROR);
		return !alreadyFailed;
	}

	/**
	 * This method should remove all the information regarding the previous failure.
	 * Should be called when the job is restarted after a failure.
	 * 
	 * @param summary
	 */
	public static void clearFailureInfo(JobSummary summary) {
		summary.setString(Failure.FAILURE_CAUSE_KEY, "");
		summary.removeKey(JobSummary.JOB_STACK_TRACE_KEY);
	}
}