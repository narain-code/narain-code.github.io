package com.king.rbea.scripts;

import java.io.Serializable;
import java.nio.file.Path;

import com.king.rbea.EventProcessor;
import com.king.rbea.exceptions.ProcessorException;

public interface ProcessorFactory {

	EventProcessor getForJavaCode(long jobId, String jobName, String javaCode) throws ProcessorException;

	EventProcessor getForJar(long jobId, String jobName, Path jarFile) throws ProcessorException;

	EventProcessor getForHDFSJar(long jobId, String jobName, String hdfsReference) throws ProcessorException;

	EventProcessor getForJavaObject(long jobId, String jobName, Serializable scriptInstance) throws ProcessorException;

	EventProcessor getForClass(long jobId, String jobName, Class<?> scriptClass) throws ProcessorException;

	EventProcessor getForGroovyScript(long jobId, String jobName, String scriptText) throws ProcessorException;

}
