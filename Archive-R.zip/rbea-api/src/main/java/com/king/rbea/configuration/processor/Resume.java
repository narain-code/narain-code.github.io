package com.king.rbea.configuration.processor;

import com.king.rbea.configuration.Configuration;

public class Resume extends ProcessorInfo {
	private static final long serialVersionUID = 1L;

	public Resume(long procId, long resumeTime) {
		super(procId);

		setLong(JobSummary.JOB_START_TIME_KEY, resumeTime);
	}
	
	public Resume(Configuration conf) {
		super(conf);
	}
	
	@Override
	protected boolean mergeToSummaryInternal(JobSummary summary) {
		Failure.clearFailureInfo(summary);
		
		summary.setString(JobSummary.JOB_STATE_KEY, JobSummary.JOB_STATE_RUNNING);
		summary.setString(JobSummary.JOB_STATE_DESCRIPTION_KEY, "");
		summary.setLong(JobSummary.JOB_START_TIME_KEY, getLong(JobSummary.JOB_START_TIME_KEY).get());
		summary.setLong(JobSummary.JOB_END_TIME_KEY, -1);
		
		// Legacy fields
		summary.setString(JobSummary.JOB_STATUS_KEY, JobSummary.JOB_STATUS_RUNNING);
		summary.setString(JobSummary.STOP_REASON_KEY, "");
		return true;
	}
	
	@Override
	public String toString() {
		return "Resume(" + getProcessorId() + ")";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		long processorId = super.getProcessorId();
		result = prime * result + (int) (processorId ^ (processorId >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Resume other = (Resume) obj;
		long processorId = super.getProcessorId();
		if (processorId != other.getProcessorId())
			return false;
		return true;
	}
}
