package com.king.rbea.scripts.proxy;

import java.io.Serializable;

public class JavaObjectExecutor extends ProxyExecutor {

	private static final long serialVersionUID = 1L;
	private final Serializable javaObj;

	public JavaObjectExecutor(long jobId, String jobName, Serializable object) {
		super(jobId, jobName);
		this.javaObj = object;
	}

	@Override
	public Object getScriptInstance() throws Exception {
		return javaObj;
	}
}
