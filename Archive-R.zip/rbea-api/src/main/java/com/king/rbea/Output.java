package com.king.rbea;

import com.google.common.base.Charsets;
import com.king.event.Event;
import com.king.rbea.documenting.RbeaDocumentedClass;
import com.king.rbea.documenting.RbeaDocumentedMethod;
import com.king.rbea.exceptions.ProcessorException;

@RbeaDocumentedClass(summary = "The output can be used to write events and other arbitrary data to different output formats.")
public interface Output {

	@RbeaDocumentedMethod(summary = "Writes the given value as a String to a script-local Kafka topic. Useful for experimenting/debugging. For writing Events use print(formatEvent(event))")
	void print(Object obj);

	@RbeaDocumentedMethod(summary = "Formats an Event into a tab delimited String.")
	String formatEvent(Event event) throws ProcessorException;

	@RbeaDocumentedMethod(summary = "Writes a byte array to the selected Kafka topic.")
	default void writeBytesToKafka(String topic, byte[] data) throws ProcessorException {
		writeBytesToKafka(topic, null, data);
	}

	@RbeaDocumentedMethod(summary = "Writes a byte array to the selected Kafka topic with key.")
	void writeBytesToKafka(String topic, byte[] key, byte[] data) throws ProcessorException;

	@RbeaDocumentedMethod(summary = "Writes the given Event as a String to the selected Kafka topic.")
	default void writeEventToKafka(String topic, Event event) throws ProcessorException {
		String partitionKey = null;
		try {
			partitionKey = event.getString(0);
		} catch (Throwable ignore) {}

		writeEventToKafka(topic, partitionKey, event);
	}

	@RbeaDocumentedMethod(summary = "Writes the given Event as a String to the selected Kafka topic with the specified partition key.")
	default void writeEventToKafka(String topic, String key, Event event) throws ProcessorException {
		writeBytesToKafka(topic,
				key != null ? key.getBytes(Charsets.UTF_8) : null,
				formatEvent(event).getBytes(Charsets.UTF_8));
	}

	@RbeaDocumentedMethod(summary = "Writes the given object as a String to the selected Kafka topic. For writing Events use writeEventToKafka(...).")
	default void writeToKafka(String topic, Object data) throws ProcessorException {
		writeBytesToKafka(topic, data.toString().getBytes(Charsets.UTF_8));
	}
	
	default String getStateExportTopic() {
		throw new UnsupportedOperationException();
	}
	
	default String getStateSchemaExportTopic() {
		throw new UnsupportedOperationException();
	}
}
