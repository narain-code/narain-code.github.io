package com.king.rbea.configuration.processor;

import com.king.rbea.configuration.Configuration;

public class JobConfig extends ProcessorInfo {
	private static final long serialVersionUID = 1L;

	public static final String JOB_CONFIG_KEY = "jobConfig";

	public JobConfig(long procId, String jsonConf) {
		super(procId);
		setString(JOB_CONFIG_KEY, jsonConf);
	}

	public JobConfig(Configuration conf) {
		super(conf);
	}

	public String getJobConfig() {
		return getString(JOB_CONFIG_KEY).get();
	}

	@Override
	public String toString() {
		return "JobConfig(" + getProcessorId() + "," + getJobConfig() + ")";
	}

	@Override
	protected boolean mergeToSummaryInternal(JobSummary summary) {
		summary.setString(JOB_CONFIG_KEY, getJobConfig());
		return false;
	}
}