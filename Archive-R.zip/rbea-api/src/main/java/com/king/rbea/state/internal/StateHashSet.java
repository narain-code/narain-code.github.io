package com.king.rbea.state.internal;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Spliterator;

import com.king.flink.utils.Unchecked;
import com.king.rbea.state.LocalState;

public class StateHashSet<V> extends HashSet<V> {

	public static final class State<T> extends LocalState<HashSet<T>> {
		private static final long serialVersionUID = 1L;

		public State(String name) {
			super(name);
		}

		@Override
		public HashSet<T> getValue(long coreId, InternalState state) throws Exception {
			return new StateHashSet<>(state);
		}
	}

	private static final long serialVersionUID = 1L;
	private HashSet<V> localState = null;
	private final InternalState state;

	public StateHashSet(InternalState state) {
		this.state = state;
	}

	@SuppressWarnings("unchecked")
	private void loadState() {
		try {
			if (localState == null) {
				Object val = state.readValue();
				localState = (HashSet<V>) (val != null ? val : new HashSet<>());
			}
		} catch (Exception ex) {
			Unchecked.throwSilently(ex);
		}
	}

	private void updateState() {
		try {
			state.writeValue(localState.isEmpty() ? null : localState);
		} catch (Exception ex) {
			Unchecked.throwSilently(ex);
		}
	}

	@Override
	public Spliterator<V> spliterator() {
		loadState();
		return localState.spliterator();
	}

	@Override
	public int size() {
		loadState();
		return localState.size();
	}

	@Override
	public boolean isEmpty() {
		loadState();
		return localState.isEmpty();
	}

	@Override
	public void clear() {
		loadState();
		localState.clear();
		updateState();
	}

	@Override
	public boolean equals(Object o) {
		loadState();
		return localState.equals(o);
	}

	@Override
	public int hashCode() {
		loadState();
		return localState.hashCode();
	}

	@Override
	public boolean contains(Object o) {
		loadState();
		return localState.contains(o);
	}

	@Override
	public Iterator<V> iterator() {
		loadState();
		return localState.iterator();
	}

	@Override
	public Object[] toArray() {
		loadState();
		return localState.toArray();
	}

	@Override
	public <T> T[] toArray(T[] a) {
		loadState();
		return localState.toArray(a);
	}

	@Override
	public boolean add(V e) {
		loadState();
		boolean added = localState.add(e);
		updateState();
		return added;
	}

	@Override
	public boolean remove(Object o) {
		loadState();
		boolean removed = localState.remove(o);
		updateState();
		return removed;
	}

	@Override
	public boolean containsAll(Collection<?> c) {
		loadState();
		return localState.containsAll(c);
	}

	@Override
	public boolean addAll(Collection<? extends V> c) {
		loadState();
		boolean added = localState.addAll(c);
		updateState();
		return added;
	}

	@Override
	public boolean retainAll(Collection<?> c) {
		loadState();
		boolean retained = localState.retainAll(c);
		updateState();
		return retained;
	}

	@Override
	public boolean removeAll(Collection<?> c) {
		loadState();
		boolean removed = localState.removeAll(c);
		updateState();
		return removed;
	}
}
