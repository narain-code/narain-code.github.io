package com.king.rbea.configuration.processor;

import com.king.rbea.configuration.Configuration;

/**
 * {@code JobSummariesEnd} indicates end of {@link JobSummary}-objects.
 */
public class JobSummariesEnd extends Configuration {
	private static final long serialVersionUID = 1L;
	
	public JobSummariesEnd() {
		super();
	}

	public JobSummariesEnd(Configuration conf) {
		super(conf);
	}
	
	@Override
	public String toString() {
		return "JobSummariesEnd()";
	}
}
