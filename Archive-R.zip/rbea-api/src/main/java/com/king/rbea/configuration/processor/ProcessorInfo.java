package com.king.rbea.configuration.processor;

import com.king.rbea.configuration.Configuration;

/**
 * {@code ProcessorInfo} represents a message that is not an event, but
 * something related to a certain processor.
 */
public abstract class ProcessorInfo extends Configuration {

	public static final String PROC_ID_KEY = "id";
	public static final String PROPAGATED_KEY = "propageted";
	private static final long serialVersionUID = 1L;

	protected ProcessorInfo(long procId) {
		super();
		setLong(PROC_ID_KEY, procId);
	}

	protected ProcessorInfo(Configuration conf) {
		super(conf);
	}

	public long getProcessorId() {
		return getLong(PROC_ID_KEY).get();
	}

	public boolean isPropagated() {
		return getBoolean(PROPAGATED_KEY).orElse(false);
	}

	public void propagate() {
		setBoolean(PROPAGATED_KEY, true);
	}

	/**
	 * Subclass-specific method to merge the instance's state to {@code summary}
	 * 
	 * @param summary
	 *            the object to merge to
	 * @return whether a message is output.
	 */
	protected abstract boolean mergeToSummaryInternal(JobSummary summary);

	/**
	 * Updates {@code summary} based on the information contained in this instance.
	 * <p>
	 * Handles synchronization on {@code summary}-objects so that the individual
	 * {@link #mergeToSummaryInternal(JobSummary)}-methods don't have to - it would
	 * be easy to forget to.
	 * 
	 * @param summary
	 *            the {@code JobSummary} to be updated
	 * @return whether a message is output
	 */
	public boolean mergeToSummary(JobSummary summary) {
		summary.lock();
		try {
			return mergeToSummaryInternal(summary);
		} finally {
			summary.unlock();
		}
	}
}
