package com.king.rbea.scripts;

interface SemanticClass {
	Object process(com.king.event.Event event);
}