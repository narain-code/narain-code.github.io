# User States

## Contents
 - [Introduction](#intro)
 - [Predefined states](#predefined)
   - [Last SC states](#last)
   - [AB Test assignments](#abstate)
 - [Custom states](#custom)
   - [Local States](#local)
   - [Fields](#fields)
 - [Advanced features](#advanced)
   - [Update callbacks](#callbacks)
   - [Reading state from other jobs](#external)

## <a name="intro"></a>Introduction

In many cases we want to keep some information (state) for each user. This can be any sort of information ranging from something as simple as flagging a user meeting a particular condition, to something more complex like tracking A/B test assignments or currently in flight sessions or transactions for the user.

In other words, we can store (pretty much) anything we want in the state as long as it is scoped to a specific core user id. Moreover state is strictly bound to a specific user both in terms of writing or reading it (we can only ever read the state for the current user id).

All state is accessed through the dedicated `State` interface which is accessible from the `Context` or can be used as a parameter to the ProcessEvent method.

## <a name="predefined"></a>Predefined states

There are several types of state already defined and updated by the system automatically. These are shared by all running scripts and can be accessed by anyone. Also these states are continuously updated since the backend started so they naturally have a longer history then any custom state which can come in handy sometimes.

### <a name="last"></a>Last Semantic Class states

We automagically keep the last event seen per user for all semantic classes. It can be accessed from the `State` by calling:  `state.getLast(SemClass)` or equivalently `state.get("LAST_CLASSNAME")`:

```groovy
SCGameStart lastGs = state.getLast(SCGameStart)
SCGameEnd lastGe = state.getLast(SCGameEnd)
```

In some cases it is possible that the object returned by `getLast` will be `null`, so it is always better to do a simple null-check.

This can be very useful when we want to join events with information that arrived earlier. For example if we want to aggregate some data, let's say revenue, per country we would most probably want to join with the last client start event to determine the current country:

```groovy
@ProcessEvent(semanticClass = SCPurchase)
def spendPerCountry(SCPurchase purchase, State state) {
    //get the most recent country if it exists:
    def country = 'UNKNOWN'
    def SCClientStart cs = state.getLast(SCClientStart)

    // cs can be null in some rare cases
    if (cs) {
    	country = (cs.countrycode.length()>0 & cs.countrycode.length()<=2) ? cs.countrycode : 'WRONG'
    }

    // Compute spend and aggregate by 'country'
}
```

### <a name="abstate"></a>AB Test assignments

We also keep track of the AB test assignments for the current user as defined by the `SCAbTestCaseAssignedServer` events. The assignments can be accessed through the `ABTestAssignments` object which is obtained by calling `state.getABTestAssignments()`:

```groovy
ABTestAssignments assignments = state.getABTestAssignments()

Integer caseNum = assignments.getCaseNum("TestName", 0)
//caseNum might be null
if(caseNum) {
  //...
}

SCAbTestCaseAssignedServer assignmentEvent = assignments.getAssignmentEvent("TestName", 0)
//assignmentEvent might be null
if(assignmentEvent) {
  //...
}

Collections<SCAbTestCaseAssignedServer> allAssingments = assignments.getAllAssignments()
```

## <a name="custom"></a>Custom states

In addition to the pre-defined states, RBea provides a very flexible way of creating user defined states.

Users can define two types of user state:
- **Local states**: Most flexible can be read/updated anywhere where we have a user context, but only accessible from the current job
- **Fields**: Can only be updated with a predefined update function, but can be read by any running job. High performance and shared

Each user state has an associated String identifier (name) that is used to read the current value from the `State`:
```groovy
state.get("name")
```

Both local states and fields must be registered in the scripts `initialize` method:

```groovy
@Initialize
def initialize(Registry registry) {
    // Register fields and callbacks here
    // registry.registerState(...)
}
```

### <a name="local"></a>Local States

Local states are the most flexible states that can be accessed only from a specific running job. They are created by registering them in the `Registry` and can be read/updated with `get/update/clear` methods from the `State` object for the current user.

Let's start by looking at an example where we count game starts by people who had a purchase with at least 10 dollars in the past. We will do this by creating a Boolean local state marking each player with true or false, whether they belong to the interesting group or not, and then reading and checking this flag on each game start.

```groovy
@ProcessEvent(semanticClass = SCPurchase)
def onPurchase(SCPurchase purchase, State state) {
    if(getUSDAmount(purchase) > 10) {
        state.set("IN_GROUP", true)
    }
}

@ProcessEvent(semanticClass = SCGameStart)
def onGameStart(SCGameStart start, State state, Aggregators agg) {
    if(state.get("IN_GROUP")) {
        agg.getCounter("Count", MINUTES_10).increment()
    }
}

@Initialize
def initialize(Registry registry) {
    registry.registerState(LocalState.create("IN_GROUP", false))
}
```

In the above case we created a localstate named "IN_GROUP" with the initial value set to `false`. If we see a purchase with more than 10 dollars, we set this flag `true` for the user. When we see a gamestart we first check the flag in the localstate and only count if the value is `true`.

There are a couple different ways to define a LocalState object that might be more convenient depending on the use case:

- **create(String name, T initialValue)** : Create a LocalState with the specified name and non-null initial value. The type is determined from the initial value.
- **create(String name, Class type)** : Creates a LocalState with the specified name and type with `null` as initial value.
- **createMap(String name, Class keyType, Class valueType)** : Creates a local Map state with an empty map as the initial value. Get commands will return a Map<K,V> object. Changes to this map are automatically reflected in the state without having to call `state.set(..)`.
- **createSet(String name, Class elementType)** : Creates a local Set state with an empty set as the initial value. Get commands will return a Set<T> object. Changes to this set are automatically reflected in the state without having to call `state.set(..)`.
- Also some convenience methods: createLong, createInt, createBoolean which are pretty self-explanatory

Every field (except for map and set) can be initialed to a given default value by calling `initializedTo(..)` when creating it. For example: `LocalState.createBoolean("MyFlag").initializedTo(false)`.

**Map and Set states**

In several use cases, we want to keep more then one piece of information for one user. This data can most of the time be structured in a Map or Set data structure.
If the Key/Value/Element types are defined in a sensible way (**not as Object**) this can be done fairly efficiently by the system. To do this we can use `LocalState.createMap(..)` and `LocalState.createSet(..)`.

The Map and Set objects returned by `state.get(..)` behave nicely in the sense that any modifications will be directly applied to the state.
Let's look at an example where we count attempts per level for every user:


```groovy
@ProcessEvent(semanticClass = SCGameEnd)
def onGameEnd(SCGameEnd end, State state) {
    long level = end.level

    Map<Long, Integer> attempts = state.get("Attempts")
    attempts.put(level, attempts.getOrDefault(level, 0) + 1)
    // We don't have to set the state again as we used the map state
}

@Initialize
def initialize(Registry registry) {
    // Define a local map state: Map<Long, Integer>
    registry.registerState(LocalState.createMap("Attempts", Long, Integer))
}
```

### <a name="fields"></a>Fields

A `Field` is a definition of a core-user state with the associated update rule.

We can register new fields by passing them to the `registerState(field)` method. Fields are defined by specifying the following attributes:

**Mandatory**

 - **Field name**: String reference for accessing the value from the State
 - **Input transformer**: The InputTransformer serves two purposes: it defines which events will the field updated on and optionally tansforms the input before passing it to the update function. Use the `Input.filter(event -> boolean)`, `Input.fromSemanticClass(SCMyClass.class)` or `Input.allEvents()` for convenience.
 - **Update function**: Defines how the Field will be updated for each transformed input. The update function comes in two flavors: `(State, Event) -> State` and `(Context, Event) -> State`.

**Optional**

- **Initializer**: By default states are initialized with `null` value. In order to specify an initializer function we can call `field.intitializedTo(initialValue)` or `field.withInitializer(CoreUserId(Long) -> State)`
- **Type**: By default type of the state is automatically inferred during runtime but in order to aid the system we can declare the type directy using `field.withType(class)`.

Fields can be created with one of the following methods:

```groovy
// Simple self-contained fields that only update the value based on the previous state value
Field.create(name, inputTransformer ,(State, Event) -> State)

// More complex update logic based on other state. Can also produce output and aggregates.
Field.createWithContext(name, inputTransformer, (Context, Event) -> State)
```

This all might look intimidating at first but it's very easy in practice.

Let's look at some examples using the `SimpleUpdateFunction` to define fields:

 ```groovy
 def initialize(Registry registry) {
     // Create field with total games per user, initialized for 0 for all users
     def total_games = Field.create("TOTAL_GAMES", Input.fromSemanticClass(SCGameStart.class),
            { Integer tg, SCGameStart e -> tg + 1 }
        ).initializedTo(0)

    registry.registerState(total_games)
}
 ```

Sometimes the state update and processing logic are tied closely together and all we need is a more complex update function that will produce the output. In these cases we can use `Field.createWithContext` variant in which case our update function has access to the Context so we can produce outputs, update aggregators and read the value of all the other fields defined.

## <a name="advanced"></a>Advanced features

### <a name="callbacks"></a>Update callbacks

Field update callbacks provide a very nice way of reacting to state changes in our program. In many cases we only want to trigger some action whenever the value of a Field changes, for instance when the number of total games has increased, or we get a new install or purchase etc.

Without the callbacks we would need to continuously monitor the state ourselves in the ProcessEvent function. Callbacks can be registered using the registry.

Let's look at a working example that tracks average time between purchases:

```groovy
def initialize(Registry registry) {
    // We register a callback on the backend managed 'last purchase' state
    registry.registerUpdateCallback("LAST_SCPURCHASE",
      {SCPurchase prev, SCPurchase current, Context ctx ->
          // prev is null for the first purchase
          if(prev) {
              ctx.getAggregators().getAverageAggregator("MyAvg", MINUTES_10).add(current.msts - prev.msts)
          }	         
      })
}
```

### <a name="external"></a>Reading state from other jobs

Sometimes it's practical to share state across multiple rbea jobs. For these usecases it is possible to read the Fields values defined by other running jobs: `state.get(jobId, "fieldName")`
*Please note that LocalStates cannot be accessed this way at the moment.*
