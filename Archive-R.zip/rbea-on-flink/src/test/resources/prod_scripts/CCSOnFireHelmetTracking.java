package prod_scripts;

import com.king.constants.external.EventField;
import com.king.constants.external.EventType;
import com.king.event.Event;
import com.king.rbea.Aggregators;
import com.king.rbea.Output;
import com.king.rbea.aggregators.AggregationWindow;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.exceptions.ProcessorException;

public class CCSOnFireHelmetTracking {

    private AggregationWindow aggWindow = AggregationWindow.MINUTES_5;

    @SuppressWarnings("deprecation")
	@ProcessEvent(eventType = EventType.AppCustomMessage)
    public void onHelmetReached(Event event, Output out, Aggregators agg) throws ProcessorException {
        String custommessage = event.get(EventField.AppCustomMessage.customMessage);
        if(custommessage.matches("CandyCrushOnFireLiveOp,.*")){
            int helmetReached = Character.getNumericValue(custommessage.charAt(23));
            agg.getCounter("Helmets Reached", aggWindow).setDimensions(helmetReached).increment();
        }
    }
}
