package prod_scripts;

import java.util.Arrays;

import com.king.constants.external.EventField;
import com.king.constants.external.EventType;
import com.king.event.Event;
import com.king.rbea.Aggregators;
import com.king.rbea.Output;
import com.king.rbea.Registry;
import com.king.rbea.State;
import com.king.rbea.aggregators.AggregationWindow;
import com.king.rbea.annotations.Initialize;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.extensions.LiveTask;
import com.king.rbea.state.LocalState;
import com.king.rbea.state.StateDescriptor;
import com.king.rbea.state.globalstate.GlobalState;

public class CCSMultipleTimeOfferForLeagues {

    private AggregationWindow aggWindow = AggregationWindow.MINUTES_5;

    private StateDescriptor<Boolean> sentSale;
    private String liveTaskAbTest = "ccsm_live_tasks_v1";
    
    // TODO - TRACKING_MSG to be updated every time script is deployed
    // Tracking parameters - can't track because leagues event has no installID
    // private static String TRACKING_TOPIC = "work.sloggo.store-livetasks-events";
    // private static String TRACKING_MSG = "SaleForLeagueEight_20171211";

    // Limitations
    private static int minimumBuild = 111;
    // Triggers
    private static String triggerName = "SaleLeagueEight";

    @SuppressWarnings("deprecation")
	@ProcessEvent(eventType = EventType.CandyCrushLeagueChanged)
    public void onLeague8Trigger(Event event, GlobalState gs, Output out, State state, Aggregators agg, LiveTask lt, Long cuid) throws Exception {
        if (cuid != null && cuid > 0L) {
            try {
                // Extract necessary build string part
                String[] buildstringParts = gs.getAppBuildString().split("\\.");
                int bs;
                // buildstringParts needs to be at least two
                if (buildstringParts.length > 1) {
                    bs = Integer.parseInt(buildstringParts[1]);
                } else {
                    bs = 0;
                }

                int league_position = event.get(EventField.CandyCrushLeagueChanged.position);
                // If correct buildstring and reached league 8, then send a sale with live task
                if (bs >= minimumBuild && league_position == 8) {

                    // Check whether the player has already received the sale, in which case do not send again
                    Boolean isSent = state.get(sentSale);

                    if(isSent != null && isSent){
                        // Aggregate
                        agg.getCounter("Triggers", aggWindow).setDimensions("AlreadySent").increment();
                    } else {
                        // Send sale through live task
                        sendSale(out, state, agg, lt, cuid, event.getFlavourId(), event.getTimeStamp());
                        // Aggregate
                        agg.getCounter("Triggers", aggWindow).setDimensions("SendSale").increment();
                    }

                }
            } catch (Exception e) {
                out.print("Error in extracting buildstring from global state or position from league change");
            }
        } else {
            out.print("Malformed event with broken coreuserid");
        }

    }

    @SuppressWarnings("deprecation")
	private void sendSale(Output out, State state, Aggregators agg, LiveTask lt, Long cuid, Integer flavourId, long msts) throws Exception {
        Integer caseNum = state.getABTestAssignments().getLastCaseNum(liveTaskAbTest);
        if (caseNum != null && caseNum == 1) {
            if (flavourId != 17) {
                // Send sale trigger
                lt.sendConfigurableLiveTaskTrigger(triggerName, Arrays.asList(""));

                // Tracking for sale live task sent
                //trackTrigger(out, cuid, flavourId, msts);

                // Aggregate
                agg.getCounter("Triggers", aggWindow).setDimensions("SendLiveTask").increment();

                // Update state
                state.update(sentSale, true);

            }
        }
    }

    // Writes help event to kafka
//    private void trackTrigger(Output out, Long cuid, int flavourId, long ts) throws Exception {
//
//        String msg = TRACKING_MSG;
//
//        // Build event
//        EventBuilder eventBuilder = new EventBuilder(flavourId);
//        EventParameters eventParams = EventType.AppCustomMessage(cuid, "", ts, msg);
//        Event helpEvent = eventBuilder.buildEvent(eventParams, 1);
//
//        // Send to kafka
//        out.writeEventToKafka(TRACKING_TOPIC, helpEvent);
//    }

    @Initialize
    public void init(Registry reg) throws ProcessorException {
        sentSale = reg.registerState(LocalState.create("SentSale", false));
    }
}
