package prod_scripts;

import com.google.common.collect.ImmutableMap;
import com.king.constants.Flavour;
import com.king.constants.KingApp;
import com.king.constants.SignInSource;
import com.king.event.Event;
import com.king.kgk.*;
import com.king.rbea.Aggregators;
import com.king.rbea.State;
import com.king.rbea.Utils;
import com.king.rbea.aggregators.AggregationWindow;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.state.basefields.ABTestAssignments;
import com.king.splat.AbTestInfo;
import com.king.utils.AbTestMetaManager;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Map;
import java.util.Set;

public class ABTestAgg {

    private AggregationWindow aggWindow = AggregationWindow.MINUTES_5;

    // TODO Missing metrics
    // booster usage -> kgk mapping egp/booster/ummapped
    // return rate
    // retention how??


    private String tablePreFix = "ABTestAggregator_";


    @ProcessEvent(semanticClass = SCPurchase.class)
    public void scPurchase(Event e, SCPurchase purchase, Utils utils, Aggregators agg, State state) throws Exception {

        aggByAbTestCase(agg, state, utils, e, "Transactions");

        BigDecimal usdAmount = utils.getCurrencyManager()
                .convertToUsd(purchase.getMsts(), purchase.getCurrency_local(), purchase.getSpend_local());

        aggByAbTestCase(agg, state, utils, e, "GrossBookings", (long) (usdAmount.doubleValue() * 100));

    }

    @ProcessEvent(semanticClass = SCItemTransaction.class)
    public void scItemTransaction(Event e, SCItemTransaction it, Utils utils, Aggregators agg, State state)
            throws Exception {

        // hardcurrency transactions
        if (Arrays.asList(100L, 200L).contains(it.getTransactionTypeId())) {
            if (it.getAmount() > 0) {
                aggByAbTestCase(agg, state, utils, e, "PositiveHCTransactions", it.getAmount());
            } else {
                aggByAbTestCase(agg, state, utils, e, "NegativeHCTransactions", Math.abs(it.getAmount()));
            }
        }
    }

    @ProcessEvent(semanticClass = SCMessageSent.class)
    public void scMessageSent(Event e, Utils utils, Aggregators agg, State state) throws Exception {
        aggByAbTestCase(agg, state, utils, e, "MessagesSent");
    }

    @ProcessEvent(semanticClass = SCGameStart.class)
    public void scGameStarts(Event e, Utils utils, Aggregators agg, State state) throws Exception {
        aggByAbTestCase(agg, state, utils, e, "GameStarts");
    }

    @ProcessEvent(semanticClass = SCGameEnd.class)
    public void scGameEnds(Event e, Utils utils, Aggregators agg, State state) throws Exception {
        aggByAbTestCase(agg, state, utils, e, "GameEnds");
    }

    @ProcessEvent(semanticClass = SCCrashReport.class)
    public void scCrashes(Event e, Utils utils, Aggregators agg, State state) throws Exception {
        aggByAbTestCase(agg, state, utils, e, "Crashes");
    }

    @SuppressWarnings("deprecation")
	private void aggByAbTestCase(Aggregators agg, State state, Utils utils, Event e, String aggregatorName, long value)
            throws ProcessorException {

        AbTestMetaManager abTestMetaManager = utils.getAbTestMetaManager();

        try {

            KingApp kingApp = KingApp.getById(Flavour.toKingAppId(e.getFlavourId()));

            Map<AbTestInfo.AbTestType, Set<AbTestInfo>> allActiveAbTests = abTestMetaManager
                    .getAllActiveAbTests(kingApp, e.getTimeStamp());

            String clientImpl = SignInSource
                    .getById(Flavour.toSignInSourceIdId(e.getFlavourId())).clientImplementation;

            ABTestAssignments assignments = state.getABTestAssignments();

            for (AbTestInfo abInfo : allActiveAbTests.get(AbTestInfo.AbTestType.STANDARD_V2)) {
                Integer caseNum = assignments.getCaseNum(abInfo.getName(), abInfo.getVersion());

                // Skip if no casenum
                if (caseNum == null) {
                    continue;
                }

                //check nr of active cases
                int activeCases = 0;
                for (AbTestInfo.Case abCase : abInfo.getCases()) {
                    if (abCase.getWeight() > 0) {
                        activeCases++;
                    }
                }

                if (activeCases > 1) {
                    agg.getSumAggregator(aggregatorName, aggWindow)
                            .setTableName(tablePreFix + aggregatorName + "_" + String.valueOf(kingApp.getId()))
                            .setDimensions(ImmutableMap.of(
                                    "ABTests", abInfo.getName(),
                                    "Versions", abInfo.getVersion(),
                                    "Cases", caseNum,
                                    "Client", clientImpl)).setLongGroups("Versions", "Cases").add(value);
                }


            }
        } catch (RuntimeException err) {
            String aggNameError = tablePreFix + "ScriptError";
            agg.getCounter(aggNameError, aggWindow)
                    .setTableName(aggNameError)
                    .setDimensions(ImmutableMap.of("kingAppId",e.getFlavour().getKingApp().id))
                    .increment();
        }
    }

    private void aggByAbTestCase(Aggregators agg, State state, Utils utils, Event e, String aggregatorName)
            throws ProcessorException {
        aggByAbTestCase(agg, state, utils, e, aggregatorName, 1L);
    }
}
