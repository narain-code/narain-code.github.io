package groovy

import com.king.rbea.testutils.SCLong;

@ProcessEvent
def processEvent(Event event,Context context) {
	Context ctx = context
	Output out = ctx.getOutput()
	
	Aggregators agg = ctx.getAggregators()
	Counter c = agg.getCounter("a", AggregationWindow.MINUTES_1)	
	SumAggregator s = agg.getSumAggregator("b", MINUTES_30)
	
	
	Utils utils =ctx.getUtils()
	CurrencyManager cm = utils.getCurrencyManager()
	State sd = ctx.getState()
	
	Timers timers = ctx.getTimers()
}

// Method called once before the processing starts
@Initialize
def initialize(registry) {
	Registry reg = registry
	reg.registerState(LocalState.create("TOTAL_SUM2", Integer.class).initializedTo(0));
	reg.registerState(LocalState.createSet("SET", Integer.class));
	reg.registerState(LocalState.createMap("MAP", Integer.class, Object.class));
	
}

