package groovy

import com.king.rbea.testutils.SCLong;

@ProcessEvent(semanticClass=SCLong.class)
def processEvent(SCLong l, Output out, State state) {
		int total2 = state.get("TOTAL_SUM2") + l.get()
		state.update("TOTAL_SUM2", total2)
		out.writeToKafka("SUM2", total2)
}

// Method called once before the processing starts
def initialize(registry) {
	registry.registerState(LocalState.create("TOTAL_SUM2", Integer.class).initializedTo(0));
}

