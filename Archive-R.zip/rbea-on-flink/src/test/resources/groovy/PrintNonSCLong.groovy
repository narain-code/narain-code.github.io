package groovy

import com.king.rbea.testutils.SCLong;

@ProcessEvent
def processEvent(Event event,Context context) {
	print(event)
	if(SCLong.process(event) == null){
		context.getOutput().writeToKafka("PRINT_1000",event.getString(0))
	}
}
