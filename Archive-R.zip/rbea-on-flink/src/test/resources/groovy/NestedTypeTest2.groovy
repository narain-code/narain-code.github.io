package groovy

@ProcessEvent
def processEvent(State s, Output out) {
	NestedClass nc = s.get("NC")
	nc = nc ? nc : new NestedClass()
	nc.count = nc.count + 2
	s.update("NC", nc)
	out.writeToKafka("PRINT_1000", nc.count)
}

@Initialize
def initialize(reg) {
	reg.registerState(LocalState.create("NC", NestedClass.class));
}



class NestedClass {
	public int count = 0;
}