package com.king.rbea.backend;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.king.rbea.backend.utils.RBEAStreamUtils;

public class BackendUtilsTest {

	@Test
	public void testOpName() {
		assertEquals("event-cr-log", RBEAStreamUtils.removeDots("event.cr.log"));
	}

}
