package com.king.rbea.backend.processors.ml;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import com.king.event.Event;
import com.king.flink.utils.CustomEvent;
import com.king.kgk.SCGameStart;
import com.king.kgk.SCPurchase;
import com.king.rbea.Output;
import com.king.rbea.Registry;
import com.king.rbea.State;
import com.king.rbea.annotations.Initialize;
import com.king.rbea.annotations.OnConfigUpdate;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.backend.processors.ProcessorTestBase;
import com.king.rbea.backend.processors.RBEATestPipeline;
import com.king.rbea.backend.processors.ml.simulator.GameSession;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.backend.types.bea.KafkaOutput;
import com.king.rbea.configuration.processor.Deployment;
import com.king.rbea.configuration.processor.JobConfig;
import com.king.rbea.configuration.processor.ProcessorInfo;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.state.LocalState;
import com.king.rbea.state.StateDescriptor;
import com.king.rbea.state.globalstate.GeneralGlobalStateScript;
import com.king.rbea.state.globalstate.GlobalState;
import com.king.rbea.state.postprocessors.ConfigurableFunction;
import com.king.rbea.state.postprocessors.NormalizationPostProc;
import com.king.rbea.state.postprocessors.SimpleMappingPostProc;
import com.king.rbea.state.postprocessors.config.MetaNumerical;
import com.king.rbea.state.postprocessors.config.PostProcConfig;

import org.apache.flink.api.java.tuple.Tuple2;
import org.junit.Test;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MlTest extends ProcessorTestBase {

	private static final long serialVersionUID = 1L;
	private ObjectMapper mapper = new ObjectMapper();

	@Override
	public List<Deployment> getBaseProcessors() {
		return Lists.newArrayList(GeneralGlobalStateScript.DEPLOYMENT);
	}

	@Test
	public void test() throws Exception {

		// config stuff
		Map<String, PostProcConfig> configMap = new HashMap<>();
		configMap.put("COUNTRY", new PostProcConfig());

		PostProcConfig purchaseConfig = new PostProcConfig();
		purchaseConfig.setMetaNumerical(new MetaNumerical.Builder().max(200.).build());
		configMap.put("PURCHASE", purchaseConfig);

		String configJson = mapper.writeValueAsString(configMap);
		JobConfig jobConfig = new JobConfig(1000, configJson);

		// pipeline definition
		RBEATestPipeline pipeline = RBEATestPipeline
				.startWithDeployment(1000, new PrintingProcessor())
				.then(jobConfig);

		GameSession gameSession = new GameSession();

		List<Event> events = new ArrayList<>();

		events.addAll(gameSession.startApp());
		events.addAll(gameSession.playGameRound());
		events.addAll(gameSession.makePurchase());
		events.addAll(gameSession.makePurchase());

		for (Event event : events) {
			pipeline.andEvent(100, CustomEvent.fromEvent(event))
					.withTimestamp(event.getTimeStamp())
					.thenWatermark(event.getTimeStamp());
		}

		// output
		Tuple2<List<ProcessorInfo>, List<BEA>> testOutput = executeProcessor(pipeline);
		List<BEA> beaOutput = testOutput.f1;

		beaOutput.forEach(bea -> {
			KafkaOutput k = (KafkaOutput) bea;
			System.out.println(new String(k.bytes));
		});
	}

	public static class PrintingProcessor implements Serializable {

		private static final long serialVersionUID = 1L;

		private static final ObjectMapper mapper = new ObjectMapper();

		private transient StateDescriptor<Double[]> countryMapped;
		private transient StateDescriptor<Double> totalSpendUSDNorm;

		private transient ConfigurableFunction<String, Double[]> countryMapperPostProcessor;
		private transient ConfigurableFunction<Double, Double> purchaseProcessor;

		private transient StateDescriptor<Double> purchases;
		private transient StateDescriptor<Double> purchaseFeature;

		@ProcessEvent
		public void process(com.king.event.Event event, Output out, GlobalState globalState) throws Exception {
			out.print(out.formatEvent(event));
			out.print(globalState.getIsPaidUser());
		}

		@ProcessEvent(semanticClass = SCPurchase.class)
		public void onPurchase(Output out, SCPurchase purchase, GlobalState globalState, State state)
				throws ProcessorException {
			state.update(purchases, purchase.getSpend_local());
			out.print(globalState.getCountry() + " => " + state.get(countryMapped));
			out.print(state.get(purchases) + " => " + state.get(purchaseFeature));
			out.print(globalState.getTotalSpendUsd() + " => " + state.get(totalSpendUSDNorm));
		}

		@ProcessEvent(semanticClass = SCGameStart.class)
		public void onGameStart(Output out, SCGameStart gameStart, GlobalState globalState, State state)
				throws ProcessorException {
			out.print(globalState.getHighestLevel() + " => ");
		}

		@OnConfigUpdate
		public void onConfigUpdate(String configJson, Output out) throws IOException {

			out.print("config | " + configJson);
			Map<String, PostProcConfig> config = mapper.readValue(configJson,
					new TypeReference<Map<String, PostProcConfig>>() {});
			if (config != null) {
				countryMapperPostProcessor.updateConf(config.get("COUNTRY"));
				purchaseProcessor.updateConf(config.get("PURCHASE"));
			}

		}

		@Initialize
		public void init(Registry reg) throws ProcessorException, IOException {

			countryMapperPostProcessor = new SimpleMappingPostProc();
			countryMapped = GlobalState.COUNTRY.postProcess(countryMapperPostProcessor);

			purchaseProcessor = NormalizationPostProc.forDouble();

			purchases = reg.registerState(LocalState.create("purchases", 0.0d));
			purchaseFeature = purchases.postProcess(purchaseProcessor);

			totalSpendUSDNorm = GlobalState.TOTAL_SPEND_USD.postProcess(purchaseProcessor);
		}

	}

}
