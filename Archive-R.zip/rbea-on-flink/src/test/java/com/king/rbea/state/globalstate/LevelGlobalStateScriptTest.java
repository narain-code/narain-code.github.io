package com.king.rbea.state.globalstate;

import static com.king.rbea.state.globalstate.GlobalState.FAILED_ATTEMPTS_HIGHEST_LEVEL;
import static com.king.rbea.state.globalstate.GlobalState.HIGHEST_LEVEL;
import static com.king.rbea.state.globalstate.GlobalState.HIGHEST_SUCCESS_LEVEL;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Rule;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;

import com.king.kgk.SCGameEnd;
import com.king.kgk.SCGameStart;
import com.king.rbea.State;
import com.king.rbea.exceptions.ProcessorException;

public class LevelGlobalStateScriptTest {

    @Rule
    public MockitoRule mocks = MockitoJUnit.rule();

    LevelGlobalStateScript sut = new LevelGlobalStateScript();

    @Mock
    SCGameStart gameStart;

    @Mock
    SCGameEnd gameEnd;

    @Mock
    State state;

    @Test
    public void shouldStoreHighestLevel() throws ProcessorException {
        when(state.get(HIGHEST_LEVEL)).thenReturn(100);

        when(gameStart.getLevel()).thenReturn(123);

        sut.onGameStart(gameStart, state);

        verify(state).update(HIGHEST_LEVEL, 123);
        verify(state).clear(FAILED_ATTEMPTS_HIGHEST_LEVEL);
    }

    @Test
    public void shouldSkipLowerLevel() throws ProcessorException {
        when(state.get(HIGHEST_LEVEL)).thenReturn(100);

        when(gameStart.getLevel()).thenReturn(50);

        sut.onGameStart(gameStart, state);

        verify(state, never()).update(eq(HIGHEST_LEVEL), anyInt());
        verify(state, never()).clear(FAILED_ATTEMPTS_HIGHEST_LEVEL);
    }

    @Test
    public void shouldSkipLiveOpsLevel() throws ProcessorException {
        when(gameStart.getLevel()).thenReturn(12345);

        sut.onGameStart(gameStart, state);

        verify(state, never()).update(eq(HIGHEST_LEVEL), anyInt());
        verify(state, never()).clear(FAILED_ATTEMPTS_HIGHEST_LEVEL);
    }

    @Test
    public void shouldFixIncorrectlyStoredLiveOpsLevel() throws ProcessorException {
        when(state.get(HIGHEST_LEVEL)).thenReturn(12345);

        when(gameStart.getLevel()).thenReturn(100);

        sut.onGameStart(gameStart, state);

        verify(state).update(HIGHEST_LEVEL, 100);
        verify(state).clear(FAILED_ATTEMPTS_HIGHEST_LEVEL);
    }

    @Test
    public void shouldStoreHighestSuccessfulLevel() throws ProcessorException {
        when(state.get(HIGHEST_SUCCESS_LEVEL)).thenReturn(100);

        when(gameEnd.getLevel()).thenReturn(120);
        when(gameEnd.getGameEndReason()).thenReturn(0);

        sut.onGameEnd(gameEnd, state);

        verify(state).update(HIGHEST_SUCCESS_LEVEL, 120);
        verify(state, never()).update(eq(FAILED_ATTEMPTS_HIGHEST_LEVEL), anyInt());
    }

    @Test
    public void shouldSkipSuccessForLowerLevel() throws ProcessorException {
        when(state.get(HIGHEST_SUCCESS_LEVEL)).thenReturn(100);

        when(gameEnd.getLevel()).thenReturn(50);
        when(gameEnd.getGameEndReason()).thenReturn(0);

        sut.onGameEnd(gameEnd, state);

        verify(state, never()).update(eq(HIGHEST_SUCCESS_LEVEL), anyInt());
        verify(state, never()).update(eq(FAILED_ATTEMPTS_HIGHEST_LEVEL), anyInt());
    }

    @Test
    public void shouldSkipSuccessForLiveOpsLevel() throws ProcessorException {
        when(gameEnd.getLevel()).thenReturn(12345);
        when(gameEnd.getGameEndReason()).thenReturn(0);

        sut.onGameEnd(gameEnd, state);

        verify(state, never()).update(eq(HIGHEST_SUCCESS_LEVEL), anyInt());
        verify(state, never()).update(eq(FAILED_ATTEMPTS_HIGHEST_LEVEL), anyInt());
    }

    @Test
    public void shouldFixIncorrectlyStoreSuccessLevel() throws ProcessorException {
        when(state.get(HIGHEST_SUCCESS_LEVEL)).thenReturn(12345);

        when(gameEnd.getLevel()).thenReturn(100);
        when(gameEnd.getGameEndReason()).thenReturn(0);

        sut.onGameEnd(gameEnd, state);

        verify(state).update(HIGHEST_SUCCESS_LEVEL, 100);
    }

    @Test
    public void shouldCountFailedAttemptOnHighestLevel() throws ProcessorException {
        when(state.get(HIGHEST_LEVEL)).thenReturn(100);
        when(state.get(FAILED_ATTEMPTS_HIGHEST_LEVEL)).thenReturn(0);

        when(gameEnd.getLevel()).thenReturn(100);
        when(gameEnd.getGameEndReason()).thenReturn(1);

        sut.onGameEnd(gameEnd, state);

        verify(state).update(FAILED_ATTEMPTS_HIGHEST_LEVEL, 1);
    }

    @Test
    public void shouldSkipFailureForLowerLevel() throws ProcessorException {
        when(state.get(HIGHEST_LEVEL)).thenReturn(100);

        when(gameEnd.getLevel()).thenReturn(50);
        when(gameEnd.getGameEndReason()).thenReturn(1);

        sut.onGameEnd(gameEnd, state);

        verify(state, never()).update(eq(FAILED_ATTEMPTS_HIGHEST_LEVEL), anyInt());
    }

}
