package com.king.rbea.backend.processors.ml;

import com.king.event.Event;
import com.king.kgk.SCClientStart;
import com.king.rbea.Output;
import com.king.rbea.State;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.state.globalstate.GlobalState;

import java.time.Clock;

public class GlobalStatesHealthCheck {

    public String getTestString(GlobalState gs) throws ProcessorException {
        String reStr = "FirstActivityMsts=" + gs.getFirstActivityMsts().toString();
        reStr += ",DaysFromFirstActivity=" + gs.getDaysFromFirstActivity().toString();
        reStr += ",AppBuildString=" + gs.getAppBuildString();
        reStr += ",LatestAppUpdateMsts=" + gs.getLatestAppUpdateMsts().toString();
        reStr += ",DeviceOs=" + gs.getDeviceOs();
        reStr += ",DeviceModel=" + gs.getDeviceModel();
        reStr += ",DeviceRam=" + gs.getDeviceRam().toString();
        reStr += ",DisplayFrameRate=" + gs.getDisplayFrameRate().toString();
        reStr += ",DeviceManufacturer=" + gs.getDeviceManufacturer();
        reStr += ",ClientPlatform=" + gs.getClientPlatform();
        reStr += ",CountryChangeHistory30days=" + gs.getcountryChangeHistory30days().toString();
        reStr += ",Country=" + gs.getCountry();
        reStr += ",NumActiveCountries30Days=" + gs.getNumActiveCountries30Days().toString();
        reStr += ",MostActiveCountry30days=" + gs.getMostActiveCountry30days();
        reStr += ",DeviceLocale=" + gs.getDeviceLocale();
        reStr += ",DeviceLanguage=" + gs.getDeviceLanguage();
        reStr += ",NumSignin=" + gs.getNumSignin().toString();
        reStr += ",FirstInstallMsts=" + gs.getFirstInstallMsts().toString();
        reStr += ",HasPlayedOnIos=" + gs.getHasPlayedOnIos().toString();
        reStr += ",HasPlayedOnAndroid=" + gs.getHasPlayedOnAndroid().toString();
        reStr += ",DeviceTimezone=" + gs.getDeviceTimezone();
        reStr += ",IsStrongAccount=" + gs.getIsStrongAccount().toString();
        reStr += ",HighestLevel=" + gs.getHighestLevel().toString();
        reStr += ",FailedAttemptsHighestLevel=" + gs.getFailedAttemptsHighestLevel().toString();
        reStr += ",HighestSuccessLevel=" + gs.getHighestSuccessLevel().toString();
        reStr += ",TotalSpendUsd=" + gs.getTotalSpendUsd().toString();
        reStr += ",IsPaidUser=" + gs.getIsPaidUser().toString();
        reStr += ",LastStoreOpenMsts=" + gs.getLastStoreOpenMsts().toString();
        reStr += ",FirstSpendMsts=" + gs.getFirstSpendMsts().toString();
        reStr += ",SpendUsdHistory30days=" + gs.getSpendUsdHistory30days().toString();
        reStr += ",LastSpendMsts=" + gs.getLastSpendMsts().toString();
        reStr += ",DaysSinceLastPayment=" + gs.getDaysSinceLastPayment().toString();
        reStr += ",SpendUsdLast30days=" + gs.getSpendUsdLast30days().toString();
        reStr += ",SpendUsdLast7days=" + gs.getSpendUsdLast7days().toString();
        reStr += ",SpendUsdLast24hrs=" + gs.getSpendUsdLast24hrs().toString();
        reStr += ",NumPaymentLast7days=" + gs.getNumPaymentLast7days().toString();
        reStr += ",NumPaymentLast30days=" + gs.getNumPaymentLast30days().toString();

        return reStr;
    }

    @ProcessEvent(semanticClass = SCClientStart.class)
    public void onClientStart(SCClientStart clientStart, Event event, State state, GlobalState gs, Output out)
            throws ProcessorException {
        if (gs.getTotalSpendUsd() > 0) {
            //if (!gs.getDeviceModel().equals("")) {
            out.print(clientStart.getCoreuserid().toString() + "|"
                    + String.valueOf(Clock.systemDefaultZone().millis())
                    + ":" + getTestString(gs));
        }
    }
}