package com.king.rbea.backend;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.apache.flink.api.java.tuple.Tuple2;
import org.junit.Ignore;
import org.junit.Test;

import com.fasterxml.jackson.core.type.TypeReference;
import com.king.rbea.backend.utils.JsonCache;

public class JsonCacheTest {

	private static final JsonCache<List<JuegoLevelMeta>, Map<Tuple2<Integer, Integer>, Integer>> CACHE = new JsonCache<>(
			"http://referenciador.int.midasplayer.com/king_constants/latest/JuegoLevelMetadata.json",
			"default_juego_meta.json",
			new TypeReference<List<JuegoLevelMeta>>() {},
			6, TimeUnit.HOURS,
			list -> new ConcurrentHashMap(
					list.stream().collect(Collectors.toMap(m -> Tuple2.of(m.kingAppId, m.level), m -> m.ordinal))));

	@Test
	@Ignore
	public void test() {
		Map<Tuple2<Integer, Integer>, Integer> ordinalMapping = CACHE.getValue();

		System.out.println(ordinalMapping.get(Tuple2.of(25, 11)));

	}

	public static final class JuegoLevelMeta {
		public int kingAppId;
		public int level;
		public int ordinal;
		public String description;
		public String releaseDate;

		@Override
		public String toString() {
			return "JuegoLevelMeta [kingAppId=" + kingAppId + ", level=" + level + ", ordinal=" + ordinal
					+ ", description=" + description + ", releaseDate=" + releaseDate + "]";
		}

	}

}
