package com.king.rbea.backend.processors;

import static org.junit.Assert.assertTrue;

import java.io.Serializable;
import java.util.List;

import org.apache.flink.api.java.tuple.Tuple2;
import org.junit.Test;

import com.google.common.collect.Lists;
import com.king.rbea.Context;
import com.king.rbea.Output;
import com.king.rbea.Registry;
import com.king.rbea.State;
import com.king.rbea.annotations.Initialize;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.backend.types.bea.KafkaOutput;
import com.king.rbea.configuration.processor.Deployment;
import com.king.rbea.configuration.processor.ProcessorInfo;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.state.LocalState;
import com.king.rbea.state.StateDescriptor;
import com.king.rbea.testutils.SCLong;

public class SimpleProcessorTest extends ProcessorTestBase {
	private static final long serialVersionUID = 1L;

	@Test
	public void test() throws Exception {
		RBEATestPipeline pipeline = RBEATestPipeline
				// "Print" everything for PRINT_TOPIC
				.startWithDeployment(1000, new PrintingProcessor())
				// This should be printed
				.thenEvent(2, "good")
				.thenEventNoCUID("bad")
				.thenDeploy(2000, new LongSumProcessor())
				.thenEventNoCUID("100")
				.thenEvent(3, "900")

				// Validate job + state restore
				.thenFailAndRestoreJob()

				// Update 1000 so it doesn't do anything anymore
				.thenUpdate(1000, new DummyProcessor())
				.thenUpdate(2000, new LongSumProcessor())

				.thenDeploySomethingOnOtherTopic()

				.thenEvent(3, "100")
				.thenRemoveProcessor(2000)
				.thenEvent(3, "500")
				.thenEvent(3, "bad");

		Tuple2<List<ProcessorInfo>, List<BEA>> testOutput = executeProcessor(pipeline);
		List<ProcessorInfo> infoOutput = testOutput.f0;
		// We will have here the RuntimeStatistics
		List<BEA> beaOutput = testOutput.f1;

		assertTrue(infoOutput.toString(), withoutRuntimeStatistics(infoOutput).isEmpty());
		validateExact(Lists.newArrayList(
				new KafkaOutput(1000, "PRINT_1000", null, "good".getBytes()),
				new KafkaOutput(2000L, "SUM", null, "900".getBytes()),
				new KafkaOutput(2000L, "SUM", null, "1000".getBytes())), beaOutput);
	}

	public List<Deployment> getBaseProcessors() {
		return Lists.newArrayList(Deployment.newJavaProcessor("TestProc", Long.MAX_VALUE - 100, new Serializable() {

			private static final long serialVersionUID = 1L;
			private StateDescriptor<Long> sum;
			private StateDescriptor<Integer> count;

			@ProcessEvent
			public void processAll(State s) throws ProcessorException {
				s.update(count, s.get(count) + 1);
			}

			@ProcessEvent(semanticClass = SCLong.class)
			public void processLong(SCLong l, State s) throws ProcessorException {
				s.update(sum, s.get(sum) + l.get());
			}

			@Initialize
			public void init(Registry reg) throws ProcessorException {
				sum = reg.registerState(LocalState.createLong("TOTAL_SUM").initializedTo(-9999L));
				count = reg.registerState(LocalState.createInt("COUNT").initializedTo(0));
			}

		}, "", 0));
	}

	public static class PrintingProcessor implements Serializable {
		private static final long serialVersionUID = 1L;

		@ProcessEvent
		public void process(com.king.event.Event event, Output out) throws Exception {
			if (SCLong.process(event) == null) {
				out.writeToKafka("PRINT_1000", event.getString(0));
			}
		}
	}

	public static class LongSumProcessor implements Serializable {
		private static final long serialVersionUID = 1L;
		private StateDescriptor<Long> sum;

		@ProcessEvent(semanticClass = SCLong.class)
		public void processEvent(com.king.event.Event event, SCLong l, State s, Context ctx) throws Exception {
			s.update(sum, s.get(sum) + l.get());
			long total = ctx.getState().get(sum);
			ctx.getOutput().writeToKafka("SUM", total);
		}

		@Initialize
		public void init(Registry reg) throws Exception {
			sum = reg.registerState(LocalState.createLong("TOTAL_SUM").initializedTo(0l));
		}
	}

	public static class DummyProcessor implements Serializable {
		private static final long serialVersionUID = 1L;

		@ProcessEvent
		public void processEvent() {}
	}
}
