package com.king.rbea.backend.operators.scriptexecution;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.flink.api.common.ExecutionConfig;
import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.typeinfo.BasicTypeInfo;
import org.apache.flink.api.common.typeinfo.PrimitiveArrayTypeInfo;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeutils.TypeSerializer;
import org.apache.flink.api.common.typeutils.base.StringSerializer;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.util.InstantiationUtil;
import org.junit.Test;
import org.mockito.Mockito;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.king.flink.utils.types.HashMapTypeInfo;
import com.king.rbea.backend.operators.scriptexecution.metrics.RBEAMetricsTracker;
import com.king.rbea.backend.types.SerializedOrCached;
import com.king.rbea.backend.types.SerializedOrCachedTypeInfo;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.state.LocalState;

@SuppressWarnings("unchecked")
public class StatesTest {

	@Test
	public void test() throws Exception {

		HashMap<Short, SerializedOrCached> baseBytes = new HashMap<>();
		ValueState<HashMap<Short, SerializedOrCached>> baseFieldStates = Mockito.mock(ValueState.class);
		Mockito.when(baseFieldStates.value()).thenReturn(baseBytes);

		HashMap<Short, byte[]> userBytes = new HashMap<>();
		ValueState<HashMap<Short, byte[]>> userFieldStates = Mockito.mock(ValueState.class);
		Mockito.when(userFieldStates.value()).thenReturn(userBytes);

		LocalState<?> valueState = LocalState.create("Value", 1);
		LocalState<?> mapState = LocalState.createMap("Map", String.class, String.class);
		LocalState<?> setState = LocalState.createSet("Set", String.class);

		Fields fields = new Fields();
		fields.initializeClean();
		fields.registerFieldInfo(1, ImmutableMap.of(
				"Value1", Tuple2.of((short) 0, valueState.getSerializer()),
				"Map1", Tuple2.of((short) 1, null),
				"Set1", Tuple2.of((short) 2, setState.getSerializer())));

		States states = new States(fields, 100, baseFieldStates, userFieldStates,
				Mockito.mock(RBEAMetricsTracker.class));

		FlinkRegistry reg = new FlinkRegistry(fields, 1, false);
		FlinkState fs = new FlinkState(states, fields);
		fs.setProcessor(1, null);

		reg.registerState(valueState);
		reg.registerState(mapState);
		reg.registerState(setState);

		reg.finalizeRegistration();

		assertEquals(1, (int) fs.get("Value"));
		assertTrue(baseBytes.isEmpty());
		assertTrue(userBytes.isEmpty());

		fs.update("Value", 10);
		assertEquals(1, userBytes.size());
		assertTrue(userBytes.containsKey((short) 0));

		fs.clear("Value");
		assertTrue(userBytes.isEmpty());

		Map<String, String> map = fs.get("Map");
		Set<String> set = fs.get("Set");

		assertTrue(map.isEmpty());
		assertTrue(set.isEmpty());
		assertTrue(userBytes.isEmpty());

		map.put("a", "b");
		map.put("b", "c");
		assertEquals(1, userBytes.size());
		assertTrue(userBytes.containsKey((short) 1));
		assertEquals(map, states.getFieldValue((short) 1, false, false));
		map.remove("a");
		map.remove("b");
		assertTrue(map.isEmpty());
		assertTrue(userBytes.isEmpty());
		assertEquals(map, states.getFieldValue((short) 1, false, false));

		map.put("a", "b");
		fs.update("Map", map);
		assertEquals(1, userBytes.size());
		assertTrue(userBytes.containsKey((short) 1));
		assertEquals(map, states.getFieldValue((short) 1, false, false));

		map.clear();
		assertTrue(map.isEmpty());
		assertTrue(userBytes.isEmpty());
		assertEquals(map, states.getFieldValue((short) 1, false, false));

		set.add("a");
		fs.update("Set", set);

		assertEquals(1, userBytes.size());
		assertEquals(set, states.getFieldValue((short) 2, false, false));

		set.clear();
		assertTrue(set.isEmpty());
		assertTrue(userBytes.isEmpty());
		assertEquals(set, states.getFieldValue((short) 2, false, false));

		map.put("", "");
		set.add("a");
		assertEquals(2, userBytes.size());
		fs.clearAll();
		assertTrue(userBytes.isEmpty());
	}

	@Test
	public void testList() throws Exception {

		HashMap<Short, SerializedOrCached> baseBytes = new HashMap<>();
		ValueState<HashMap<Short, SerializedOrCached>> baseFieldStates = Mockito.mock(ValueState.class);
		Mockito.when(baseFieldStates.value()).thenReturn(baseBytes);

		HashMap<Short, byte[]> userBytes = new HashMap<>();
		ValueState<HashMap<Short, byte[]>> userFieldStates = Mockito.mock(ValueState.class);
		Mockito.when(userFieldStates.value()).thenReturn(userBytes);

		LocalState<?> listState = LocalState.createList("l", new TypeHint<String>() {});

		Fields fields = new Fields();
		fields.initializeClean();
		fields.registerFieldInfo(1, ImmutableMap.of("l1", Tuple2.of((short) 0, listState.getSerializer())));
		States states = new States(fields, 100, baseFieldStates, userFieldStates,
				Mockito.mock(RBEAMetricsTracker.class));

		FlinkRegistry reg = new FlinkRegistry(fields, 1, false);
		FlinkState fs = new FlinkState(states, fields);
		fs.setProcessor(1, null);
		reg.registerState(listState);
		reg.finalizeRegistration();

		List<String> list = fs.get("l");
		assertEquals(new ArrayList<>(), list);
		assertEquals(0, userBytes.size());

		list.add("a");
		assertEquals(1, userBytes.size());
		list = fs.get("l");
		assertEquals(Lists.newArrayList("a"), list);

		list.clear();
		assertTrue(userBytes.isEmpty());

		fs.update("l", list);
	}

	@Test
	public void testDoubleAdd() throws Exception {

		LocalState<?> valueState = LocalState.create("Value", 1);

		Fields fields = new Fields();
		fields.initializeClean();
		fields.registerFieldInfo(1, ImmutableMap.of(
				"Value1", Tuple2.of((short) 0, valueState.getSerializer())));

		FlinkRegistry reg = new FlinkRegistry(fields, 1, false);
		reg.registerState(valueState);
		try {
			reg.registerState(valueState);
			fail();
		} catch (ProcessorException e) {}
	}

	@Test
	public void cachedValueTest() throws IOException {
		String s = "a";
		StringSerializer ss = StringSerializer.INSTANCE;
		SerializedOrCached c1 = new SerializedOrCached(InstantiationUtil.serializeToByteArray(ss, s));
		SerializedOrCached c2 = new SerializedOrCached(ss, s);
		SerializedOrCached c3 = new SerializedOrCached(ss, "b");
		assertEquals(c1, c2);
		assertFalse(c1.equals(c3));
		assertFalse(c2.equals(c3));
	}

	@Test
	public void testUpdate() throws Exception {

		LocalState<?> valueState = LocalState.create("Value", 1);
		LocalState<?> mapState = LocalState.createMap("Map", String.class, String.class);
		LocalState<?> setState = LocalState.createSet("Set", String.class);

		Fields fields = new Fields();
		fields.initializeClean();
		fields.registerFieldInfo(1, ImmutableMap.of(
				"Value1", Tuple2.of((short) 0, valueState.getSerializer()),
				"Map1", Tuple2.of((short) 1, mapState.getSerializer()),
				"Set1", Tuple2.of((short) 2, setState.getSerializer())));

		FlinkRegistry reg = new FlinkRegistry(fields, 1, false);
		reg.registerState(valueState);
		reg.registerState(mapState);
		reg.registerState(setState);

		reg.finalizeRegistration();

		assertFalse(fields.isEmpty());

		assertTrue(fields.has("Value1"));
		assertTrue(fields.has("Map1"));
		assertTrue(fields.has("Set1"));

		assertEquals(3, fields.getUserFields().size());

		fields.registerFieldInfo(1, ImmutableMap.of(
				"Value1", Tuple2.of((short) 500, valueState.getSerializer()),
				"Set1", Tuple2.of((short) 1000, setState.getSerializer())));

		reg = new FlinkRegistry(fields, 1, false);
		reg.registerState(LocalState.create("Value", 1));
		reg.registerState(LocalState.createSet("Set", String.class));
		reg.finalizeRegistration();

		assertEquals(2, fields.getUserFields().size());
		assertEquals(Sets.newHashSet("Value1", "Set1"), new HashSet<>(fields.getAllForProcId(1)));

		assertTrue(fields.has("Value1"));
		assertFalse(fields.has("Map1"));
		assertTrue(fields.has("Set1"));
		assertEquals(0, (int) fields.getIdForName("Value1"));
		assertEquals(2, (int) fields.getIdForName("Set1"));

		fields.registerFieldInfo(1, ImmutableMap.of());
		assertFalse(fields.has("Value1"));
		assertFalse(fields.has("Map1"));
		assertFalse(fields.has("Set1"));

		assertFalse(fields.isEmpty());

		fields.removeFieldsForProcessor(1, true);
		assertTrue(fields.isEmpty());
	}

	@Test
	public void testFailCleanup() throws Exception {

		LocalState<?> valueState = LocalState.create("Value", 1);
		LocalState<?> mapState = LocalState.createMap("Map", String.class, String.class);
		LocalState<?> setState = LocalState.createSet("Set", String.class);

		Fields fields = new Fields();
		fields.initializeClean();
		fields.registerFieldInfo(1, ImmutableMap.of(
				"Value1", Tuple2.of((short) 0, valueState.getSerializer()),
				"Map1", Tuple2.of((short) 1, mapState.getSerializer()),
				"Set1", Tuple2.of((short) 2, setState.getSerializer())));

		fields.removeFieldsForProcessor(1, false);

		assertEquals(0, (short) fields.getIdForName("Value1"));
		assertEquals(1, (short) fields.getIdForName("Map1"));
		assertEquals(2, (short) fields.getIdForName("Set1"));

		// Try overwriting... should not happen
		fields.registerFieldInfo(1, ImmutableMap.of(
				"Value1", Tuple2.of((short) 4, valueState.getSerializer()),
				"Map1", Tuple2.of((short) 5, mapState.getSerializer()),
				"Set1", Tuple2.of((short) 6, setState.getSerializer())));

		assertEquals(0, (short) fields.getIdForName("Value1"));
		assertEquals(1, (short) fields.getIdForName("Map1"));
		assertEquals(2, (short) fields.getIdForName("Set1"));

		fields.removeFieldsForProcessor(1, true);
		assertTrue(fields.isEmpty());
	}

	@Test
	public void testCheckpointRestore() throws Exception {

		HashMap<Short, byte[]> baseBytes = new HashMap<>();
		ValueState<HashMap<Short, byte[]>> baseFieldStates = Mockito.mock(ValueState.class);
		Mockito.when(baseFieldStates.value()).thenReturn(baseBytes);

		HashMap<Short, byte[]> userBytes = new HashMap<>();
		ValueState<HashMap<Short, byte[]>> userFieldStates = Mockito.mock(ValueState.class);
		Mockito.when(userFieldStates.value()).thenReturn(userBytes);

		LocalState<?> valueState = LocalState.create("Value", 1);

		Fields fields = new Fields();
		fields.initializeClean();
		fields.registerFieldInfo(1, ImmutableMap.of(
				"Value1", Tuple2.of((short) 0, valueState.getSerializer())));

		FlinkRegistry reg = new FlinkRegistry(fields, 1, false);
		reg.registerState(valueState);
		reg.finalizeRegistration();

		fields.addUserField(Long.MAX_VALUE - 1, LocalState.create("bf", Integer.class), "bf");
		Short bid = fields.getIdForName("bf");

		Tuple2<Short, Map<Short, String>> snapshotState = fields.snapshotState();
		assertEquals(-2, (int) snapshotState.f0);
		assertEquals(ImmutableMap.of((short) -1, "bf"), snapshotState.f1);

		fields = new Fields();
		fields.initializeFromState(snapshotState.f0, snapshotState.f1);

		assertTrue(fields.has(bid));

		snapshotState = fields.snapshotState();
		assertEquals(-2, (int) snapshotState.f0);
	}

	@Test
	public void compatiblityTest() throws IOException {
		HashMap<Short, byte[]> map = new HashMap<>();
		map.put((short) 1, new byte[] { 1 });

		TypeInformation<HashMap<Short, byte[]>> stateType = new HashMapTypeInfo<>(
				BasicTypeInfo.SHORT_TYPE_INFO,
				PrimitiveArrayTypeInfo.BYTE_PRIMITIVE_ARRAY_TYPE_INFO);

		TypeInformation<HashMap<Short, SerializedOrCached>> stateType2 = new HashMapTypeInfo<>(
				BasicTypeInfo.SHORT_TYPE_INFO,
				new SerializedOrCachedTypeInfo());

		assertTrue(stateType2.canEqual(stateType));
		assertTrue(stateType2.equals(stateType));

		TypeSerializer<HashMap<Short, byte[]>> serializer1 = stateType.createSerializer(new ExecutionConfig());
		TypeSerializer<HashMap<Short, SerializedOrCached>> serializer2 = stateType2
				.createSerializer(new ExecutionConfig());

		assertTrue(serializer2.canEqual(serializer1));
		assertTrue(serializer2.equals(serializer1));

		HashMap<Short, SerializedOrCached> map2 = InstantiationUtil.deserializeFromByteArray(serializer2,
				InstantiationUtil.serializeToByteArray(serializer1, map));
		assertArrayEquals(map.get((short) 1), map2.get((short) 1).getBytes());
	}

	@Test
	public void testStateCleanup() throws Exception {

		HashMap<Short, SerializedOrCached> baseBytes = new HashMap<>();
		ValueState<HashMap<Short, SerializedOrCached>> baseFieldStates = Mockito.mock(ValueState.class);
		Mockito.when(baseFieldStates.value()).thenReturn(baseBytes);

		HashMap<Short, byte[]> userBytes = new HashMap<>();
		ValueState<HashMap<Short, byte[]>> userFieldStates = Mockito.mock(ValueState.class);
		Mockito.when(userFieldStates.value()).thenReturn(userBytes);

		LocalState<?> valueState = LocalState.create("Value", 1);

		Fields fields = new Fields();
		fields.initializeClean();
		fields.registerFieldInfo(1, ImmutableMap.of("Value1", Tuple2.of((short) 0, valueState.getSerializer())));

		States states = new States(fields, 100, baseFieldStates, userFieldStates,
				Mockito.mock(RBEAMetricsTracker.class));
		userBytes.put((short) 0, new byte[] {});

		fields.removeFieldsForProcessor(1, false);
		assertTrue(userBytes.containsKey((short) 0));

		states.cleanupStates();

		assertTrue(userBytes.containsKey((short) 0));

		fields.removeFieldsForProcessor(1, true);
		states.cleanupStates();

		assertFalse(userBytes.containsKey((short) 0));
	}
}
