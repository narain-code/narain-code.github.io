package com.king.rbea.backend;

import static org.junit.Assert.assertEquals;

import java.io.IOException;

import org.apache.flink.util.InstantiationUtil;
import org.junit.Test;

import com.king.event.Event;
import com.king.flink.utils.CustomEvent;
import com.king.flink.utils.types.EventTypeInfo;
import com.king.flink.utils.types.EventTypeSerializer;

public class EventSerializerTest {

	@Test
	public void test() throws IOException {

		Event e = CustomEvent.create(10).withField(1, 2);

		EventTypeSerializer ts = new EventTypeInfo().createSerializer(null);
		Event e2 = InstantiationUtil.deserializeFromByteArray(ts, InstantiationUtil.serializeToByteArray(ts, e));

		assertEquals(e.toString(), CustomEvent.fromEvent(e2).toString());
	}

}
