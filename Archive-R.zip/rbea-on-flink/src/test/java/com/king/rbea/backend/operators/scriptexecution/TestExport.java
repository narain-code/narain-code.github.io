package com.king.rbea.backend.operators.scriptexecution;

import java.io.Serializable;
import com.king.kgk.SCPurchase;
import com.king.kgk.SCGameStart;
import com.king.rbea.Registry;
import com.king.rbea.State;
import com.king.rbea.annotations.Initialize;
import com.king.rbea.annotations.OnSessionEnd;
import com.king.rbea.annotations.Param;
import com.king.rbea.annotations.ParamType;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.annotations.state.ExportColumn;
import com.king.rbea.annotations.state.ExportTable;
import com.king.rbea.annotations.state.ExportType;
import com.king.rbea.configuration.processor.Deployment.JavaCodeDeployment;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.scripts.proxy.JavaCodeExecutor;
import com.king.rbea.state.LocalState;
import com.king.rbea.state.StateDescriptor;

@ExportTable
public class TestExport {
	
	
	public static void main(String[] args){
		
		
		try {
			System.out.println(new JavaCodeExecutor(0, "a", internal).getScriptInstance().getClass());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static String internal =
			//"package test;"+"\n"+
			"import java.io.Serializable;"+"\n"+
			 "import com.king.kgk.SCGameStart;"+"\n"+
			 "import com.king.rbea.Registry;"+"\n"+
			 "import com.king.rbea.State;"+"\n"+
			 "import com.king.rbea.annotations.Initialize;"+"\n"+
			 "import com.king.rbea.annotations.OnSessionEnd;"+"\n"+
			 "import com.king.rbea.annotations.Param;"+"\n"+
			 "import com.king.rbea.annotations.ParamType;"+"\n"+
			 "import com.king.rbea.annotations.ProcessEvent;"+"\n"+
			 "import com.king.rbea.annotations.state.ExportTable;"+"\n"+
			 "import com.king.rbea.annotations.state.ExportColumn;"+"\n"+
			 "import com.king.rbea.annotations.state.ExportType;"+"\n"+
			 "import com.king.rbea.Aggregators;"+"\n"+
			 "import com.king.rbea.configuration.processor.Deployment.JavaCodeDeployment;"+"\n"+
			 "import com.king.rbea.exceptions.ProcessorException;"+"\n"+
			 "import com.king.rbea.scripts.proxy.JavaCodeExecutor;"+"\n"+
			 "import com.king.rbea.state.LocalState;"+"\n"+
			 "import com.king.rbea.state.StateDescriptor;"+"\n"+
			 "@ExportTable(name=\"aa\" , leadingColumns={@ExportColumn(name = \"cuid\", type = ExportType.LONG, nullable = false)} )"+"\n"+
			"public class ExportTestProc implements Serializable {" +"\n" +
			"@ExportColumn(type = ExportType.INT)"+"\n" +
        "public StateDescriptor<Integer> counter;"+"\n" +
        "@ProcessEvent(semanticClass=SCGameStart.class)"+"\n" +
        "public void process(State state,Aggregators agg) throws ProcessorException {"+"\n" +
        "        state.update(counter, state.get(counter) + 1);"+"\n" +
       " }"+"\n" +
       "@OnSessionEnd"+"\n" +
      "  public void export(State state, @Param(ParamType.CUID) long cuid) throws ProcessorException {"+"\n" +
     "           state.export(cuid);"+"\n" +
      "          state.clear(counter);"+"\n" +
       " }"+"\n" +
       "@Initialize"+"\n" +
       " public void init(Registry reg) throws ProcessorException {"+"\n" +
        "        counter = reg.registerState(LocalState.createInt(\"counter\").initializedTo(0));"+"\n" +
        "}"+"\n" +
"}";

}
