package com.king.rbea.backend.operators.scriptexecution;

import static com.king.rbea.annotations.state.ExportType.INT;
import static com.king.rbea.testutils.RBeaOperatorTestUtils.createRBEAHarness;
import static com.king.rbea.testutils.RBeaOperatorTestUtils.input;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Optional;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.apache.avro.Schema;
import org.apache.avro.generic.GenericDatumReader;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.io.DatumReader;
import org.apache.flink.api.common.typeutils.base.IntSerializer;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.apache.flink.streaming.util.KeyedTwoInputStreamOperatorTestHarness;
import org.apache.flink.types.Either;
import org.junit.Test;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import com.king.flink.utils.CustomEvent;
import com.king.rbea.Aggregators;
import com.king.rbea.Registry;
import com.king.rbea.State;
import com.king.rbea.aggregators.AggregationWindow;
import com.king.rbea.annotations.Initialize;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.annotations.state.ExportColumn;
import com.king.rbea.annotations.state.ExportNested;
import com.king.rbea.annotations.state.ExportTable;
import com.king.rbea.annotations.state.ExportType;
import com.king.rbea.backend.types.EventWrapper;
import com.king.rbea.backend.types.bea.Aggregate;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.backend.types.bea.KafkaOutput;
import com.king.rbea.configuration.Configuration;
import com.king.rbea.configuration.processor.Deployment;
import com.king.rbea.configuration.processor.DeploymentWithFields;
import com.king.rbea.configuration.processor.Failure;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.state.LocalState;
import com.king.rbea.state.StateDescriptor;
import com.king.rbea.state.baseprocessors.DefaultBaseProcessorProvider;
import com.king.rbea.state.export.StateExportDeserializer;
import com.king.rbea.testutils.RBeaOperatorTestUtils;

public class StateExportTest {

	@ExportTable("gyf.TS")
	public static class ExportTestProc implements Serializable {
		private static final long serialVersionUID = 1L;

		@ExportColumn(type = ExportType.INT)
		public LocalState<Integer> F1 = LocalState.createInt("s").initializedTo(0);

		@ProcessEvent(eventType = 1336)
		public void process(State s,Aggregators agg) throws ProcessorException {
			s.update(F1, s.get(F1) + 1);
			agg.getCounter("counter_1", AggregationWindow.MINUTES_1).increment();
		}

		@ProcessEvent(eventType = 1337)
		public void export(State s) throws ProcessorException {
			s.export();
		}

		@Initialize
		public void init(Registry reg) throws ProcessorException {
			reg.registerState(F1);
		}

	}

	@ExportTable("TS")
	public static class InvalidExport implements Serializable {
		private static final long serialVersionUID = 1L;

		@ExportColumn(name = "F1", type = ExportType.INT)
		public StateDescriptor<Integer> intState;

		@ProcessEvent(eventType = 1337)
		public void export(State s) throws ProcessorException {
			s.export();
		}
	}

	@Test
	public void basicTest() throws Exception {
		KeyedTwoInputStreamOperatorTestHarness<Long, EventWrapper, Configuration, Either<BEA, Configuration>> harness = createRBEAHarness(
				DefaultBaseProcessorProvider.INSTANCE.getBaseProcessors());

		DeploymentWithFields df = new DeploymentWithFields(
				Deployment.newJavaProcessor("", 9, new ExportTestProc(), "", 1),
				ImmutableMap.of("s9", Tuple2.of((short) 0, IntSerializer.INSTANCE)));

		harness.processElement2(new StreamRecord<Configuration>(df));

		@SuppressWarnings({ "rawtypes", "unchecked" })
		ConcurrentLinkedQueue<StreamRecord<Either<BEA, Configuration>>> output = (ConcurrentLinkedQueue) harness
				.getOutput();

		KafkaOutput schemaOutput = (KafkaOutput) output.poll().getValue().left();
		Tuple2<Long, Schema> t = StateExportDeserializer.deserializeSchema(schemaOutput.bytes);

		assertEquals(9, (long) t.f0);
		assertEquals(t.f1.getFullName(), new String(schemaOutput.key));
		assertEquals("gyf.TS", t.f1.getFullName());

		assertEquals("st", schemaOutput.getTopic());

		Deployment dep = ((DeploymentWithFields) output.poll().getValue().right()).getDeployment();
		assertTrue(dep.containsKey(Deployment.CONFIG_SCHEMAS));
		assertTrue(dep.containsKey(Deployment.STATE_INFO));

		assertTrue(output.isEmpty());

		harness.processElement1(input(CustomEvent.create(1336), 100));
		harness.processElement1(input(CustomEvent.create(1336), 100));

		assertTrue(output.isEmpty());
		harness.processElement1(input(CustomEvent.create(1337), 100));

		KafkaOutput kafkaRecord = (KafkaOutput) output.poll().getValue().left();
		assertEquals("et", kafkaRecord.getTopic());

		StateExportDeserializer deserializer = new StateExportDeserializer() {
			@Override
			public Optional<DatumReader<GenericRecord>> getReader(String schemaName) {
				assertEquals("gyf.TS", schemaName);
				return Optional.of(new GenericDatumReader<>(t.f1));
			}
		};
		GenericRecord record = deserializer
				.deserializeRecord(StateExportDeserializer.extractSchemaName(kafkaRecord.bytes)).get();
		assertEquals(2, record.get("F1"));

		harness.processElement2(
				RBeaOperatorTestUtils.input(Deployment.newJavaProcessor("test", 10000, new InvalidExport(), "", 1)));

		Failure f = (Failure) output.poll().getValue().right();
		assertTrue(f.getCause().contains("Table name must contain schema"));
	}

	@ExportTable(name = "myTopic", leadingColumns = {
			@ExportColumn(name = "cuid", type = ExportType.LONG, nullable = false)
	}, kafka = true)
	public static class ExportTestProc2 implements Serializable {
		private static final long serialVersionUID = 1L;

		@ExportColumn(name = "F1", type = ExportType.INT)
		public StateDescriptor<Integer> intState;

		@ProcessEvent(eventType = 1336)
		public void process(State s) throws ProcessorException {
			s.update(intState, s.get(intState) + 1);
		}

		@ProcessEvent(eventType = 1337)
		public void export(State s) throws ProcessorException {
			try {
				s.export();
				fail();
			} catch (ProcessorException e) {
				assertTrue(e.getMessage().contains("Number of arguments passed to state.export"));
			}
			s.export(10l);
		}

		@Initialize
		public void init(Registry reg) throws ProcessorException {
			intState = reg.registerState(LocalState.createInt("s").initializedTo(0));
		}

	}

	@Test
	public void leadingTest() throws Exception {
		KeyedTwoInputStreamOperatorTestHarness<Long, EventWrapper, Configuration, Either<BEA, Configuration>> harness = createRBEAHarness(
				DefaultBaseProcessorProvider.INSTANCE.getBaseProcessors());

		DeploymentWithFields df = new DeploymentWithFields(
				Deployment.newJavaProcessor("", 9, new ExportTestProc2(), "", 1),
				ImmutableMap.of("s9", Tuple2.of((short) 0, IntSerializer.INSTANCE)));

		harness.processElement2(new StreamRecord<Configuration>(df));

		@SuppressWarnings({ "rawtypes", "unchecked" })
		ConcurrentLinkedQueue<StreamRecord<Either<BEA, Configuration>>> output = (ConcurrentLinkedQueue) harness
				.getOutput();

		KafkaOutput schemaOutput = (KafkaOutput) output.poll().getValue().left();
		Tuple2<Long, Schema> t = StateExportDeserializer.deserializeSchema(schemaOutput.bytes);

		assertEquals(9, (long) t.f0);
		assertEquals(t.f1.getFullName(), new String(schemaOutput.key));
		assertEquals("myTopic", t.f1.getFullName());

		assertEquals("st", schemaOutput.getTopic());

		assertTrue(output.poll().getValue().right() instanceof Configuration);
		assertTrue(output.isEmpty());

		harness.processElement1(input(CustomEvent.create(1336), 100));
		harness.processElement1(input(CustomEvent.create(1336), 100));

		assertTrue(output.isEmpty());
		harness.processElement1(input(CustomEvent.create(1337), 100));

		KafkaOutput kafkaRecord = (KafkaOutput) output.poll().getValue().left();
		assertEquals("myTopic", kafkaRecord.getTopic());

		StateExportDeserializer deserializer = new StateExportDeserializer() {
			@Override
			public Optional<DatumReader<GenericRecord>> getReader(String schemaName) {
				assertEquals("myTopic", schemaName);
				return Optional.of(new GenericDatumReader<>(t.f1));
			}
		};
		GenericRecord record = deserializer
				.deserializeRecord(StateExportDeserializer.extractSchemaName(kafkaRecord.bytes)).get();
		assertEquals(2, record.get("F1"));
		assertEquals(10l, record.get("cuid"));
	}

	@ExportTable(name = "myTopic", leadingColumns = {
			@ExportColumn(name = "arr", type = ExportType.BOOLEAN, nullable = true, array = true)
	}, kafka = true)
	public static class ExportTestProc3 implements Serializable {
		private static final long serialVersionUID = 1L;

		@ProcessEvent(eventType = 1337)
		public void export(State s) throws ProcessorException {
			s.export(Lists.newArrayList(false, true, null));
		}
	}

	@Test
	public void arrayTest() throws Exception {
		KeyedTwoInputStreamOperatorTestHarness<Long, EventWrapper, Configuration, Either<BEA, Configuration>> harness = createRBEAHarness(
				DefaultBaseProcessorProvider.INSTANCE.getBaseProcessors());

		DeploymentWithFields df = new DeploymentWithFields(
				Deployment.newJavaProcessor("", 9, new ExportTestProc3(), "", 1), new HashMap<>());

		harness.processElement2(new StreamRecord<Configuration>(df));

		@SuppressWarnings({ "rawtypes", "unchecked" })
		ConcurrentLinkedQueue<StreamRecord<Either<BEA, Configuration>>> output = (ConcurrentLinkedQueue) harness
				.getOutput();

		KafkaOutput schemaOutput = (KafkaOutput) output.poll().getValue().left();
		Tuple2<Long, Schema> t = StateExportDeserializer.deserializeSchema(schemaOutput.bytes);

		assertEquals(9, (long) t.f0);
		assertEquals(t.f1.getFullName(), new String(schemaOutput.key));
		assertEquals("myTopic", t.f1.getFullName());

		assertEquals("st", schemaOutput.getTopic());

		assertTrue(output.poll().getValue().right() instanceof Configuration);
		assertTrue(output.isEmpty());
		harness.processElement1(input(CustomEvent.create(1337), 100));

		KafkaOutput kafkaRecord = (KafkaOutput) output.poll().getValue().left();
		assertEquals("myTopic", kafkaRecord.getTopic());

		StateExportDeserializer deserializer = new StateExportDeserializer() {
			@Override
			public Optional<DatumReader<GenericRecord>> getReader(String schemaName) {
				assertEquals("myTopic", schemaName);
				return Optional.of(new GenericDatumReader<>(t.f1));
			}
		};
		GenericRecord record = deserializer
				.deserializeRecord(StateExportDeserializer.extractSchemaName(kafkaRecord.bytes)).get();
		assertEquals(Lists.newArrayList(false, true, null), record.get("arr"));
	}
	
	@SuppressWarnings("serial")
	@ExportTable(name = "nested", kafka = true)
	public static class ExportTestProc4 implements Serializable {

		@ExportColumn(type = INT)
		public int f0 = 1;
		@ExportNested(prefix = "a_")
		public A a = new A();

		public static class A implements Serializable {
			@ExportColumn(type = INT)
			public int f1 = 2;
			@ExportNested(prefix = "b_")
			public B b = new B();
		}

		public static class B implements Serializable {
			@ExportColumn(type = INT)
			public int f2 = 3;
		}

		@ProcessEvent(eventType = 1337)
		public void export(State s) throws ProcessorException {
			s.export();
		}
	}

	@Test
	public void nestedTest() throws Exception {
		KeyedTwoInputStreamOperatorTestHarness<Long, EventWrapper, Configuration, Either<BEA, Configuration>> harness = createRBEAHarness(
				DefaultBaseProcessorProvider.INSTANCE.getBaseProcessors());

		DeploymentWithFields df = new DeploymentWithFields(
				Deployment.newJavaProcessor("", 9, new ExportTestProc4(), "", 1), new HashMap<>());

		harness.processElement2(new StreamRecord<Configuration>(df));

		@SuppressWarnings({ "rawtypes", "unchecked" })
		ConcurrentLinkedQueue<StreamRecord<Either<BEA, Configuration>>> output = (ConcurrentLinkedQueue) harness
				.getOutput();

		KafkaOutput schemaOutput = (KafkaOutput) output.poll().getValue().left();
		Tuple2<Long, Schema> t = StateExportDeserializer.deserializeSchema(schemaOutput.bytes);

		assertTrue(output.poll().getValue().right() instanceof Configuration);

		harness.processElement1(input(CustomEvent.create(1337), 100));

		StateExportDeserializer deserializer = schemaName -> Optional.of(new GenericDatumReader<>(t.f1));

		final byte[] message = ((KafkaOutput) output.poll().getValue().left()).bytes;

		final GenericRecord record = deserializer.deserializeRecord(StateExportDeserializer.extractSchemaName(message)).get();
		assertThat(record.get("f0"), is(1));
		assertThat(record.get("a_f1"), is(2));
		assertThat(record.get("a_b_f2"), is(3));
	}
}
