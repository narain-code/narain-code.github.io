package com.king.rbea.backend.operators.scriptexecution;

import static com.king.rbea.testutils.RBeaOperatorTestUtils.createRBEAHarness;
import static com.king.rbea.testutils.RBeaOperatorTestUtils.input;
import static org.junit.Assert.assertTrue;

import java.io.Serializable;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.apache.flink.streaming.util.KeyedTwoInputStreamOperatorTestHarness;
import org.apache.flink.types.Either;
import org.junit.Test;

import com.king.flink.utils.CustomEvent;
import com.king.rbea.Output;
import com.king.rbea.State;
import com.king.rbea.annotations.Async;
import com.king.rbea.annotations.OnError;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.backend.types.EventWrapper;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.backend.types.bea.KafkaOutput;
import com.king.rbea.backend.utils.BlockingExecutor;
import com.king.rbea.configuration.Configuration;
import com.king.rbea.configuration.processor.Deployment;
import com.king.rbea.configuration.processor.Failure;
import com.king.rbea.configuration.processor.Notification;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.state.baseprocessors.DefaultBaseProcessorProvider;
import com.king.rbea.testutils.RBeaOperatorTestUtils;

public class AsyncProcessingTest {

	public static class AsyncTestProc implements Serializable {
		private static final long serialVersionUID = 1L;

		@ProcessEvent(eventType = 1337)
		public void process(State state, Output out) throws ProcessorException {
			asyncOutput(out);
		}

		@ProcessEvent(eventType = 1338)
		public void process2(State state, Output out) throws ProcessorException {
			throwErr();
		}

		@ProcessEvent(eventType = 1339)
		public void process3(State state, Output out) throws ProcessorException {
			circularAsync(out);
		}

		@Async
		@ProcessEvent(eventType = 1340)
		public void process4(Output out) throws ProcessorException {
			out.print("yo");
		}

		@Async
		@ProcessEvent(eventType = 1341)
		public void process5(Output out) throws ProcessorException {
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				return;
			}
		}

		@Async
		public void asyncOutput(Output out) {
			out.print("hi");
		}

		@Async
		public void throwErr() {
			throw new RuntimeException("ERR");
		}

		@Async
		public void circularAsync(Output out) {
			// Expected to fail
			asyncOutput(out);
		}

		@OnError(maxErrorsPerMin = 2)
		public void doNothing() {}
	}

	@Test
	public void basicTest() throws Exception {

		KeyedTwoInputStreamOperatorTestHarness<Long, EventWrapper, Configuration, Either<BEA, Configuration>> harness = createRBEAHarness(DefaultBaseProcessorProvider.INSTANCE.getBaseProcessors());
		RBEAOperator op = RBeaOperatorTestUtils.getRbeaOperator(harness);

		harness.processElement2(
				input(Deployment.newJavaProcessor("", 10000, new AsyncTestProc(), "", 1)));

		@SuppressWarnings({ "rawtypes", "unchecked" })
		ConcurrentLinkedQueue<StreamRecord<Either<BEA, Configuration>>> output = (ConcurrentLinkedQueue) harness
				.getOutput();

		BlockingExecutor.TIMEOUT_SECONDS = 2;

		output.clear();
		harness.processElement1(input(CustomEvent.create(1337), 100));
		op.waitForAsyncTasks();
		assertTrue(output.poll().getValue().left() instanceof KafkaOutput);
		harness.processElement1(input(CustomEvent.create(1340), 100));
		op.waitForAsyncTasks();
		assertTrue(output.poll().getValue().left() instanceof KafkaOutput);
		harness.processElement1(input(CustomEvent.create(1338), 100));
		op.waitForAsyncTasks();
		Thread.sleep(100);
		assertTrue(output.poll().getValue().isRight());
		harness.processElement1(input(CustomEvent.create(1339), 100));
		op.waitForAsyncTasks();
		Thread.sleep(100);
		assertTrue(output.poll().getValue().right() instanceof Notification);
		harness.processElement1(input(CustomEvent.create(1341), 100));
		op.waitForAsyncTasks();
		Thread.sleep(100);
		assertTrue(output.poll().getValue().right() instanceof Failure);
	}

}
