package com.king.rbea.backend.operators.scriptexecution;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.Serializable;
import java.util.Collections;

import org.apache.flink.api.common.typeutils.base.BooleanSerializer;
import org.apache.flink.api.java.tuple.Tuple2;
import org.junit.Test;
import org.mockito.Mockito;

import com.google.common.base.Ticker;
import com.google.common.collect.ImmutableMap;
import com.king.rbea.EventProcessor;
import com.king.rbea.Registry;
import com.king.rbea.annotations.Initialize;
import com.king.rbea.annotations.OnConfigUpdate;
import com.king.rbea.configuration.processor.Deployment;
import com.king.rbea.configuration.processor.Deployment.JavaProcessorDeployment;
import com.king.rbea.configuration.processor.DeploymentWithFields;
import com.king.rbea.configuration.processor.JobConfig;
import com.king.rbea.configuration.processor.Removal;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.scripts.ProcessorFactory;
import com.king.rbea.scripts.proxy.ProxyExecutorFactory;
import com.king.rbea.state.LocalState;

/**
 * Tests for {@link DeploymentManager}.
 */
public class DeploymentManagerTest {
	/**
	 * Deploys, removes keeping the state and removes removing the state.
	 */
	@Test
	public void deployRemoveTest() throws Exception {
		DeploymentWithFields df = createDeployment(1, 0);
		DeploymentManager deploymentManager = createManager();

		deploymentManager.applyProcessorInfo(df);
		assertNotNull(deploymentManager.deployedProcs.get(1L));

		deploymentManager.applyProcessorInfo(new Removal(1, 1L).keepStateAfterRemoval());
		assertTrue(deploymentManager.fields.has((short) 0));
		deploymentManager.applyProcessorInfo(new Removal(1, 1L));
		assertFalse(deploymentManager.fields.has((short) 0));
	}

	@Test
	public void deployRemoveWithTwoManagersTest() throws Exception {
		DeploymentWithFields df = createDeployment(1, 0);
		DeploymentWithFields df2 = createDeployment(2, 1);

		DeploymentManager deploymentManager = createManager();
		DeploymentManager deploymentManager2 = createManager();

		// Deploy to both DMs and assert they're in the same state
		deploymentManager.applyProcessorInfo(df);
		deploymentManager2.applyProcessorInfo(df);
		assertEquals(deploymentManager, deploymentManager2);

		deploymentManager2.applyProcessorInfo(df2);
		assertNotEquals(deploymentManager, deploymentManager2);

		deploymentManager2.applyProcessorInfo(new Removal(2, 1L).keepStateAfterRemoval());
		assertNotEquals(deploymentManager, deploymentManager2);
		deploymentManager2.applyProcessorInfo(new Removal(2, 1L));
		assertEquals(deploymentManager, deploymentManager2);
		assertTrue(deploymentManager.fields.has((short) 0));
	}

	@Test
	public void testConfigUpdates() throws Exception {
		DeploymentWithFields dep = createDeployment(1, 0);
		dep.getDeployment().withInitialConfig("Hi");
		TestProc testProc = getProc(dep);

		DeploymentManager deploymentManager = createManager();
		deploymentManager.applyProcessorInfo(dep);

		EventProcessor proc = deploymentManager.processors.getForId(1).f1;
		assertEquals(1, testProc.initTimes);

		Mockito.verify(proc, Mockito.times(1)).onConfigUpdate(Mockito.eq("Hi"), Mockito.any());
		assertEquals("Hi", deploymentManager.getDeployedProc(1).getDeployment().getJobConfig().get());
		deploymentManager.applyProcessorInfo(new JobConfig(1, "Bye"));
		Mockito.verify(proc, Mockito.times(1)).onConfigUpdate(Mockito.eq("Bye"), Mockito.any());
		Mockito.verify(proc, Mockito.times(2)).onConfigUpdate(Mockito.any(), Mockito.any());
		assertEquals("Bye", deploymentManager.getDeployedProc(1).getDeployment().getJobConfig().get());

		DeploymentWithFields update = createDeployment(1, 100);
		TestProc updatedTestProc = getProc(update);

		// This should be ignored because not marked as update
		deploymentManager.applyProcessorInfo(update);
		assertEquals(1, testProc.initTimes);
		assertEquals(0, updatedTestProc.initTimes);
		assertEquals(deploymentManager.processors.getForId(1).f1, proc);

		update.getDeployment().asUpdate();
		deploymentManager.applyProcessorInfo(update);
		assertEquals(1, updatedTestProc.initTimes);
		EventProcessor updatedProc = deploymentManager.processors.getForId(1).f1;
		assertNotEquals(updatedProc, proc);

		// Make sure updated proc is initialized with correct conf
		Mockito.verify(updatedProc, Mockito.times(0)).onConfigUpdate(Mockito.eq("Hi"), Mockito.any());
		Mockito.verify(updatedProc, Mockito.times(1)).onConfigUpdate(Mockito.eq("Bye"), Mockito.any());

		DeploymentWithFields update2 = createDeployment(1, 300);
		update2.getDeployment().asUpdate();
		update2.getDeployment().withInitialConfig("Hello");
		deploymentManager.applyProcessorInfo(update2);
		EventProcessor updatedProc2 = deploymentManager.processors.getForId(1).f1;
		assertNotEquals(updatedProc2, updatedProc);

		// Make sure updated proc is initialized with correct conf
		Mockito.verify(updatedProc2, Mockito.times(1)).onConfigUpdate(Mockito.any(), Mockito.any());
		Mockito.verify(updatedProc2, Mockito.times(1)).onConfigUpdate(Mockito.eq("Hello"), Mockito.any());

		assertEquals("Hello", deploymentManager.getDeployedProc(1).getDeployment().getJobConfig().get());
	}

	public TestProc getProc(DeploymentWithFields dep) {
		return (TestProc) dep.getDeployment().getRawValue(Deployment.PROCESSOR_OBJECT_KEY).get();
	}

	private DeploymentWithFields createDeployment(long procId, int stateId) throws Exception {
		TestProc testProc = new TestProc();
		JavaProcessorDeployment dep = Deployment.newJavaProcessor("Test", procId, testProc, "test", 0l, false);
		return new DeploymentWithFields(spyDep(dep),
				ImmutableMap.of("state" + procId, Tuple2.of((short) stateId, BooleanSerializer.INSTANCE)));
	}

	/**
	 * Instantiates a {@link DeploymentManager} for test purposes.
	 * 
	 * @return the instance
	 */
	private DeploymentManager createManager() throws Exception {
		Processors processors = new Processors();
		Fields fields = new Fields();
		fields.initializeClean();
		ProcessorFactory executorFactory = ProxyExecutorFactory.builder().build();
		return new DeploymentManager(processors, fields, 0,
				runner -> {
					runner.execute(Mockito.mock(ContextManager.class));
					return Collections.emptyList();
				}, Ticker.systemTicker(), null, executorFactory);
	}

	private static Deployment spyDep(Deployment dep) {
		return new Deployment(dep) {
			private static final long serialVersionUID = 1L;

			@Override
			public EventProcessor getProcessor(ProcessorFactory executorFactory) throws ProcessorException {
				return Mockito.spy(dep.getProcessor(executorFactory));
			}

		};
	}

	private static class TestProc implements Serializable {
		private static final long serialVersionUID = 1L;

		public int initTimes = 0;

		@Initialize
		public void init(Registry reg) throws ProcessorException {
			// We need to count invocation times (can't mock this :S)
			initTimes++;
			reg.registerState(LocalState.createBoolean("state"));
		}

		@OnConfigUpdate
		public void onConf(String c) {};
	}
}
