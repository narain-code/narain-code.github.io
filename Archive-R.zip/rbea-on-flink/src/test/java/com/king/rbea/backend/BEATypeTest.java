package com.king.rbea.backend;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.Random;

import org.apache.flink.api.common.typeutils.TypeSerializer;
import org.apache.flink.api.java.typeutils.runtime.PojoSerializer;
import org.apache.flink.util.InstantiationUtil;
import org.junit.Test;

import com.king.rbea.backend.types.bea.Aggregate;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.backend.types.bea.BEASerializer;
import com.king.rbea.backend.types.bea.KafkaOutput;
import com.king.rbea.backend.types.bea.RatioAggregate;
import com.king.rbea.backend.types.bea.SumAggregate;
import com.king.rbea.exceptions.ProcessorException;

public class BEATypeTest {

	static Random rnd = new Random();

	@Test
	public void testSerializerPojo() {
		assertTrue(KafkaOutput.serializer instanceof PojoSerializer);
		assertTrue(SumAggregate.serializer instanceof PojoSerializer);
		assertTrue(RatioAggregate.serializer instanceof PojoSerializer);
	}

	@Test
	public void test() throws IOException, ProcessorException {

		TypeSerializer<BEA> s = new BEASerializer<>();

		int n = 100;

		for (int i = 0; i < n; i++) {
			BEA testEvent = createRandomEvent();
			BEA serdeser = InstantiationUtil.deserializeFromByteArray(s,
					InstantiationUtil.serializeToByteArray(s, testEvent));
			BEA copy = s.copy(testEvent);

			assertEquals(testEvent, serdeser);
			assertEquals(testEvent, copy);
		}

	}

	private static BEA createRandomEvent() throws ProcessorException {
		double p = rnd.nextDouble();
		if (p < 0.25) {
			Aggregate agg = new SumAggregate(0L, 100L, "agg", "{}", 5L);
			if (p < 0.12) {
				agg.setTimestamp(10000);
			}
			return agg;
		} else if (p < 0.5) {
			return new KafkaOutput(0L, "myT", "asd".getBytes(), "sad".getBytes());
		} else if (p < 0.75) {
			return new KafkaOutput(0L, "myT", null, "asd".getBytes());
		} else {
			return new RatioAggregate(0L, 100L, "agg", "{}", 5L, 0);
		}
	}

}
