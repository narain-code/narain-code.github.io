package com.king.rbea.matchers;

import static org.hamcrest.CoreMatchers.is;

import org.hamcrest.CustomTypeSafeMatcher;
import org.hamcrest.Matcher;

import com.king.event.Event;

public final class EventMatchers {

	private EventMatchers() {
		throw new AssertionError("No com.king.rbea.matchers.EventMatchers instances for you!");
	}

	public static Matcher<Event> hasFlavour(int flavourId) {
		return hasFlavour(is(flavourId));
	}

	public static Matcher<Event> hasFlavour(Matcher<Integer> matcher) {
		return new CustomTypeSafeMatcher<Event>("has flavour") {
			@Override
			protected boolean matchesSafely(Event event) {
				return matcher.matches(event.getFlavourId());
			}
		};
	}

	public static Matcher<Event> hasType(long eventType) {
		return hasType(is(eventType));
	}

	public static Matcher<Event> hasType(Matcher<Long> matcher) {
		return new CustomTypeSafeMatcher<Event>("has type") {
			@Override
			protected boolean matchesSafely(Event event) {
				return matcher.matches(event.getEventType());
			}
		};
	}

	public static Matcher<Event> hasField(int[][] longField, long value) {
		return hasField(longField, is(value));
	}

	public static Matcher<Event> hasField(int[][] longField, Matcher<Long> matcher) {
		return new CustomTypeSafeMatcher<Event>("has field") {
			@Override
			protected boolean matchesSafely(Event event) {
				return matcher.matches(event.get(longField));
			}
		};
	}

}
