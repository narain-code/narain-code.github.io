package com.king.rbea.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.HashMap;
import java.util.Map;

import org.apache.flink.api.common.functions.ReduceFunction;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.runtime.state.internal.InternalAppendingState;
import org.apache.flink.streaming.api.operators.AbstractStreamOperator;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import com.king.rbea.state.CachingReducingState;

public class CachingReducingStateTest {

	private static Object currentKey = null;

	@Test
	public void test() throws Exception {
		ReduceFunction<Integer> reducer = (x, y) -> x + y;
		AbstractStreamOperator<?> op = Mockito.mock(AbstractStreamOperator.class);
		MockState<Integer> state = new MockState<>(op, reducer);
		CachingReducingState<Integer> cachingState = new CachingReducingState<>(state, op, 2, 0.5, reducer);

		Mockito.when(op.getCurrentKey()).then(i -> CachingReducingStateTest.getKey());
		Mockito.doAnswer(new Answer<Void>() {

			@Override
			public Void answer(InvocationOnMock invocation) throws Throwable {
				currentKey = invocation.getArguments()[0];
				return null;
			}
		}).when(op).setCurrentKey(Mockito.any());

		currentKey = "a";
		cachingState.add(10);
		cachingState.add(5);

		assertEquals(15, (int) cachingState.get());

		cachingState.setCurrentNamespace(-1);
		assertNull(cachingState.get());
		cachingState.add(100);

		cachingState.setCurrentNamespace(null);
		assertEquals(15, (int) cachingState.get());

		cachingState.flush(1);
		cachingState.add(1);
		assertEquals(16, (int) cachingState.get());
		cachingState.add(2);
		assertEquals(18, (int) cachingState.get());

		currentKey = "b";
		cachingState.add(0);

		currentKey = "a";
		assertEquals(18, (int) cachingState.get());

		currentKey = "c";
		cachingState.add(0);
		currentKey = "d";
		cachingState.add(0);

		currentKey = "a";
		assertEquals(18, (int) cachingState.get());
	}

	public static Object getKey() {
		return currentKey;
	}

	private static class MockState<V> implements InternalAppendingState<Object, V, V> {

		private Object currentNamespace;
		private AbstractStreamOperator<?> op;
		private Map<Tuple2<Object, Object>, V> states = new HashMap<>();
		private ReduceFunction<V> reducer;

		public MockState(AbstractStreamOperator<?> op, ReduceFunction<V> reducer) {
			this.op = op;
			this.reducer = reducer;
		}

		@Override
		public byte[] getSerializedValue(byte[] arg0) throws Exception {
			return null;
		}

		@Override
		public void setCurrentNamespace(Object ns) {
			this.currentNamespace = ns;
		}

		private Tuple2<Object, Object> getMapKey() {
			return Tuple2.of(op.getCurrentKey(), currentNamespace);
		}

		@Override
		public void clear() {
			states.remove(getMapKey());
		}

		@Override
		public void add(V val) throws Exception {
			Tuple2<Object, Object> mapKey = getMapKey();
			if (states.containsKey(mapKey)) {
				states.put(getMapKey(), reducer.reduce(states.get(getMapKey()), val));
			} else {
				states.put(getMapKey(), val);
			}
		}

		@Override
		public V get() throws Exception {
			return states.get(getMapKey());
		}

	}

}
