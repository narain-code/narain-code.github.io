package com.king.rbea.testutils;

public final class SCLong {
	private final long i;

	private SCLong(long i) {
		this.i = i;
	}

	public long get() {
		return i;
	}

	public static SCLong process(com.king.event.Event e) {
		try {
			return new SCLong(Long.parseLong(e.getString(0)));
		} catch (Exception ex) {
			return null;
		}
	}
}
