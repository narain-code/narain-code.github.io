package com.king.rbea.backend.processors.ml.simulator;

public class Player {

	public int lives;
	public int episode = 3;
	public int level = 3;
	public long coreUserId = 1234L;
	public int transactionId = 900903;
	public long installID = 1333337;
	public boolean isStrongAccount = false;
	public String email = "lnagligelang@cmail.com";
}
