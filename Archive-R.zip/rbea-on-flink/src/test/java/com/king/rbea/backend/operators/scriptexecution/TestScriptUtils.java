package com.king.rbea.backend.operators.scriptexecution;

import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.scripts.ScriptUtils;

public class TestScriptUtils {
	
	public static void main(String[] args) throws ProcessorException{
		String str =
		"@ProcessEvent"+"\n"+
		"def printType(Event event, Output out,com.king.rbea.globalstate.GlobalState st) {"+"\n"+
		 " out.print(\"Event: \" + event.getEventType())"+"\n"+
		"}";
		ScriptUtils.compile(str);
	}

}
