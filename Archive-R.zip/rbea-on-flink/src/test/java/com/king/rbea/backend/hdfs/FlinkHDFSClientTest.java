package com.king.rbea.backend.hdfs;

import static org.junit.Assert.assertFalse;

import java.io.IOException;

import org.junit.Ignore;
import org.junit.Test;

/**
 * Tests for {@link FlinkHDFSClient}.
 * <p>
 * Ignored right now, can be safely enabled if needed.
 */
@Ignore
public class FlinkHDFSClientTest {
	/**
	 * Tests creating the client works.
	 */
	@Test
	public void testConnectivity() throws Exception {
		createClient();
	}

	/**
	 * Tests a simple HDFS operation succeeds, guarantees
	 * connectivity etc works.
	 * 
	 * @throws Exception
	 */
	@Test
	public void testExists() throws Exception {	
		FlinkHDFSClient flinkHDFSClient = createClient();
		
		assertFalse(flinkHDFSClient.exists("non-existing-file-name"));
	}
	
	private FlinkHDFSClient createClient() throws IOException {
		return new FlinkHDFSClient("/flink/test/FlinkHDFSClientTest");
	}
}
