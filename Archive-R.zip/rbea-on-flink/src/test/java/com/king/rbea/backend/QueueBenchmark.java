package com.king.rbea.backend;

import java.util.PriorityQueue;

import org.apache.flink.runtime.state.KeyGroupRange;
import org.apache.flink.streaming.api.operators.HeapInternalTimerService;
import org.apache.flink.streaming.api.operators.KeyContext;
import org.apache.flink.streaming.runtime.tasks.ProcessingTimeService;
import org.mockito.Mockito;

public class QueueBenchmark {

	public static void main(String[] args) {

		KeyContext ctx = new TestContext();

		new HeapInternalTimerService<>(120,
				Mockito.mock(KeyGroupRange.class), ctx, Mockito.mock(ProcessingTimeService.class));

		int numElements = 5_000_000;
		for (int i = 0; i < 3; i++) {
			extracted(numElements);
		}
	}

	private static void extracted(int numElements) {
		PriorityQueue<Integer> queue = new PriorityQueue<>();
		long time0 = System.nanoTime();
		for (int i = 0; i < numElements; i++) {
			queue.add(i);
		}

		long time1 = System.nanoTime();
		for (int i = 0; i < numElements; i++) {
			queue.remove(i);
			queue.add(numElements + i);
			queue.add(numElements + i);
		}

		long time2 = System.nanoTime();

		System.out.println((time1 - time0) / 1_000_000 + " " + (time2 - time1) / 1_000_000);
	}

	private static final class TestContext implements KeyContext {

		private Object key;

		@Override
		public Object getCurrentKey() {
			return key;
		}

		@Override
		public void setCurrentKey(Object key) {
			this.key = key;
		}

	}

}
