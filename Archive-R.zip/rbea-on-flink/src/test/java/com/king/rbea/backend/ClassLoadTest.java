package com.king.rbea.backend;

import org.junit.Test;

public class ClassLoadTest {

	@Test
	public void groovyLoadTest() throws Exception {
		// EventProcessor proc = ClassUtils.getProcessor(
		// "file:///Users/gyulafora/git/SPLAT/scala-test/target/ScalaProcessor-1.0-SNAPSHOT.jar",
		// "stest.MyProcessor");
		//
		// proc.initialize(null);
	}

}
