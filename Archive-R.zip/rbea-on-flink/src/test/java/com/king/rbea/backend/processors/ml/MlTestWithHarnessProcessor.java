package com.king.rbea.backend.processors.ml;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.king.event.Event;
import com.king.kgk.*;
import com.king.rbea.Context;
import com.king.rbea.Registry;
import com.king.rbea.State;
import com.king.rbea.Utils;
import com.king.rbea.annotations.Initialize;
import com.king.rbea.annotations.OnConfigUpdate;
import com.king.rbea.annotations.OnSessionEnd;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.state.LocalState;
import com.king.rbea.state.StateDescriptor;
import com.king.rbea.state.globalstate.GlobalState;
import com.king.rbea.state.globalstate.GlobalStateUtility;
import com.king.rbea.state.postprocessors.ConfigurableFunction;
import com.king.rbea.state.postprocessors.NormalizationPostProc;
import com.king.rbea.state.postprocessors.SimpleMappingPostProc;
import com.king.rbea.state.postprocessors.config.PostProcConfig;
import com.king.splat.fxrate.MissingRateException;

import java.io.IOException;
import java.io.Serializable;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Map;

public class MlTestWithHarnessProcessor implements Serializable {

    private static final long serialVersionUID = 1L;
    private final static int numSession = 10;
    private final static String[] delims = {"|", ";", ","};

    //Global
    private ConfigurableFunction<String, Double[]> countryMapper = new SimpleMappingPostProc();
    public StateDescriptor<Double[]> countryVec;

    private ConfigurableFunction<String, Double[]> timezoneMapper = new SimpleMappingPostProc();
    public StateDescriptor<Double[]> timezoneVec;

    private ConfigurableFunction<String, Double[]> manufacturerMapper = new SimpleMappingPostProc();
    public StateDescriptor<Double[]> manufacturerVec;

    private ConfigurableFunction<String, Double[]> platformMapper = new SimpleMappingPostProc();
    public StateDescriptor<Double[]> platformVec;

    private ConfigurableFunction<Integer, Double> highestLevelNormer = NormalizationPostProc.forInteger();
    public StateDescriptor<Double> highestLevelNorm;

    private ConfigurableFunction<Double, Double> totalSpendUsdNormer = NormalizationPostProc.forDouble();
    public StateDescriptor<Double> totalSpendUsdNorm;

    //Local
    public ConfigurableFunction<Double, Double> purchaseUsdNormer = NormalizationPostProc.forDouble();
    public StateDescriptor<Double> purchaseUsd;
    public StateDescriptor<Double> purchaseUsdNorm;

    public StateDescriptor<Integer> numPurchase;
    public StateDescriptor<Integer> numItemTxn;
    public StateDescriptor<Integer> numHcTxn;
    public StateDescriptor<Long> hcDeduct;
    public StateDescriptor<Long> hcAccumulated;
    public StateDescriptor<Integer> numClientStart;
    public StateDescriptor<Integer> numGameStart;
    public StateDescriptor<Integer> numSuccessGamePlay;
    public StateDescriptor<Integer> numGameEnd;
    public StateDescriptor<Integer> numSignin;
    public StateDescriptor<Integer> numMsg;
    public StateDescriptor<Integer> numAdsEvent;
    public StateDescriptor<Long> sessionStartMsts;

    // Should not be cleared by the end of each session
    public StateDescriptor<Long> lastSessionEndMsts;

    // State for session history
    public StateDescriptor<ArrayList<CoreUserSession>> coreUserSessionList;

    public static String getDateFeatureStr(long timeMsts) throws Exception{
        Date dt = new Date();
        dt.setTime(timeMsts);
        SimpleDateFormat ft = new SimpleDateFormat ("M,W,E");
        String[] dateArray = ft.format(dt).split(",");
        if(dateArray.length != 3){
            throw new Exception("Failed to get date feature string, code 1.");
        }

        int month = Integer.valueOf(dateArray[0]);
        int week = Integer.valueOf(dateArray[1]);
        int weekday = -1;
        switch (dateArray[2]){
            case "Mon":
                weekday = 1;
                break;
            case "Tue":
                weekday = 2;
                break;
            case "Wed":
                weekday = 3;
                break;
            case "Thu":
                weekday = 4;
                break;
            case "Fri":
                weekday = 5;
                break;
            case "Sat":
                weekday = 6;
                break;
            case "Sun":
                weekday = 7;
        }

        if(month < 1 || month > 12 || week < 1 || week > 5 || weekday < 1 || weekday > 7){
            throw new Exception("Failed to get date feature string, code 2.");
        }

        return String.valueOf((month-1)/11.0) + delims[2] + String.valueOf((week-1)/4.0) + delims[2] + String.valueOf((weekday-1)/6.0);
    }

    public static class CoreUserSession{
        public long lastEndMsts;
        public long startMsts;
        public long endMsts;
        public String featureStr;

        public CoreUserSession(long l, long s, long e, String f){
            this.lastEndMsts = l;
            this.startMsts = s;
            this.endMsts = e;
            this.featureStr = f;
        }
    }

    private void updateSessionStartMsts(State state, Long msts) throws ProcessorException {
        if (state.get(sessionStartMsts) <= 0 && msts > 0) {
            state.update(sessionStartMsts, msts);
        }
    }

    private void clearSessionStates(State state) throws ProcessorException {
        state.clear(purchaseUsd);
        state.clear(numPurchase);
        state.clear(numItemTxn);
        state.clear(numHcTxn);
        state.clear(hcDeduct);
        state.clear(hcAccumulated);
        state.clear(numClientStart);
        state.clear(numGameStart);
        state.clear(numSuccessGamePlay);
        state.clear(numGameEnd);
        state.clear(numSignin);
        state.clear(numMsg);
        state.clear(numAdsEvent);
        state.clear(sessionStartMsts);
    }

    private String tryEncodeSessionData(State state, Context ctx, Long sessionEndMsts) {
        String codedStr = "";
        try {
            Long _lastSessionEndMsts = state.get(lastSessionEndMsts);
            if (state.get(lastSessionEndMsts) > 0) {
                GlobalState gs = new GlobalState(ctx);
                codedStr += Arrays.toString(state.get(countryVec)).replaceAll("\\s+|(\\[)|(\\])", "") + delims[2];
                codedStr += Arrays.toString(state.get(timezoneVec)).replaceAll("\\s+|(\\[)|(\\])", "") + delims[2];
                codedStr += Arrays.toString(state.get(manufacturerVec)).replaceAll("\\s+|(\\[)|(\\])", "") + delims[2];
                codedStr += Arrays.toString(state.get(platformVec)).replaceAll("\\s+|(\\[)|(\\])", "") + delims[2];
                codedStr += String.valueOf(state.get(highestLevelNorm)) + delims[2];
                codedStr += String.valueOf(state.get(totalSpendUsdNorm)) + delims[2];
                codedStr += String.valueOf(state.get(purchaseUsdNorm)) + delims[1];

                codedStr += (gs.getIsPaidUser() ? "1" : "0") + delims[1];
                codedStr += gs.getCountry() + delims[1];
                codedStr += gs.getDeviceModel() + delims[1];
                codedStr += gs.getDeviceLocale() + delims[1];
                codedStr += gs.getDeviceTimezone() + delims[1];
                codedStr += gs.getAppBuildString() + delims[1];
                codedStr += gs.getDeviceOs() + delims[1];
                codedStr += gs.getTotalSpendUsd() + delims[1];
                codedStr += gs.getHighestLevel() + delims[1];
                codedStr += gs.getHighestSuccessLevel() + delims[1];
                codedStr += String.valueOf(Double.valueOf(gs.getDeviceRam()) / GlobalStateUtility.bytesPerGb) + delims[1];
                codedStr += gs.getDisplayFrameRate() + delims[1];
                codedStr += gs.getDeviceManufacturer() + delims[1];
                codedStr += gs.getClientPlatform() + delims[1];

                codedStr += String.valueOf(state.get(numPurchase)) + delims[2];
                codedStr += String.valueOf(state.get(numItemTxn)) + delims[2];
                codedStr += String.valueOf(state.get(numHcTxn)) + delims[2];
                codedStr += String.valueOf(state.get(hcDeduct)) + delims[2];
                codedStr += String.valueOf(state.get(hcAccumulated)) + delims[2];
                codedStr += String.valueOf(state.get(numClientStart)) + delims[2];
                codedStr += String.valueOf(state.get(numGameStart)) + delims[2];
                codedStr += String.valueOf(state.get(numSuccessGamePlay)) + delims[2];
                codedStr += String.valueOf(state.get(numGameEnd)) + delims[2];
                codedStr += String.valueOf(state.get(numSignin)) + delims[2];
                codedStr += String.valueOf(state.get(numMsg)) + delims[2];
                codedStr += String.valueOf(state.get(numAdsEvent)) + delims[2];
                Long _sessionStartMsts = state.get(sessionStartMsts);
                codedStr += String.valueOf(GlobalStateUtility.elapsedHours(_lastSessionEndMsts, _sessionStartMsts)) + delims[2];
                codedStr += String.valueOf(GlobalStateUtility.elapsedHours(_sessionStartMsts, sessionEndMsts)) + delims[2];
                codedStr += String.valueOf(Double.valueOf(_sessionStartMsts % GlobalStateUtility.msPerDay) / GlobalStateUtility.msPerHour) + delims[2];
                codedStr += getDateFeatureStr(sessionEndMsts);
            }
        } catch (Exception e) {}
        return codedStr;
    }

    @OnConfigUpdate
    public void onConfigUpdate(String configJson) throws IOException {
        Map<String, PostProcConfig> config = new ObjectMapper().readValue(configJson,
                new TypeReference<Map<String, PostProcConfig>>() {});
        if (config != null) {
            //Global
            countryMapper.updateConf(config.get("COUNTRY"));
            timezoneMapper.updateConf(config.get("DEVICE_TIMEZONE"));
            manufacturerMapper.updateConf(config.get("DEVICE_MANUFACTURER"));
            totalSpendUsdNormer.updateConf(config.get("TOTAL_SPEND_USD"));
            highestLevelNormer.updateConf(config.get("HIGHEST_LEVEL"));
            platformMapper.updateConf(config.get("CLIENT_PLATFORM"));

            //Local
            purchaseUsdNormer.updateConf(config.get("PURCHASE_USD"));
        }
    }

    @ProcessEvent(semanticClass = SCClientStart.class)
    public void onClientStart(SCClientStart clientStart, State state) throws ProcessorException {
        updateSessionStartMsts(state, clientStart.getMsts());
        state.update(numClientStart, state.get(numClientStart) + 1);
    }

    @ProcessEvent(semanticClass = SCGameStart.class)
    public void onGameStart(SCGameStart gameStart, State state) throws ProcessorException {
        updateSessionStartMsts(state, gameStart.getMsts());
        state.update(numGameStart, state.get(numGameStart) + 1);
    }

    @ProcessEvent(semanticClass = SCGameEnd.class)
    public void onGameEnd(SCGameEnd gameEnd, State state) throws ProcessorException {
        updateSessionStartMsts(state, gameEnd.getMsts());
        state.update(numGameEnd, state.get(numGameEnd) + 1);

        if (gameEnd.getGameEndReason() == 0) {
            state.update(numSuccessGamePlay, state.get(numSuccessGamePlay) + 1);
        }
    }

    @ProcessEvent(semanticClass = SCSignIn.class)
    public void onSignIn(SCSignIn signIn, State state) throws ProcessorException {
        updateSessionStartMsts(state, signIn.getMsts());
        state.update(numSignin, state.get(numSignin) + 1);
    }

    @ProcessEvent(semanticClass = {SCMessageSent.class, SCMessageClicked.class, SCMessageProcessed.class})
    public void onMsg(Event event, State state) throws ProcessorException {
        updateSessionStartMsts(state, event.getTimeStamp());
        state.update(numMsg, state.get(numMsg) + 1);
    }

    @ProcessEvent(semanticClass = SCAdTracking.class)
    public void onAdTracking(SCAdTracking adTracking, State state) throws ProcessorException {
        updateSessionStartMsts(state, adTracking.getMsts());
        state.update(numAdsEvent, state.get(numAdsEvent) + 1);
    }

    @ProcessEvent(semanticClass = SCPurchase.class)
    public void onPurchase(SCPurchase purchase, State state, Utils utils) throws ProcessorException, MissingRateException {
        updateSessionStartMsts(state, purchase.getMsts());
        state.update(numPurchase, state.get(numPurchase) + 1);

        Double _purchaseUsd = state.get(purchaseUsd);
        BigDecimal usdAmount = utils.getCurrencyManager().convertToUsd(purchase.getMsts(), purchase.getCurrency_local(), purchase.getSpend_local());
        _purchaseUsd += usdAmount.doubleValue();
        state.update(purchaseUsd, _purchaseUsd);
    }

    @ProcessEvent(semanticClass = SCItemTransaction.class)
    public void onItemTransaction(SCItemTransaction itemTransaction, State state) throws ProcessorException {
        updateSessionStartMsts(state, itemTransaction.getMsts());
        state.update(numItemTxn, state.get(numItemTxn) + 1);

        if(GlobalStateUtility.isHcItemType(itemTransaction.getItemType())){
            state.update(numHcTxn, state.get(numHcTxn) + 1);
            Long hcAmount = itemTransaction.getAmount();
            if (hcAmount > 0) {
                Long _hcAccumulated = state.get(hcAccumulated);
                state.update(hcAccumulated, _hcAccumulated + hcAmount);
            } else if (hcAmount < 0) {
                Long _hcDeduct = state.get(hcDeduct);
                state.update(hcDeduct, _hcDeduct + hcAmount);
            }
        }
    }

    @OnSessionEnd
    public void onSessionEnd(Event event, State state, Context ctx) throws Exception {
        Long _sessionEndMsts = event.getTimeStamp();
        String codedSessionFeatures = tryEncodeSessionData(state, ctx, _sessionEndMsts);
        if (!codedSessionFeatures.equals("")) {
            ArrayList<CoreUserSession> cusl = state.get("coreUserSessionList");
            cusl.add(new CoreUserSession(state.get(lastSessionEndMsts), state.get(sessionStartMsts), _sessionEndMsts, codedSessionFeatures));
            if (cusl.size() > numSession) {
                String tsSample = "";
                cusl.remove(0);
                for (int i = 0; i < numSession; i++) {
                    tsSample += cusl.get(i).featureStr;
                    if (i < numSession - 1) {
                        tsSample += delims[0];
                    }
                }
                System.out.println("Sample: " + tsSample);
            }
        }
        state.update(lastSessionEndMsts, _sessionEndMsts);
        clearSessionStates(state);
        System.out.println("Session " + String.valueOf(event.getTimeStamp()) + ": All tests passed!");
    }

    @Initialize
    public void init(Registry reg) throws ProcessorException, IOException {
        //Global
        countryVec = GlobalState.COUNTRY.postProcess(countryMapper);
        timezoneVec = GlobalState.DEVICE_TIMEZONE.postProcess(timezoneMapper);
        manufacturerVec = GlobalState.DEVICE_MANUFACTURER.postProcess(manufacturerMapper);
        highestLevelNorm = GlobalState.HIGHEST_LEVEL.postProcess(highestLevelNormer);
        totalSpendUsdNorm = GlobalState.TOTAL_SPEND_USD.postProcess(totalSpendUsdNormer);
        platformVec = GlobalState.CLIENT_PLATFORM.postProcess(platformMapper);

        //Local
        purchaseUsd = reg.registerState(LocalState.create("purchaseUsd", .0d));
        purchaseUsdNorm = purchaseUsd.postProcess(purchaseUsdNormer);

        numPurchase = reg.registerState(LocalState.create("numPurchase", 0));
        numItemTxn = reg.registerState(LocalState.create("numItemTxn", 0));
        numHcTxn = reg.registerState(LocalState.create("numHcTxn", 0));
        hcDeduct = reg.registerState(LocalState.create("hcDeduct", 0l));
        hcAccumulated = reg.registerState(LocalState.create("hcAccumulated", 0l));
        numClientStart = reg.registerState(LocalState.create("numClientStart", 0));
        numGameStart = reg.registerState(LocalState.create("numGameStart", 0));
        numSuccessGamePlay = reg.registerState(LocalState.create("numSuccessGamePlay", 0));
        numGameEnd = reg.registerState(LocalState.create("numGameEnd", 0));
        numSignin = reg.registerState(LocalState.create("numSignin", 0));
        numMsg = reg.registerState(LocalState.create("numMsg", 0));
        numAdsEvent = reg.registerState(LocalState.create("numAdsEvent", 0));

        sessionStartMsts = reg.registerState(LocalState.create("sessionStartMsts", 0l));
        lastSessionEndMsts = reg.registerState(LocalState.create("lastSessionEndMsts", 0l));

        coreUserSessionList = reg.registerState(LocalState.createList("coreUserSessionList", CoreUserSession.class));
    }

}
