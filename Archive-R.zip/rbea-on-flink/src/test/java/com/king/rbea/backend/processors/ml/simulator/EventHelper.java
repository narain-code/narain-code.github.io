package com.king.rbea.backend.processors.ml.simulator;

import com.king.constants.EventParameters;
import com.king.event.Event;
import com.king.event.EventBuilder;


public class EventHelper {
	private final InternalTimeProvider timeProvider;
	private final EventBuilder eventBuilder;

	public EventHelper() {
		timeProvider = new InternalTimeProvider();
		eventBuilder = new EventBuilder(70017, timeProvider);
		// eventBuilder = new EventBuilder(50131, timeProvider);
	}


	public Event buildEvent(EventParameters params, long msts){
		timeProvider.time(msts);
		return eventBuilder.buildEvent(params, 0);
	}


	private static class InternalTimeProvider implements EventBuilder.TimeProvider{
		private long time = 0;

		public void time(long msts) {
			this.time = msts;
		}

		@Override
		public long currentTimeMillis() {
			return time;
		}
	}
}
