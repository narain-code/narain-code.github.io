package com.king.rbea.backend.processors.groovy;

import com.king.rbea.backend.processors.ProcessorTestBase;
import com.king.rbea.backend.processors.RBEATestPipeline;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.configuration.processor.ProcessorInfo;
import org.apache.flink.api.java.tuple.Tuple2;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertEquals;

public class GroovyImportTest extends ProcessorTestBase {
	private static final long serialVersionUID = 1L;

	@Test
	public void test() throws Exception {
		RBEATestPipeline source = RBEATestPipeline
				.startWithGroovyDeployment(1000,
						"src/test/resources/groovy/CallEverything.groovy")
				.thenEvent(2, "good")
				.thenEvent(3, "900")
				.thenEvent(3, "bad");

		Tuple2<List<ProcessorInfo>, List<BEA>> testOutput = executeProcessor(source);
		List<ProcessorInfo> infoOutput = withoutRuntimeStatistics(testOutput.f0);
		
		System.out.println(infoOutput);

		assertEquals(infoOutput.toString(), 0, infoOutput.size());
	}
}
