package com.king.rbea.backend;

import java.util.List;

import com.king.event.Event;
import com.king.kgk.SCClientStart;
import com.king.kgk.SCCommunityDataUpdated;
import com.king.kgk.SCDeviceInfo;
import com.king.kgk.SCGameEnd;
import com.king.kgk.SCGameStart;
import com.king.kgk.SCPurchase;
import com.king.kgk.SCStoreOpen;
import com.king.rbea.backend.batch.BatchEvent;
import com.king.rbea.backend.batch.BatchEventTypeSerializer;
import com.king.rbea.backend.batch.FileSourceTypes;
import com.king.rbea.backend.batch.FileWrapper;
import com.king.rbea.backend.batch.LazyEventParser;

public class BatchEventStreamTest {
	
	public static void main(String[] args){
		List<FileWrapper> all=FileWrapper.getWrapperForType(FileSourceTypes.LOCALFILE).getSplitDirectories("/Users/narain/work/FileReaderFlink");
		BatchEventTypeSerializer serial= new BatchEventTypeSerializer();
		all.stream().forEach(fw->{
			fw.consume(s->{
				Event e =LazyEventParser.parse(s);
				try {
					//serial.doSerialize(((BatchEvent)e).toBytes());
					//serial.doSerialize(((BatchEvent)e).toBytes());
					SCClientStart.process(e); SCDeviceInfo.process(e); SCCommunityDataUpdated.process(e);
					SCGameStart.process(e); SCGameEnd.process(e); SCPurchase.process(e);
					SCStoreOpen.process(e); SCClientStart.process(e);SCPurchase.process(e);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					System.out.println(e.toString());
				}});
		});
	}

}
