package com.king.rbea.backend.processors.ml;

import com.google.common.collect.ImmutableMap;
import com.google.protobuf.ByteString;
import com.google.protobuf.Int64Value;
import com.king.kgk.SCPurchase;
import com.king.rbea.*;
import com.king.rbea.aggregators.AggregationWindow;
import com.king.rbea.annotations.Async;
import com.king.rbea.annotations.Initialize;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.exceptions.ProcessorException;
import org.apache.commons.io.IOUtils;
import org.apache.flink.core.fs.FileSystem;
import org.apache.flink.core.fs.Path;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.tensorflow.example.*;
import org.tensorflow.framework.DataType;
import org.tensorflow.framework.TensorProto;
import org.tensorflow.framework.TensorShapeProto;

import tensorflow.serving.Model.ModelSpec;
import tensorflow.serving.Predict.PredictRequest;
import tensorflow.serving.Predict.PredictResponse;
import tensorflow.serving.PredictionServiceGrpc.PredictionServiceBlockingStub;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;


public class WideAndDeepModelClientTest {

    private JSONObject conf;
    private JSONArray cols;
    private HashMap<String, Feature> inputFeatureMap = new HashMap<>();
    private ByteString inputStr;
    private final static Integer modelVer = 1511790797;

    @Initialize
    public void init(Registry reg) throws ProcessorException, IOException, JSONException {
        Path filePath = new Path("hdfs:///tensorflow/models/" + modelVer.toString() + "/config.json");
        FileSystem fileSystem = filePath.getFileSystem();
        String json = IOUtils.toString(fileSystem.open(filePath), StandardCharsets.UTF_8);
        conf = new JSONObject(json);
        cols = conf.getJSONArray("columns");
        // TensorShapeProto.Dim dim = TensorShapeProto.Dim.newBuilder().setSize(1).build();

        // Iterate across the columns
        for (int i = 0; i < cols.length(); i++) {
            //generate dummy input data for the 1-th column
            JSONObject col = cols.getJSONObject(i);
            String name = col.getString("name");
            String dtype = "";
            if (col.has("dtype")) {
                dtype = col.getString("dtype").toLowerCase();
            }

            /* raw boolean case: string
            if (dtype.equals("")) {
                TensorProto proto = TensorProto.newBuilder()
                        .addStringVal(ByteString.copyFromUtf8("true"))
                        .setTensorShape(TensorShapeProto.newBuilder().addDim(dim).build())
                        .setDtype(DataType.DT_STRING)
                        .build();
                inputTensorMap.put(name, proto);
            } else if (dtype.equals("float")) {
                TensorProto proto = TensorProto.newBuilder()
                        .addFloatVal(1.1415f)
                        .setTensorShape(TensorShapeProto.newBuilder().addDim(dim).build())
                        .setDtype(DataType.DT_FLOAT)
                        .build();
                inputTensorMap.put(name, proto);
            } else if (dtype.equals("int")) {
                TensorProto proto = TensorProto.newBuilder()
                        .addIntVal(1)
                        .setTensorShape(TensorShapeProto.newBuilder().addDim(dim).build())
                        .setDtype(DataType.DT_INT64)
                        .build();
                inputTensorMap.put(name, proto);
            } else if (dtype.equals("string")) {
                TensorProto proto = TensorProto.newBuilder()
                        .addStringVal(ByteString.copyFromUtf8("__unknown__"))
                        .setTensorShape(TensorShapeProto.newBuilder().addDim(dim).build())
                        .setDtype(DataType.DT_STRING)
                        .build();
                inputTensorMap.put(name, proto);
            }*/


            Feature feature = null;
            if (dtype.equals("")) {
                feature = Feature.newBuilder().setBytesList(BytesList.newBuilder().addValue(ByteString.copyFromUtf8("true"))).build();
            } else if (dtype.equals("float")) {
                feature = Feature.newBuilder().setFloatList(FloatList.newBuilder().addValue(1.1415f)).build();
            } else if (dtype.equals("int")) {
                feature = Feature.newBuilder().setInt64List(Int64List.newBuilder().addValue(1l)).build();
            } else if (dtype.equals("string")) {
                feature = Feature.newBuilder().setBytesList(BytesList.newBuilder().addValue(ByteString.copyFromUtf8("__unknown__"))).build();
            }
            if (feature != null) {
                inputFeatureMap.put(name, feature);
            }
            Features features = Features.newBuilder().putAllFeature(inputFeatureMap).build();
            inputStr = Example.newBuilder().setFeatures(features).build().toByteString();
        }
    }

    @Async
    private PredictResponse predict(PredictionServiceBlockingStub stub) {

        TensorProto proto = TensorProto.newBuilder()
                .addStringVal(inputStr)
                .setTensorShape(TensorShapeProto.newBuilder().addDim(TensorShapeProto.Dim.newBuilder().setSize(1).build()).build())
                .setDtype(DataType.DT_STRING)
                .build();

        PredictRequest req = PredictRequest.newBuilder()
                .setModelSpec(ModelSpec.newBuilder()
                        .setName("uprofile")
                        .setSignatureName("serving_default")
                        .setVersion(Int64Value.newBuilder().setValue(modelVer)))
                .putAllInputs(ImmutableMap.of("inputs", proto))
                .build();

        return stub.predict(req);
    }

    @ProcessEvent(semanticClass = SCPurchase.class)
    public void onSomething(Output out, Aggregators agg, PredictionServiceBlockingStub stub) throws ProcessorException {
        out.print(inputStr);
        long start = System.nanoTime();
        PredictResponse response = predict(stub);
        long elapsedMillis = (System.nanoTime() - start) / 1000000;
        agg.getAverageAggregator("AvgMillis", AggregationWindow.MINUTES_5)
                .setTableName("AvgTFPredictionTimeMillis")
                .add(elapsedMillis);
        out.writeToKafka("tf_prediction_test1", response.getOutputsMap());
    }
}
