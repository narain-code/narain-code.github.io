package com.king.rbea.backend.processors;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.Serializable;
import java.util.List;

import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.junit.Test;

import com.king.constants.external.EventField;
import com.king.event.Event;
import com.king.flink.utils.events.LazyEventFormat;
import com.king.rbea.Aggregators;
import com.king.rbea.aggregators.AggregationWindow;
import com.king.rbea.aggregators.Counter;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.backend.types.bea.KafkaOutput;
import com.king.rbea.configuration.processor.ProcessorInfo;

public class SimpleAggregatorTest extends ProcessorTestBase {
	private static final long serialVersionUID = 1L;

	public SimpleAggregatorTest() {
		super();
	}

	@Test
	public void test() throws Exception {
		RBEATestPipeline pipeline = RBEATestPipeline
				.startWithDeployment(9999, new CountAll())
				.thenEvent(1, "event").withTimestamp(100)
				.andEvent(1, "event").withTimestamp(10000)
				.andEvent(2, "event").withTimestamp(80000)
				.thenWait(Time.seconds(1))
				.thenFailAndRestoreJob()
				.andEvent(3, "event").withTimestamp(20000)
				.thenWatermark(65000)
				.thenEvent(3, "event").withTimestamp(70000)
				.thenWatermark(130000)
				.thenWait(Time.seconds(5));

		Tuple2<List<ProcessorInfo>, List<BEA>> output = executeProcessor(pipeline);

		assertTrue(output.f0.toString(), withoutRuntimeStatistics(output.f0).isEmpty());
		System.out.println(output.f1);

		assertEquals(2, output.f1.size());
		KafkaOutput first = (KafkaOutput) output.f1.get(0);
		KafkaOutput second = (KafkaOutput) output.f1.get(1);

		assertEquals("aggrigato.test", first.getTopic());
		assertEquals("aggrigato.test", second.getTopic());

		LazyEventFormat ef = new LazyEventFormat();
		Event agg1 = ef.parse(new String(first.getBytes()));
		Event agg2 = ef.parse(new String(second.getBytes()));
		if (agg2.get(EventField.AggrigatoLong.bucketStartMsts) == 0) {
			Event tmp = agg1;
			agg1 = agg2;
			agg2 = tmp;
		}

		assertEquals("TestCount_9999", agg1.get(EventField.AggrigatoLong.aggregatorId));
		assertEquals("TestCount_9999", agg2.get(EventField.AggrigatoLong.aggregatorId));
		assertEquals(3L, agg1.get(EventField.AggrigatoLong.aggregatedValue));
		assertEquals(2L, agg2.get(EventField.AggrigatoLong.aggregatedValue));
		assertEquals(0, agg1.get(EventField.AggrigatoLong.bucketStartMsts));
		assertEquals(60000, agg2.get(EventField.AggrigatoLong.bucketStartMsts));
		assertEquals(60000, agg1.get(EventField.AggrigatoLong.bucketSizeMs));
		assertEquals(60000, agg2.get(EventField.AggrigatoLong.bucketSizeMs));
	}

	public static class CountAll implements Serializable {
		private static final long serialVersionUID = 1L;

		@ProcessEvent
		public void process(Event event, Aggregators agg) throws Exception {
			Counter c = agg.getCounter("TestCount", AggregationWindow.MINUTES_1);
			c.increment();
		}
	}
}
