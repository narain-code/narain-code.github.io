package com.king.rbea.backend.processors;

import static org.junit.Assert.assertEquals;

import java.io.Serializable;
import java.util.List;

import org.apache.flink.api.java.tuple.Tuple2;
import org.junit.Test;
import org.mockito.Mockito;

import com.google.common.collect.Lists;
import com.king.rbea.Context;
import com.king.rbea.Registry;
import com.king.rbea.State;
import com.king.rbea.Timers;
import com.king.rbea.annotations.Initialize;
import com.king.rbea.annotations.OnTimer;
import com.king.rbea.annotations.Param;
import com.king.rbea.annotations.ParamType;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.backend.types.bea.KafkaOutput;
import com.king.rbea.backend.utils.BackendConstants;
import com.king.rbea.configuration.processor.Deployment;
import com.king.rbea.configuration.processor.ProcessorInfo;
import com.king.rbea.exceptions.BackendException;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.state.LocalState;
import com.king.rbea.state.StateDescriptor;
import com.king.rbea.testutils.SCLong;
import com.mysql.jdbc.Connection;

public class TimerTest extends ProcessorTestBase {
	private static final long serialVersionUID = 1L;

	public TimerTest() {
		super();
	}

	@Test
	public void test() throws Exception {
		RBEATestPipeline pipeline = RBEATestPipeline
				.startWithDeployment(1000, new TimerTestProcessor())
				.thenDeploy(6000, new TimerTestProcessor2())
				.thenDeploy(7000, new TimerTestProcessor3())
				.thenEvent(3, "1500")
				.thenEvent(1, "random")
				.thenEvent(1, "700")
				.thenWatermark(800)
				.thenEvent(3, "random")
				.thenFailAndRestoreJob()
				.thenEvent(2, "1000")
				.thenWatermark(1600)
				.thenEvent(3, "random")
				.thenDeploy(2000, new ProcWithFailingTimer())
				.thenEvent(3, "2000")
				.thenWatermark(2001)
				.thenWatermark(2600)
				.thenRemoveProcessor(1000)
				.thenEvent(4, "3000")
				.thenRemoveProcessor(6000)
				.thenWatermark(4000 + BackendConstants.SESSION_TIMEOUT);

		Tuple2<List<ProcessorInfo>, List<BEA>> testOutput = executeProcessor(pipeline);
		List<BEA> beaOutput = testOutput.f1;
		List<ProcessorInfo> infoOut = testOutput.f0;

		assertEquals(infoOut.toString(), 2, withoutRuntimeStatistics(infoOut).size());

		validateExact(Lists.newArrayList(
				new KafkaOutput(1000, "PRINT", null, "1-700-2-700".getBytes()),
				new KafkaOutput(1000, "PRINT", null, "2-1000-1-1000".getBytes()),
				new KafkaOutput(1000, "PRINT", null, "3-1500-2-1500".getBytes()),
				new KafkaOutput(1000, "PRINT", null, "3-2000-4-3500".getBytes()),
				new KafkaOutput(2000, "U", null, "MAD".getBytes())), beaOutput);
	}

	public List<Deployment> getBaseProcessors() {
		return Lists.newArrayList(Deployment.newJavaProcessor("TestProc", Long.MAX_VALUE - 100, new Serializable() {

			private static final long serialVersionUID = 1L;
			private StateDescriptor<Long> sum;

			@ProcessEvent(semanticClass = SCLong.class)
			public void processLong(SCLong l, State s) throws ProcessorException {
				s.update(sum, s.get(sum) + l.get());
			}

			@Initialize
			public void init(Registry reg) throws ProcessorException {
				sum = reg.registerState(LocalState.createLong("TOTAL_SUM").initializedTo(0L));
			}

		}, "", 0));
	}

	public static class ProcWithFailingTimer implements Serializable {
		private static final long serialVersionUID = 1L;

		@ProcessEvent
		public void processEvent(Timers timers) throws Exception {
			timers.registerTimer(2500, null);
		}

		@OnTimer
		public void ot(Context c) throws ProcessorException, BackendException {
			c.getOutput().writeToKafka("U", "MAD");
			throw new RuntimeException("FAIL");
		}
	}

	public static class TimerTestProcessor implements Serializable {
		private static final long serialVersionUID = 1L;
		private StateDescriptor<Integer> count;

		@ProcessEvent
		public void processAll(State s) throws ProcessorException {
			s.update(count, s.get(count) + 1);
		}

		@ProcessEvent(semanticClass = SCLong.class)
		public void processEvent(Timers timers, SCLong l) throws Exception {
			timers.registerTimer(l.get(), l.get());
		}

		@OnTimer
		public void onTimer(@Param(ParamType.TimerParam) Object params, Context c)
				throws ProcessorException, BackendException {
			c.getOutput().writeToKafka("PRINT",
					c.getCoreUserId() + "-"
							+ params + "-"
							+ c.getState().get("COUNT") + "-"
							+ c.getState().get("TOTAL_SUM"));
		}

		@Initialize
		public void initialize(Registry reg) throws Exception {
			count = reg.registerState(LocalState.createInt("COUNT")
					.initializedTo(0));
		}
	}

	public static class TimerTestProcessor2 implements Serializable {
		private static final long serialVersionUID = 1L;

		@ProcessEvent
		public void processEvent(com.king.event.Event event, Context ctx) throws Exception {
			SCLong l = SCLong.process(event);
			if (l != null) {
				ctx.getTimers().registerTimer(l.get(), l.get());
				int id2 = ctx.getTimers().registerTimer(l.get() + 100, l.get());
				ctx.getTimers().removeTimer(id2);
			}
		}

		@OnTimer
		public void onTimer(@Param(ParamType.TimeStamp) long ts,
				@Param(ParamType.TimerParam) Object params, Context c)
				throws ProcessorException, BackendException {
			if ("".equals(params)) {
				c.getOutput().print("noooo");
			}
			if (params instanceof Long) {
				c.getTimers().registerTimer(ts + 100, "");
				c.getTimers().removeAllTimers();
			}
		}
	}

	public static class TimerTestProcessor3 implements Serializable {
		private static final long serialVersionUID = 1L;

		@ProcessEvent
		public void processEvent(com.king.event.Event event, Context ctx) throws Exception {
			ctx.getTimers().registerTimer(1000, Mockito.mock(Connection.class));
		}

		@OnTimer
		public void onTimer(@Param(ParamType.TimerParam) Object params) throws ProcessorException, BackendException {
			System.err.println(params);
		}
	}
}
