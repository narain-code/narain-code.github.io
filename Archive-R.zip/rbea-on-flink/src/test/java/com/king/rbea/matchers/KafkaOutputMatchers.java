package com.king.rbea.matchers;

import static java.nio.charset.StandardCharsets.UTF_8;
import static org.hamcrest.CoreMatchers.is;

import java.util.Optional;

import org.hamcrest.CustomTypeSafeMatcher;
import org.hamcrest.Matcher;

import com.king.event.Event;
import com.king.event.format.EventFormat;
import com.king.event.format.EventFormatException;
import com.king.rbea.backend.operators.FailureHandlingSchema;
import com.king.rbea.backend.types.bea.KafkaOutput;

public final class KafkaOutputMatchers {

	private KafkaOutputMatchers() {
		throw new AssertionError("No com.king.rbea.matchers.KafkaOuputMatchers instances for you!");
	}

	public static Matcher<KafkaOutput> hasTopic(String topic) {
		return hasTopic(is(topic));
	}

	public static Matcher<KafkaOutput> hasTopic(Matcher<String> matcher) {
		return new CustomTypeSafeMatcher<KafkaOutput>("has topic") {
			@Override
			protected boolean matchesSafely(KafkaOutput output) {
				return matcher.matches(output.getTopic());
			}
		};
	}

	public static Matcher<KafkaOutput> hasKey(long key) {
		return hasKey(Long.toString(key));
	}

	public static Matcher<KafkaOutput> hasKey(String key) {
		return hasKey(key.getBytes(UTF_8));
	}

	public static Matcher<KafkaOutput> hasKey(byte[] key) {
		return hasKey(is(key));
	}

	public static Matcher<KafkaOutput> hasKey(Matcher<byte[]> matcher) {
		return new CustomTypeSafeMatcher<KafkaOutput>("has key") {
			@Override
			protected boolean matchesSafely(KafkaOutput output) {
				final Optional<byte[]> key = output.getKey();
				return key.isPresent() ? matcher.matches(key.get()) : false;
			}
		};
	}

	public static Matcher<KafkaOutput> hasEvent(Matcher<Event> matcher) {
		return hasEvent(matcher, FailureHandlingSchema.eventFormat);
	}

	public static Matcher<KafkaOutput> hasEvent(Matcher<Event> matcher, EventFormat eventFormat) {
		return new CustomTypeSafeMatcher<KafkaOutput>("has event") {
			@Override
			protected boolean matchesSafely(KafkaOutput item) {
				try {
					final Event event = eventFormat.parse(new String(item.getBytes()));
					return matcher.matches(event);
				} catch (EventFormatException e) {
					throw new RuntimeException(e);
				}
			}
		};
	}
}
