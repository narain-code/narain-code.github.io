package com.king.rbea.backend;

import static org.junit.Assert.assertEquals;

import org.apache.flink.api.java.utils.ParameterTool;
import org.junit.Test;

import com.google.common.collect.ImmutableMap;

public class ParamMergingTest {

	@Test
	public void test() {
		ParameterTool params = ParameterTool.fromMap(ImmutableMap.of("a", "a", "b", "b"))
				.mergeWith(ParameterTool.fromMap(ImmutableMap.of("a", "b", "c", "c")));

		assertEquals("b", params.getRequired("a"));
		assertEquals("c", params.getRequired("c"));
	}
}
