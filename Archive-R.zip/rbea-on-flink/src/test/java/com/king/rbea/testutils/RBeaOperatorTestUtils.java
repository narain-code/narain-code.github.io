package com.king.rbea.testutils;

import java.lang.reflect.Field;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.flink.api.common.ExecutionConfig;
import org.apache.flink.api.common.typeinfo.BasicTypeInfo;
import org.apache.flink.api.java.typeutils.EitherTypeInfo;
import org.apache.flink.api.java.typeutils.TypeExtractor;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.streaming.api.watermark.Watermark;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.apache.flink.streaming.util.AbstractStreamOperatorTestHarness;
import org.apache.flink.streaming.util.KeyedTwoInputStreamOperatorTestHarness;
import org.apache.flink.types.Either;

import com.google.common.collect.ImmutableMap;
import com.king.event.Event;
import com.king.flink.utils.Unchecked;
import com.king.flink.utils.Unchecked.ThrowingConsumer;
import com.king.rbea.Context;
import com.king.rbea.backend.operators.scriptexecution.ContextManager;
import com.king.rbea.backend.operators.scriptexecution.RBEAOperator;
import com.king.rbea.backend.types.EventWrapper;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.backend.types.bea.BEATypeInfo;
import com.king.rbea.backend.utils.ContextRunner;
import com.king.rbea.configuration.Configuration;
import com.king.rbea.configuration.processor.Deployment;
import com.king.rbea.configuration.processor.DeploymentWithFields;
import com.king.rbea.exceptions.BackendException;
import com.king.rbea.exceptions.ProcessorException;

public class RBeaOperatorTestUtils {

	public static StreamRecord<Configuration> input(Configuration conf) {
		return new StreamRecord<Configuration>(conf);
	}

	public static StreamRecord<Configuration> input(Deployment dep) {
		return new StreamRecord<Configuration>(new DeploymentWithFields(dep, Collections.emptyMap()));
	}

	public static StreamRecord<EventWrapper> input(Event event) {
		return input(event, event.getCoreUserId().get());
	}

	public static StreamRecord<EventWrapper> backfill(StreamRecord<EventWrapper> rec) {
		return new StreamRecord<EventWrapper>(rec.getValue(), Long.MAX_VALUE);
	}

	public static StreamRecord<EventWrapper> input(Event event, long cuid) {
		return new StreamRecord<EventWrapper>(new EventWrapper(event, cuid));
	}

	public static List<? extends Either<BEA, Configuration>> getOutputList(
			KeyedTwoInputStreamOperatorTestHarness<Long, EventWrapper, Configuration, Either<BEA, Configuration>> op) {
		return op.extractOutputStreamRecords().stream().map(StreamRecord::getValue).collect(Collectors.toList());
	}

	public static KeyedTwoInputStreamOperatorTestHarness<Long, EventWrapper, Configuration, Either<BEA, Configuration>> createRBEAHarness(
			List<Deployment> baseProcs) throws Exception {

		ParameterTool params = ParameterTool.fromMap(ImmutableMap.of("stateCacheSize", "10", "flushPct", "1",
				"stateExportTopic", "et", "stateSchemaTopic", "st"));
		RBEAOperator rbeaOperator = new RBEAOperator(baseProcs, params);
		rbeaOperator.enableTestMode();

		KeyedTwoInputStreamOperatorTestHarness<Long, EventWrapper, Configuration, Either<BEA, Configuration>> op = new KeyedTwoInputStreamOperatorTestHarness<>(
				rbeaOperator,
				EventWrapper::getPartitionKey,
				null, BasicTypeInfo.LONG_TYPE_INFO);
		rbeaOperator.setTicker(new ManualTicker());
		op.setup(new EitherTypeInfo<>(new BEATypeInfo<>(),
				TypeExtractor.getForClass(Configuration.class))
						.createSerializer(new ExecutionConfig()));
		op.open();
		return op;
	}

	public static RBEAOperator getRbeaOperator(
			KeyedTwoInputStreamOperatorTestHarness<Long, EventWrapper, Configuration, Either<BEA, Configuration>> harness)
			throws IllegalArgumentException, Exception {
		Field field = AbstractStreamOperatorTestHarness.class.getDeclaredField("operator");
		field.setAccessible(true);
		return (RBEAOperator) field.get(harness);
	}

	public static void advanceWatermark(KeyedTwoInputStreamOperatorTestHarness<?, ?, ?, ?> op, long ts)
			throws Exception {
		Watermark wm = new Watermark(ts);
		op.processWatermark1(wm);
		op.processWatermark2(wm);
	}

	public static void checkContext(RBEAOperator op, ThrowingConsumer<Context> consumer) throws BackendException {
		checkContext(op, Long.MAX_VALUE - 1000, consumer);
	}

	public static void checkContext(RBEAOperator op, long pid, ThrowingConsumer<Context> consumer)
			throws BackendException {
		op.runWithContext(Optional.of((Long) op.getCurrentKey()), null, new ContextRunner() {
			@Override
			public List<ProcessorException> execute(ContextManager ctxMgr) {
				ctxMgr.setProcessorId(pid);
				Context ctx = ctxMgr.getContext();
				try {
					consumer.accept(ctx);
				} catch (Exception e) {
					Unchecked.throwSilently(e);
				}
				return null;
			}
		});
	}

}
