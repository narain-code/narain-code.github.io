package com.king.rbea.backend.operators.scriptexecution;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.apache.flink.api.common.typeutils.TypeSerializer;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.utils.ParameterTool;
import org.junit.Before;
import org.junit.Test;

import com.king.rbea.configuration.processor.Deployment;
import com.king.rbea.configuration.processor.DeploymentWithFields;
import com.king.rbea.configuration.processor.Removal;

/**
 * Tests for {@link RBEAOperator}
 */
public class RBEAOperatorTest {
	private RBEAOperator rbeaOp;

	@SuppressWarnings("unchecked")
	@Before
	public void setup() {
		this.rbeaOp = new RBEAOperator(Collections.EMPTY_LIST, ParameterTool.fromMap(new HashMap<>()));		
	}
	
	/**
	 * Tests {@link RBEAOperator#createTestDeploymentRemoval(com.king.rbea.configuration.processor.ProcessorInfo)}.
	 */
	@Test
	public void testCreateTestDeploymentRemoval() {
		Map<String, Tuple2<Short, TypeSerializer<?>>> fieldMapping = null;
		Deployment deployment = new Deployment.TestDeployment();
		
		DeploymentWithFields dwf = new DeploymentWithFields(deployment, fieldMapping);
		assertFalse(rbeaOp.createTestDeploymentRemoval(dwf).isPresent());
		
		deployment.setBoolean(Deployment.TEST_KEY, true);
		dwf = new DeploymentWithFields(deployment, fieldMapping);
		Optional<Removal> opt = rbeaOp.createTestDeploymentRemoval(dwf);
		assertTrue(opt.isPresent());
		Removal removal = opt.get();
		assertEquals(removal.getProcessorId(), deployment.getProcessorId());
	}
}
