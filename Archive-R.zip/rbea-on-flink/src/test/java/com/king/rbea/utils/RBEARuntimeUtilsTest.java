package com.king.rbea.utils;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Optional;

import org.junit.Test;

import com.king.rbea.backend.operators.scriptexecution.RBEAOperator;
import com.king.rbea.exceptions.BackendException;
import com.king.rbea.exceptions.ProcessorException;

public class RBEARuntimeUtilsTest {

	@Test(expected = BackendException.class)
	public void testBackendEx1() throws BackendException {
		RBEAOperator.run(100, "Test", false, () -> {
			throw new BackendException("");
		});
	}

	@Test(expected = BackendException.class)
	public void testBackendEx2() throws BackendException {
		RBEAOperator.run(-1, "Test", false, () -> {
			throw new Exception("");
		});
	}

	@Test
	public void testProcEx1() throws BackendException {
		Optional<ProcessorException> err = RBEAOperator.run(100, "Test", true, () -> {
			throw new Exception("a");
		});
		assertTrue(err.get().isRecoverable());
	}

	@Test
	public void testProcEx2() throws BackendException {
		Optional<ProcessorException> err = RBEAOperator.run(100, "Test", false, () -> {
			throw new ProcessorException("b");
		});
		assertFalse(err.get().isRecoverable());
	}

}
