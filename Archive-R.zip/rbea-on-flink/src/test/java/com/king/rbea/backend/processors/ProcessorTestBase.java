package com.king.rbea.backend.processors;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.io.FileUtils;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.typeutils.TypeExtractor;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.ConfigConstants;
import org.apache.flink.contrib.streaming.state.RocksDBStateBackend;
import org.apache.flink.runtime.state.memory.MemoryStateBackend;
import org.apache.flink.streaming.api.CheckpointingMode;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.sink.SinkFunction;
import org.apache.flink.types.Either;
import org.junit.AfterClass;
import org.junit.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Optional;
import com.google.common.collect.Lists;
import com.king.flink.utils.types.EitherUtils;
import com.king.rbea.backend.RBEA;
import com.king.rbea.backend.output.OutputWriter;
import com.king.rbea.backend.output.RBEAOutput;
import com.king.rbea.backend.types.EventWrapper;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.backend.types.bea.KafkaOutput;
import com.king.rbea.backend.types.processorinfo.RuntimeStatistics;
import com.king.rbea.backend.utils.BackendConstants;
import com.king.rbea.configuration.Configuration;
import com.king.rbea.configuration.processor.Deployment;
import com.king.rbea.configuration.processor.Failure;
import com.king.rbea.configuration.processor.ProcessorInfo;

/**
 * {@code ProcessorTestBase} is a base class for implementing tests that test a
 * specific Flink job.
 * <p>
 * The basic usage pattern in a subclass is to first create the
 * {@code RBEATestSource}, then execute it and finally validate the results,
 * e.g.
 * <p>
 * 
 * <pre>
 * RBEATestPipeline pipeline = RBEATestPipeline.thenEvent(1, "good");
 * Tuple2<List<ProcessorInfo>, List<BEA>> testOutput = executeProcessor(pipeline);
 * assertTrue(testOutput.f0.isEmpty());
 * </pre>
 */
public abstract class ProcessorTestBase implements Serializable {
	private static final long serialVersionUID = 1L;

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	private static File TEMP_DIR;

	private final CollectingInfoSink infoSink;
	private final CollectingBEASink beaSink;

	protected ProcessorTestBase() {
		infoSink = new CollectingInfoSink();
		beaSink = new CollectingBEASink();
	}

	/**
	 * Executes the given {@code source}.
	 * 
	 * @param source
	 * @return the job output
	 * @throws Exception
	 */
	@SuppressWarnings("deprecation")
	public Tuple2<List<ProcessorInfo>, List<BEA>> executeProcessor(RBEATestPipeline source) throws Exception {
		StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
		env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime);
		env.setParallelism(3);
		env.enableCheckpointing(1000, CheckpointingMode.EXACTLY_ONCE, true);

		TEMP_DIR = new File(ConfigConstants.DEFAULT_TASK_MANAGER_TMP_PATH, UUID.randomUUID().toString());
		env.setStateBackend(new RocksDBStateBackend(new MemoryStateBackend(), true));

		DataStream<Optional<Either<EventWrapper, Configuration>>> sourceData = env.addSource(source).setParallelism(1);

		sourceData
				.filter(o -> !o.isPresent()).setParallelism(1)
				.map(e -> true).returns(Boolean.class).setParallelism(1)
				.addSink(new OnceFailingSink());

		DataStream<EventWrapper> events = sourceData
				.filter(Optional::isPresent).setParallelism(1)
				.map(new MapFunction<Optional<Either<EventWrapper, Configuration>>, Either<EventWrapper, Configuration>>() {
					private static final long serialVersionUID = 1L;

					@Override
					public Either<EventWrapper, Configuration> map(Optional<Either<EventWrapper, Configuration>> value)
							throws Exception {
						return value.get();
					}
				}).setParallelism(1)
				.flatMap(new EitherUtils.ProjectLeft<>(EventWrapper.TYPE))
				.setParallelism(1);

		DataStream<Configuration> deploymentStream = sourceData
				.filter(Optional::isPresent).setParallelism(1)
				.map(new MapFunction<Optional<Either<EventWrapper, Configuration>>, Either<EventWrapper, Configuration>>() {
					private static final long serialVersionUID = 1L;

					@Override
					public Either<EventWrapper, Configuration> map(Optional<Either<EventWrapper, Configuration>> value)
							throws Exception {
						return value.get();
					}
				}).setParallelism(1)
				.flatMap(new EitherUtils.ProjectRight<>(TypeExtractor.getForClass(Configuration.class)))
				.setParallelism(1);

		Map<String, String> params = new HashMap<>();
		params.put(BackendConstants.TEST_ITER_TIMEOUT, "10000");
		params.put(BackendConstants.TEST_SOURCE_QUERY_SECS, "10");
		params.put(BackendConstants.AGGRIGATO_TOPIC, "aggrigato.test");
		params.put(BackendConstants.STATE_CACHE_SIZE, "2");

		RBEAOutput output = RBEA.run(
				events,
				deploymentStream,
				ParameterTool.fromMap(params),
				getBaseProcessors(),
				new CollectingOutputWriter(), true, "test", "test");

		output.getConfigurationOutput().addSink(infoSink).setParallelism(1);
		CollectingOutputWriter.allOutput.addSink(beaSink).setParallelism(1);
		env.execute();

		List<ProcessorInfo> infoOut = infoSink.getOutput();
		infoOut.forEach(info -> {
			if (info.isPropagated()) {
				fail("Output should not contain propagated infos: " + info);
			}
		});

		return Tuple2.of(
				infoOut.stream()
						.filter(pi -> Lists.newArrayList(Failure.class, KafkaOutput.class, RuntimeStatistics.class)
								.contains(pi.getClass()))
						.collect(Collectors.toList()),
				beaSink.getOutput());
	}

	public List<Deployment> getBaseProcessors() {
		return Collections.emptyList();
	}

	public static void validateExact(List<BEA> expected, List<BEA> actual) {
		assertEquals(expected, actual);
	}

	public static void validateSet(List<BEA> expected, List<BEA> actual) {
		assertEquals(new HashSet<>(expected), new HashSet<>(actual));
	}

	/**
	 * A Flink {@link SinkFunction} for {@link ProcessorInfo}-objects that appends
	 * the input to a {@link List}.
	 */
	private static class CollectingInfoSink implements SinkFunction<Configuration> {
		private static final long serialVersionUID = 1L;

		private static final List<Configuration> OUTPUT = Collections.synchronizedList(new ArrayList<>());

		public CollectingInfoSink() {}

		@Override
		public void invoke(Configuration out) throws Exception {
			OUTPUT.add(out);
		}

		@SuppressWarnings({ "rawtypes", "unchecked" })
		public List<ProcessorInfo> getOutput() {
			return (List) OUTPUT;
		}
	}

	/**
	 * A Flink {@link SinkFunction} for {@link BEA}-objects that appends the input
	 * to a {@link List}.
	 */
	private static class CollectingBEASink implements SinkFunction<BEA> {
		private static final long serialVersionUID = 1L;

		private static List<BEA> OUTPUT = Collections.synchronizedList(new ArrayList<>());;

		public CollectingBEASink() {}

		@Override
		public void invoke(BEA out) throws Exception {
			OUTPUT.add(out);
		}

		public List<BEA> getOutput() {
			return OUTPUT;
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private static class CollectingOutputWriter implements OutputWriter {

		static DataStream<BEA> allOutput = null;

		@Override
		public SingleOutputStreamOperator<Configuration> writeKafkaOutput(ParameterTool props,
				DataStream<KafkaOutput> bea,
				DataStream<KafkaOutput> aggrigato) {

			aggrigato = aggrigato.filter(k -> !(new String(k.getBytes()).contains("RBEA_STATS_")));
			if (allOutput == null) {
				allOutput = (DataStream) bea.union(aggrigato);
			} else {
				allOutput = allOutput.union((DataStream) bea.union(aggrigato));
			}

			return null;
		}

	}

	@AfterClass
	public static void destroyHDFS() {
		try {
			FileUtils.deleteDirectory(TEMP_DIR);
		} catch (Exception ignored) {}
	}

	@Before
	public void cleanOutputs() {
		beaSink.getOutput().clear();
		infoSink.getOutput().clear();
		CollectingOutputWriter.allOutput = null;
	}

	/**
	 * Filters out {@link RuntimeStatistics} from the given {@code infoOutput}. The
	 * idea is that most tests don't care about statistics and can just ignore those
	 * from the output. This makes testing simpler than always trying to figure out
	 * the exact count (and content...) of {@link RuntimeStatistics}, since the
	 * frequency and contents of the {@link RuntimeStatistics} may change in the
	 * future.
	 * 
	 * @param infoOutput
	 *            the input list
	 * @return the filtered list
	 */
	protected List<ProcessorInfo> withoutRuntimeStatistics(List<ProcessorInfo> infoOutput) {
		return infoOutput.stream().filter(pi -> !(pi instanceof RuntimeStatistics)).collect(Collectors.toList());
	}

	public static class OnceFailingSink implements SinkFunction<Boolean> {
		private static final long serialVersionUID = 1L;
		private static boolean hasFailed = false;

		@Override
		public void invoke(Boolean input) throws Exception {
			if (!hasFailed) {
				hasFailed = true;
				throw new RuntimeException("FAIL");
			}
		}

	}
}
