package com.king.rbea.backend.operators.scriptexecution;

import static com.king.rbea.testutils.RBeaOperatorTestUtils.createRBEAHarness;
import static com.king.rbea.testutils.RBeaOperatorTestUtils.input;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.apache.flink.streaming.util.KeyedTwoInputStreamOperatorTestHarness;
import org.apache.flink.types.Either;
import org.junit.Test;
import org.mockito.Mockito;

import com.king.rbea.Registry;
import com.king.rbea.backend.operators.FieldIdAssigner;
import com.king.rbea.backend.types.EventWrapper;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.configuration.Configuration;
import com.king.rbea.configuration.processor.Deployment;
import com.king.rbea.configuration.processor.DeploymentWithFields;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.scripts.ProcessorFactory;
import com.king.rbea.scripts.proxy.ProxyExecutorFactory;
import com.king.rbea.state.baseprocessors.DefaultBaseProcessorProvider;

public class ProdScriptTest {

	@SuppressWarnings("rawtypes")
	@Test
	public void testProdScripts() throws Exception {

		List<Deployment> baseProcs = DefaultBaseProcessorProvider.INSTANCE.getBaseProcessors();

		KeyedTwoInputStreamOperatorTestHarness<Long, EventWrapper, Configuration, Either<BEA, Configuration>> harness = createRBEAHarness(
				baseProcs);

		FieldIdAssigner idAssigner = new FieldIdAssigner();
		idAssigner.setProcessorFactory(ProxyExecutorFactory.builder().build());

		int i = 0;

		for (File file : new File("src/test/resources/prod_scripts").listFiles()) {
			String script = new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8);
			harness.processElement2(
					input(idAssigner.map(
							Deployment.newJavaCodeProcessor("", i++, script, "", 1))));
		}

		for (Object o : harness.getOutput()) {
			@SuppressWarnings("unchecked")
			Either<BEA, Configuration> e = (Either<BEA, Configuration>) ((StreamRecord) o).getValue();
			assertTrue(e.right() instanceof DeploymentWithFields);
		}

	}

	public static void validate(String path) throws IOException, Exception, ProcessorException {
		String code = new String(Files.readAllBytes(Paths.get(path)));
		ProcessorFactory processorFactory = ProxyExecutorFactory.builder().build();
		processorFactory.getForJavaCode(0, "", code).initialize(Mockito.mock(Registry.class), null);
	}
}
