package com.king.rbea.utils;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Optional;

import org.junit.Test;

import com.king.constants.external.EventType;
import com.king.event.Event;
import com.king.flink.utils.CoreUserIdFetcher;

public class CoreUserIdFetcherTest {

    @Test
    public void test() {
        Optional<Long> id = CoreUserIdFetcher.getCoreUserId(new TestEvent(EventType.EmailSent));
        assertTrue(id.isPresent());

        id = CoreUserIdFetcher.getCoreUserId(new TestEvent(EventType.AbTestCloseVersion));
        assertFalse(id.isPresent());

        id = CoreUserIdFetcher.getCoreUserId(new TestEvent(EventType.MessageSentWithRecipient3));
        assertTrue(id.isPresent());
        
        id = CoreUserIdFetcher.getCoreUserId(new TestEvent(EventType.AppMessageSentWithRecipient5));
        assertTrue(id.isPresent());
        
        id = CoreUserIdFetcher.getCoreUserId(new TestEvent(EventType.VirtualCurrencyTransferTransaction));
        assertFalse(id.isPresent());
    }

    private class TestEvent implements Event {

        private final long eventType;

        public TestEvent(long eventType) {
            super();
            this.eventType = eventType;
        }

        @Override
        public long getTimeStamp() {
            // TODO Auto-generated method stub
            return 0;
        }

        @Override
        public int getFlavourId() {
            // TODO Auto-generated method stub
            return 0;
        }

        @Override
        public long getEventType() {
            return eventType;
        }

        @Override
        public long getUniqueId() {
            // TODO Auto-generated method stub
            return 0;
        }

        @Override
        public String getHostname() {
            // TODO Auto-generated method stub
            return null;
        }

        @Override
        public long getUacid() {
            // TODO Auto-generated method stub
            return 0;
        }

        @Override
        public Iterable<String> fields() {
            // TODO Auto-generated method stub
            return null;
        }

        @Override
        public String getString(int index) {
            // TODO Auto-generated method stub
            return null;
        }

        @Override
        public int getInt(int index) {
            // TODO Auto-generated method stub
            return 0;
        }

        @Override
        public long getLong(int index) {
            // TODO Auto-generated method stub
            return 99999999999999l;
        }

        @Override
        public double getDouble(int index) {
            // TODO Auto-generated method stub
            return 0;
        }

        @Override
        public float getFloat(int index) {
            // TODO Auto-generated method stub
            return 0;
        }

        @Override
        public boolean getBoolean(int index) {
            // TODO Auto-generated method stub
            return false;
        }

        @Override
        public int get(int[] intIndex) {
            // TODO Auto-generated method stub
            return 0;
        }

        @Override
        public long get(int[][] longIndex) {
            // TODO Auto-generated method stub
            return 0;
        }

        @Override
        public String get(int[][][] stringIndex) {
            // TODO Auto-generated method stub
            return null;
        }

        @Override
        public double get(int[][][][] doubleIndex) {
            // TODO Auto-generated method stub
            return 0;
        }

        @Override
        public boolean get(int[][][][][] booleanIndex) {
            // TODO Auto-generated method stub
            return false;
        }

        @Override
        public float get(int[][][][][][] floatIndex) {
            // TODO Auto-generated method stub
            return 0;
        }

        @Override
        public Integer get(long[] intIndex) {
            // TODO Auto-generated method stub
            return null;
        }

        @Override
        public Long get(long[][] longIndex) {
            // TODO Auto-generated method stub
            return null;
        }

        @Override
        public Double get(long[][][][] doubleIndex) {
            // TODO Auto-generated method stub
            return null;
        }

        @Override
        public Boolean get(long[][][][][] booleanIndex) {
            // TODO Auto-generated method stub
            return null;
        }

        @Override
        public Float get(long[][][][][][] booleanIndex) {
            // TODO Auto-generated method stub
            return null;
        }

    }
}
