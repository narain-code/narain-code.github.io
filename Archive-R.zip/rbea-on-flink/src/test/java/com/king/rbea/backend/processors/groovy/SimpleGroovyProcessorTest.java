package com.king.rbea.backend.processors.groovy;

import java.io.Serializable;
import java.util.List;

import org.apache.flink.api.java.tuple.Tuple2;
import org.junit.Test;

import com.google.common.collect.Lists;
import com.king.rbea.Registry;
import com.king.rbea.State;
import com.king.rbea.annotations.Initialize;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.backend.processors.ProcessorTestBase;
import com.king.rbea.backend.processors.RBEATestPipeline;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.backend.types.bea.KafkaOutput;
import com.king.rbea.configuration.processor.Deployment;
import com.king.rbea.configuration.processor.ProcessorInfo;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.state.LocalState;
import com.king.rbea.state.StateDescriptor;
import com.king.rbea.testutils.SCLong;

public class SimpleGroovyProcessorTest extends ProcessorTestBase {

	private static final long serialVersionUID = 1L;

	@Test
	public void test() throws Exception {

		RBEATestPipeline source = RBEATestPipeline
				.startWithGroovyDeployment(1000,
						"src/test/resources/groovy/PrintNonSCLong.groovy")
				.thenWait(1000)
				.thenEvent(2, "good")
				.thenDeployGroovy(2000, "src/test/resources/groovy/SCLongSum.groovy")
				.thenEvent(3, "900")

				.thenFailAndRestoreJob()

				.thenRemoveProcessor(1000)
				.thenEvent(3, "100")
				.thenEvent(3, "bad");

		Tuple2<List<ProcessorInfo>, List<BEA>> testOutput = executeProcessor(source);
		List<ProcessorInfo> infoOutput = testOutput.f0;
		List<BEA> beaOutput = testOutput.f1;

		System.out.println(infoOutput);

		validateExact(Lists.newArrayList(
				new KafkaOutput(1000, "PRINT_1000", null, "good".getBytes()),
				new KafkaOutput(2000L, "SUM2", null, "900".getBytes()),
				new KafkaOutput(2000L, "SUM2", null, "1000".getBytes())), beaOutput);
	}

	public List<Deployment> getBaseProcessors() {
		return Lists.newArrayList(Deployment.newJavaProcessor("TestProc", Long.MAX_VALUE - 100, new Serializable() {

			private static final long serialVersionUID = 1L;
			private StateDescriptor<Long> sum;
			private StateDescriptor<Integer> count;

			@ProcessEvent
			public void processAll(State s) throws ProcessorException {
				s.update(count, s.get(count) + 1);
			}

			@ProcessEvent(semanticClass = SCLong.class)
			public void processLong(SCLong l, State s) throws ProcessorException {
				s.update(sum, s.get(sum) + l.get());
			}

			@Initialize
			public void init(Registry reg) throws ProcessorException {
				sum = reg.registerState(LocalState.createLong("TOTAL_SUM").initializedTo(-9999L));
				count = reg.registerState(LocalState.createInt("COUNT").initializedTo(0));
			}

		}, "", 0, true));
	}
}
