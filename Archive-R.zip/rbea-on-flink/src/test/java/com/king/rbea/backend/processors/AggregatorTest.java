package com.king.rbea.backend.processors;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.Serializable;
import java.util.List;

import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.junit.Test;

import com.king.constants.external.EventField;
import com.king.constants.external.EventType;
import com.king.event.Event;
import com.king.event.format.EventFormatException;
import com.king.flink.utils.events.LazyEventFormat;
import com.king.rbea.Aggregators;
import com.king.rbea.aggregators.AggregationWindow;
import com.king.rbea.aggregators.AverageAggregator;
import com.king.rbea.aggregators.RatioAggregator;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.backend.types.bea.KafkaOutput;
import com.king.rbea.configuration.processor.ProcessorInfo;
import com.king.rbea.testutils.SCLong;

/**
 * Tests for {@link AverageAggregator} and {@link RatioAggregator}.
 */
public class AggregatorTest extends ProcessorTestBase {
	private static final long serialVersionUID = 1L;

	public AggregatorTest() {
		super();
	}

	@Test
	public void test() throws Exception {

		RBEATestPipeline pipeline = RBEATestPipeline
				.startWithDeployment(666, new Aggregator())
				.thenEvent(1, "0").withTimestamp(100)
				.andEvent(1, "10").withTimestamp(10000)
				.andEvent(2, "20").withTimestamp(80000)
				.andEvent(2, "20").withTimestamp(80000)
				.andEvent(2, "0").withTimestamp(80000)
				.thenWatermark(2000000)
				.thenWait(Time.seconds(5));

		Tuple2<List<ProcessorInfo>, List<BEA>> output = executeProcessor(pipeline);

		assertTrue(withoutRuntimeStatistics(output.f0).isEmpty());

		assertEquals(4, output.f1.size());

		Event avg = null;
		Event avg2 = null;
		Event rate = null;
		Event rate2 = null;
		for (BEA bea : output.f1) {
			Event e = toEvent(bea);
			if (e.getEventType() == EventType.AggrigatoLong) {
				if (e.get(EventField.AggrigatoLong.aggregatorId).equals("table")) {
					avg = e;
				} else {
					rate = e;
				}
			} else {
				if (e.get(EventField.AggrigatoLongRatio.aggregatorId).equals("table")) {
					avg2 = e;
				} else {
					rate2 = e;
				}
			}
		}

		assertEquals("table", avg.get(EventField.AggrigatoLong.aggregatorId));
		assertEquals(10 * 1_000_000, avg.get(EventField.AggrigatoLong.aggregatedValue));
		assertEquals(0, avg.get(EventField.AggrigatoLong.bucketStartMsts));
		assertEquals(600000, avg.get(EventField.AggrigatoLong.bucketSizeMs));

		assertEquals("table", avg2.get(EventField.AggrigatoLongRatio.aggregatorId));
		assertEquals(50, avg2.get(EventField.AggrigatoLongRatio.aggregatedNumerator));
		assertEquals(5, avg2.get(EventField.AggrigatoLongRatio.aggregatedDenominator));
		assertEquals(0, avg2.get(EventField.AggrigatoLongRatio.bucketStartMsts));
		assertEquals(600000, avg2.get(EventField.AggrigatoLongRatio.bucketSizeMs));

		assertEquals("RateTest_666", rate.get(EventField.AggrigatoLong.aggregatorId));
		assertEquals((long) (0.1 * 1_000_000), rate.get(EventField.AggrigatoLong.aggregatedValue));
		assertEquals(0, rate.get(EventField.AggrigatoLong.bucketStartMsts));
		assertEquals(600000, rate.get(EventField.AggrigatoLong.bucketSizeMs));

		assertEquals("RateTest_666", rate2.get(EventField.AggrigatoLongRatio.aggregatorId));
		assertEquals(5, rate2.get(EventField.AggrigatoLongRatio.aggregatedNumerator));
		assertEquals(50, rate2.get(EventField.AggrigatoLongRatio.aggregatedDenominator));
		assertEquals(0, rate2.get(EventField.AggrigatoLongRatio.bucketStartMsts));
		assertEquals(600000, rate2.get(EventField.AggrigatoLongRatio.bucketSizeMs));
	}

	private Event toEvent(BEA first) throws EventFormatException {
		return new LazyEventFormat().parse(new String(((KafkaOutput) first).getBytes()));
	}

	public static class Aggregator implements Serializable {
		private static final long serialVersionUID = 1L;

		@ProcessEvent(semanticClass = SCLong.class)
		public void process(SCLong longEvent, Aggregators agg) throws Exception {
			AverageAggregator avg = agg.getAverageAggregator("AvgTest", AggregationWindow.MINUTES_10)
					.setTableName("table");
			RatioAggregator rate = agg.getRatioAggregator("RateTest", AggregationWindow.MINUTES_10);
			avg.add(longEvent.get());
			rate.addToNumerator(1);
			rate.addToDenominator(longEvent.get());
		}
	}
}
