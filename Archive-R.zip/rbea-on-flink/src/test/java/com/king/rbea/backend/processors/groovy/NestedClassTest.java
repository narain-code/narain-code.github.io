package com.king.rbea.backend.processors.groovy;

import com.google.common.collect.Lists;
import com.king.rbea.backend.processors.ProcessorTestBase;
import com.king.rbea.backend.processors.RBEATestPipeline;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.backend.types.bea.KafkaOutput;
import com.king.rbea.configuration.processor.ProcessorInfo;
import org.apache.flink.api.java.tuple.Tuple2;
import org.junit.Test;

import java.util.List;

public class NestedClassTest extends ProcessorTestBase {
	private static final long serialVersionUID = 1L;

	public NestedClassTest() {
		super();
	}
	
	@Test
	public void test() throws Exception {

		RBEATestPipeline source = RBEATestPipeline
				.startWithGroovyDeployment(1000,
						"src/test/resources/groovy/NestedTypeTest.groovy")
				.thenWait(1000)
				.thenEvent(2, "a")
				.thenEvent(3, "b")

				.thenFailAndRestoreJob()
				.thenEvent(3, "c")
				.thenUpdateGroovy(1000, "src/test/resources/groovy/NestedTypeTest2.groovy")
				.thenEvent(3, "d")
				.thenRemoveProcessor(1000)
				.thenEvent(3, "e");

		Tuple2<List<ProcessorInfo>, List<BEA>> testOutput = executeProcessor(source);
		// List<ProcessorInfo> infoOutput = testOutput.f0;
		List<BEA> beaOutput = testOutput.f1;

		validateExact(Lists.newArrayList(
				new KafkaOutput(1000, "PRINT_1000", null, "1".getBytes()),
				new KafkaOutput(1000, "PRINT_1000", null, "1".getBytes()),
				new KafkaOutput(1000, "PRINT_1000", null, "2".getBytes()),
				new KafkaOutput(1000, "PRINT_1000", null, "4".getBytes())), beaOutput);
	}
}
