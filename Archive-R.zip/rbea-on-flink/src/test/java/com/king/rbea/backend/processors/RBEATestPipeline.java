package com.king.rbea.backend.processors;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.streaming.api.checkpoint.ListCheckpointed;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.apache.flink.streaming.api.watermark.Watermark;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.types.Either;

import com.google.common.base.Optional;
import com.king.event.Event;
import com.king.flink.utils.CustomEvent;
import com.king.rbea.Output;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.backend.types.EventWrapper;
import com.king.rbea.configuration.Configuration;
import com.king.rbea.configuration.processor.Deployment;
import com.king.rbea.configuration.processor.Removal;
import com.king.rbea.exceptions.BackendException;
import com.king.rbea.exceptions.ProcessorException;

/**
 * {@code RBEATestPipeline} is a testing tool for creating Flink pipelines and
 * e.g. sending events to the pipeline. See {@link ProcessorTestBase} how to use
 * it.
 */
@SuppressWarnings("deprecation")
public class RBEATestPipeline
		implements SourceFunction<Optional<Either<EventWrapper, Configuration>>>, ListCheckpointed<Serializable> {

	private static final long serialVersionUID = -1941744145020948404L;

	private volatile boolean isRunning = false;

	/**
	 * The internal representation of the RBEA job and events, i.e. the testing
	 * flow steps.
	 * <ul>
	 * <li>f0: what to collect
	 * <li>f1: sleep. How many millis to sleep after the test steps
	 * <li>f2: if present, a watermark step
	 * <li>f3: the timestamp when collecting, is not presents defaults to 0.
	 * </ul>
	 */
	private LinkedList<Tuple4<EventOrProc, Long, Optional<Long>, Optional<Long>>> data = new LinkedList<>();

	public static long DEFAULT_SLEEP = 500;

	private long currentTime = 0;

	private int index = 0;

	private RBEATestPipeline() {}

	/**
	 * Runs the test RBEA job.
	 */
	@Override
	public void run(SourceContext<Optional<Either<EventWrapper, Configuration>>> ctx)
			throws Exception {

		isRunning = true;

		while (index < data.size()) {
			if (!isRunning) {
				return;
			}

			long sleep;

			synchronized (ctx.getCheckpointLock()) {
				Tuple4<EventOrProc, Long, Optional<Long>, Optional<Long>> t = data.get(index++);
				long ts = t.f3.or(currentTime);

				ctx.collectWithTimestamp(t.f0 != null ? Optional.of(t.f0.toEither()) : Optional.absent(), ts);
				if (t.f2.isPresent()) {
					long wm = t.f2.get();
					ctx.emitWatermark(new Watermark(wm));
				}

				sleep = t.f1;
			}

			if (sleep > 0) {
				Thread.sleep(sleep);
			}
		}

		Thread.sleep(DEFAULT_SLEEP);
		ctx.emitWatermark(new Watermark(Long.MAX_VALUE));
	}

	private RBEATestPipeline then(Either<EventWrapper, Configuration> element, long sleep) {
		data.add(Tuple4.of(EventOrProc.fromEither(element), sleep, Optional.absent(), Optional.absent()));
		return this;
	}

	private EventWrapper createEvent(Long core, String data) {
		return new EventWrapper(CustomEvent.create(0).withField(0, data), core);
	}

	private EventWrapper createEvent(Long core, String data, long ts) {
		return new EventWrapper(CustomEvent.create(0).withField(0, data).withTimeStamp(ts), core);
	}

	public RBEATestPipeline thenFailAndRestoreJob() {
		return thenWait(Time.seconds(3)).then(null, DEFAULT_SLEEP).thenWait(Time.seconds(1));
	}

	public RBEATestPipeline thenEvent(long core, String data, long ts) {
		return then(Either.Left(createEvent(core, data, ts)), DEFAULT_SLEEP).withTimestamp(ts);
	}

	public RBEATestPipeline thenEvent(long core, Event e) {
		return then(Either.Left(new EventWrapper(e, core)), DEFAULT_SLEEP);
	}
	
	public RBEATestPipeline andEvent(long core, Event e) {
		return then(Either.Left(new EventWrapper(e, core)), 0);
	}

	/**
	 * Creates and sends an event with user id {@code code} with content
	 * {@code data}.
	 * 
	 * @param core
	 *            the user id
	 * @param data
	 *            the content
	 * @return self
	 */
	public RBEATestPipeline thenEvent(long core, String data) {
		return then(Either.Left(createEvent(core, data)), DEFAULT_SLEEP);
	}

	public RBEATestPipeline andEvent(long core, String data) {
		return then(Either.Left(createEvent(core, data)), 0);
	}

	public RBEATestPipeline thenEventNoCUID(String data) {
		return then(Either.Left(createEvent(null, data)), DEFAULT_SLEEP);
	}

	public RBEATestPipeline andEventNoCUID(long core, String data) {
		return then(Either.Left(createEvent(null, data)), 0);
	}

	public RBEATestPipeline thenWatermark(long timestamp) {
		data.getLast().f2 = Optional.of(timestamp);
		return this;
	}

	public RBEATestPipeline withTimestamp(long timestamp) {
		data.getLast().f3 = Optional.of(timestamp);
		return this;
	}

	public RBEATestPipeline thenDeployGroovy(long procId, String scriptPath) throws IOException, ProcessorException {
		return then(
				Either.Right(
						Deployment.newGroovyProcessor("", procId, FileUtils.readFileToString(new File(scriptPath)),
								"test", System.currentTimeMillis())),
				DEFAULT_SLEEP);
	}

	public RBEATestPipeline then(long procId, String scriptPath) throws IOException, ProcessorException {
		return then(
				Either.Right(
						Deployment.newGroovyProcessor("", procId, FileUtils.readFileToString(new File(scriptPath)),
								"test", System.currentTimeMillis())),
				DEFAULT_SLEEP);
	}

	public RBEATestPipeline then(Configuration conf) throws IOException, ProcessorException {
		return then(Either.Right(conf),
				DEFAULT_SLEEP);
	}

	public RBEATestPipeline thenDeployJavaFile(long procId, String scriptPath) throws IOException, ProcessorException {
		return then(
				Either.Right(
						Deployment.newJavaCodeProcessor("", procId, FileUtils.readFileToString(new File(scriptPath)),
								"test", System.currentTimeMillis())),
				DEFAULT_SLEEP);
	}

	/**
	 * Deploys processor {@code proc} with id {@code procId} to the Flink job.
	 * 
	 * @param procId
	 *            the processor id
	 * @param proc
	 *            the processor
	 * @return self
	 * @throws ProcessorException
	 */
	public RBEATestPipeline thenDeploy(long procId, Serializable proc) throws ProcessorException {
		return then(Either.Right(Deployment.newJavaProcessor("", procId, proc, "test", System.currentTimeMillis())),
				DEFAULT_SLEEP);
	}

	public RBEATestPipeline thenUpdate(long procId, Serializable proc) throws ProcessorException {
		return then(Either.Right(Deployment.newJavaProcessor("", procId, proc, "test", System.currentTimeMillis())
				.asUpdate()),
				DEFAULT_SLEEP);
	}

	public RBEATestPipeline thenRemoveProcessor(long procId) {
		return then(Either.Right(new Removal(procId, 1L)), DEFAULT_SLEEP);
	}

	public RBEATestPipeline thenWait(long millis) {
		data.getLast().f1 += millis;
		return this;
	}

	public RBEATestPipeline thenWait(Time time) {
		return thenWait(time.toMilliseconds());
	}

	public RBEATestPipeline thenDeploySomethingOnOtherTopic() {
		return then(Either.Right(Deployment.newJavaProcessor("", 6666, new Serializable() {
			private static final long serialVersionUID = 1L;

			@ProcessEvent
			public void process(Output out) throws ProcessorException, BackendException {
				out.print("NOOO");
			}
		}, "other", System.currentTimeMillis())),
				DEFAULT_SLEEP);
	}

	public static RBEATestPipeline starWithEvent(long core, String data) {
		return new RBEATestPipeline().thenEvent(core, data);
	}

	/**
	 * A convenience entry point {@code RBEATestSource} that creates a
	 * {@code RBEATestSource} and deploys processor {@code proc} on that, a
	 * shortcut to creating a new {@code RBEATestSource} and calling
	 * {@link #thenDeploy(long, Serializable)}.
	 * 
	 * @param procId
	 *            the processor id of the deployment
	 * @param proc
	 *            the processor
	 * @return the new instance
	 * @throws ProcessorException
	 *             if fails
	 */
	public static RBEATestPipeline startWithDeployment(long procId, Serializable proc) throws ProcessorException {
		return new RBEATestPipeline().thenDeploy(procId, proc);
	}

	public static RBEATestPipeline startWith(Configuration conf) throws ProcessorException {
		return new RBEATestPipeline().then(Either.Right(conf), DEFAULT_SLEEP);
	}

	public static RBEATestPipeline startWithGroovyDeployment(long procId, String scriptPath)
			throws IOException, ProcessorException {
		return new RBEATestPipeline().then(
				Either.Right(
						Deployment.newGroovyProcessor("", procId, FileUtils.readFileToString(new File(scriptPath)),
								"test", System.currentTimeMillis())),
				DEFAULT_SLEEP);
	}

	public RBEATestPipeline thenUpdateGroovy(long procId, String scriptPath) throws ProcessorException, IOException {
		return then(
				Either.Right(Deployment.newGroovyProcessor("", procId, FileUtils.readFileToString(new File(scriptPath)),
						"test", System.currentTimeMillis())
						.asUpdate()),
				DEFAULT_SLEEP);
	}

	public static RBEATestPipeline startWithJavaCodeDeployment(long procId, String scriptPath)
			throws IOException, ProcessorException {
		return new RBEATestPipeline().then(
				Either.Right(
						Deployment.newJavaCodeProcessor("", procId, FileUtils.readFileToString(new File(scriptPath)),
								"test", System.currentTimeMillis())),
				DEFAULT_SLEEP);
	}

	public static RBEATestPipeline startWithJarDeployment(long procId, String jarURL)
			throws IOException, ProcessorException {
		return new RBEATestPipeline().then(
				Either.Right(
						Deployment.newJarProcessor("", procId, jarURL, "test", System.currentTimeMillis())),
				DEFAULT_SLEEP);
	}

	@Override
	public void cancel() {
		isRunning = false;
	}

	private static class EventOrProc implements Serializable {
		private static final long serialVersionUID = 1L;
		public final boolean isEvent;
		public final EventWrapper event;
		public final Configuration procInfo;

		public EventOrProc(Configuration procInfo) {
			this.isEvent = false;
			this.event = null;
			this.procInfo = procInfo;
		}

		public EventOrProc(EventWrapper event) {
			this.isEvent = true;
			this.event = event;
			this.procInfo = null;
		}

		public static EventOrProc fromEither(Either<EventWrapper, Configuration> e) {
			if (e == null) {
				return null;
			} else if (e.isLeft()) {
				return new EventOrProc(e.left());
			} else {
				return new EventOrProc(e.right());
			}
		}

		public Either<EventWrapper, Configuration> toEither() {
			if (isEvent) {
				return Either.Left(event);
			} else {
				return Either.Right(procInfo);
			}
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void restoreState(List<Serializable> s) throws Exception {
		Tuple2 t = (Tuple2) s.get(0);
		data = (LinkedList<Tuple4<EventOrProc, Long, Optional<Long>, Optional<Long>>>) t.f0;
		index = (int) t.f1;
	}

	@Override
	public List<Serializable> snapshotState(long arg0, long arg1) throws Exception {
		return Collections.singletonList(Tuple2.of(data, index));
	}
}
