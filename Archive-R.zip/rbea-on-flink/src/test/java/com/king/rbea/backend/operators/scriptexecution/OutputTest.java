package com.king.rbea.backend.operators.scriptexecution;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;

import org.apache.flink.types.Either;
import org.apache.flink.util.Collector;
import org.apache.flink.util.InstantiationUtil;
import org.junit.Test;

import com.king.rbea.backend.operators.scriptexecution.CollectingOutput;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.backend.types.bea.BEASerializer;
import com.king.rbea.backend.types.bea.KafkaOutput;
import com.king.rbea.configuration.Configuration;
import com.king.rbea.exceptions.BackendException;
import com.king.rbea.exceptions.ProcessorException;

public class OutputTest {

	@Test
	public void kafkaKeyTest() throws IOException {
		BEASerializer<KafkaOutput> serializer = new BEASerializer<>();

		KafkaOutput kafka = new KafkaOutput(1, "topic", null, "asd".getBytes());

		assertEquals("topic", kafka.getTopic());
		assertEquals("asd", new String(kafka.getBytes()));
		assertFalse(kafka.getKey().isPresent());

		KafkaOutput keyed = new KafkaOutput(1, "topic", "asd".getBytes(), "sad".getBytes());

		assertEquals("topic", keyed.getTopic());
		assertEquals("sad", new String(keyed.getBytes()));
		assertEquals("asd", new String(keyed.getKey().get()));

		kafka = InstantiationUtil.deserializeFromByteArray(serializer,
				InstantiationUtil.serializeToByteArray(serializer, kafka));

		assertEquals("topic", kafka.getTopic());
		assertEquals("asd", new String(kafka.getBytes()));
		assertFalse(kafka.getKey().isPresent());

		keyed = InstantiationUtil.deserializeFromByteArray(serializer,
				InstantiationUtil.serializeToByteArray(serializer, keyed));

		assertEquals("topic", keyed.getTopic());
		assertEquals("sad", new String(keyed.getBytes()));
		assertEquals("asd", new String(keyed.getKey().get()));
	}

	@Test
	public void test() throws ProcessorException, BackendException {
		MyCollector c = new MyCollector();
		CollectingOutput out = new CollectingOutput(c, 100, 2);

		out.print("A");
		assertEquals(new KafkaOutput(100, "PRINT_100", new byte[] { 0, 0, 0, 2 }, "A".getBytes()), c.last);

		out.writeBytesToKafka("t", new byte[] { 1, 2, 3 });
		assertEquals(new KafkaOutput(100, "t", null, new byte[] { 1, 2, 3 }), c.last);

		out.writeToKafka("t", "asd");
		assertEquals(new KafkaOutput(100, "t", null, "asd".getBytes()), c.last);

		try {
			out.writeBytesToKafka("event.candycrush.log", new byte[] { 1, 2, 3 });
			fail();
		} catch (Exception e) {
			assertTrue(e.getMessage().contains("Illegal output Kafka topic"));
		}

		try {
			out.writeToKafka("event.any.log", "asd");
			fail();
		} catch (Exception e) {
			assertTrue(e.getMessage().contains("Illegal output Kafka topic"));
		}
	}

	private static class MyCollector implements Collector<Either<BEA, Configuration>> {

		public BEA last;

		@Override
		public void collect(Either<BEA, Configuration> o) {
			last = o.left();
		}

		@Override
		public void close() {}
	}

}
