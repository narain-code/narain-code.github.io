package com.king.rbea.backend.operators.scriptexecution;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.flink.api.common.ExecutionConfig;
import org.apache.flink.api.common.typeutils.TypeSerializer;
import org.apache.flink.api.java.typeutils.TypeExtractor;
import org.apache.flink.types.Either;
import org.apache.flink.util.Collector;
import org.apache.flink.util.InstantiationUtil;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.junit.Test;

import com.clearspring.analytics.stream.cardinality.HyperLogLog;
import com.king.flink.utils.Unchecked;
import com.king.rbea.aggregators.AggregationWindow;
import com.king.rbea.aggregators.AverageAggregator;
import com.king.rbea.aggregators.Counter;
import com.king.rbea.aggregators.DimensionType;
import com.king.rbea.aggregators.RatioAggregator;
import com.king.rbea.aggregators.SumAggregator;
import com.king.rbea.backend.types.bea.Aggregate;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.backend.types.bea.HLLAggregate;
import com.king.rbea.backend.types.bea.RatioAggregate;
import com.king.rbea.backend.types.bea.SumAggregate;
import com.king.rbea.configuration.Configuration;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.utils.AggregateUtils;

public class AggregatorTest {

	@Test
	public void validateDimensionContent() throws ProcessorException, JSONException {
		Map<String, Object> dims = new HashMap<>();
		Set<String> types = new HashSet<>();

		dims.put("a", null);
		checkProcException(() -> AggregateUtils.createDimJSON(dims, null), "Dimension cannot be null");
		dims.clear();

		dims.put("", 2);
		checkProcException(() -> AggregateUtils.createDimJSON(dims, types), "Cannot have empty dimension name");
		dims.clear();

		char[] chars = new char[255];
		Arrays.fill(chars, 'a');

		dims.put("a", new String(chars));
		AggregateUtils.createDimJSON(dims, null);
		dims.clear();

		chars = new char[256];
		Arrays.fill(chars, 'a');

		dims.put("a", new String(chars));
		checkProcException(() -> AggregateUtils.createDimJSON(dims, null),
				"String dimension (encoded) longer than 255 chars.");
		dims.clear();

		dims.put("a", 2);
		types.add("a");
		dims.put("b", "");
		AggregateUtils.createDimJSON(dims, types);
		dims.clear();
		types.clear();

		dims.put("a", 2);
		dims.put("b", 2.1);
		types.add("a");
		types.add("b");
		checkProcException(() -> AggregateUtils.createDimJSON(dims, types), "Number dimensions must be long values");
		dims.clear();
		types.clear();

		dims.put("a", "\t");
		dims.put("b", 2.00);
		dims.put("c", Long.MAX_VALUE);
		dims.put("d", Long.MIN_VALUE);
		types.add("b");
		types.add("c");
		types.add("d");
		JSONObject jsonObj = new JSONObject(AggregateUtils.createDimJSON(dims, types));
		assertEquals(jsonObj.get("a"), "\t");
		assertEquals(jsonObj.get("b"), 2);
		dims.clear();
	}

	private void checkProcException(Unchecked.ThrowingCallable<?> callable, String text) {
		try {
			callable.call();
			fail();
		} catch (ProcessorException pe) {
			assertTrue(pe.getMessage().contains(text));
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@Test
	public void testDimFormat() throws ProcessorException {
		assertEquals("{}", getAgg(null, null).getDimensions());
		assertEquals("{\"a\":2}",
				getAgg(mapOf("a", 2), Collections.singleton("a"))
						.getDimensions());

		Map<String, Object> dims = new HashMap<>();
		dims.put("a", 2);
		dims.put("b", "a");

		assertEquals("{\"a\":2,\"b\":\"a\"}",
				getAgg(dims, Collections.singleton("a")).getDimensions());
	}

	private Aggregate getAgg(Map<String, ?> dims, Set<String> dimensionTypes) throws ProcessorException {
		return new SumAggregate(1l, 2l, "", AggregateUtils.createDimJSON(dims, dimensionTypes), 100l);
	}

	@Test
	public void testSum() throws ProcessorException {
		MyCollector c = new MyCollector();
		CollectingAggregators agg = new CollectingAggregators(c, 100);

		SumAggregator sum = agg.getSumAggregator("a", AggregationWindow.MINUTES_1);
		sum.setStringDimension("0", "a");
		sum.add(5);
		assertEquals(new SumAggregate(100L, 60000L, "a_100",
				AggregateUtils.createDimJSON(mapOf("0", "a"), null), 5L),
				c.last);

		sum.add(6);
		assertEquals(new SumAggregate(100L, 60000L, "a_100",
				AggregateUtils.createDimJSON(mapOf("0", "a"), null), 6L),
				c.last);

		sum.setStringDimension("0", "a");
		sum.setTableName("MY_TABLE");
		sum.add(7);
		assertEquals(
				new SumAggregate(100L, 60000L, "MY_TABLE",
						AggregateUtils.createDimJSON(mapOf("0", "a"), null),
						7L),
				c.last);

	}

	@Test
	public void testSetDimension() throws ProcessorException {
		MyCollector c = new MyCollector();
		CollectingAggregators agg = new CollectingAggregators(c, 100);

		SumAggregator sum = agg.getSumAggregator("a", AggregationWindow.MINUTES_1);
		sum.setStringDimension("dim1", "a");
		sum.setLongDimension("dim2", 2);
		sum.add(5);
		assertEquals(new SumAggregate(100L, 60000L, "a_100",
				AggregateUtils.createDimJSON(mapOf("dim1", "a", "dim2", 2), Collections.singleton("dim2")), 5L),
				c.last);

		assertEquals("{\"dim1\":\"a\",\"dim2\":2}",
				AggregateUtils.createDimJSON(mapOf("dim1", "a", "dim2", 2), Collections.singleton("dim2")));
	}

	@Test
	public void testNaming() throws ProcessorException {
		MyCollector c = new MyCollector();
		CollectingAggregators agg = new CollectingAggregators(c, 100);

		Counter counter = agg.getCounter(" a b ", AggregationWindow.MINUTES_1);
		counter.increment();
		assertEquals(new SumAggregate(100L, 60000L, "a_b_100", "{}", 1L), c.last);
		counter.setTableName("valid_table");
		try {
			counter.setTableName("invalid table").increment();
			fail();
		} catch (ProcessorException e) {}

		try {
			counter.setTableName("1asd").decrement();
			fail();
		} catch (ProcessorException e) {}

		try {
			counter.setTableName(
					"waaaaaaaaaaaaaaaaaaaaaaaaaaaytoooooooooooooooooooooooooooooooooooooooooolooooooooooooooooooooooooong")
					.increment();
			fail();
		} catch (ProcessorException e) {}

		try {
			((Counter) agg.getCounter("2ab", AggregationWindow.MINUTES_1)).increment();
			fail();
		} catch (ProcessorException e) {}

		try {
			((Counter) agg.getCounter(
					"waaaaaaaaaaaaaaaaaaaaaaaaaaaytoooooooooooooooooooooooooooooooooooooooooolooooooooooooooooooooooooong",
					AggregationWindow.MINUTES_1)).increment();
			fail();
		} catch (ProcessorException e) {}

	}

	@Test
	public void testRatio() throws ProcessorException {
		MyCollector c = new MyCollector();
		CollectingAggregators agg = new CollectingAggregators(c, 100);

		RatioAggregator ratio = agg.getRatioAggregator("A", AggregationWindow.MINUTES_10);

		ratio.addToNumerator(10);
		Aggregate r = (Aggregate) c.last;

		ratio.addToDenominator(5);
		r.update((Aggregate) c.last);

		ratio.addToNumerator(5);
		r.update((Aggregate) c.last);

		assertEquals(new RatioAggregate(100, 600000, "A_100", "{}", 15, 5), r);
		assertEquals(3 * 1_000_000, r.getLongValue());

		ratio.addToDenominator(25);
		r.update((Aggregate) c.last);

		assertEquals(500000, r.getLongValue());

		assertEquals(0, new RatioAggregate(100, 600000, "A_100", "", 15, 0).getLongValue());
	}

	private static <T> Map<String, T> mapOf(String k, T val, String k2, T val2) {
		Map<String, T> map = new TreeMap<>();
		map.put(k, val);
		map.put(k2, val2);
		return map;
	}

	private static <T> Map<String, T> mapOf(String k, T val) {
		Map<String, T> map = new TreeMap<>();
		map.put(k, val);
		return map;
	}

	@Test
	public void testAvg() throws ProcessorException {
		MyCollector c = new MyCollector();
		CollectingAggregators agg = new CollectingAggregators(c, 100);

		AverageAggregator ratio = agg.getAverageAggregator("A", AggregationWindow.MINUTES_10);
		ratio
				.groupBy(mapOf("dim", 1))
				.setGroupTypes(mapOf("dim", DimensionType.LONG));

		ratio.add(10);
		Aggregate r = (Aggregate) c.last;

		ratio.add(5);
		r.update((Aggregate) c.last);

		ratio.add(15);
		r.update((Aggregate) c.last);

		assertEquals(
				new RatioAggregate(100, 600000, "A_100", AggregateUtils.createDimJSON(mapOf("dim", 1),
						Collections.singleton("dim")),
						30, 3),
				r);
		assertEquals(10 * 1_000_000, r.getLongValue());

		ratio.add(-26);
		r.update((Aggregate) c.last);

		assertEquals(1_000_000, r.getLongValue());

	}

	@SuppressWarnings("deprecation")
	@Test
	public void testCounter() throws ProcessorException {
		MyCollector c = new MyCollector();
		CollectingAggregators agg = new CollectingAggregators(c, 100);

		Counter counter = agg.getCounter("a", AggregationWindow.MINUTES_1);
		counter.setDimensions("a");
		counter.increment();
		assertEquals(new SumAggregate(100L, 60000L, "a_100",
				AggregateUtils.createDimJSON(mapOf("0", "a"), null), 1L),
				c.last);

		counter.groupBy(mapOf("a", 1));
		counter.increment();
		assertEquals(
				new SumAggregate(100L, 60000L, "a_100", AggregateUtils.createDimJSON(mapOf("a", 1),
						new HashSet<>()), 1L),
				c.last);

		counter.groupBy("a");
		counter.setTableName("MY_TABLE");
		counter.increment();
		assertEquals(
				new SumAggregate(100L, 60000L, "MY_TABLE",
						AggregateUtils.createDimJSON(mapOf("0", "a"), null),
						1L),
				c.last);
	}

	/**
	 * Tests updating HLL aggregate with large number of hashes yields to an
	 * estimate "good enough".
	 */
	@Test
	public void hyperLogLogEstimation() throws IOException {
		HLLAggregate agg = new HLLAggregate(1, 2, "3", "{}", 1000);

		int count = 1_000_000;
		for (int i = 0; i < count; i++) {
			agg.update(new HLLAggregate(1, 2, "3", "{}", i));
		}

		assertTrue(agg.getValue() instanceof HyperLogLog);
		assertTrue(Math.abs(agg.getLongValue() - count) < count * 0.05);
	}

	/**
	 * Tests ser/deser cycle of {@link HLLAggregate} works.
	 */
	@Test
	public void hyperLogLogFlinkSerialization() throws Exception {
		HLLAggregate agg = new HLLAggregate(1, 2, "3", "{}", 1000);
		for (int i = 0; i < 100; i++) {
			agg.update(new HLLAggregate(1, 2, "3", "{}", i));
			HLLAggregate agg2 = serializeAndDeserialize(agg);
			assertEquals(agg.getDimensions(), agg2.getDimensions());
			assertEquals(agg.getLongValue(), agg2.getLongValue());
			assertEquals(agg.getName(), agg2.getName());
		}
	}

	/**
	 * Tests that updating two HLL aggregate with large number of hashes and merging
	 * the HLLs yields to an estimate "good enough".
	 */
	@Test
	public void hyperLogMergeEstimation() throws Exception {
		HLLAggregate agg1 = new HLLAggregate(1, 2, "3", "{}", 1000);
		HLLAggregate agg2 = new HLLAggregate(1, 2, "3", "{}", 1000);

		int count = 1_000_000;

		for (int i = 0; i < count; i++) {
			agg1.update(new HLLAggregate(1, 2, "3", "{}", i));
		}

		Base64.getEncoder().encodeToString(serialize(agg1.container.hll));

		for (int i = count; i < (count * 2); i++) {
			agg2.update(new HLLAggregate(1, 2, "3", "{}", i));
		}
		long error = Math.abs(agg1.getValue().merge(agg2.getValue()).cardinality()) - (count * 2);
		assertTrue("" + error, error < (count * 2) * 0.05);
	}

	public static byte[] serialize(Serializable obj) {
		try {
			ByteArrayOutputStream baos = new ByteArrayOutputStream(512);
			ObjectOutputStream out = null;
			try {
				// stream closed in the finally
				out = new ObjectOutputStream(baos);
				out.writeObject(obj);
			} finally {
				if (out != null) {
					out.close();
				}
			}
			return baos.toByteArray();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	@Test
	public void hyperLogLogTest() throws IOException {
		HLLAggregate hll1 = new HLLAggregate(1, 2, "3", "{}", 1000);
		HLLAggregate hll2 = new HLLAggregate(1, 2, "3", "{}", 2000);
		assertNull(hll1.container);
		hll1.update(hll2);
		assertNotNull(hll1.container);

		HLLAggregate hll3 = serializeAndDeserialize(hll1);
		assertNotNull(hll3.container);
		hll1.update(hll3);

		assertEquals(1, hll2.getLongValue());
		hll2.update(hll1);
		assertEquals(2, hll2.getLongValue());
		assertEquals(2, hll3.getLongValue());
		assertEquals(2, hll1.getLongValue());
	}

	private HLLAggregate serializeAndDeserialize(HLLAggregate agg) throws IOException {
		TypeSerializer<HLLAggregate> serializer = TypeExtractor.getForClass(HLLAggregate.class)
				.createSerializer(new ExecutionConfig());
		return InstantiationUtil.deserializeFromByteArray(serializer,
				InstantiationUtil.serializeToByteArray(serializer, agg));
	}

	private static class MyCollector implements Collector<Either<BEA, Configuration>> {

		public BEA last;

		@Override
		public void collect(Either<BEA, Configuration> o) {
			last = o.left();
		}

		@Override
		public void close() {}
	}

}
