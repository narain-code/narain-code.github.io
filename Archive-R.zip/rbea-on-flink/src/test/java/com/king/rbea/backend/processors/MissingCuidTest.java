package com.king.rbea.backend.processors;

import static org.junit.Assert.assertTrue;

import java.io.Serializable;
import java.util.List;

import org.apache.flink.api.java.tuple.Tuple2;
import org.junit.Test;

import com.google.common.collect.Lists;
import com.king.event.Event;
import com.king.rbea.Output;
import com.king.rbea.State;
import com.king.rbea.Timers;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.annotations.ProcessingPolicy;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.backend.types.bea.KafkaOutput;
import com.king.rbea.configuration.processor.ProcessorInfo;
import com.king.rbea.exceptions.ProcessorException;

public class MissingCuidTest extends ProcessorTestBase {
	private static final long serialVersionUID = 1L;

	public MissingCuidTest() {
		super();
	}

	@Test
	public void test() throws Exception {
		RBEATestPipeline pipeline = RBEATestPipeline
				.startWithDeployment(1000, new PrintingProcessor())
				.thenEvent(2, "a")
				.thenEventNoCUID("b")
				.thenEvent(3, "c");

		Tuple2<List<ProcessorInfo>, List<BEA>> testOutput = executeProcessor(pipeline);
		List<ProcessorInfo> infoOutput = testOutput.f0;
		List<BEA> beaOutput = testOutput.f1;

		assertTrue(infoOutput.toString(), withoutRuntimeStatistics(infoOutput).isEmpty());
		validateSet(Lists.newArrayList(
				new KafkaOutput(1000, "PRINT_1000", null, "IGNORE_a".getBytes()),
				new KafkaOutput(1000, "PRINT_1000", null, "PROCESS_a".getBytes()),
				new KafkaOutput(1000, "PRINT_1000", null, "PROCESS_b".getBytes()),
				new KafkaOutput(1000, "PRINT_1000", null, "PROCESS_ONLY_b".getBytes()),
				new KafkaOutput(1000, "PRINT_1000", null, "IGNORE_c".getBytes()),
				new KafkaOutput(1000, "PRINT_1000", null, "PROCESS_c".getBytes())), beaOutput);
	}

	public static class PrintingProcessor implements Serializable {
		private static final long serialVersionUID = 1L;

		@ProcessEvent
		public void ignore(Event event, Output out) throws Exception {
			out.writeToKafka("PRINT_1000", "IGNORE_" + event.getString(0));
		}

		@ProcessEvent(missingCUID = ProcessingPolicy.PROCESS)
		public void process(Event event, Output out) throws Exception {
			out.writeToKafka("PRINT_1000", "PROCESS_" + event.getString(0));
		}

		@ProcessEvent(missingCUID = ProcessingPolicy.PROCESS_ONLY)
		public void processOnly(Event event, Output out, Timers t, State s) throws Exception {
			out.writeToKafka("PRINT_1000", "PROCESS_ONLY_" + event.getString(0));
			try {
				t.registerTimer(1, "");
			} catch (ProcessorException e) {}

			try {
				t.removeAllTimers();
			} catch (ProcessorException e) {}

			try {
				t.removeTimer(2);
			} catch (ProcessorException e) {}

			try {
				s.get("a");
			} catch (ProcessorException e) {}

			try {
				s.get(2, "a");
			} catch (ProcessorException e) {}
		}
	}
}
