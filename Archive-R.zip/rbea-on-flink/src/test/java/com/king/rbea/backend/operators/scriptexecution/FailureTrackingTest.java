package com.king.rbea.backend.operators.scriptexecution;

import static com.king.rbea.testutils.RBeaOperatorTestUtils.createRBEAHarness;
import static com.king.rbea.testutils.RBeaOperatorTestUtils.input;
import static org.junit.Assert.assertTrue;

import java.io.Serializable;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.TimeUnit;

import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.apache.flink.streaming.util.KeyedTwoInputStreamOperatorTestHarness;
import org.apache.flink.types.Either;
import org.junit.Test;

import com.king.flink.utils.CustomEvent;
import com.king.rbea.Output;
import com.king.rbea.State;
import com.king.rbea.annotations.OnError;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.backend.types.EventWrapper;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.backend.types.bea.KafkaOutput;
import com.king.rbea.backend.types.processorinfo.RuntimeStatistics;
import com.king.rbea.configuration.Configuration;
import com.king.rbea.configuration.processor.Deployment;
import com.king.rbea.configuration.processor.Failure;
import com.king.rbea.configuration.processor.Notification;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.state.baseprocessors.DefaultBaseProcessorProvider;
import com.king.rbea.testutils.ManualTicker;
import com.king.rbea.testutils.RBeaOperatorTestUtils;

public class FailureTrackingTest {

	@Test
	public void basicTest() throws Exception {

		KeyedTwoInputStreamOperatorTestHarness<Long, EventWrapper, Configuration, Either<BEA, Configuration>> harness = createRBEAHarness(
				DefaultBaseProcessorProvider.INSTANCE.getBaseProcessors());

		ManualTicker ticker = (ManualTicker) RBeaOperatorTestUtils.getRbeaOperator(harness).getTicker();

		harness.processElement2(input(Deployment.newJavaProcessor("", 10000, new Serializable() {
			private static final long serialVersionUID = 1L;

			@ProcessEvent(eventType = 1337)
			public void error(State state, Output out) throws ProcessorException {
				throw new RuntimeException("YO");
			}

			@ProcessEvent(eventType = 1338)
			public void process(State state, Output out) throws ProcessorException {
				out.print("hi");
			}

		}, "", 1).withErrorTolerance(3)));

		@SuppressWarnings({ "rawtypes", "unchecked" })
		ConcurrentLinkedQueue<StreamRecord<Either<BEA, Configuration>>> output = (ConcurrentLinkedQueue) harness
				.getOutput();

		output.clear();
		harness.processElement1(input(CustomEvent.create(1337), 100));
		assertTrue(getNextNonStat(output).right() instanceof Notification);

		harness.processElement1(input(CustomEvent.create(1338), 100));
		assertTrue(getNextNonStat(output).left() instanceof KafkaOutput);

		ticker.add(TimeUnit.SECONDS.toNanos(10));
		harness.processElement1(input(CustomEvent.create(1337), 100));
		assertTrue(getNextNonStat(output).right() instanceof Notification);

		ticker.add(TimeUnit.SECONDS.toNanos(10));
		harness.processElement1(input(CustomEvent.create(1337), 100));
		assertTrue(getNextNonStat(output).right() instanceof Notification);

		harness.processElement1(input(CustomEvent.create(1338), 100));
		assertTrue(getNextNonStat(output).left() instanceof KafkaOutput);

		ticker.add(TimeUnit.SECONDS.toNanos(45));
		harness.processElement1(input(CustomEvent.create(1337), 100));
		assertTrue(getNextNonStat(output).right() instanceof Notification);

		harness.processElement1(input(CustomEvent.create(1337), 100));
		assertTrue(getNextNonStat(output).right() instanceof Failure);
	}

	@Test
	public void annotatedTest() throws Exception {

		KeyedTwoInputStreamOperatorTestHarness<Long, EventWrapper, Configuration, Either<BEA, Configuration>> harness = createRBEAHarness(
				DefaultBaseProcessorProvider.INSTANCE.getBaseProcessors());

		ManualTicker ticker = (ManualTicker) RBeaOperatorTestUtils.getRbeaOperator(harness).getTicker();

		harness.processElement2(input(Deployment.newJavaProcessor("", 10000, new Serializable() {
			private static final long serialVersionUID = 1L;

			@ProcessEvent(eventType = 1337)
			public void error(State state, Output out) throws ProcessorException {
				throw new RuntimeException("YO");
			}

			@ProcessEvent(eventType = 1338)
			public void process(State state, Output out) throws ProcessorException {
				out.print("hi");
			}

			@OnError(maxErrorsPerMin = 3)
			public void doNothing() {}

		}, "", 1)));

		@SuppressWarnings({ "rawtypes", "unchecked" })
		ConcurrentLinkedQueue<StreamRecord<Either<BEA, Configuration>>> output = (ConcurrentLinkedQueue) harness
				.getOutput();

		output.clear();
		harness.processElement1(input(CustomEvent.create(1337), 100));
		assertTrue(getNextNonStat(output).right() instanceof Notification);

		harness.processElement1(input(CustomEvent.create(1338), 100));
		assertTrue(getNextNonStat(output).left() instanceof KafkaOutput);

		ticker.add(TimeUnit.SECONDS.toNanos(10));
		harness.processElement1(input(CustomEvent.create(1337), 100));
		assertTrue(getNextNonStat(output).right() instanceof Notification);

		ticker.add(TimeUnit.SECONDS.toNanos(10));
		harness.processElement1(input(CustomEvent.create(1337), 100));
		assertTrue(getNextNonStat(output).right() instanceof Notification);

		harness.processElement1(input(CustomEvent.create(1338), 100));
		assertTrue(getNextNonStat(output).left() instanceof KafkaOutput);

		ticker.add(TimeUnit.SECONDS.toNanos(45));
		harness.processElement1(input(CustomEvent.create(1337), 100));
		assertTrue(getNextNonStat(output).right() instanceof Notification);

		harness.processElement1(input(CustomEvent.create(1337), 100));
		assertTrue(getNextNonStat(output).right() instanceof Failure);
	}

	public Either<BEA, Configuration> getNextNonStat(
			ConcurrentLinkedQueue<StreamRecord<Either<BEA, Configuration>>> output) {
		while (!output.isEmpty()) {
			Either<BEA, Configuration> value = output.poll().getValue();
			if (value.isRight() && value.right() instanceof RuntimeStatistics) {
				continue;
			} else {
				return value;
			}
		}
		return null;
	}

}
