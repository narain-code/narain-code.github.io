package com.king.rbea.backend.processors;

import static org.junit.Assert.assertEquals;

import java.io.Serializable;
import java.util.List;

import org.apache.flink.api.java.tuple.Tuple2;
import org.junit.Test;

import com.google.common.collect.Lists;
import com.king.rbea.Output;
import com.king.rbea.Registry;
import com.king.rbea.State;
import com.king.rbea.Timers;
import com.king.rbea.annotations.Initialize;
import com.king.rbea.annotations.OnSessionEnd;
import com.king.rbea.annotations.OnTimer;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.backend.types.bea.KafkaOutput;
import com.king.rbea.backend.utils.BackendConstants;
import com.king.rbea.configuration.processor.ProcessorInfo;
import com.king.rbea.exceptions.BackendException;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.state.LocalState;
import com.king.rbea.state.StateDescriptor;
import com.king.rbea.testutils.SCLong;

public class TimerTest2 extends ProcessorTestBase {
	private static final long serialVersionUID = 1L;

	public TimerTest2() {
		super();
	}

	@Test
	public void test() throws Exception {
		RBEATestPipeline pipeline = RBEATestPipeline
				.startWithDeployment(1000, new TimerTestProcessor())
				.thenEvent(1, "700", 700)
				.thenWatermark(800)
				.thenEvent(1, "1000", 1000)
				.thenWatermark(1600)
				.thenEvent(1, "1700", 1700)
				.thenWatermark(2000 + BackendConstants.SESSION_TIMEOUT)
				.thenEvent(1, "100");

		Tuple2<List<ProcessorInfo>, List<BEA>> testOutput = executeProcessor(pipeline);
		List<BEA> beaOutput = testOutput.f1;
		List<ProcessorInfo> infoOut = testOutput.f0;

		assertEquals(infoOut.toString(), 0, withoutRuntimeStatistics(infoOut).size());

		validateExact(Lists.newArrayList(
				new KafkaOutput(1000, "out", null, "1000".getBytes()),
				new KafkaOutput(1000, "out", null, "1000".getBytes()),
				new KafkaOutput(1000, "out", null, "2000".getBytes())), beaOutput);
	}

	public static class TimerTestProcessor implements Serializable {
		private static final long serialVersionUID = 1L;
		private StateDescriptor<Integer> s;

		@ProcessEvent(semanticClass = SCLong.class)
		public void processEvent(Timers timers, SCLong l, State state, Output out) throws Exception {
			timers.registerTimer(l.get(), l.get());
			if (state.get(s) > 0) {
				out.writeToKafka("out", state.get(s));
			}
		}

		@OnTimer
		public void onTimer(State state) throws ProcessorException, BackendException {
			state.update(s, 1000);
		}

		@OnSessionEnd
		public void end(State state) throws ProcessorException, BackendException {
			state.update(s, 2000);
		}

		@Initialize
		public void initialize(Registry reg) throws Exception {
			s = reg.registerState(LocalState.create("i", 0));
		}
	}
}
