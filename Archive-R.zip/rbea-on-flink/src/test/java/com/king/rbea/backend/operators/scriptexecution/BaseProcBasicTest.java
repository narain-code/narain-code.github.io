package com.king.rbea.backend.operators.scriptexecution;

import static com.king.rbea.testutils.RBeaOperatorTestUtils.advanceWatermark;
import static com.king.rbea.testutils.RBeaOperatorTestUtils.createRBEAHarness;
import static com.king.rbea.testutils.RBeaOperatorTestUtils.input;
import static java.util.Collections.emptyList;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.io.Serializable;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.flink.api.java.tuple.Tuple1;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.apache.flink.streaming.util.KeyedTwoInputStreamOperatorTestHarness;
import org.apache.flink.types.Either;
import org.junit.Test;

import com.google.common.collect.Lists;
import com.king.event.Event;
import com.king.flink.utils.CustomEvent;
import com.king.rbea.State;
import com.king.rbea.Timers;
import com.king.rbea.annotations.Close;
import com.king.rbea.annotations.Initialize;
import com.king.rbea.annotations.OnConfigUpdate;
import com.king.rbea.annotations.OnError;
import com.king.rbea.annotations.OnSessionEnd;
import com.king.rbea.annotations.OnTimer;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.backend.types.EventWrapper;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.configuration.Configuration;
import com.king.rbea.configuration.processor.Deployment;
import com.king.rbea.configuration.processor.JobConfig;
import com.king.rbea.configuration.processor.Removal;
import com.king.rbea.exceptions.BackendException;
import com.king.rbea.exceptions.ProcessorException;

@SuppressWarnings("serial")
public class BaseProcBasicTest {

	@Test(expected = BackendException.class)
	public void stateErrorTest() throws Exception {

		List<Deployment> baseProcs = Lists
				.newArrayList(Deployment.newJavaProcessor("B1", Long.MAX_VALUE - 100, new Serializable() {
					@ProcessEvent
					public void process2(State state) throws ProcessorException {
						state.update("BS2", "nooo");
					}
				}, "", 0));

		createRBEAHarness(baseProcs)
				.processElement1(input(CustomEvent.create(100l).withField(0, "a"), 1000));
	}

	@Test(expected = BackendException.class)
	public void runtimeErrorTest() throws Exception {

		List<Deployment> baseProcs = Lists
				.newArrayList(Deployment.newJavaProcessor("B1", Long.MAX_VALUE - 100, new Serializable() {
					@ProcessEvent
					public void process2(State state) throws ProcessorException {
						throw new RuntimeException("Test");
					}
				}, "", 0));

		createRBEAHarness(baseProcs)
				.processElement1(input(CustomEvent.create(100l).withField(0, "a"), 1000));
	}

	@Test(expected = BackendException.class)
	public void initErrorTest() throws Exception {
		List<Deployment> baseProcs = Lists
				.newArrayList(Deployment.newJavaProcessor("B1", Long.MAX_VALUE - 100, new Serializable() {
					@Initialize
					public void init() {
						throw new RuntimeException("Hi");
					}
				}, "", 0));

		createRBEAHarness(baseProcs);
	}

	@Test
	public void shouldCloseOnRemoval() throws Exception {
		final long procId = Integer.MAX_VALUE - 100;
		final AtomicInteger ai = new AtomicInteger(0);

		final Deployment deployment = Deployment.newJavaProcessor("B1", procId, new Serializable() {
			@Close
			public void onClose() {
				ai.incrementAndGet();
			}
		}, "", 0);

		final KeyedTwoInputStreamOperatorTestHarness<Long, EventWrapper, Configuration, Either<BEA, Configuration>> op = createRBEAHarness(emptyList());
		op.processElement2(input(deployment));
		op.processElement2(input(new Removal(procId, 1000)));
		advanceWatermark(op, 1000);

		assertEquals(1, ai.get());
	}

	@Test
	public void shouldCloseOnError() throws Exception {
		final long procId = Integer.MAX_VALUE - 100;
		final AtomicInteger ai = new AtomicInteger(0);

		final Deployment deployment = Deployment.newJavaProcessor("B1", procId, new Serializable() {
			@ProcessEvent
			public void onEvent() {
				throw new RuntimeException("yo");
			}

			@Close
			public void onClose() {
				ai.incrementAndGet();
			}
		}, "", 0);

		final KeyedTwoInputStreamOperatorTestHarness<Long, EventWrapper, Configuration, Either<BEA, Configuration>> op = createRBEAHarness(emptyList());
		op.processElement2(input(deployment));
		op.processElement1(input(CustomEvent.create(100l), 1000));
		advanceWatermark(op, 1000);

		assertEquals(1, ai.get());
	}

	@Test(expected = BackendException.class)
	public void timerTest() throws Exception {

		List<Deployment> baseProcs = Lists
				.newArrayList(Deployment.newJavaProcessor("B1", Long.MAX_VALUE - 100, new Serializable() {
					@ProcessEvent
					public void process2(Timers t) throws ProcessorException {
						t.registerTimerWithId(0, 1000);
					}

					@OnTimer
					public void onTime() {
						throw new RuntimeException("yo");
					}
				}, "", 0));

		KeyedTwoInputStreamOperatorTestHarness<Long, EventWrapper, Configuration, Either<BEA, Configuration>> op = createRBEAHarness(
				baseProcs);

		op.processElement1(input(CustomEvent.create(100l).withField(0, "a"), 1000));
		advanceWatermark(op, 1000);
	}

	@Test(expected = BackendException.class)
	public void sessionTest() throws Exception {

		List<Deployment> baseProcs = Lists
				.newArrayList(Deployment.newJavaProcessor("B1", Long.MAX_VALUE - 100, new Serializable() {

					@OnSessionEnd
					public void onTime() {
						throw new RuntimeException("yo");
					}
				}, "", 0));

		KeyedTwoInputStreamOperatorTestHarness<Long, EventWrapper, Configuration, Either<BEA, Configuration>> op = createRBEAHarness(
				baseProcs);

		op.processElement1(input(CustomEvent.create(100l).withTimeStamp(1000).withField(0, "a"), 1000));
		advanceWatermark(op, 1000);
		advanceWatermark(op, 10000000);
	}

	@Test
	public void confTest() throws Exception {
		Tuple1<String> t = Tuple1.of(null);
		long id = Long.MAX_VALUE - 100;

		List<Deployment> baseProcs = Lists
				.newArrayList(Deployment.newJavaProcessor("B1", id, new Serializable() {
					@OnConfigUpdate
					public void doIt(String conf) {
						t.f0 = conf;
					}
				}, "", 0, false).withInitialConfig("asd"));

		createRBEAHarness(baseProcs)
				.processElement2(new StreamRecord<>(new JobConfig(id, "test")));
		assertEquals("test", t.f0);
	}

	@Test
	public void onErrTest() throws Exception {
		long id = Long.MAX_VALUE - 100;

		List<Deployment> baseProcs = Lists
				.newArrayList(Deployment.newJavaProcessor("B1", id, new Serializable() {

					@OnError(maxErrorsPerMin = 10)
					public void onErr(Throwable t) {
						// ignore
					}

					@ProcessEvent
					public void doIt(Event e) throws Exception {
						String string = e.getString(0);
						if (string.equals("err")) {
							throw new BackendException("hi");
						} else {
							throw new Exception("ouch");
						}
					}

				}, "", 0));

		KeyedTwoInputStreamOperatorTestHarness<Long, EventWrapper, Configuration, Either<BEA, Configuration>> harness = createRBEAHarness(
				baseProcs);
		harness.processElement1(input(CustomEvent.create(0).withField(0, "not err"), 1));
		try {
			harness.processElement1(input(CustomEvent.create(0).withField(0, "err"), 1));
			fail();
		} catch (BackendException be) {
			assertEquals("hi", be.getMessage());
		}
	}

}
