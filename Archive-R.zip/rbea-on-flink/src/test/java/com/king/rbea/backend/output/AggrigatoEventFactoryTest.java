package com.king.rbea.backend.output;

import static org.junit.Assert.assertEquals;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.UnsupportedEncodingException;

import org.apache.commons.codec.binary.Base64InputStream;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xerial.snappy.SnappyInputStream;

import com.clearspring.analytics.stream.cardinality.HyperLogLog;

/**
 * Tests for {@link AggrigatoEventFactory}.
 */
public class AggrigatoEventFactoryTest {
	private final Logger logger = LoggerFactory.getLogger(getClass());

	/**
	 * Tests the serialization used in the Kafka-event for HLL works.
	 */
	@Test
	public void testSerializeDeserialize() throws Exception {
		HyperLogLog hll = new HyperLogLog(14);
		hll.offer("abc");
		hll.offer("def");
		
		AggrigatoEventFactory factory = new AggrigatoEventFactory();
		String hllString = factory.serializeHyperLogLog(hll);
		logger.debug("Size {}", hllString.length());
		HyperLogLog hll2 = deserializeHyperLogLog(hllString);
		
		assertEquals(hll.cardinality(), hll2.cardinality());
	}
	
	private HyperLogLog deserializeHyperLogLog(String hllString) throws ClassNotFoundException, UnsupportedEncodingException, IOException {
		try (ObjectInputStream ois = new ObjectInputStream(new SnappyInputStream(new Base64InputStream(new ByteArrayInputStream(hllString.getBytes("UTF-8")))))) {
			return (HyperLogLog) ois.readObject();
		}
	}
}
