package com.king.rbea.backend.processors.javacode;

import java.io.Serializable;
import java.util.List;

import org.apache.flink.api.java.tuple.Tuple2;
import org.junit.Test;

import com.king.rbea.Output;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.backend.processors.ProcessorTestBase;
import com.king.rbea.backend.processors.RBEATestPipeline;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.configuration.processor.ProcessorInfo;
import com.king.rbea.testutils.SCLong;

public class JavaCodeTest extends ProcessorTestBase {

	private static final long serialVersionUID = 1L;

	@Test
	public void test() throws Exception {

		RBEATestPipeline source = RBEATestPipeline
				.startWithJavaCodeDeployment(1000,
						"src/test/java/com/king/rbea/backend/processors/javacode/NestedTypeProc.java")
				.thenEvent(1, "")
				.thenEvent(1, "")

				// Validate job + state restore
				.thenFailAndRestoreJob()

				.thenEvent(1, "")
				.thenEvent(1, "");

		Tuple2<List<ProcessorInfo>, List<BEA>> testOutput = executeProcessor(source);
		List<ProcessorInfo> infoOutput = testOutput.f0;
		List<BEA> beaOutput = testOutput.f1;

		System.out.println(infoOutput);
		System.out.println(beaOutput);
	}

	public static class PrintingProcessor implements Serializable {
		private static final long serialVersionUID = 1L;

		@ProcessEvent
		public void process(com.king.event.Event event, Output out) throws Exception {
			if (SCLong.process(event) == null) {
				out.print(event.getString(0));
			}
		}
	}
}
