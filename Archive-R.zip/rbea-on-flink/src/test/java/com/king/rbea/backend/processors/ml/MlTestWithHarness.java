package com.king.rbea.backend.processors.ml;

import static com.king.rbea.testutils.RBeaOperatorTestUtils.createRBEAHarness;
import static com.king.rbea.testutils.RBeaOperatorTestUtils.input;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.apache.commons.io.IOUtils;
import org.apache.flink.streaming.api.watermark.Watermark;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.apache.flink.streaming.util.KeyedTwoInputStreamOperatorTestHarness;
import org.apache.flink.types.Either;
import org.junit.Assert;
import org.junit.Test;

import com.king.event.Event;
import com.king.rbea.State;
import com.king.rbea.backend.operators.FieldIdAssigner;
import com.king.rbea.backend.operators.scriptexecution.RBEAOperator;
import com.king.rbea.backend.processors.ml.simulator.GameSession;
import com.king.rbea.backend.types.EventWrapper;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.configuration.Configuration;
import com.king.rbea.configuration.processor.Deployment;
import com.king.rbea.scripts.proxy.ProxyExecutorFactory;
import com.king.rbea.state.globalstate.GeneralGlobalStateScript;
import com.king.rbea.state.globalstate.GlobalState;
import com.king.rbea.state.globalstate.GlobalStateUtility;
import com.king.rbea.state.globalstate.LevelGlobalStateScript;
import com.king.rbea.state.globalstate.SpendGlobalStateScript;
import com.king.rbea.state.globalstate.UniversalGlobalStateScript;
import com.king.rbea.testutils.RBeaOperatorTestUtils;

public class MlTestWithHarness {

	private static KeyedTwoInputStreamOperatorTestHarness<Long, EventWrapper, Configuration, Either<BEA, Configuration>> harness;

	private static void congestEvents(List<Event> events) throws Exception {
		for (Event event : events) {
			harness.processElement1(input(event));
			harness.processWatermark1(new Watermark(event.getTimeStamp()));
			System.out.println(String.valueOf(event.getTimeStamp()) + ": " + event.fields());
		}
		events.clear();
	}

	@Test
	public void test() throws Exception {

		// Default Configurations
		String configJson = IOUtils.toString(getClass().getClassLoader().getResourceAsStream("postproc_config.json"),
				StandardCharsets.UTF_8);

		// Init Operator
		harness = createRBEAHarness(
				Arrays.asList(
						UniversalGlobalStateScript.DEPLOYMENT,
						GeneralGlobalStateScript.DEPLOYMENT,
						SpendGlobalStateScript.DEPLOYMENT,
						LevelGlobalStateScript.DEPLOYMENT));

		RBEAOperator op = RBeaOperatorTestUtils.getRbeaOperator(harness);

		harness.processWatermark2(new Watermark(Long.MAX_VALUE));

		@SuppressWarnings({ "rawtypes", "unchecked" })
		ConcurrentLinkedQueue<StreamRecord<Either<BEA, Configuration>>> output = (ConcurrentLinkedQueue) harness
				.getOutput();

		MlTestWithHarnessProcessor testProcessor = new MlTestWithHarnessProcessor();
		FieldIdAssigner idAssigner = new FieldIdAssigner();
		idAssigner.setProcessorFactory(ProxyExecutorFactory.builder().build());

		harness.processElement2(
				input(idAssigner.map(
						Deployment.newJavaProcessor("", 1000, testProcessor, "", 1, false)
								.withInitialConfig(configJson))));

		output.clear();

		/**
		 * Test Part 1
		 */
		// Mocking Events Part 1
		GameSession gameSession = new GameSession();
		List<Event> events = new ArrayList<>();
		events.addAll(gameSession.startApp());
		gameSession.progressTime(5 * 1000l);
		events.addAll(gameSession.playGameRound(true));
		gameSession.progressTime(5 * 1000l);
		Long firstSpendMsts = gameSession.getCurrentTime();
		events.addAll(gameSession.makePurchase());
		congestEvents(events);

		gameSession.progressTime(2 * 60 * 1000l);
		events.addAll(gameSession.makePurchase());
		congestEvents(events);

		// Test States Part 1
		RBeaOperatorTestUtils.checkContext(op, 1000, ctx -> {
			GlobalState gs = new GlobalState(ctx);
			State ls = ctx.getState();

			assertEquals("SE", gs.getCountry());
			Assert.assertArrayEquals(new Double[] { .5, .5, .0, .5 }, ls.get(testProcessor.countryVec));
			assertEquals((Integer) 23, gs.getHighestLevel());
			assertEquals((Double) (1d / (gs.getHighestLevel().doubleValue() + 1d)),
					ls.get(testProcessor.highestLevelNorm));
			assertEquals((Double) 20., gs.getTotalSpendUsd());
			assertEquals((Double) 5., ls.get(testProcessor.totalSpendUsdNorm));
			assertEquals(true, gs.getIsPaidUser());
			assertEquals(gameSession.getDevice().buildString, gs.getAppBuildString());
			assertEquals(gameSession.getDevice().deviceTimeZone.toLowerCase(), gs.getDeviceTimezone());
			Assert.assertArrayEquals(new Double[] { 0.1111111111111111 }, ls.get(testProcessor.timezoneVec));
			assertEquals("7.1.2", gs.getDeviceOs());
			assertEquals("en-se_se", gs.getDeviceLocale());
			assertEquals("en", gs.getDeviceLanguage());
			assertEquals("iphone-3,3", gs.getDeviceModel());
			assertEquals("ios", gs.getClientPlatform());
			Assert.assertArrayEquals(new Double[] { .0, 1., .0, .0, .0 }, ls.get(testProcessor.platformVec));

			// Test Local session States
			assertEquals((Double) 20.0, ls.get(testProcessor.purchaseUsd));
			assertEquals((Double) 0.1, ls.get(testProcessor.purchaseUsdNorm));
			assertEquals((Integer) 4, ls.get(testProcessor.numItemTxn));
			assertEquals((Integer) 3, ls.get(testProcessor.numHcTxn));
			assertEquals((Long) (-10l), ls.get(testProcessor.hcDeduct));
			assertEquals((Long) 48l, ls.get(testProcessor.hcAccumulated));
			assertEquals((Integer) 1, ls.get(testProcessor.numClientStart));
			assertEquals((Integer) 1, ls.get(testProcessor.numGameStart));
			assertEquals((Integer) 1, ls.get(testProcessor.numGameEnd));
			assertEquals((Integer) 1, ls.get(testProcessor.numSignin));
			assertEquals((Integer) 1, ls.get(testProcessor.numSuccessGamePlay));
			assertEquals((Integer) 0, ls.get(testProcessor.numMsg));
			assertEquals((Integer) 0, ls.get(testProcessor.numAdsEvent));

			// Test Helper states
			assertNotEquals((Long) gameSession.getCurrentTime(), ls.get(testProcessor.sessionStartMsts));
		});

		/**
		 * Test Part 2
		 */
		// Mocking Events part 2
		gameSession.progressTime(16 * 60 * 1000l);
		harness.processWatermark1(new Watermark(gameSession.getCurrentTime()));

		gameSession.progressTime(20 * 60 * 1000l);
		events.addAll(gameSession.playGameRound());
		events.addAll(gameSession.sendCustomMessage());
		events.addAll(gameSession.makePurchase());
		congestEvents(events);

		Long lastSpendMsts = gameSession.getCurrentTime();
		gameSession.progressTime(5 * 60 * 1000l);
		events.addAll(gameSession.requestLifeFromOthers());
		events.addAll(gameSession.openStore());
		congestEvents(events);

		// Test states part 2
		RBeaOperatorTestUtils.checkContext(op, 1000, ctx -> {
			GlobalState gs = new GlobalState(ctx);
			State ls = ctx.getState();

			assertEquals((Integer) 23, gs.getHighestSuccessLevel());
			assertEquals((Integer) 24, gs.getHighestLevel());
			assertEquals((Double) (1d / (gs.getHighestLevel().doubleValue() + 1d)),
					ls.get(testProcessor.highestLevelNorm));
			assertEquals((Long) 2084044800l, gs.getDeviceRam());
			assertEquals((Double) 51.978455d, gs.getDisplayFrameRate());
			assertEquals("apple", gs.getDeviceManufacturer());
			assertEquals((Integer) 1, gs.getNumActiveCountries30Days());
			Assert.assertArrayEquals(new Double[] { 0.5225225225225225 }, ls.get(testProcessor.manufacturerVec));
			assertEquals(false, gs.getIsStrongAccount());
			assertEquals((Long) gameSession.getCurrentTime(), gs.getLastStoreOpenMsts());
			assertEquals((Integer) 1, gs.getFailedAttemptsHighestLevel());
			assertEquals((Double) 30d, gs.getSpendUsdLast30days());
			assertEquals((Double) 30d, gs.getSpendUsdLast7days());
			assertEquals((Double) 30d, gs.getSpendUsdLast24hrs());
			assertEquals((Integer) 3, gs.getNumPaymentLast7days());
			assertEquals((Integer) 3, gs.getNumPaymentLast30days());

			// Test Local session States
			assertEquals((Double) 10.0, ls.get(testProcessor.purchaseUsd));
			assertEquals((Double) 0.05, ls.get(testProcessor.purchaseUsdNorm));
			assertEquals((Integer) 3, ls.get(testProcessor.numItemTxn));
			assertEquals((Integer) 2, ls.get(testProcessor.numHcTxn));
			assertEquals((Long) (-10l), ls.get(testProcessor.hcDeduct));
			assertEquals((Long) 24l, ls.get(testProcessor.hcAccumulated));
			assertEquals((Integer) 0, ls.get(testProcessor.numClientStart));
			assertEquals((Integer) 1, ls.get(testProcessor.numGameStart));
			assertEquals((Integer) 1, ls.get(testProcessor.numGameEnd));
			assertEquals((Integer) 0, ls.get(testProcessor.numSignin));
			assertEquals((Integer) 0, ls.get(testProcessor.numSuccessGamePlay));
			assertEquals((Integer) 1, ls.get(testProcessor.numMsg));
			assertEquals((Integer) 1, ls.get(testProcessor.numAdsEvent));

			// Test Helper states
			assertNotEquals((Long) gameSession.getCurrentTime(), ls.get(testProcessor.sessionStartMsts));
		});

		/**
		 * Test Part 3
		 */
		// Mocking event part 3
		gameSession.progressTime(26 * 60 * 1000l);
		harness.processWatermark1(new Watermark(gameSession.getCurrentTime()));

		// Test of generating 10 more sessions
		for (int i = 3; i <= 13; i++) {
			gameSession.progressTime(2 * 60 * 1000l);
			events.addAll(gameSession.playGameRound(i % 2 == 0));
			congestEvents(events);

			gameSession.progressTime(18 * 60 * 1000l);
			harness.processWatermark1(new Watermark(gameSession.getCurrentTime()));
		}

		// Test mostFrequentCountry over last 30 days
		gameSession.progressTime(100l);
		gameSession.getDevice().ipCountryCode = "cN";
		gameSession.getDevice().buildString = "1.11.0";
		Long latestUpdateMsts = gameSession.getCurrentTime();
		gameSession.getPlayer().isStrongAccount = true;
		events.addAll(gameSession.startApp());
		congestEvents(events);

		gameSession.progressTime(100l);
		gameSession.getDevice().ipCountryCode = "jp";
		events.addAll(gameSession.startApp());
		congestEvents(events);

		gameSession.progressTime(GlobalStateUtility.msPerDay * 5l);
		gameSession.getDevice().ipCountryCode = "CN";
		events.addAll(gameSession.startApp());
		congestEvents(events);

		gameSession.progressTime(GlobalStateUtility.msPerDay * 12l);
		gameSession.getDevice().ipCountryCode = "se";
		events.addAll(gameSession.startApp());
		congestEvents(events);

		gameSession.progressTime(GlobalStateUtility.msPerDay * 15l);
		gameSession.getDevice().ipCountryCode = "no";
		events.addAll(gameSession.startApp());
		congestEvents(events);

		gameSession.progressTime(5 * 1000l);
		events.addAll(gameSession.openStore());
		congestEvents(events);

		// Test states part 3
		RBeaOperatorTestUtils.checkContext(op, 1000, ctx -> {
			GlobalState gs = new GlobalState(ctx);
			assertEquals("SE", gs.getMostActiveCountry30days());
			assertEquals((Integer) 4, gs.getNumActiveCountries30Days());
			assertNotEquals((Integer) 0, gs.getFirstInstallMsts());
			assertEquals(false, gs.getHasPlayedOnAndroid());
			assertEquals(true, gs.getHasPlayedOnIos());
			assertEquals(true, gs.getIsStrongAccount());
			assertEquals(latestUpdateMsts, gs.getLatestAppUpdateMsts());
			assertEquals((Long) gameSession.getCurrentTime(), gs.getLastStoreOpenMsts());
			assertEquals(lastSpendMsts, gs.getLastSpendMsts());
			assertEquals(firstSpendMsts, gs.getFirstSpendMsts());
			assertEquals(true, gs.getDaysSinceLastPayment() - 32.22 < 0.01);
			assertEquals((Integer) 1, gs.getFailedAttemptsHighestLevel());

		});

	}

}
