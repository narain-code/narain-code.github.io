package com.king.rbea.testutils;

import com.google.common.base.Ticker;

public class ManualTicker extends Ticker {
	public long tick;

	@Override
	public long read() {
		return tick;
	}

	public void add(long ts) {
		this.tick += ts;
	}
}