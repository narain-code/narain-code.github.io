package com.king.rbea.backend.processors;

import static org.junit.Assert.assertTrue;

import java.io.Serializable;
import java.util.List;

import org.apache.flink.api.java.tuple.Tuple2;
import org.junit.Test;

import com.google.common.collect.Lists;
import com.king.rbea.Output;
import com.king.rbea.Registry;
import com.king.rbea.State;
import com.king.rbea.annotations.Bind;
import com.king.rbea.annotations.Initialize;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.backend.types.bea.KafkaOutput;
import com.king.rbea.configuration.processor.Deployment;
import com.king.rbea.configuration.processor.JobConfig;
import com.king.rbea.configuration.processor.ProcessorInfo;
import com.king.rbea.state.LocalState;
import com.king.rbea.state.StateDescriptor;
import com.king.rbea.testutils.SCLong;

public class UpdateTest extends ProcessorTestBase {
	private static final long serialVersionUID = 1L;

	@Test
	public void test() throws Exception {
		RBEATestPipeline pipeline = RBEATestPipeline
				// "Print" everything for PRINT_TOPIC
				.startWith(Deployment.newJavaProcessor("", 2000, new LongSumProcessor(), "test",
						System.currentTimeMillis()).withInitialConfig("{\"topic\":\"SUM\"}"))
				.thenEvent(1, "2")
				.thenEvent(1, "4")
				.thenUpdate(2000, new LongSumProcessor())
				.then(Deployment.newJavaProcessor("", 2000, new LongSumProcessor(), "test",
						System.currentTimeMillis()).asUpdate())
				.thenUpdate(2000, new LongSumBroken())
				.thenEvent(1, "9999")
				// Validate job + state restore
				.thenFailAndRestoreJob()
				.thenEvent(1, "9999")
				.then(Deployment.newJavaProcessor("", 2000, new LongSumProcessor(), "test",
						System.currentTimeMillis()).asUpdate().withInitialConfig("{\"topic\":\"AWESUM\"}"))
				.thenEvent(1, "8")
				.then(new JobConfig(2000, "{\"topic\":\"AWESUM2\"}"))
				.then(new JobConfig(0, "{\"topic\":\"ohno\"}"))
				.thenEvent(1, "16")
				.thenRemoveProcessor(2000)
				.thenEvent(1, "16")
				.thenEvent(1, "32");

		Tuple2<List<ProcessorInfo>, List<BEA>> testOutput = executeProcessor(pipeline);
		List<ProcessorInfo> infoOutput = testOutput.f0;
		// We will have here the RuntimeStatistics
		List<BEA> beaOutput = testOutput.f1;

		validateExact(Lists.newArrayList(
				new KafkaOutput(2000L, "SUM", null, "2".getBytes()),
				new KafkaOutput(2000L, "SUM", null, "6".getBytes()),
				new KafkaOutput(2000L, "AWESUM", null, "14".getBytes()),
				new KafkaOutput(2000L, "AWESUM2", null, "30".getBytes())), beaOutput);
		assertTrue(infoOutput.toString(), withoutRuntimeStatistics(infoOutput).size() == 1);
	}

	public static class LongSumProcessor implements Serializable {
		private static final long serialVersionUID = 1L;
		private StateDescriptor<Long> sum;

		@Bind
		String topic = null;

		@ProcessEvent(semanticClass = SCLong.class)
		public void processEvent(SCLong l, State state, Output out) throws Exception {
			long total = state.get(sum) + l.get();
			state.update(sum, total);
			out.writeToKafka(topic, total);
		}

		@Initialize
		public void init(Registry reg) throws Exception {
			sum = reg.registerState(LocalState.createLong("SUM").initializedTo(0l));
		}
	}

	public static class LongSumBroken implements Serializable {
		private static final long serialVersionUID = 1L;
		@SuppressWarnings("unused")
		private StateDescriptor<Long> sum;

		@ProcessEvent
		public void processEvent() throws Exception {
			throw new RuntimeException("Ouch");
		}

		@Initialize
		public void init(Registry reg) throws Exception {
			sum = reg.registerState(LocalState.createLong("SUM").initializedTo(0l));
		}
	}
}
