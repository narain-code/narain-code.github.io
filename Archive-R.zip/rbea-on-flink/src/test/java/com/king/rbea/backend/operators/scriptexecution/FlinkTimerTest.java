package com.king.rbea.backend.operators.scriptexecution;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;

import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.metrics.MetricGroup;
import org.apache.flink.runtime.state.VoidNamespace;
import org.apache.flink.streaming.api.operators.InternalTimer;
import org.apache.flink.streaming.api.operators.InternalTimerService;
import org.apache.flink.streaming.api.operators.TimestampedCollector;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import com.google.common.base.Ticker;
import com.king.rbea.EventProcessor;
import com.king.rbea.backend.operators.scriptexecution.metrics.RBEAMetricsTracker;

public class FlinkTimerTest {

	@SuppressWarnings("unchecked")
	@Test
	public void test() throws Exception {
		EventProcessor proc = Mockito.mock(EventProcessor.class);
		RBEAOperator op = new RBEAOperator(Collections.EMPTY_LIST,
				ParameterTool.fromMap(new HashMap<>()));
		op.collector = mock(TimestampedCollector.class);
		op.processors.addProcessor(998, proc);
		MetricGroup mg = mock(MetricGroup.class);
		Mockito.when(mg.gauge(Mockito.any(), Mockito.any())).then(new Answer<Object>() {
			@Override
			public Object answer(InvocationOnMock arg0) throws Throwable {
				return arg0.getArgument(1);
			}
		});
		op.metrics = new RBEAMetricsTracker(0, mg, Ticker.systemTicker(), op.processors, op.fields, null);

		FlinkTimers timers = new TestingTimers(op);
		ValueState<HashMap<Tuple2<Long, Integer>, Tuple2<Long, Object>>> state = (MockValueState<HashMap<Tuple2<Long, Integer>, Tuple2<Long, Object>>>) timers.newTimerState;
		ValueState<Long> nextTs = (MockValueState<Long>) timers.nextTimer;

		timers.setProcId(999);
		timers.registerTimerWithId(1, 2, null);
		assertEquals(Tuple2.of(2l, null), state.value().get(Tuple2.of(999l, 1)));
		verify(timers.newTimerService, times(1)).registerEventTimeTimer(any(), anyLong());
		timers.registerTimerWithId(1, 3, null);
		assertEquals(Tuple2.of(3l, null), state.value().get(Tuple2.of(999l, 1)));
		verify(timers.newTimerService, times(1)).registerEventTimeTimer(any(), anyLong());

		timers.registerTimerWithId(1, 1, null);
		timers.registerTimerWithId(2, 4, null);
		assertEquals(Tuple2.of(1l, null), state.value().get(Tuple2.of(999l, 1)));
		verify(timers.newTimerService, times(2)).registerEventTimeTimer(any(), anyLong());

		timers.removeTimer(1);
		timers.removeTimer(2);
		assertNull(state.value());
		assertEquals(1l, (long) nextTs.value());

		timers.registerTimerWithId(1, 2, null);
		timers.registerTimerWithId(2, 2, null);
		timers.registerTimerWithId(3, 2, null);

		timers.setProcId(998);
		timers.registerTimerWithId(1, 2, null);
		timers.registerTimerWithId(2, 5, null);

		timers.setProcId(999);
		assertEquals(5, state.value().size());
		timers.removeAllTimers();
		assertEquals(2, state.value().size());
		timers.registerTimerWithId(1, 3, null);
		assertEquals(3, state.value().size());

		// This should not fire any timers but remove all for proc 999
		timers.onEventTime(new InternalTimer<Long, VoidNamespace>(0, 0l, VoidNamespace.INSTANCE));
		assertEquals(2l, (long) nextTs.value());
		assertEquals(2, state.value().size());

		timers.onEventTime(new InternalTimer<Long, VoidNamespace>(2, 0l, VoidNamespace.INSTANCE));
		assertEquals(5l, (long) nextTs.value());
		assertEquals(1, state.value().size());

		timers.onEventTime(new InternalTimer<Long, VoidNamespace>(5, 0l, VoidNamespace.INSTANCE));
		assertNull(state.value());
		assertNull(nextTs.value());
	}

	private static class MockValueState<T> implements ValueState<T> {

		public T value = null;

		@Override
		public void clear() {
			value = null;
		}

		@Override
		public void update(T arg0) throws IOException {
			value = arg0;
		}

		@Override
		public T value() throws IOException {
			return value;
		}

	}

	public static class TestingTimers extends FlinkTimers {

		public TestingTimers(RBEAOperator rbeaOp) {
			super(rbeaOp);
		}

		@SuppressWarnings("unchecked")
		@Override
		public void init(RBEAOperator rbeaOp) {
			this.newTimerService = mock(InternalTimerService.class);
			this.newTimerState = new MockValueState<>();
			this.nextTimer = new MockValueState<>();
			this.metrics = rbeaOp.metrics;
		}

		@Override
		public void runTimerForProc(long pid, long ts, long coreUserId, int timerId, Object timerParam,
				Tuple2<Boolean, Boolean> stateFetched) {
			// Do nothing
		}

	}
}
