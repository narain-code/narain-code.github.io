package com.king.rbea.backend.processors;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.Serializable;
import java.util.List;

import org.apache.flink.api.java.tuple.Tuple2;
import org.junit.Test;

import com.king.rbea.Context;
import com.king.rbea.EventProcessor;
import com.king.rbea.Registry;
import com.king.rbea.annotations.Initialize;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.annotations.ProcessingPolicy;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.configuration.processor.ProcessorInfo;
import com.king.rbea.state.LocalState;

public class FailureHandlingTest extends ProcessorTestBase {
	private static final long serialVersionUID = 1L;

	public FailureHandlingTest() {
		super();
	}

	@Test
	public void test() throws Exception {
		RBEATestPipeline pipeline = RBEATestPipeline
				.startWithDeployment(1000, new FailingProcessor())
				.thenDeploy(4000, new TypeError())
				.thenEvent(2, "a")
				.thenEvent(3, "a")
				.thenDeploy(2000, new FailingProcessor2())
				.thenEvent(4, "a")
				.thenEvent(3, "c")
				.thenEvent(3, "c")
				.thenEvent(3, "c")
				.thenDeploy(5000, new NoCUIDError())
				.thenEventNoCUID("a");

		Tuple2<List<ProcessorInfo>, List<BEA>> testOutput = executeProcessor(pipeline);
		List<ProcessorInfo> infoOutput = testOutput.f0;
		List<BEA> beaOutput = testOutput.f1;

		assertEquals(4, infoOutput.size());
		assertTrue(beaOutput.isEmpty());
		infoOutput.forEach(System.out::print);
	}

	public static class FailingProcessor implements Serializable {
		private static final long serialVersionUID = 1L;
		static volatile boolean failed = false;

		@ProcessEvent
		public void processEvent(com.king.event.Event event, Context ctx) throws Exception {
			if (!failed) {
				failed = true;
				throw new RuntimeException("ERROR1");
			}
		}
	}

	public static class FailingProcessor2 implements Serializable {
		private static final long serialVersionUID = 1L;
		static volatile boolean failed = false;

		@ProcessEvent
		public void proc(com.king.event.Event event, Context ctx) throws Exception {
			if (!failed) {
				failed = true;
				throw new NoClassDefFoundError("ERROR2");
			}
		}
	}

	public static class TypeError implements EventProcessor {
		private static final long serialVersionUID = 1L;
		static volatile boolean failed = false;

		@ProcessEvent
		@Override
		public void processEvent(com.king.event.Event event, Context ctx) throws Exception {

		}

		@Initialize
		public void initialize(Registry reg) throws Exception {
			reg.registerState(LocalState.createInt("asd"));
		}
	}

	public static class NoCUIDError implements EventProcessor {
		private static final long serialVersionUID = 1L;
		static volatile boolean failed = false;

		@ProcessEvent(missingCUID = ProcessingPolicy.PROCESS_ONLY)
		@Override
		public void processEvent(com.king.event.Event event, Context ctx) throws Exception {
			throw new Exception("Yo");
		}

	}
}
