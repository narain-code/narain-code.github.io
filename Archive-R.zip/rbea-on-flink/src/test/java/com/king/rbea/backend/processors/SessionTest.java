package com.king.rbea.backend.processors;

import static org.junit.Assert.assertEquals;

import java.io.Serializable;
import java.util.List;

import org.apache.flink.api.java.tuple.Tuple2;
import org.junit.Test;

import com.google.common.collect.Lists;
import com.king.event.Event;
import com.king.flink.utils.CustomEvent;
import com.king.rbea.Output;
import com.king.rbea.Registry;
import com.king.rbea.State;
import com.king.rbea.annotations.Initialize;
import com.king.rbea.annotations.OnSessionEnd;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.backend.types.bea.KafkaOutput;
import com.king.rbea.backend.utils.BackendConstants;
import com.king.rbea.configuration.processor.ProcessorInfo;
import com.king.rbea.state.LocalState;

public class SessionTest extends ProcessorTestBase {
	private static final long serialVersionUID = 1L;

	@Test
	public void test() throws Exception {
		RBEATestPipeline pipeline = RBEATestPipeline
				.startWithDeployment(1000, new SessionTester())
				.thenEvent(1, "x", 500)
				.thenEvent(1, CustomEvent.create(0).withTimeStamp(100))
				.thenWatermark(500)
				.thenEvent(1, CustomEvent.create(1).withTimeStamp(690))
				.thenWatermark(BackendConstants.SESSION_TIMEOUT / 2)
				.thenEvent(1, "b", BackendConstants.SESSION_TIMEOUT / 2 + 100)
				.thenWatermark(2 * BackendConstants.SESSION_TIMEOUT)
				.thenEvent(1, CustomEvent.create(1327)
						.withTimeStamp(2 * BackendConstants.SESSION_TIMEOUT + 100).withField(0, "c"))
				.thenWatermark(4 * BackendConstants.SESSION_TIMEOUT);

		Tuple2<List<ProcessorInfo>, List<BEA>> testOutput = executeProcessor(pipeline);
		List<BEA> beaOutput = testOutput.f1;
		List<ProcessorInfo> infoOut = testOutput.f0;

		assertEquals(0, infoOut.size());

		validateExact(Lists.newArrayList(KafkaOutput.create(1000, "out", "4-b".getBytes(), null),
				KafkaOutput.create(1000, "out", "1-c".getBytes(), null)), beaOutput);
	}

	public static class SessionTester implements Serializable {
		private static final long serialVersionUID = 1L;

		@ProcessEvent
		public void processEvent(Event e, State s) throws Exception {
			s.update("Count", s.<Integer> get("Count") + 1);
		}

		@OnSessionEnd
		public void on(State state, Output out, Event e) throws Exception {
			out.writeToKafka("out", state.get("Count") + "-" + e.getString(0));
			state.clearAll();
		}

		@Initialize
		public void initialize(Registry reg) throws Exception {
			reg.registerState(LocalState.create("Count", 0));
		}
	}
}
