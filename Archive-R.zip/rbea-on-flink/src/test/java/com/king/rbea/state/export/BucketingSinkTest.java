package com.king.rbea.state.export;

import org.apache.hadoop.fs.Path;
import org.junit.Test;

public class BucketingSinkTest {

	@Test
	public void test() {
		String basePath = "hdfs:///test/base";
		String uncommitted = "hdfs:///test/uncommitted";
		RBEABucketingSink<Object> sink = new RBEABucketingSink<>(basePath, uncommitted);
		Path bucket = new Path(basePath + "/Test/1991-05-02");
		System.out.println(sink.getPendingPathFor(bucket));
		System.out.println(sink.getInProgressPathFor(bucket));
	}
}
