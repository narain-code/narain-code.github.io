package com.king.rbea.backend.processors;

import static com.king.constants.KingApp.BITERO;
import static com.king.constants.SignInSource.BACK_END;
import static com.king.rbea.matchers.EventMatchers.hasField;
import static com.king.rbea.matchers.EventMatchers.hasFlavour;
import static com.king.rbea.matchers.EventMatchers.hasType;
import static com.king.rbea.matchers.KafkaOutputMatchers.hasEvent;
import static com.king.rbea.matchers.KafkaOutputMatchers.hasKey;
import static com.king.rbea.matchers.KafkaOutputMatchers.hasTopic;
import static org.hamcrest.CoreMatchers.allOf;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;

import java.io.Serializable;
import java.util.List;

import org.apache.flink.api.java.tuple.Tuple2;
import org.junit.Test;

import com.king.constants.Flavour;
import com.king.constants.external.EventField;
import com.king.constants.external.EventType;
import com.king.rbea.Utils;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.backend.types.bea.KafkaOutput;
import com.king.rbea.configuration.processor.ProcessorInfo;
import com.king.rbea.testutils.SCLong;

@SuppressWarnings("serial")
public class BiteroTest extends ProcessorTestBase {
	static final long CORE_USER_ID = 1_234_567_890L;
	static final long SEGMENT_ID = 1234;
	static final String BITERO_TOPIC = "work.bitero.store-segment-updates";
	static final int FLAVOUR_ID = Flavour.createFlavour(BITERO, BACK_END);

	public BiteroTest() {
		super();
	}

	@Test
	public void shouldSendEventsToBitero() throws Exception {
		RBEATestPipeline source = RBEATestPipeline
				.startWithDeployment(666, new BiteroUsage())
				.thenEvent(CORE_USER_ID, "0").withTimestamp(10)
				.thenEvent(CORE_USER_ID, "1").withTimestamp(20);

		Tuple2<List<ProcessorInfo>, List<BEA>> output = executeProcessor(source);

		assertFalse(output.f1.isEmpty());
		final KafkaOutput first = (KafkaOutput) output.f1.get(0);
		assertThat(first, allOf(
				hasTopic(BITERO_TOPIC),
				hasKey(CORE_USER_ID),
				hasEvent(allOf(
						hasFlavour(FLAVOUR_ID),
						hasType(EventType.PlayerAddedToSegment),
						hasField(EventField.PlayerAddedToSegment.coreUserId, CORE_USER_ID),
						hasField(EventField.PlayerAddedToSegment.segmentId, SEGMENT_ID)))));

		final KafkaOutput second = (KafkaOutput) output.f1.get(1);
		assertThat(second, allOf(
				hasTopic(BITERO_TOPIC),
				hasKey(CORE_USER_ID),
				hasEvent(allOf(
						hasFlavour(FLAVOUR_ID),
						hasType(EventType.PlayerRemovedFromSegment),
						hasField(EventField.PlayerRemovedFromSegment.coreUserId, CORE_USER_ID),
						hasField(EventField.PlayerRemovedFromSegment.segmentId, SEGMENT_ID)))));
	}

	public static class BiteroUsage implements Serializable {

		@ProcessEvent(semanticClass = SCLong.class)
		public void process(SCLong longEvent, Utils utils) throws Exception {
			if (longEvent.get() == 0) {
				utils.getBitero().addPlayerToSegment(CORE_USER_ID, SEGMENT_ID);
			} else {
				utils.getBitero().removePlayerFromSegment(CORE_USER_ID, SEGMENT_ID);
			}
		}
	}
}
