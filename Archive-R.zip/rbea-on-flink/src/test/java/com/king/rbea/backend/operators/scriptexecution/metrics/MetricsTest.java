package com.king.rbea.backend.operators.scriptexecution.metrics;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.metrics.MetricGroup;
import org.apache.flink.streaming.api.operators.AbstractStreamOperator;
import org.junit.Test;
import org.mockito.Mockito;

import com.king.rbea.backend.operators.scriptexecution.Processors;
import com.king.rbea.exceptions.BackendException;
import com.king.rbea.state.CachingState;
import com.king.rbea.testutils.ManualTicker;

public class MetricsTest {

	@Test
	public void test() throws BackendException, IOException {
		// Create mock objects
		MetricGroup mg = Mockito.mock(MetricGroup.class);
		Mockito.when(mg.gauge(Mockito.any(), Mockito.any())).then(i -> i.getArguments()[1]);
		AbstractStreamOperator<?> op = Mockito.mock(AbstractStreamOperator.class);
		Mockito.when(op.getCurrentKey()).thenReturn(new Object());
		ValueState<?> vs = Mockito.mock(ValueState.class);

		ManualTicker ticker = new ManualTicker();
		RBEAMetricsTracker tracker = new RBEAMetricsTracker(100, mg, ticker, null, null, null);

		// We mock the complete state access behaviour (state access will be hardcoded
		// to take 1000 ns)

		Mockito.when(vs.value()).thenAnswer(i -> {
			ticker.add(1000);
			return new Object();
		});

		CachingState<?> baseState = new CachingState<>(1, vs, op, null,
				tracker.baseStateReadWatch, null, null);
		CachingState<?> userState = new CachingState<>(1, vs, op, null,
				tracker.userStateReadWatch, null, null);

		Tuple2<Boolean, Boolean> fetched = Tuple2.of(false, false);
		ExecutionStats stats = new ExecutionStats();

		tracker.callAndMeasure(stats, fetched, () -> {
			return null;
		});

		assertEquals(Tuple2.of(false, false), fetched);
		assertEquals(1, stats.count);
		assertEquals(0, stats.totalTimeNanos);
		assertEquals(0, stats.maxTimeNanos);

		tracker.callAndMeasure(stats, fetched, () -> {
			ticker.add(100);
			return null;
		});

		assertEquals(Tuple2.of(false, false), fetched);
		assertEquals(2, stats.count);
		assertEquals(100, stats.totalTimeNanos);
		assertEquals(100, stats.maxTimeNanos);

		tracker.callAndMeasure(stats, fetched, () -> {
			ticker.add(110);
			try {
				baseState.value();
			} catch (IOException e) {}
			return null;
		});

		assertEquals(Tuple2.of(false, true), fetched);
		assertEquals(3, stats.count);
		assertEquals(210, stats.totalTimeNanos);
		assertEquals(110, stats.maxTimeNanos);

		tracker.callAndMeasure(stats, fetched, () -> {
			ticker.add(100);
			return null;
		});

		assertEquals(Tuple2.of(false, true), fetched);
		assertEquals(4, stats.count);
		assertEquals(310, stats.totalTimeNanos);
		assertEquals(110, stats.maxTimeNanos);

		tracker.callAndMeasure(stats, fetched, () -> {
			try {
				userState.value();
			} catch (IOException e) {}
			return null;
		});

		assertEquals(Tuple2.of(true, true), fetched);
		assertEquals(5, stats.count);
		assertEquals(310, stats.totalTimeNanos);
		assertEquals(110, stats.maxTimeNanos);
	}

	@Test
	public void test2() {
		MetricGroup mg = Mockito.mock(MetricGroup.class);
		Processors p = Mockito.spy(new Processors());
		Mockito.when(mg.gauge(Mockito.any(), Mockito.any())).then(i -> i.getArguments()[1]);
		ManualTicker ticker = new ManualTicker();
		RBEAMetricsTracker.runtimeStatsIntervalMillis = 100;
		RBEAMetricsTracker tracker = new RBEAMetricsTracker(100, mg, ticker, p, null, null);
		tracker.conditionallyCollectRuntimeStatistics(null);
		Mockito.verify(p, Mockito.times(0)).getAll();
		ticker.add(1000);
		tracker.conditionallyCollectRuntimeStatistics(null);
		Mockito.verify(p, Mockito.times(0)).getAll();
		ticker.add(TimeUnit.MILLISECONDS.toNanos(100));
		tracker.conditionallyCollectRuntimeStatistics(null);
		Mockito.verify(p, Mockito.times(1)).getAll();
	}

	@Test
	public void testSlidingWindowCounter() {
		SlidingWindowCounter counter = new SlidingWindowCounter(60);

		counter.increment(0);
		counter.increment(100);
		counter.increment(3000);
		counter.increment(3600);
		counter.increment(40400);
		counter.increment(59000);

		assertEquals(6, (long) counter.getValue(60000));
		assertEquals(4, (long) counter.getValue(60001));
	}

}
