package com.king.rbea.backend.operators.scriptexecution;

import static com.king.rbea.testutils.RBeaOperatorTestUtils.backfill;
import static com.king.rbea.testutils.RBeaOperatorTestUtils.createRBEAHarness;
import static com.king.rbea.testutils.RBeaOperatorTestUtils.input;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.io.Serializable;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.apache.flink.streaming.util.KeyedTwoInputStreamOperatorTestHarness;
import org.apache.flink.types.Either;
import org.junit.Test;

import com.google.common.collect.Lists;
import com.king.constants.external.EventType;
import com.king.event.Event;
import com.king.event.EventBuilder;
import com.king.flink.utils.CustomEvent;
import com.king.rbea.Output;
import com.king.rbea.State;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.backend.types.EventWrapper;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.backend.types.bea.KafkaOutput;
import com.king.rbea.configuration.Configuration;
import com.king.rbea.configuration.processor.Deployment;
import com.king.rbea.exceptions.BackendException;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.state.abstate.ABTestBaseProcessor;
import com.king.rbea.state.basefields.ABTestAssignments;

public class ABStateTest {

	@Test
	public void basicTest() throws Exception {
		KeyedTwoInputStreamOperatorTestHarness<Long, EventWrapper, Configuration, Either<BEA, Configuration>> harness = createRBEAHarness(
				 Lists.newArrayList(ABTestBaseProcessor.DEPLOYMENT));

		harness.processElement1(input(assign(100, "ab1", 9999, 1)));
		harness.processElement1(input(assign(100, "ab2", 8000, 2)));

		harness.processElement2(input(Deployment.newJavaProcessor("", 10000, new Serializable() {
			private static final long serialVersionUID = 1L;

			@ProcessEvent(eventType = 1337)
			public void process(State state, Output out) throws ProcessorException {
				ABTestAssignments assignments = state.getABTestAssignments();
				out.writeToKafka("out", "" + assignments.getCaseNum("ab1", 9999));
				out.writeToKafka("out", "" + assignments.getLastCaseNum("ab1"));
			}

		}, "", 1)));

		@SuppressWarnings({ "rawtypes", "unchecked" })
		ConcurrentLinkedQueue<StreamRecord<Either<BEA, Configuration>>> output = (ConcurrentLinkedQueue) harness
				.getOutput();

		output.clear();
		harness.processElement1(input(CustomEvent.create(1337), 100));
		assertEquals("1", getNextKafkaOutput(output));
		assertEquals("1", getNextKafkaOutput(output));

		harness.processElement1(input(assign(100, "ab1", 10000, 5)));
		harness.processElement1(input(CustomEvent.create(1337), 100));

		assertEquals("null", getNextKafkaOutput(output));
		assertEquals("5", getNextKafkaOutput(output));

		harness.processElement2(input(Deployment.newJavaProcessor("", 10000, new Serializable() {
			private static final long serialVersionUID = 1L;

			@ProcessEvent(eventType = 1337)
			public void process(State state, Output out) throws ProcessorException {
				ABTestAssignments assignments = state.getABTestAssignments();
				out.writeToKafka("out", "" + assignments.getLastCaseNum("ab2"));
			}

		}, "", 1).asUpdate()));
		output.clear();

		harness.processElement1(input(CustomEvent.create(1337), 100));
		assertEquals("2", getNextKafkaOutput(output));
	}

	@Test
	public void backFillTest() throws Exception {
		KeyedTwoInputStreamOperatorTestHarness<Long, EventWrapper, Configuration, Either<BEA, Configuration>> harness = createRBEAHarness(Lists.newArrayList(ABTestBaseProcessor.DEPLOYMENT));

		// Test wrong JSON format
		harness.processElement1(input(assign(100, "ab1", 1, 0)));
		harness.processElement1(backfill(input(stateBackfill(100, "AB_TEST_ASSIGNMENTS_BACKFILL_3", "not-a-json"))));

		// Test wrong json format
		harness.processElement1(input(assign(101, "ab1", 1, 0)));
		harness.processElement1(
				backfill(input(
						stateBackfill(101, "AB_TEST_ASSIGNMENTS_BACKFILL_3", "[{\"ab\": \"wrong_json_format\"}]"))));

		// Test missing values
		harness.processElement1(input(assign(102, "ab1", 1, 0)));
		harness.processElement1(
				backfill(input(stateBackfill(102, "AB_TEST_ASSIGNMENTS_BACKFILL_3", "[{\"version\": 1}]"))));

		// Test values that are null
		harness.processElement1(input(assign(103, "ab1", 1, 0)));
		harness.processElement1(backfill(input(stateBackfill(103, "AB_TEST_ASSIGNMENTS_BACKFILL_3",
				"[{\"name\":\"ab2\",\"version\":null,\"casenum\":null}]"))));

		// Test changing version and case number
		harness.processElement1(input(assign(110, "ab1", 1, 0)));
		harness.processElement1(backfill(input(
				stateBackfill(110, "AB_TEST_ASSIGNMENTS_BACKFILL_3",
						"[{\"name\":\"ab1\",\"version\":2,\"casenum\":1}]"))));

		// Test trying to change to lower version, shouldn't be able to do that
		harness.processElement1(input(assign(111, "ab1", 5, 2)));
		harness.processElement1(backfill(input(
				stateBackfill(111, "AB_TEST_ASSIGNMENTS_BACKFILL_3",
						"[{\"name\":\"ab1\",\"version\":4,\"casenum\":1}]"))));

		// Test trying to change to different casenum without changing version,
		// shouldn't be able to do that
		harness.processElement1(input(assign(112, "ab1", 1, 0)));
		harness.processElement1(backfill(input(
				stateBackfill(112, "AB_TEST_ASSIGNMENTS_BACKFILL_3",
						"[{\"name\":\"ab1\",\"version\":1,\"casenum\":1}]"))));

		// Test trying to backfill multiple AB tests
		harness.processElement1(backfill(input(stateBackfill(120, "AB_TEST_ASSIGNMENTS_BACKFILL_3",
				"[{\"name\":\"ab1\",\"version\":1,\"casenum\":1}, {\"name\":\"ab2\",\"version\":2,\"casenum\":2}]"))));

		harness.processElement2(input(Deployment.newJavaProcessor("", 10000, new Serializable() {
			private static final long serialVersionUID = 1L;

			@ProcessEvent(eventType = 1330)
			public void test1(State state) throws BackendException {
				try {
					ABTestAssignments ass = state.getABTestAssignments();
					assertEquals((Integer) 1, ass.getLastVersion("ab1"));
				} catch (Throwable r) {
					throw new BackendException(r);
				}
			}

			@ProcessEvent(eventType = 1331)
			public void test2(State state) throws BackendException {
				try {
					ABTestAssignments ass = state.getABTestAssignments();
					assertEquals((Integer) 1, ass.getLastVersion("ab1"));
				} catch (Throwable r) {
					throw new BackendException(r);
				}
			}

			@ProcessEvent(eventType = 1332)
			public void test7(State state) throws BackendException {
				try {
					ABTestAssignments ass = state.getABTestAssignments();
					assertEquals((Integer) 1, ass.getLastVersion("ab1"));
				} catch (Throwable r) {
					throw new BackendException(r);
				}
			}

			@ProcessEvent(eventType = 1333)
			public void test8(State state) throws BackendException {
				try {
					ABTestAssignments ass = state.getABTestAssignments();
					assertEquals((Integer) 1, ass.getLastVersion("ab1"));
					assertNull(ass.getLastCaseNum("ab2"));
				} catch (Throwable r) {
					throw new BackendException(r);
				}
			}

			@ProcessEvent(eventType = 1340)
			public void test3(State state) throws BackendException {
				try {
					ABTestAssignments ass = state.getABTestAssignments();
					assertEquals((Integer) 2, ass.getLastVersion("ab1"));
					assertEquals((Integer) 1, ass.getLastCaseNum("ab1"));
				} catch (Throwable r) {
					throw new BackendException(r);
				}
			}

			@ProcessEvent(eventType = 1341)
			public void test4(State state) throws BackendException {
				try {
					ABTestAssignments ass = state.getABTestAssignments();
					assertEquals((Integer) 5, ass.getLastVersion("ab1"));
					assertEquals((Integer) 2, ass.getLastCaseNum("ab1"));
				} catch (Throwable r) {
					throw new BackendException(r);
				}
			}

			@ProcessEvent(eventType = 1342)
			public void test5(State state) throws BackendException {
				try {
					ABTestAssignments ass = state.getABTestAssignments();
					assertEquals((Integer) 1, ass.getLastVersion("ab1"));
					assertEquals((Integer) 0, ass.getLastCaseNum("ab1"));
				} catch (Throwable r) {
					throw new BackendException(r);
				}
			}

			@ProcessEvent(eventType = 1350)
			public void test6(State state) throws BackendException {
				try {
					ABTestAssignments ass = state.getABTestAssignments();

					assertEquals((Integer) 1, ass.getLastVersion("ab1"));
					assertEquals((Integer) 1, ass.getLastCaseNum("ab1"));

					assertEquals((Integer) 2, ass.getLastVersion("ab2"));
					assertEquals((Integer) 2, ass.getLastCaseNum("ab2"));
				} catch (Throwable r) {
					throw new BackendException(r);
				}
			}

		}, "", 1)));

		harness.processElement1(input(CustomEvent.create(1330), 100));
		harness.processElement1(input(CustomEvent.create(1331), 101));
		harness.processElement1(input(CustomEvent.create(1332), 102));
		harness.processElement1(input(CustomEvent.create(1333), 103));
		harness.processElement1(input(CustomEvent.create(1340), 110));
		harness.processElement1(input(CustomEvent.create(1341), 111));
		harness.processElement1(input(CustomEvent.create(1342), 112));
		harness.processElement1(input(CustomEvent.create(1350), 120));

	}

	private String getNextKafkaOutput(ConcurrentLinkedQueue<StreamRecord<Either<BEA, Configuration>>> output) {
		byte[] bytes = ((KafkaOutput) output.poll().getValue().left()).bytes;
		return new String(bytes);
	}

	public static Event stateBackfill(long cuid, String key, String value) {
		return CustomEvent.fromEvent(new EventBuilder(0).buildEvent(EventType.RbeaStateUpdate(cuid, key, value), 0));
	}

	public static Event assign(long cuid, String name, int version, int caseNum) {
		return new EventBuilder(0).buildEvent(EventType.AbTestCaseAssigned(cuid, name, version, caseNum), 100);
	}

}
