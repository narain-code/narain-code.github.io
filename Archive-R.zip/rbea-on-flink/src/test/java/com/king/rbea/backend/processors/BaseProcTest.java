package com.king.rbea.backend.processors;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.flink.api.java.tuple.Tuple2;
import org.junit.Test;

import com.google.common.collect.Lists;
import com.king.rbea.Output;
import com.king.rbea.Registry;
import com.king.rbea.State;
import com.king.rbea.annotations.Bind;
import com.king.rbea.annotations.Initialize;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.backend.types.bea.KafkaOutput;
import com.king.rbea.configuration.processor.Deployment;
import com.king.rbea.configuration.processor.JobConfig;
import com.king.rbea.configuration.processor.ProcessorInfo;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.state.LocalState;
import com.king.rbea.state.StateDescriptor;
import com.king.rbea.testutils.SCLong;

public class BaseProcTest extends ProcessorTestBase {
	private static final long serialVersionUID = 1L;

	@Test
	public void test() throws Exception {
		RBEATestPipeline pipeline = RBEATestPipeline
				// "Print" everything for PRINT_TOPIC
				.startWithDeployment(1000, new PrintingProcessor())
				.then(new JobConfig((long) Integer.MAX_VALUE + 10, "{\"increment\":1}"))
				.thenEvent(1, "10")

				// Validate job + state restore
				.thenFailAndRestoreJob()

				.thenEvent(1, "20")
				.thenEvent(2, "a");

		Tuple2<List<ProcessorInfo>, List<BEA>> testOutput = executeProcessor(pipeline);
		List<ProcessorInfo> infoOutput = testOutput.f0;
		// We will have here the RuntimeStatistics
		List<BEA> beaOutput = testOutput.f1;

		assertTrue(infoOutput.toString(), withoutRuntimeStatistics(infoOutput).isEmpty());
		validateExact(Lists.newArrayList(
				new KafkaOutput(1000, "out", null, "1-10-1".getBytes()),
				new KafkaOutput(1000, "out", null, "1-30-2".getBytes()),
				new KafkaOutput(1000, "out", null, "2-0-1".getBytes())), beaOutput);
	}

	@Override
	public List<Deployment> getBaseProcessors() {
		return Lists.newArrayList(Deployment.newJavaProcessor("", (long) Integer.MAX_VALUE + 10, new Serializable() {
			private static final long serialVersionUID = 1L;
			private StateDescriptor<Long> bs1;
			private StateDescriptor<Integer> bs2;
			private StateDescriptor<ArrayList<Integer>> bs3;

			@Bind
			public int increment = 0;

			@ProcessEvent(semanticClass = SCLong.class)
			public void process(SCLong sc, State state) throws ProcessorException {
				state.update(bs1, state.get(bs1) + sc.get());
				ArrayList<Integer> list = state.get(bs3);
				list.add(0);
			}

			@ProcessEvent
			public void process2(State state) throws ProcessorException {
				state.update(bs2, state.get(bs2) + increment);
			}

			@Initialize
			public void init(Registry reg) throws ProcessorException {
				bs1 = reg.registerState(LocalState.create("BS1", Long.class).initializedTo(0l));
				bs2 = reg.registerState(LocalState.create("BS2", Integer.class).initializedTo(0));
				bs3 = reg.registerState(LocalState.createList("List", Integer.class));
			}

		}, "", 0));
	}

	public static class PrintingProcessor implements Serializable {
		private static final long serialVersionUID = 1L;

		@ProcessEvent
		public void process(long cuid, State state, Output out) throws Exception {
			out.writeToKafka("out", "" + cuid + "-" + state.get("BS1") + "-" + state.get("BS2"));
			ArrayList<Integer> list = state.get("List");
			list.size();
			try {
				list.add(0);
				fail("Illegal base state modification");
			} catch (Exception pe) {
				assertTrue(pe instanceof ProcessorException);
			}
		}
	}
}
