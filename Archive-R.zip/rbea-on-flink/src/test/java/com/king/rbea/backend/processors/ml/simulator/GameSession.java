package com.king.rbea.backend.processors.ml.simulator;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.List;

import com.king.constants.SignInSource;
import com.king.constants.external.EventType;
import com.king.event.Event;
import com.king.rbea.state.globalstate.GlobalState;

public class GameSession {

	private final Player player;

	public Player getPlayer() {
		return player;
	}

	public Device getDevice() {
		return device;
	}

	private final Device device;
	private final EventHelper eventHelper;

	public long getCurrentTime() {
		return GlobalState.getClock().millis();
	}

	public int numSignins = 0;

	public GameSession() {
		player = new Player();
		device = new Device();
		eventHelper = new EventHelper();
		GlobalState.setClock(Clock.fixed(Instant.ofEpochSecond(1510173000), ZoneId.systemDefault()));
	}

	public void progressTime(Long additionalTimeInMS) {
		GlobalState.setClock(Clock.offset(GlobalState.getClock(), Duration.ofMillis(additionalTimeInMS)));
	}

	public List<Event> startApp() {

		Event appStart = eventHelper.buildEvent(
				EventType.AppStart13(
						player.coreUserId,
						device.installId,
						"installEx",
						device.uDaid,
						device.macInstallId,
						"macEx",
						device.idfvInstallId,
						"idfEx",
						getCurrentTime(),
						device.ipCountryCode,
						device.os,
						device.buildString,
						device.referrer,
						device.networkOperator,
						device.deviceLocale,
						device.deviceTimeZone,
						"channelId"),
				getCurrentTime());

		// Device Info
		// ClientEvent deviceInfo =
		// EventHelper.buildClientEvent(EventType.AppDeviceInfo5())
		Event deviceInfo5 = eventHelper.buildEvent(EventType.AppDeviceInfo5(
				player.coreUserId,
				device.installId,
				"installEx",
				getCurrentTime(),
				device.uDaid,
				device.idfvInstallId,
				0l,
				"",
				0l,
				"",
				"",
				"",
				device.manufacturer,
				device.model,
				device.os,
				"",
				0,
				9,
				0.0d,
				0.0d,
				false,
				4096L), getCurrentTime());

		// Module versions
		Event plataformaModule = eventHelper.buildEvent(EventType.AppClientModuleVersion(
				player.coreUserId,
				device.installId,
				"installEx",
				getCurrentTime(),
				"platafaforma",
				"47.0.0"), getCurrentTime());

		// Sign In Event 1
		numSignins++;
		Event signInUser2 = eventHelper.buildEvent(EventType.SignInUser2(
				player.coreUserId,
				SignInSource.DEVELOPMENT_IOS,
				numSignins,
				getCurrentTime() - 1,
				numSignins,
				getCurrentTime() - 1,
				numSignins,
				getCurrentTime() - 1,
				numSignins,
				getCurrentTime() - 1), getCurrentTime());

		progressTime(1l);

		// Sign in Event 2
		Event appSignInUser = eventHelper.buildEvent(EventType.AppSignInUser(
				player.coreUserId,
				device.installId,
				"installEx"), getCurrentTime());

		/*
		 * if(SCSignIn.process(signInUser2) == null) { throw new RuntimeException(":(");
		 * }
		 */

		if (player.isStrongAccount) {
			Event facebookDataUpdated4 = eventHelper.buildEvent(EventType.FacebookDataUpdated4(
					player.coreUserId,
					device.ipCountryCode,
					"",
					0l,
					37,
					0,
					device.deviceLocale,
					0,
					device.deviceTimeZone), getCurrentTime());

			return Arrays.asList(appStart, deviceInfo5, plataformaModule, signInUser2, appSignInUser,
					facebookDataUpdated4);
		}

		return Arrays.asList(appStart, deviceInfo5, plataformaModule, signInUser2, appSignInUser);
	}

	public List<Event> openStore() {
		Event appCustomFunnel2 = eventHelper.buildEvent(EventType.AppCustomFunnel2(
				player.coreUserId,
				player.installID,
				"installEx",
				getCurrentTime(),
				"purchase",
				"gui_opened",
				"45B8151B-2337-429D-824E-E477A08B0F78"), getCurrentTime());

		Event appStoreOpen = eventHelper.buildEvent(EventType.AppStoreOpen(
				player.coreUserId,
				player.installID,
				"installEx",
				getCurrentTime(),
				player.installID + "00000000",
				0,
				0), getCurrentTime());

		Event appGuiShown = eventHelper.buildEvent(EventType.AppGuiShown5(
				player.coreUserId,
				player.installID,
				"installEx",
				getCurrentTime(),
				23068,
				"",
				"",
				""), getCurrentTime());

		return Arrays.asList(appCustomFunnel2, appStoreOpen, appGuiShown);
	}

	public List<Event> makePurchase() {

		long amountCents = 1000L;
		String currencyCode = "USD";
		String transactionId = String.valueOf(player.transactionId);
		Long transactionType = 100L;
		Long productPackageVersionId = 123L;

		Event transactionBegin = eventHelper.buildEvent(EventType.ExternalStoreTransactionBegin(
				player.coreUserId,
				device.installId,
				"installEx",
				transactionType,
				1000L,
				transactionId,
				getCurrentTime(),
				amountCents,
				currencyCode,
				false), getCurrentTime());

		Event transactionDone = eventHelper.buildEvent(EventType.ExternalStoreTransactionDone(
				player.coreUserId,
				device.installId,
				"installEx",
				transactionType,
				productPackageVersionId,
				transactionId,
				getCurrentTime(),
				amountCents,
				currencyCode,
				false

		), getCurrentTime());

		Event validationStart = eventHelper.buildEvent(EventType.ExternalStorePurchaseValidationStart2(
				player.coreUserId,
				device.installId,
				"installEx",
				transactionType,
				productPackageVersionId,
				transactionId,
				getCurrentTime(),
				"ext-id"), getCurrentTime());

		Event validationDone = eventHelper.buildEvent(EventType.ExternalStorePurchaseValidationDone2(
				player.coreUserId,
				device.installId,
				"installEx",
				transactionType,
				productPackageVersionId,
				transactionId,
				getCurrentTime(),
				0,
				"ext-id"

		), getCurrentTime());

		Event receipt = eventHelper.buildEvent(EventType.ExternalStorePurchaseValidReceipt5(
				player.coreUserId,
				device.installId,
				"installEx",
				1,
				100,
				1,
				"asdf",
				"asdf",
				getCurrentTime(),
				1000,
				"USD",
				1000,
				"USD",
				1,
				0.0,
				"",
				false,
				0,
				0,
				"", ""), getCurrentTime());

		// deliver goldbars
		Event itemTransaction4 = eventHelper.buildEvent(EventType.ItemTransaction4(
				player.coreUserId,
				3280L,
				100L,
				transactionType,
				productPackageVersionId,
				24,
				32,
				"item-details",
				transactionId), getCurrentTime());

		player.transactionId += 1;

		return Arrays.asList(transactionBegin, transactionDone, validationStart, validationDone, receipt,
				itemTransaction4);
	}

	public List<Event> playGameRound() {
		return playGameRound(false);
	}

	public List<Event> playGameRound(boolean success) {
		long gameRoundId = System.currentTimeMillis();

		// game start
		Event gameStart = eventHelper.buildEvent(EventType.SagaAppGameStart2(
				player.coreUserId,
				device.installId,
				"installEx",
				getCurrentTime(),
				player.episode,
				player.level,
				gameRoundId,
				1), getCurrentTime());

		progressTime(1000l * 60 * 5);

		// hc deduction
		Event hcTrans = eventHelper.buildEvent(EventType.AppItemTransaction4(
				player.coreUserId,
				device.installId,
				"installEx",
				getCurrentTime(),
				4010L,
				101L,
				0L,
				-10,
				16,
				"hc Transaction",
				""), getCurrentTime());

		progressTime(1000l * 60 * 1);

		// other item deduction
		Event itemTrans = eventHelper.buildEvent(EventType.AppItemTransaction4(
				player.coreUserId,
				device.installId,
				"installEx",
				getCurrentTime(),
				12002L,
				10214L,
				0L,
				-1,
				2,
				"In,,15,1508441654",
				""), getCurrentTime());

		// game end
		Event gameEnd = eventHelper.buildEvent(EventType.SagaAppGameEnd3(
				player.coreUserId,
				device.installId,
				"installEx",
				getCurrentTime(),
				player.episode,
				player.level,
				100000,
				3,
				success ? 0 : 1,
				0,
				0,
				0,
				0,
				gameRoundId,
				1), getCurrentTime());

		if (success) {
			player.level++;
			return Arrays.asList(gameStart, hcTrans, itemTrans, gameEnd);
		} else {
			Event fawkesKNNVideoAdTrack3 = eventHelper.buildEvent(EventType.FawkesKNNVideoAdTrack3(
					player.coreUserId,
					device.installId,
					"installEx",
					10026l,
					"1481172402227977",
					"KNN_AD_REQUEST",
					getCurrentTime(),
					"",
					"",
					0,
					"",
					"",
					"OutOfLives(2178029096)",
					"{ \"Reward\" : { \"ItemType\" : 6301, \"Quantity\" : 1} }",
					"",
					-1,
					"",
					"IMA",
					"VN",
					768), getCurrentTime());
			return Arrays.asList(gameStart, hcTrans, itemTrans, gameEnd, fawkesKNNVideoAdTrack3);
		}
	}

	public List<Event> sendCustomMessage() {
		Event appCustomMessage1 = eventHelper.buildEvent(EventType.AppCustomMessage(
				player.coreUserId,
				player.installID,
				"installEx",
				getCurrentTime(),
				"performance_tracking_v2:{AverageFrameRate:\"51.978455\",CpuInfo:\"(null)\",FpsSpan_BrokenGameFps_config:\"0 - 0\",FpsSpan_BrokenGameFps_hits:\"0\",FpsSpan_BrokenGameFps_percentage:\"0\",FpsSpan_HighFps_config:\"59 - 120\",FpsSpan_HighFps_hits:\"1748\",FpsSpan_HighFps_percentage:\"83\",FpsSpan_LowFps_config:\"29 - 43\",FpsSpan_LowFps_hits:\"17\",FpsSpan_LowFps_percentage:\"0\",FpsSpan_ModerateFps_config:\"44 - 58\",FpsSpan_ModerateFps_hits:\"290\",FpsSpan_ModerateFps_percentage:\"13\",FpsSpan_VeryLowFps_config:\"1 - 28\",FpsSpan_VeryLowFps_hits:\"27\",FpsSpan_VeryLowFps_percentage:\"1\",LoadSpan_StartUp:\"9.162688\",Manufacturer:\"apple\",MemoryConsumed:\"25280512\",Model:\"iPhone8,2\",NumFrameTicks:\"2090\",NumTextures:\"423\",NumTexturesInMemory:\"103\",OSVersion:\"11.0.2\",PhysicalSystemMemory:\"2084044800\",RunningTime:\"40.208968\",TextureMemoryUsed:\"140556226\",VersionString:\"1.111.0.3\"}"),
				getCurrentTime());

		progressTime(1l);

		Event appCustomMessage2 = eventHelper.buildEvent(EventType.AppCustomMessage(
				player.coreUserId,
				player.installID,
				"installEx",
				getCurrentTime(),
				"Calendar Reward Deliverd,DailyLoginCalendarAdsEnabledNewGiftboxesGoingLivev2_2017-09-26-141257,1,430139"),
				getCurrentTime());

		return Arrays.asList(appCustomMessage1, appCustomMessage2);
	}

	public List<Event> requestLifeFromOthers() {
		Event appMessageSentWithRecipient5 = eventHelper.buildEvent(EventType.AppMessageSentWithRecipient5(
				getCurrentTime(),
				player.coreUserId,
				3919803235l,
				"364623807294075",
				646334879,
				530944305177l,
				"fb",
				"notif",
				"requestLifeFromUser"), getCurrentTime());

		return Arrays.asList(appMessageSentWithRecipient5);
	}

}
