package com.king.rbea.backend.processors;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.junit.Test;

import com.google.common.collect.Lists;
import com.king.rbea.Output;
import com.king.rbea.Registry;
import com.king.rbea.State;
import com.king.rbea.annotations.Initialize;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.backend.types.bea.KafkaOutput;
import com.king.rbea.configuration.processor.ProcessorInfo;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.state.LocalState;
import com.king.rbea.state.StateDescriptor;
import com.king.rbea.testutils.SCTuple;

public class LocalStateTest extends ProcessorTestBase {
	private static final long serialVersionUID = 1L;

	public LocalStateTest() {
		super();
	}
	
	@Test
	public void test() throws Exception {
		RBEATestPipeline pipeline = RBEATestPipeline
				.startWithDeployment(1000, new ProcWithLocalState())
				.thenEvent(3, "ignore1")
				.andEvent(2, "ignore2")
				.andEvent(1, "ignore3")
				.thenEvent(1, "a,2")
				.thenEvent(1, "a,3")
				.thenEvent(1, "b,4")
				.thenWait(Time.seconds(1))
				.thenFailAndRestoreJob()
				.thenEvent(2, "a,0")
				.thenEvent(1, "b,1")
				.thenRemoveProcessor(1000)
				.thenWait(2000);

		Tuple2<List<ProcessorInfo>, List<BEA>> testOutput = executeProcessor(pipeline);
		List<BEA> beaOutput = testOutput.f1;

		List<BEA> expected = Lists.newArrayList(
				new KafkaOutput(1000, "a", null, "2".getBytes()),
				new KafkaOutput(1000, "a", null, "5".getBytes()),
				new KafkaOutput(1000, "b", null, "4".getBytes()),
				new KafkaOutput(1000, "a", null, "0".getBytes()),
				new KafkaOutput(1000, "b", null, "5".getBytes()));

		validateExact(expected, beaOutput);
	}

	public static class ProcWithLocalState implements Serializable {
		private static final long serialVersionUID = 1L;
		private StateDescriptor<HashMap<String, Integer>> stateMap;

		@ProcessEvent(semanticClass = SCTuple.class)
		public void processEvent(SCTuple sct, State state, Output output) throws Exception {
			Tuple2<String, Integer> t = sct.get();
			Map<String, Integer> ls = state.get(stateMap);
			int total = ls.getOrDefault(t.f0, 0) + t.f1;
			output.writeToKafka(t.f0, total);
			ls.put(t.f0, total);
		}

		@Initialize
		public void init(Registry reg) throws ProcessorException {
			stateMap = reg.registerState(LocalState.createMap("LS", String.class, Integer.class));
		}

	}
}
