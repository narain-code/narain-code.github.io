package com.king.rbea.backend.processors.ml.simulator;

public class Device {


	public long installId = 1234;
	public long macInstallId = 5678;
	public long idfvInstallId = 910;
	public String ipCountryCode = "SE";
	public String os = " 7.1.2";
	public String model = "iPhone-3,3 ";
	public String buildString = "1.10";
	public String referrer = "";
	public String networkOperator = "telia";
	public String deviceLocale = "en-SE_SE ";
	public String deviceTimeZone = "GMT+02:00";
	public String uDaid = "uDaidy";
	public String manufacturer = "Apple";

}
