package com.king.rbea.backend.processors;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.Serializable;
import java.util.List;

import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.junit.Test;

import com.king.constants.external.EventField;
import com.king.event.Event;
import com.king.flink.utils.events.LazyEventFormat;
import com.king.rbea.Aggregators;
import com.king.rbea.aggregators.AggregationWindow;
import com.king.rbea.aggregators.ApproximateDistinctCounter;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.backend.types.bea.KafkaOutput;
import com.king.rbea.configuration.processor.ProcessorInfo;
import com.king.rbea.testutils.SCLong;

/**
 * Tests for approximate discount aggregator.
 */
public class ApproximateDistinctTest extends ProcessorTestBase {
	private static final long serialVersionUID = 1L;

	public ApproximateDistinctTest() {
		super();
	}

	@Test
	public void test() throws Exception {
		RBEATestPipeline pipeline = RBEATestPipeline
				.startWithDeployment(666, new Aggregator())
				.thenEvent(1, "1").withTimestamp(100)
				.andEvent(1, "2").withTimestamp(10000)
				.andEvent(2, "1").withTimestamp(80000)
				.andEvent(2, "3").withTimestamp(80000)
				.andEvent(2, "2").withTimestamp(80000)
				.thenWatermark(2000000)
				.thenWait(Time.seconds(5));

		Tuple2<List<ProcessorInfo>, List<BEA>> output = executeProcessor(pipeline);

		assertTrue(withoutRuntimeStatistics(output.f0).isEmpty());
		assertEquals(1, output.f1.size());
		KafkaOutput first = (KafkaOutput) output.f1.get(0);

		Event aggrigatoHyperLogLog = new LazyEventFormat().parse(new String(first.getBytes()));

		assertEquals("DC", aggrigatoHyperLogLog.get(EventField.AggrigatoHyperLogLog.aggregatorId));
		assertEquals(0, aggrigatoHyperLogLog.get(EventField.AggrigatoHyperLogLog.bucketStartMsts));
		assertEquals(600000, aggrigatoHyperLogLog.get(EventField.AggrigatoHyperLogLog.bucketSizeMs));

		assertNotNull(aggrigatoHyperLogLog.get(EventField.AggrigatoHyperLogLog.aggregatedHyperLogLog));
	}

	public static class Aggregator implements Serializable {
		private static final long serialVersionUID = 1L;

		@ProcessEvent(semanticClass = SCLong.class)
		public void process(SCLong longEvent, Aggregators agg) throws Exception {
			ApproximateDistinctCounter dc = agg.getApproximateDistinctCounter("DC", AggregationWindow.MINUTES_10)
					.setTableName("DC");
			dc.offer(longEvent.get());
		}
	}
}
