package com.king.rbea.backend;

import static org.junit.Assert.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.flink.api.common.state.ValueState;
import org.junit.Test;
import org.mockito.Mockito;

import com.google.common.collect.Lists;
import com.king.rbea.backend.operators.scriptexecution.RBEAOperator;
import com.king.rbea.state.CachingState;
import com.king.rbea.state.LRUMap;

public class CachingStateTest {

	@Test
	public void cacheBypassTest() throws IOException {
		MemState state = new MemState();
		state.states.put(1, "a");
		state.states.put(2, "b");

		RBEAOperator op = Mockito.mock(RBEAOperator.class);
		Mockito.when(op.getCurrentKey()).then(i -> state.currentKey);

		CachingState<String> cState = new CachingState<>(1000, state, op);

		state.currentKey = 1;
		assertEquals("a", cState.value());

		state.currentKey = 2;
		assertEquals("b", cState.bypassCache().value());
		Mockito.verify(state.states, Mockito.times(2)).get(Mockito.any());

		state.currentKey = 1;
		assertEquals("a", cState.value());
		Mockito.verify(state.states, Mockito.times(2)).get(Mockito.any());

		state.currentKey = 2;
		assertEquals("b", cState.bypassCache().value());
		Mockito.verify(state.states, Mockito.times(3)).get(Mockito.any());

		state.currentKey = 1;
		cState.bypassCache().update("c");

		state.currentKey = 2;
		cState.bypassCache().update("d");

		assertEquals("a", state.states.get(1));
		assertEquals("d", state.states.get(2));

		Mockito.verify(state.states, Mockito.times(5)).get(Mockito.any());

		state.currentKey = 1;
		assertEquals("c", cState.bypassCache().value());
		Mockito.verify(state.states, Mockito.times(5)).get(Mockito.any());

		state.currentKey = 2;
		assertEquals("d", cState.value());
		Mockito.verify(state.states, Mockito.times(6)).get(Mockito.any());
	}

	public class MemState implements ValueState<String> {

		public Object currentKey = null;

		HashMap<Object, String> states = Mockito.spy(new HashMap<>());

		@Override
		public void clear() {
			states.remove(currentKey);
		}

		@Override
		public String value() throws IOException {
			return states.get(currentKey);
		}

		@Override
		public void update(String value) throws IOException {
			states.put(currentKey, value);
		}

	}

	@Test
	public void LRUTest() {
		List<String> removed = new ArrayList<>();
		LRUMap<String, Void> map = new LRUMap<>(3, e -> removed.add(e.getKey()));

		map.put("a", null);
		map.put("b", null);
		map.put("c", null);

		assertTrue(removed.isEmpty());
		map.get("a");
		map.put("d", null);

		assertEquals(Lists.newArrayList("b"), removed);
		assertEquals(3, map.size());

		map.put("d", null);
		map.put("b", null);

		assertEquals(Lists.newArrayList("b", "c"), removed);
		assertEquals(3, map.size());
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testPushOut() throws IOException {
		MemState state = new MemState();
		for (int i = 1; i <= 5; i++) {
			state.states.put(i, "");
		}
		Mockito.clearInvocations(state.states);

		RBEAOperator op = Mockito.mock(RBEAOperator.class);
		Mockito.when(op.getCurrentKey()).then(i -> state.currentKey);
		Mockito.doAnswer(invocation -> {
			state.currentKey = invocation.getArgument(0);
			return null;
		}).when(op).setCurrentKey(Mockito.any());

		CachingState<String> cState = new CachingState<>(5, state, op);

		for (int i = 1; i <= 5; i++) {
			state.currentKey = i;
			cState.value();
		}

		Mockito.verify(state.states, Mockito.times(5)).get(Mockito.any());
		Mockito.clearInvocations(state.states);

		state.currentKey = 1;
		cState.update("v");

		for (int i = 2; i <= 5; i++) {
			state.currentKey = i;
			cState.value();
		}

		Mockito.verifyZeroInteractions(state.states);
		state.currentKey = 6;
		cState.update("6");
		Mockito.verify(state.states, Mockito.times(1)).put(Mockito.eq(1), Mockito.eq("v"));
	}

	@SuppressWarnings("unchecked")
	@Test
	public void cacheLogicTest() throws IOException {
		MemState state = new MemState();
		state.states.put(1, "a");
		state.states.put(2, "b");
		state.states.put(3, "c");
		Mockito.clearInvocations(state.states);

		RBEAOperator op = Mockito.mock(RBEAOperator.class);
		Mockito.when(op.getCurrentKey()).then(i -> state.currentKey);
		Mockito.doAnswer(invocation -> {
			state.currentKey = invocation.getArgument(0);
			return null;
		}).when(op).setCurrentKey(Mockito.any());

		CachingState<String> cState = new CachingState<>(5, state, op);

		state.currentKey = 1;
		assertEquals("a", cState.value());
		state.currentKey = 2;
		assertEquals("b", cState.value());
		state.currentKey = 3;
		assertEquals("c", cState.value());

		Mockito.verify(state.states, Mockito.times(3)).get(Mockito.any());
		Mockito.verify(state.states, Mockito.times(0)).put(Mockito.any(), Mockito.any());
		Mockito.verify(state.states, Mockito.times(0)).remove(Mockito.any());
		Mockito.clearInvocations(state.states);

		state.currentKey = 4;
		cState.update("d");
		state.currentKey = 5;
		cState.update("e");

		state.currentKey = 4;
		assertEquals("d", cState.value());
		state.currentKey = 5;
		assertEquals("e", cState.value());

		assertEquals(5, cState.getValues().size());

		Mockito.verifyZeroInteractions(state.states);

		state.currentKey = 1;
		cState.update("a2");
		state.currentKey = 2;
		cState.update("b2");

		assertEquals(5, cState.getValues().size());
		assertTrue(cState.getValues().containsKey(3));

		state.currentKey = 6;
		cState.update("f");

		Mockito.verifyZeroInteractions(state.states);

		state.currentKey = 7;
		cState.update("g");

		Mockito.verify(state.states, Mockito.times(1)).put(Mockito.eq(4), Mockito.eq("d"));

		assertEquals(5, cState.getValues().size());
		assertFalse(cState.getValues().containsKey(3));

		state.currentKey = 1;
		assertEquals("a2", cState.value());
		state.currentKey = 2;
		assertEquals("b2", cState.value());
		state.currentKey = 3;
		assertEquals("c", cState.value());
		state.currentKey = 4;
		assertEquals("d", cState.value());
		state.currentKey = 5;
		assertEquals("e", cState.value());
		state.currentKey = 6;
		assertEquals("f", cState.value());
		state.currentKey = 7;
		assertEquals("g", cState.value());

		cState.writeAllToDb();

		assertEquals(5, cState.getValues().size());

		state.currentKey = 1;
		assertEquals("a2", cState.value());
		state.currentKey = 2;
		assertEquals("b2", cState.value());
		state.currentKey = 3;
		assertEquals("c", cState.value());
		state.currentKey = 4;
		assertEquals("d", cState.value());
		state.currentKey = 5;
		assertEquals("e", cState.value());
		state.currentKey = 6;
		assertEquals("f", cState.value());
		state.currentKey = 7;
		assertEquals("g", cState.value());

		for (int i = 1; i <= 7; i++) {
			state.currentKey = i;
			cState.clear();
		}

		for (int i = 1; i <= 7; i++) {
			state.currentKey = i;
			assertNull(cState.value());
		}
		assertTrue(state.states.isEmpty());
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testFullFlush() throws IOException {
		MemState state = new MemState();
		Mockito.clearInvocations(state.states);

		RBEAOperator op = Mockito.mock(RBEAOperator.class);
		Mockito.when(op.getCurrentKey()).then(i -> state.currentKey);
		Mockito.doAnswer(invocation -> {
			state.currentKey = invocation.getArgument(0);
			return null;
		}).when(op).setCurrentKey(Mockito.any());

		CachingState<String> cState = new CachingState<>(2, state, op);

		state.currentKey = 1;
		cState.update("a");
		state.currentKey = 2;
		cState.update("b");

		Mockito.verifyZeroInteractions(state.states);

		state.currentKey = 3;
		cState.update("c");
		Mockito.verify(state.states, Mockito.times(1)).put(Mockito.eq(1), Mockito.eq("a"));

		assertEquals(2, cState.getValues().size());
	}

}
