package com.king.rbea.backend.processors.jar;

import static org.junit.Assert.assertNotNull;

import java.io.InputStream;
import java.io.Serializable;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.apache.flink.api.java.tuple.Tuple2;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.king.rbea.Output;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.backend.hdfs.FlinkHDFSClient;
import com.king.rbea.backend.processors.ProcessorTestBase;
import com.king.rbea.backend.processors.RBEATestPipeline;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.configuration.processor.ProcessorInfo;
import com.king.rbea.hdfs.HDFSPathTool;
import com.king.rbea.hdfs.HDFSRootProvider;
import com.king.rbea.testutils.SCLong;

/**
 * Ignored right now, can be safely enabled if needed.
 * The test prefixes all HDFS paths so that the test data
 * cannot conflict with prod / QA etc data.
 */
@Ignore
public class JarDeploymentTest extends ProcessorTestBase {
	private static final long serialVersionUID = 1L;

	private final Logger logger = LoggerFactory.getLogger(getClass());

	String fileName = "classes.jar";
	
	/**
	 * Uploads the test jar to HDFS.
	 */
	@Before
	public void setup() throws Exception {
		HDFSRootProvider.setup("/flink/test/JarDeploymentTest");
		
		String applicationFilePath = HDFSPathTool.getInstance().getApplicationFilePath() + "/" + fileName;
		FlinkHDFSClient flinkHDFSClient = new FlinkHDFSClient(HDFSRootProvider.getInstance().getRoot());
		assertNotNull(flinkHDFSClient);

		if (flinkHDFSClient.exists(applicationFilePath)) {
			flinkHDFSClient.delete(applicationFilePath);
		}
		InputStream inputStream = getClass().getClassLoader().getResourceAsStream("com/king/rbea/backend/processors/jar/JarTest/" + fileName);
		flinkHDFSClient.storeFile(applicationFilePath, IOUtils.toByteArray(inputStream));
	}
	
	@Test
	public void test() throws Exception {		
		RBEATestPipeline source = RBEATestPipeline
				.startWithJarDeployment(1000, fileName)
				.thenEvent(1, "")
				.thenEvent(1, "")
				.thenEvent(1, "")
				.thenEvent(1, "")
				.thenRemoveProcessor(1000);

		Tuple2<List<ProcessorInfo>, List<BEA>> testOutput = executeProcessor(source);
		List<ProcessorInfo> infoOutput = testOutput.f0;
		List<BEA> beaOutput = testOutput.f1;

		logger.debug("" + infoOutput);
		logger.debug("" + beaOutput);
	}

	public static class PrintingProcessor implements Serializable {
		private static final long serialVersionUID = 1L;

		@ProcessEvent
		public void process(com.king.event.Event event, Output out) throws Exception {
			if (SCLong.process(event) == null) {
				out.print(event.getString(0));
			}
		}
	}
}
