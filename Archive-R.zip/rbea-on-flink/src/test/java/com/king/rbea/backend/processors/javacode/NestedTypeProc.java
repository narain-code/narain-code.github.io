package com.king.rbea.backend.processors.javacode;

import com.king.event.Event;
import com.king.rbea.Registry;
import com.king.rbea.State;
import com.king.rbea.annotations.Initialize;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.exceptions.ProcessorException;

public class NestedTypeProc {

	public static class InnerState {
		public boolean field = true;
	}

	@ProcessEvent
	public void processAppCustomMessage(Event e, State state) throws Exception {
		throw new NoClassDefFoundError();
	}

	@Initialize
	public void init(Registry registry) throws ProcessorException {
		// registry.registerState(LocalState.create("i", InnerState.class));
	}

}
