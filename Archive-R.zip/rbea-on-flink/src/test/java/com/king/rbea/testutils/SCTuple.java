package com.king.rbea.testutils;

import org.apache.flink.api.java.tuple.Tuple2;

public class SCTuple {
	private final Tuple2<String, Integer> t;

	private SCTuple(Tuple2<String, Integer> t) {
		this.t = t;
	}

	public Tuple2<String, Integer> get() {
		return t;
	}

	public static SCTuple process(com.king.event.Event e) {
		try {
			String[] split = e.getString(0).split(",");
			return new SCTuple(Tuple2.of(split[0], Integer.valueOf(split[1])));
		} catch (Exception ex) {
			return null;
		}
	}
}
