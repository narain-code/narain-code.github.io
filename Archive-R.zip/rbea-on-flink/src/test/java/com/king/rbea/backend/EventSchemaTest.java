package com.king.rbea.backend;

import static org.junit.Assert.*;

import org.apache.flink.api.java.typeutils.TypeExtractor;
import org.junit.Test;

import com.king.rbea.backend.operators.FailureHandlingSchema;
import com.king.rbea.backend.types.EventWrapper;

public class EventSchemaTest {

	@Test
	public void test() {
		FailureHandlingSchema schema = FailureHandlingSchema.INSTANCE;
		String valid = "B	20170306T134032.985+0100	80112	351131	29556361151132690	fbweb497	2023136582	8225737340	MOID39c35a96b8fd69811c117ac301bbc0a71488803973333	e8405c042c039b55	c15c2b20-2560-471b-b650-e4a23e5ddd02	afe2346e-f826-46fa-abb5-d57fcbf6120d	10622	World";

		assertTrue(schema.deserialize(valid.getBytes()).getEventType() != FailureHandlingSchema.PARSE_ERROR_TYPE);
		assertTrue(schema.deserialize("invalid".getBytes()).getEventType() == FailureHandlingSchema.PARSE_ERROR_TYPE);
	}

	@Test
	public void wrapperTypeTest() {
		assertEquals(EventWrapper.TYPE, TypeExtractor.getForClass(EventWrapper.class));
	}

}
