package com.king.rbea.backend.processors.runtimestatistics;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.flink.api.java.tuple.Tuple2;
import org.junit.Before;
import org.junit.Test;

import com.google.common.collect.Lists;
import com.king.rbea.Output;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.backend.operators.scriptexecution.metrics.RBEAMetricsTracker;
import com.king.rbea.backend.processors.ProcessorTestBase;
import com.king.rbea.backend.processors.RBEATestPipeline;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.backend.types.processorinfo.RuntimeStatistics;
import com.king.rbea.configuration.processor.ProcessorInfo;
import com.king.rbea.testutils.SCLong;

/**
 * Test for emitting and validating {@link RuntimeStatistics}-messages as part
 * of an RBEA job.
 */
public class RuntimeStatisticsTest extends ProcessorTestBase {
	private static final long serialVersionUID = 1L;

	@Before
	public void setup() {
		// Speed up things by setting the flush value to a smaller value
		RBEAMetricsTracker.runtimeStatsIntervalMillis = 5 * 1000;
	}

	/**
	 * Tests that when sending an event and not waiting no RT is emitted.
	 */
	@Test
	public void testNoFlush() throws Exception {
		RBEATestPipeline pipeline = RBEATestPipeline
				.startWithDeployment(1000, new PrintingProcessor())
				.thenEvent(1, "good"); // No flush

		Tuple2<List<ProcessorInfo>, List<BEA>> testOutput = executeProcessor(pipeline);
		List<ProcessorInfo> infoOutput = testOutput.f0;
		assertTrue(infoOutput.isEmpty());
	}

	/**
	 * Tests that resulting RS looks correct when sending one event and with one
	 * processor.
	 */
	@Test
	public void testOneEventOneProcessor() throws Exception {
		RBEATestPipeline pipeline = RBEATestPipeline
				.startWithDeployment(1000, new PrintingProcessor())
				.thenWait(RBEAMetricsTracker.runtimeStatsIntervalMillis + 500)
				.thenEvent(1, "good"); // Will trigger RT flush

		internalTestOneProcessor(pipeline, 1);
	}

	/**
	 * Tests that resulting RS looks correct when sending multiple event and with
	 * one processor.
	 */
	@Test
	public void testMultipleEventsOneProcessor() throws Exception {
		RBEATestPipeline pipeline = RBEATestPipeline
				.startWithDeployment(1000, new PrintingProcessor())
				.thenEvent(1, "good")
				.thenEvent(1, "good")
				.thenWait(RBEAMetricsTracker.runtimeStatsIntervalMillis + 500)
				.thenEvent(1, "good"); // Will trigger RT flush

		internalTestOneProcessor(pipeline, 3);
	}

	/**
	 * Tests that resulting RSs look correct when sending multiple event and with
	 * multiple processors.
	 */
	@Test
	public void testMultipleEventsMultipleProcessors() throws Exception {
		List<Long> processorIds = Lists.newArrayList(1L, 2L, 3L, 4L);

		RBEATestPipeline pipeline = RBEATestPipeline.startWithDeployment(processorIds.get(0), new PrintingProcessor());
		for (int i = 1; i < processorIds.size(); i++) {
			pipeline = pipeline.thenDeploy(processorIds.get(i), new PrintingProcessor());
		}

		pipeline = pipeline.thenEvent(1, "good")
				.thenEvent(1, "good")
				.thenWait(RBEAMetricsTracker.runtimeStatsIntervalMillis + 500)
				.thenEvent(1, "good"); // Will trigger RT flush

		Tuple2<List<ProcessorInfo>, List<BEA>> testOutput = executeProcessor(pipeline);
		List<ProcessorInfo> infoOutput = testOutput.f0;
		assertEquals(processorIds.size(), infoOutput.size());

		Map<Long, RuntimeStatistics> rss = new HashMap<>();
		for (ProcessorInfo pi : infoOutput) {
			RuntimeStatistics rs = (RuntimeStatistics) pi;
			rss.put(rs.getProcessorId(), rs);
		}

		for (long procId : processorIds) {
			assertTrue("" + procId, rss.containsKey(procId));
			validateRuntimeStatistics(rss.get(procId), 3, procId);
		}
	}

	/**
	 * Like {@link #testMultipleEventsMultipleProcessors}, but flushes the stats
	 * twice.
	 */
	@Test
	public void testMultipleEventsMultipleProcessorsMultipleFlushes() throws Exception {
		List<Long> processorIds = Lists.newArrayList(1L, 2L, 3L, 4L);

		RBEATestPipeline pipeline = RBEATestPipeline.startWithDeployment(processorIds.get(0), new PrintingProcessor());
		for (int i = 1; i < processorIds.size(); i++) {
			pipeline = pipeline.thenDeploy(processorIds.get(i), new PrintingProcessor());
		}

		pipeline = pipeline.thenEvent(1, "good")
				.thenEvent(1, "good")
				.thenWait(RBEAMetricsTracker.runtimeStatsIntervalMillis + 500)
				.thenEvent(1, "good") // Will trigger RT flush with three events
				.thenEvent(1, "good")
				.thenEvent(1, "good")
				.thenEvent(1, "good")
				.thenWait(RBEAMetricsTracker.runtimeStatsIntervalMillis + 500)
				.thenEvent(1, "good"); // Will trigger RT flush with four events

		Tuple2<List<ProcessorInfo>, List<BEA>> testOutput = executeProcessor(pipeline);
		List<ProcessorInfo> infoOutput = testOutput.f0;
		assertEquals(processorIds.size() * 2, infoOutput.size());

		Map<Long, RuntimeStatistics> rss = new HashMap<>();
		for (int i = 0; i < 4; i++) {
			ProcessorInfo pi = infoOutput.get(i);
			RuntimeStatistics rs = (RuntimeStatistics) pi;
			rss.put(rs.getProcessorId(), rs);
		}
		for (long procId : processorIds) {
			assertTrue("" + procId, rss.containsKey(procId));
			validateRuntimeStatistics(rss.get(procId), 3, procId);
		}

		rss.clear();
		for (int i = 4; i < 8; i++) {
			ProcessorInfo pi = infoOutput.get(i);
			RuntimeStatistics rs = (RuntimeStatistics) pi;
			rss.put(rs.getProcessorId(), rs);
		}
		for (long procId : processorIds) {
			assertTrue("" + procId, rss.containsKey(procId));
			validateRuntimeStatistics(rss.get(procId), 4, procId);
		}
	}

	private void internalTestOneProcessor(RBEATestPipeline source, int count) throws Exception {
		Tuple2<List<ProcessorInfo>, List<BEA>> testOutput = executeProcessor(source);
		List<ProcessorInfo> infoOutput = testOutput.f0;
		assertEquals(1, infoOutput.size());

		validateRuntimeStatistics((RuntimeStatistics) infoOutput.get(0), count, 1000);
	}

	/**
	 * Checks the given {@code rs} matches the arguments.
	 * 
	 * @param rs
	 *            the checked instance
	 * @param count
	 *            expected execution count, i.e. processed events count
	 * @param processorId
	 *            expected processor id
	 */
	private void validateRuntimeStatistics(RuntimeStatistics rs, int count, long processorId) {
		assertEquals(count, rs.getExecutionCount());
		assertTrue(rs.getExecutionTimeSum() > 0);
		if (count == 1) {
			assertEquals(rs.getExecutionTimeSum(), rs.getMaxExecutionTime());
		} else {
			assertTrue(rs.getExecutionTimeSum() > rs.getMaxExecutionTime());
		}
		assertEquals(processorId, rs.getProcessorId());
	}

	public static class PrintingProcessor implements Serializable {
		private static final long serialVersionUID = 1L;

		@ProcessEvent
		public void process(com.king.event.Event event, Output out) throws Exception {
			if (SCLong.process(event) == null) {
				out.print(event.getString(0));
			}
		}
	}

	public static class DummyProcessor implements Serializable {
		private static final long serialVersionUID = 1L;

		@ProcessEvent
		public void processEvent() {}
	}
}
