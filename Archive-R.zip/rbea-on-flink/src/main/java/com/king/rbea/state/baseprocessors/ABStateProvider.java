package com.king.rbea.state.baseprocessors;

import java.util.Collections;
import java.util.List;

import com.king.rbea.configuration.processor.Deployment;
import com.king.rbea.state.abstate.ABTestBaseProcessor;

public class ABStateProvider implements BaseProcessorProvider {
	@Override
	public List<Deployment> getBaseProcessors() {
		return Collections.singletonList(ABTestBaseProcessor.DEPLOYMENT);
	}
}
