package com.king.rbea.backend.operators.scriptexecution;

import org.apache.flink.types.Either;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.king.event.Event;
import com.king.rbea.Context;
import com.king.rbea.State;
import com.king.rbea.Timers;
import com.king.rbea.Utils;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.configuration.Configuration;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.utils.MissingState;
import com.king.rbea.utils.MissingTimers;

public class FlinkContext implements Context {
	
	

	public final FlinkRBEAUtils utils;

	public final long coreId;
	public final boolean hasCoreId;

	public final Collector<Either<BEA, Configuration>> collector;
	public final FlinkTimers flinkTimers;

	public final long procId;
	public final Event event;
	public final FlinkState state;

	private final int subtaskIndex;

	private String stateExportTopic;
	private String stateSchemaTopic;

	public FlinkContext(long coreId, boolean hasCoreId, Collector<Either<BEA, Configuration>> collector,
			FlinkTimers flinkTimers, long procId, Event event, FlinkState state, int subtaskIndex,
			String stateExportTopic, String stateSchemaTopic) {

		this.coreId = coreId;
		this.hasCoreId = hasCoreId;
		this.collector = collector;
		this.flinkTimers = flinkTimers;
		this.procId = procId;
		this.event = event;
		this.state = state;
		this.subtaskIndex = subtaskIndex;
		this.stateExportTopic = stateExportTopic;
		this.stateSchemaTopic = stateSchemaTopic;
		this.utils = new FlinkRBEAUtils(this);
	}

	@Override
	public Long getCoreUserId() throws ProcessorException {
		return hasCoreId ? coreId : null;
	}

	@Override
	public State getState() {
		if (hasCoreId) {
			return state;
		} else {
			return MissingState.INSTANCE;
		}
	}

	@Override
	public CollectingAggregators getAggregators() {
		return new CollectingAggregators(collector, procId);
	}

	@Override
	public CollectingOutput getOutput() {
		return new CollectingOutput(collector, procId, subtaskIndex, stateExportTopic, stateSchemaTopic);
	}

	@Override
	public Timers getTimers() {
		if (hasCoreId) {
			return flinkTimers;
		} else {
			return MissingTimers.INSTANCE;
		}
	}

	@Override
	public Utils getUtils() {
		return utils;
	}

	@Override
	public Event getEvent() {
		return event;
	}
}
