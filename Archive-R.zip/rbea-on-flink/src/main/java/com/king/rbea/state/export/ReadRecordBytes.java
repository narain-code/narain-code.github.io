package com.king.rbea.state.export;

import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.util.Collector;

public class ReadRecordBytes implements FlatMapFunction<byte[], Tuple2<String, byte[]>> {
	private static final long serialVersionUID = 1L;

	@Override
	public void flatMap(byte[] bytes, Collector<Tuple2<String, byte[]>> out) throws Exception {
		try {
			out.collect(StateExportDeserializer.extractSchemaName(bytes));
		} catch (Throwable t) {
			StateExportWriterJob.LOG.error("Error while deserializing export message", t);
		}
	}
}