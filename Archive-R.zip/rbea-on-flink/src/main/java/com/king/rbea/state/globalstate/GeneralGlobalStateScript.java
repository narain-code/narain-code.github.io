package com.king.rbea.state.globalstate;

import static org.apache.commons.lang3.ArrayUtils.contains;

import java.io.IOException;
import java.io.Serializable;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;

import com.king.constants.external.EventType;
import com.king.constants.external.event.typed.events.AppCustomMessage;
import com.king.constants.external.event.typed.events.SignInUser2;
import com.king.event.Event;
import com.king.kgk.SCClientStart;
import com.king.kgk.SCCommunityDataUpdated;
import com.king.kgk.SCDeviceInfo;
import com.king.rbea.Output;
import com.king.rbea.Registry;
import com.king.rbea.State;
import com.king.rbea.annotations.Initialize;
import com.king.rbea.annotations.OnError;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.configuration.processor.Deployment;
import com.king.rbea.exceptions.ProcessorException;

public class GeneralGlobalStateScript implements Serializable {

	private static final long serialVersionUID = 1L;
	public static final Deployment DEPLOYMENT = Deployment.newJavaProcessor("GeneralGlobalStateScript",
			Long.MAX_VALUE - 1337, new GeneralGlobalStateScript(), "", 0l, false);

	private static final Long minRamBytes = 1024l;

	private static final Pattern regexBuildString = Pattern.compile("[a-z0-9_.-]+");
	private static final Pattern regexDeviceOsString = Pattern.compile("[a-z0-9_. ]+");
	private static final Pattern regexDeviceLocaleString = Pattern.compile("[a-z_-]+");
	private static final Pattern regexDeviceModelString = Pattern.compile("[a-z0-9,_. -]+");
	private static final Pattern regexDeviceManufacturerString = Pattern.compile("[a-z0-9]+");
	private static final Pattern regexTimezoneString = Pattern.compile("^gmt(?:[+-](?:2[0-3]|[01][0-9]):[0-5][0-9])$");

	private GeneralGlobalStateScript() {}

	@OnError(maxErrorsPerMin = Integer.MAX_VALUE)
	public void handleErr(Throwable err, Output out) throws ProcessorException {
		GlobalStateUtility.log("GeneralGlobalStateScript error", err, out);
	}

	@ProcessEvent(semanticClass = SCClientStart.class)
	public void onClientStart(SCClientStart clientStart, Event event, State state) throws ProcessorException {
		/**
		 * APP_BUILD_STRING LATEST_APP_UPDATE_MSTS
		 */
		String appBuildStr = clientStart.getBuildstring();
		if (appBuildStr != null) {
			appBuildStr = appBuildStr.trim().toLowerCase();
			if (regexBuildString.matcher(appBuildStr).matches()) {
				String lastAppBuildStr = state.get(GlobalState.APP_BUILD_STRING);
				if (!lastAppBuildStr.equals(appBuildStr)) {
					state.update(GlobalState.APP_BUILD_STRING, appBuildStr);
					state.update(GlobalState.LATEST_APP_UPDATE_MSTS, event.getTimeStamp());
				}
			}
		}

		/**
		 * CLIENT_PLATFORM
		 */
		String platform = GlobalStateUtility.getPlatformFromFid(clientStart.getFlavourId());
		state.update(GlobalState.CLIENT_PLATFORM, platform);

		/**
		 * HAS_PLAYED_ON_IOS
		 */
		if (!state.get(GlobalState.HAS_PLAYED_ON_IOS) &&
				platform.equalsIgnoreCase(GlobalStateUtility.Platforms.IOS.toString())) {
			state.update(GlobalState.HAS_PLAYED_ON_IOS, true);
		}

		/**
		 * HAS_PLAYED_ON_ANDROID
		 */
		if (!state.get(GlobalState.HAS_PLAYED_ON_ANDROID) &&
				platform.equalsIgnoreCase(GlobalStateUtility.Platforms.ANDROID.toString())) {
			state.update(GlobalState.HAS_PLAYED_ON_ANDROID, true);
		}

		/**
		 * COUNTRY_CHANGE_HISTORY_30DAYS
		 */
		TreeMap<Long, String> countryChangeHistory = state.get(GlobalState.COUNTRY_CHANGE_HISTORY_30DAYS);
		String country = clientStart.getCountrycode();
		long now = event.getTimeStamp();
		if (country != null) {
			country = country.trim().toUpperCase();
			if (contains(GlobalStateUtility.isoCountryCodes, country)) {
				// Case: time stamp < latest time stamp in list
				if (!countryChangeHistory.isEmpty()) {
					Map.Entry<Long, String> latestListEntry = countryChangeHistory.lastEntry();
					if (latestListEntry.getKey() < now && !latestListEntry.getValue().equals(country)) {
						countryChangeHistory.put(now, country);
					}
				} else {
					countryChangeHistory.put(now, country);
				}
			}
		}
		// Act: remove entire entries older than 30 days, while keeping at least one
		// entry
		GlobalStateUtility.historyCleanup(countryChangeHistory, now, GlobalStateUtility.hrsPer30Days,
				GlobalStateUtility.maxCountryNum);

		/**
		 * DEVICE_TIMEZONE
		 */
		String timezone = clientStart.getDevicetimezone();
		if (timezone != null && timezone.length() >= 3) {
			timezone = timezone.trim().toLowerCase();
			if (regexTimezoneString.matcher(timezone).matches()) {
				state.update(GlobalState.DEVICE_TIMEZONE, timezone);
			} else {
				state.update(GlobalState.DEVICE_TIMEZONE, "illegal_string");
			}
		}

		/**
		 * DEVICE_OS
		 */
		String os = clientStart.getOs();
		if (os != null) {
			os = os.trim().toLowerCase();
			if (regexDeviceOsString.matcher(os).matches()) {
				state.update(GlobalState.DEVICE_OS, os);
			}
		}

		/**
		 * DEVICE_LOCALE
		 */
		String locale = clientStart.getDevicelocale();
		if (locale != null) {
			locale = locale.trim().toLowerCase();
			if (regexDeviceLocaleString.matcher(locale).matches()) {
				state.update(GlobalState.DEVICE_LOCALE, locale);
			}
		}

	}

	@ProcessEvent(eventType = EventType.SignInUser2)
	public void onSignInUser2(SignInUser2 signInUser2, Event event, State state) throws ProcessorException {
		/**
		 * NUM_SIGNIN
		 */
		int numSignIn = signInUser2.getNumSignIns();
		state.update(GlobalState.NUM_SIGNIN, numSignIn);

		/**
		 * FIRST_INSTALL_MSTS
		 */
		if (numSignIn < 2) {
			state.update(GlobalState.FIRST_INSTALL_MSTS, event.getTimeStamp());
		}
	}

	@ProcessEvent(semanticClass = SCDeviceInfo.class)
	public void onDeviceInfo(SCDeviceInfo deviceInfo, Event event, State state) throws ProcessorException {
		/**
		 * DEVICE_MODEL
		 */
		String model = deviceInfo.getModel();
		if (model != null) {
			model = model.trim().toLowerCase();
			if (regexDeviceModelString.matcher(model).matches()) {
				state.update(GlobalState.DEVICE_MODEL, model);
			}
		}

		/**
		 * DEVICE_OS
		 */
		String os = deviceInfo.getOs();
		if (os != null) {
			os = os.trim().toLowerCase();
			if (regexDeviceOsString.matcher(os).matches()) {
				state.update(GlobalState.DEVICE_OS, os);
			}
		}

		/**
		 * DEVICE_RAM
		 */
		Long ram = deviceInfo.getDeviceram(); // this does not work for games such as CCS
		if (ram != null && ram > 0) {
			state.update(GlobalState.DEVICE_RAM, ram);
		}

		/**
		 * DEVICE_MANUFACTURER
		 */
		String manufacturer = deviceInfo.getManufacturer();
		if (manufacturer != null) {
			manufacturer = manufacturer.trim().toLowerCase();
			if (regexDeviceManufacturerString.matcher(manufacturer).matches()) {
				state.update(GlobalState.DEVICE_MANUFACTURER, manufacturer);
			}
		}
	}

	@ProcessEvent(eventType = EventType.AppCustomMessage)
	public void onAppCustomMessage(AppCustomMessage customMessage, Event event, State state) throws ProcessorException {
		String customMsg = customMessage.getCustomMessage();
		if (customMsg == null) {
			return;
		}
		int idxRam = customMsg.indexOf("PhysicalSystemMemory:");
		int idxFr = customMsg.indexOf("AverageFrameRate:");
		if (customMsg.contains("performance_tracking_v")) {
			/**
			 * DEVICE_RAM
			 */
			if (idxRam >= 0) {
				String strInQuotes = StringUtils.substringBetween(customMsg.substring(idxRam), "\"", "\"");
				long ram;
				try {
					ram = Long.parseLong(strInQuotes.replaceAll("[^\\d.]", ""));
				} catch (Exception e) {
					ram = 0l;
				}
				if (ram >= minRamBytes) {
					state.update(GlobalState.DEVICE_RAM, ram);
				}
			}
			/**
			 * DISPLAY_FRAME_RATE
			 */
			if (idxFr >= 0) {
				String strInQuotes = StringUtils.substringBetween(customMsg.substring(idxFr), "\"", "\"");
				double fr;
				try {
					fr = Double.parseDouble(strInQuotes.replaceAll("[^\\d.]", ""));
				} catch (Exception e) {
					fr = 0d;
				}
				if (fr > 0) {
					state.update(GlobalState.DISPLAY_FRAME_RATE, fr);
				}
			}

		}
	}

	@ProcessEvent(semanticClass = SCCommunityDataUpdated.class)
	public void onCommunityDataUpdated(SCCommunityDataUpdated communityDataUpdated, Event event, State state)
			throws ProcessorException {
		/**
		 * IS_STRONG_ACCOUNT
		 */
		state.update(GlobalState.IS_STRONG_ACCOUNT, true);
	}

	/**
	 * All states have to be initialized here (incl. default value)
	 */
	@Initialize
	public void init(Registry reg) throws ProcessorException, IOException {
		reg.registerState(GlobalState.APP_BUILD_STRING);
		reg.registerState(GlobalState.LATEST_APP_UPDATE_MSTS);
		reg.registerState(GlobalState.DEVICE_TIMEZONE);
		reg.registerState(GlobalState.DEVICE_LOCALE);
		reg.registerState(GlobalState.DEVICE_OS);
		reg.registerState(GlobalState.DEVICE_MODEL);
		reg.registerState(GlobalState.DEVICE_RAM);
		reg.registerState(GlobalState.DISPLAY_FRAME_RATE);
		reg.registerState(GlobalState.DEVICE_MANUFACTURER);
		reg.registerState(GlobalState.CLIENT_PLATFORM);
		reg.registerState(GlobalState.FIRST_INSTALL_MSTS);
		reg.registerState(GlobalState.NUM_SIGNIN);
		reg.registerState(GlobalState.HAS_PLAYED_ON_IOS);
		reg.registerState(GlobalState.HAS_PLAYED_ON_ANDROID);
		reg.registerState(GlobalState.COUNTRY_CHANGE_HISTORY_30DAYS);
		reg.registerState(GlobalState.IS_STRONG_ACCOUNT);
	}

}