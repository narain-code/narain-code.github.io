package com.king.rbea.state.export;

import static com.king.rbea.backend.utils.BackendConstants.CHECKPOINT_DIR;
import static com.king.rbea.backend.utils.BackendConstants.CHECKPOINT_INTERVAL_SECONDS;
import static org.apache.flink.api.java.utils.ParameterTool.fromPropertiesFile;

import java.io.File;

import org.apache.avro.Schema;
import org.apache.avro.generic.GenericRecord;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.runtime.state.filesystem.FsStateBackend;
import org.apache.flink.streaming.api.CheckpointingMode;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.CheckpointConfig;
import org.apache.flink.streaming.api.environment.CheckpointConfig.ExternalizedCheckpointCleanup;
import org.apache.flink.streaming.api.environment.LocalStreamEnvironment;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.king.rbea.backend.configuration.KafkaParams;
import com.king.rbea.backend.utils.BackendConstants;
import com.king.rbea.backend.utils.RBEAStreamUtils;

public class StateExportWriterJob {

	public static final String EXPORT_BATCH_SIZE = "exportBatchSize";
	public static final String EXPORT_BUCKET_SIZE_MINUTES = "exportBucketSizeMinutes";
	public static final String EXPORT_BASE_PATH = "exportBasePath";
	public static final String HIVE_CONNECTION_STRING = "hiveConnectionString";
	public static final Logger LOG = LoggerFactory.getLogger(StateExportWriterJob.class);

	public static void main(String[] args) throws Exception {

		if (args.length != 1) {
			System.out.println("Need to specify properties files");
			return;
		}

		ParameterTool allParams = fromPropertiesFile(args[0]);
		String backendShortName = new File(args[0]).getName().split("\\.")[0];

		StreamExecutionEnvironment env = createExecutionEnvironment(allParams, backendShortName);

		KafkaParams kafkaParams = new KafkaParams(allParams);
		int sourceParallelism = allParams.getInt(BackendConstants.SOURCE_PARALLELISM);

		DataStream<byte[]> rawExportStream = RBEAStreamUtils.readRaw(env,
				allParams.get(BackendConstants.STATE_EXPORT_TOPIC), kafkaParams, "export",
				"ExportStream", sourceParallelism);

		DataStream<byte[]> rawSchemaStream = RBEAStreamUtils.readRaw(env,
				allParams.get(BackendConstants.STATE_SCHEMA_TOPIC), kafkaParams, "schema",
				"SchemaStream", sourceParallelism);

		DataStream<Tuple2<Long, Schema>> schemaStream = rawSchemaStream.flatMap(new ReadSchema()).name("Read schema");
		DataStream<Tuple2<String, byte[]>> exportStream = rawExportStream.flatMap(new ReadRecordBytes())
				.name("Read record bytes");

		DataStream<GenericRecord> avroRecords = schemaStream.broadcast().connect(exportStream)
				.transform("Deserialize Avro records", TypeInformation.of(GenericRecord.class),
						new StateExportOperator(allParams))
				.uid("deserialize");

		String basePath = allParams.get(EXPORT_BASE_PATH);
		RBEABucketingSink<GenericRecord> sink = new RBEABucketingSink<>(basePath + "/final", basePath + "/uncommitted");

		sink.setBucketer(new AvroDateTimeBucketer(allParams.getInt(EXPORT_BUCKET_SIZE_MINUTES, 10)));
		sink.setBatchSize(allParams.getLong(EXPORT_BATCH_SIZE, RBEABucketingSink.DEFAULT_BATCH_SIZE));
		sink.setWriter(new FlinkAvroWriter());
		sink.setCommitCallback(new HiveTableManager(allParams.get(HIVE_CONNECTION_STRING), basePath));

		avroRecords.addSink(sink).uid("bucketsink").name("Bucketing file sink");
		env.execute("State Export");
	}

	private static StreamExecutionEnvironment createExecutionEnvironment(ParameterTool allParams, String backendName)
			throws Exception {
		StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

		String cpDir = allParams.getRequired(CHECKPOINT_DIR);
		cpDir = cpDir.endsWith("/") ? cpDir : cpDir + "/";
		cpDir += backendName;

		env.getConfig().disableSysoutLogging();
		env.setStateBackend(new FsStateBackend(cpDir));
		env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime);

		if (allParams.has(BackendConstants.MAX_PARALLELISM)) {
			env.setMaxParallelism(allParams.getInt(BackendConstants.MAX_PARALLELISM));
		}

		long cpInterval = allParams.getLong(CHECKPOINT_INTERVAL_SECONDS) * 1000;
		if (cpInterval > 0) {
			LOG.info("Checkpointing enabled with cp interval = {} s", cpInterval / 1000);

			CheckpointConfig checkpointConf = env.getCheckpointConfig();
			checkpointConf.setCheckpointInterval(cpInterval);
			checkpointConf.setMinPauseBetweenCheckpoints(cpInterval);
			checkpointConf.setCheckpointingMode(CheckpointingMode.EXACTLY_ONCE);
			checkpointConf.setCheckpointTimeout(10 * 60 * 60 * 1000);
			checkpointConf.setMaxConcurrentCheckpoints(1);
			if (!(env instanceof LocalStreamEnvironment)) {
				checkpointConf.enableExternalizedCheckpoints(ExternalizedCheckpointCleanup.RETAIN_ON_CANCELLATION);
			}
		}
		return env;
	}

}
