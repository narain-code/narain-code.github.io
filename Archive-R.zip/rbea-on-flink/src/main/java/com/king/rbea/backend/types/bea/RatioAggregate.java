package com.king.rbea.backend.types.bea;

import org.apache.flink.api.common.ExecutionConfig;
import org.apache.flink.api.common.typeutils.TypeSerializer;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.typeutils.TypeExtractor;

import com.king.rbea.aggregators.AverageAggregator;
import com.king.rbea.backend.utils.BackendConstants;

/**
 * {@code RatioAggregate} is a {@link BEA} that is an aggregate that sums stuff and keeps track of numerator and
 * denominator, see {@link AverageAggregator}.
 */
public class RatioAggregate extends Aggregate {
	private static final long serialVersionUID = 1L;
	
	public static final TypeSerializer<RatioAggregate> serializer = TypeExtractor.getForClass(RatioAggregate.class)
			.createSerializer(new ExecutionConfig());

	public long numerator;
	public long denominator;

	public RatioAggregate(long processorId, long windowSizeMillis, String aggregatorName, String dimensions,
			long numerator, long denominator) {
		super(BackendConstants.BEA_RATIO_AGGREGATE_TYPE, windowSizeMillis, processorId, aggregatorName, dimensions);
		this.numerator = numerator;
		this.denominator = denominator;
	}

	public RatioAggregate() {
		// Empty constructor for deserialization
	}

	@Override
	public void update(Aggregate ratio) {
		Tuple2<Long, Long> v = ((RatioAggregate) ratio).getValue();
		numerator += v.f0;
		denominator += v.f1;
	}

	@Override
	public Tuple2<Long, Long> getValue() {
		return Tuple2.of(numerator, denominator);
	}

	@Override
	public long getLongValue() {
		if (denominator == 0) {
			return 0;
		}
		return (1_000_000 * numerator) / denominator;
	}

	public long getNumerator() {
		return numerator;
	}
	
	public long getDenominator() {
		return denominator;
	}
}