package com.king.rbea.state.export;

import java.io.Serializable;
import java.util.function.BiConsumer;

import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

public interface FileCommitCallback extends BiConsumer<FileSystem, Path>, Serializable, AutoCloseable {

	default void open() throws Exception {}
	
	default void close() throws Exception {}
}
