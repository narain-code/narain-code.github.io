package com.king.rbea.backend.operators.scriptexecution;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.function.Supplier;

import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.typeutils.TypeSerializer;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.util.InstantiationUtil;

import com.king.flink.utils.Unchecked;
import com.king.rbea.backend.operators.scriptexecution.metrics.RBEAMetricsTracker;
import com.king.rbea.backend.types.SerializedOrCached;
import com.king.rbea.exceptions.BackendException;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.state.LocalState;
import com.king.rbea.state.internal.InternalState;

public final class States {
	public HashMap<Short, SerializedOrCached> cachedBaseStates = null;
	public HashMap<Short, byte[]> userStates = null;

	private boolean baseChanged = false;
	private boolean userChanged = false;

	private final long coreId;
	private final Fields fields;
	private final ValueState<HashMap<Short, SerializedOrCached>> baseFieldStates;
	private final ValueState<HashMap<Short, byte[]>> userFieldStates;
	private final RBEAMetricsTracker metrics;

	public States(Fields fields, long coreId, ValueState<HashMap<Short, SerializedOrCached>> baseFieldStates,
			ValueState<HashMap<Short, byte[]>> userFieldStates, RBEAMetricsTracker metricsTracker) {
		this.fields = fields;
		this.coreId = coreId;
		this.baseFieldStates = baseFieldStates;
		this.userFieldStates = userFieldStates;
		this.metrics = metricsTracker;
	}

	public Tuple2<Boolean, Supplier<Object>> updateFieldValue(Short id, Object val, boolean baseField,
			boolean baseAccess) throws ProcessorException {
		return updateFieldValue(id, val, baseField, fields.getFieldForId(id), baseAccess);
	}

	private Tuple2<Boolean, Supplier<Object>> updateFieldValue(Short id, Object val, boolean baseField,
			LocalState<?> localState, boolean baseAccess) throws ProcessorException {

		fetchIfNotPresent(baseField);

//		if (baseField && !baseAccess) {
//			throw new ProcessorException("Illegal base state modification");
//		}

		if (baseField) {
			baseChanged = true;
			TypeSerializer<?> serializer = localState.getSerializer();
			SerializedOrCached newVal = val == null ? null
					: serializer.isImmutableType() ? new SerializedOrCached(serializer, val)
							: new SerializedOrCached(serialize(baseField, localState, val));

			SerializedOrCached prevVal = newVal != null ? cachedBaseStates.put(id, newVal)
					: cachedBaseStates.remove(id);

			if ((prevVal == null && newVal == null) || (prevVal != null && prevVal.equals(newVal))) {
				return Tuple2.of(false, () -> null);
			} else {
				return Tuple2.of(true, () -> {
					try {
						return prevVal == null ? null : prevVal.deserialize(serializer);
					} catch (Exception e) {
						Unchecked.throwSilently(e);
						return null;
					}
				});

			}
		} else {
			userChanged = true;
			byte[] newValBytes = serialize(baseField, localState, val);
			byte[] prevBytes = newValBytes != null ? userStates.put(id, newValBytes) : userStates.remove(id);
			if (Arrays.equals(prevBytes, newValBytes)) {
				return Tuple2.of(true, () -> null);
			} else {
				return Tuple2.of(true, () -> {
					try {
						return deserialize(baseField, localState, prevBytes);
					} catch (ProcessorException e) {
						Unchecked.throwSilently(e);
						return null;
					}
				});

			}
		}
	}

	public void update() {
		try {
			if (cachedBaseStates != null && baseChanged) {
				baseFieldStates.update(cachedBaseStates);
			}
			if (userStates != null && userChanged) {
				userFieldStates.update(userStates);
			}
			metrics.baseStateAccessRate.add(cachedBaseStates != null);
			metrics.userStateAccessRate.add(userStates != null);
		} catch (Exception e) {
			Unchecked.throwSilently(new BackendException(e, "Error while writing states to the state backend."));
		}
	}

	private void fetchIfNotPresent(boolean baseField) {
		if (baseField) {
			if (cachedBaseStates == null) {
				try {
					cachedBaseStates = baseFieldStates.value();
					if (cachedBaseStates == null) {
						cachedBaseStates = new HashMap<>();
					}
				} catch (Exception e) {
					Unchecked.throwSilently(
							new BackendException(e, "Error while retrieving base fields from the state backend."));
				}
			}
		} else {
			if (userStates == null) {
				try {
					userStates = userFieldStates.value();
					if (userStates == null) {
						userStates = new HashMap<>();
					}
				} catch (Exception e) {
					Unchecked.throwSilently(
							new BackendException(e, "Error while retrieving user fields from the state backend."));
				}
			}
		}
	}

	private Object readFieldValue(Short id, boolean baseField, LocalState<?> localState) throws ProcessorException {
		if (baseField) {
			SerializedOrCached value = cachedBaseStates.get(id);
			if (value != null) {
				try {
					return value.deserialize(localState.getSerializer());
				} catch (IOException e) {
					Unchecked.throwSilently(
							new BackendException(e, "Error while getting base field: " + localState.getStateName()));
				}
			}
		} else {
			byte[] stateBytes = userStates.get(id);
			return deserialize(baseField, localState, stateBytes);
		}

		return null;
	}

	private Object deserialize(boolean baseField, LocalState<?> localState, byte[] stateBytes)
			throws ProcessorException {
		if (stateBytes != null && stateBytes.length > 0) {
			try {
				return InstantiationUtil.deserializeFromByteArray(localState.getSerializer(), stateBytes);
			} catch (Throwable e) {
				throwErr(baseField, e,
						"Could not deserialize value for base state: " + localState.getStateName(),
						"Could not deserialize value for user state: " + localState.getStateName());
			}
		}
		return null;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public byte[] serialize(boolean baseField, LocalState<?> localState, Object value) throws ProcessorException {
		if (value == null) {
			return null;
		}

		try {
			return InstantiationUtil.serializeToByteArray((TypeSerializer) localState.getSerializer(), value);
		} catch (Throwable e) {
			throwErr(baseField, e,
					"Could not serialize value for base state: " + localState.getStateName(),
					"Could not serialize value for user state: " + localState.getStateName());
			return null;
		}
	}

	public Object getFieldValue(Short id, boolean baseField, boolean baseAccess) throws ProcessorException {

		LocalState<?> localState = fields.getFieldForId(id);

		InternalState iState = new InternalState() {
			@Override
			public void writeValue(Object value) throws ProcessorException, BackendException {
				fetchIfNotPresent(baseField);
				updateFieldValue(id, value, baseField, localState, baseAccess);
			}

			@Override
			public Object readValue() throws ProcessorException, BackendException {
				fetchIfNotPresent(baseField);
				return readFieldValue(id, baseField, localState);
			}

		};

		try {
			return localState.getValue(coreId, iState);
		} catch (Throwable e) {
			return throwErr(baseField, e,
					"Could not read value for base state: " + localState.getStateName(),
					"Could not read value for user state: " + localState.getStateName());
		}

	}

	public void cleanupStates() {
		fetchIfNotPresent(true);
		fetchIfNotPresent(false);
		userStates.keySet().removeIf(id -> !fields.has(id));
		cachedBaseStates.keySet().removeIf(id -> !fields.has(id));
	}

	private Object throwErr(boolean baseField, Throwable e, String baseErrMsg, String userErrMsg)
			throws ProcessorException {

		if (baseField) {
			Unchecked.throwSilently(new BackendException(e, baseErrMsg));
			return null;
		} else {
			ProcessorException pe = new ProcessorException(e, userErrMsg);
			pe.setNotRecoverable();
			throw pe;
		}
	}
}