package com.king.rbea.backend.operators.jobinfo;

import java.util.HashMap;
import java.util.Map;

import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.util.Collector;

import com.king.rbea.backend.types.bea.Aggregate;
import com.king.rbea.backend.types.bea.RatioAggregate;
import com.king.rbea.backend.types.processorinfo.RuntimeStatistics;
import com.king.rbea.configuration.Configuration;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.utils.AggregateUtils;

/**
 * Operator used to transform {@link RuntimeStatistics} objects into Aggregate
 * events that will be pushed to aggrigato.
 * 
 */
public class StatsToAggregate implements FlatMapFunction<Configuration, Aggregate> {

	private static final long serialVersionUID = 1L;
	private final Map<String, Object> dimValueReuse = new HashMap<>();

	private final static String PROC_PREFIX = "RBEA_STATS_PROC_";
	private final String environment;
	private final String backend;

	public StatsToAggregate(String environment, String backend) {
		this.environment = environment;
		this.backend = backend;
	}

	@Override
	public void flatMap(Configuration conf, Collector<Aggregate> out) throws Exception {
		if (!(conf instanceof RuntimeStatistics)) {
			return;
		}

		RuntimeStatistics stats = (RuntimeStatistics) conf;

		long windowMillis = stats.getMeasurementWindow() / 1_000_000;

		String dims = createDims(stats);

		out.collect(new RatioAggregate(stats.getProcessorId(), windowMillis, PROC_PREFIX + "TIMEFRACTION",
				dims, stats.getExecutionTimeSum(), stats.getMeasurementWindow()).setTimestamp(stats.getTimestamp()));

		out.collect(new RatioAggregate(stats.getProcessorId(), windowMillis, PROC_PREFIX + "AVGTIME",
				dims, stats.getExecutionTimeSum(), stats.getExecutionCount()).setTimestamp(stats.getTimestamp()));

		// out.collect(new SumAggregate(stats.getProcessorId(), windowMillis,
		// PROC_PREFIX + "MAXTIME",
		// dims, stats.getMaxExecutionTime()).setTimestamp(stats.getTimestamp()));
	}

	private String createDims(RuntimeStatistics stats) throws ProcessorException {
		dimValueReuse.put("environment", environment);
		dimValueReuse.put("backend", backend);
		dimValueReuse.put("processorId", stats.getProcessorId());
		dimValueReuse.put("subtask", stats.getSubtaskIndex());
		return AggregateUtils.createDimJSON(dimValueReuse, null);
	}
}
