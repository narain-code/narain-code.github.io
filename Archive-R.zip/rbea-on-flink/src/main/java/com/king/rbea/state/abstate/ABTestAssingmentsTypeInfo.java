package com.king.rbea.state.abstate;

import org.apache.flink.api.common.ExecutionConfig;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeutils.TypeSerializer;

public class ABTestAssingmentsTypeInfo extends TypeInformation<ABTestAssignmentsNew> {

	private static final long serialVersionUID = 1L;

	@Override
	public boolean isBasicType() {
		return false;
	}

	@Override
	public boolean isTupleType() {
		return false;
	}

	@Override
	public int getArity() {
		return 0;
	}

	@Override
	public int getTotalFields() {
		return 0;
	}

	@Override
	public Class<ABTestAssignmentsNew> getTypeClass() {
		return ABTestAssignmentsNew.class;
	}

	@Override
	public boolean isKeyType() {
		return false;
	}

	@Override
	public TypeSerializer<ABTestAssignmentsNew> createSerializer(ExecutionConfig config) {
		return new ABTestAssignmentsNewSerializer();
	}

	@Override
	public String toString() {
		return "ABTestAssigments";
	}

	@Override
	public boolean equals(Object obj) {
		return obj instanceof ABTestAssingmentsTypeInfo;
	}

	@Override
	public int hashCode() {
		return 0;
	}

	@Override
	public boolean canEqual(Object obj) {
		return equals(obj);
	}

}
