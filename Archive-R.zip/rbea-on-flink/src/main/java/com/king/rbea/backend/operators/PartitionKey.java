package com.king.rbea.backend.operators;

import org.apache.flink.api.common.functions.MapFunction;

import com.king.event.Event;
import com.king.rbea.backend.types.EventWrapper;

public enum PartitionKey {

	CUID(CUIDWrapper.INSTANCE), UACID(UACIDWrapper.INSTANCE);

	private final MapFunction<Event, EventWrapper> wrapper;

	private PartitionKey(MapFunction<Event, EventWrapper> wrapper) {
		this.wrapper = wrapper;
	}

	public MapFunction<Event, EventWrapper> getEventWrapper() {
		return wrapper;
	}

}
