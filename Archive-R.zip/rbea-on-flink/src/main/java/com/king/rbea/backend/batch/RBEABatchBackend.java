package com.king.rbea.backend.batch;

import static com.king.rbea.backend.utils.BackendConstants.BACKEND_TOPIC;
import static com.king.rbea.backend.utils.BackendConstants.CHECKPOINT_DIR;
import static com.king.rbea.backend.utils.BackendConstants.INCREMENTAL_CHECKPOINTS;
import static com.king.rbea.backend.utils.BackendConstants.SOURCE_PARALLELISM;
import static org.apache.flink.api.java.utils.ParameterTool.fromPropertiesFile;

import java.io.File;
import java.text.MessageFormat;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.apache.avro.generic.GenericRecord;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.java.hadoop.mapreduce.HadoopInputFormat;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.typeutils.TypeExtractor;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.contrib.streaming.state.OptionsFactory;
import org.apache.flink.contrib.streaming.state.RocksDBStateBackend;
import org.apache.flink.runtime.state.filesystem.FsStateBackend;
import org.apache.flink.shaded.guava18.com.google.common.collect.Sets;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.AssignerWithPeriodicWatermarks;
import org.apache.flink.streaming.api.watermark.Watermark;
import org.apache.flink.util.Collector;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.rocksdb.BlockBasedTableConfig;
import org.rocksdb.ColumnFamilyOptions;
import org.rocksdb.CompactionStyle;
import org.rocksdb.CompressionType;
import org.rocksdb.DBOptions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.king.rbea.backend.RBEA;
import com.king.rbea.backend.RBEABaseUtils;
import com.king.rbea.backend.TestStateBackend;
import com.king.rbea.backend.operators.MaxWatermark;
import com.king.rbea.backend.output.IgnoringOutputWriter;
import com.king.rbea.backend.output.RBEAOutput;
import com.king.rbea.backend.utils.BackendConstants;
import com.king.rbea.configuration.Configuration;
import com.king.rbea.configuration.processor.Deployment;

public class RBEABatchBackend {

	private static final Logger LOG = LoggerFactory.getLogger(RBEABatchBackend.class);
	private static final String BATCHTOPIC = "batchtopic";

	public static void main(String[] args) throws Exception {
		
		new RBEABatchBackend().start(args);
	}

	public void start(String[] args) throws Exception {
		
		if (args.length != 6) {
		
			System.out.println("Need to specify properties file,data file, dates and game script file");
			

			return;
		}
		String eventInput = args[1];
		String jobInput = args[2];
		String backendShortName = new File(args[0]).getName().split("\\.")[0];
		
		//others
		String startDate = args[3];
		String endDate = args[4];
		String game = args[5];
		
		
		
		
		
		
		ParameterTool allParams = fromPropertiesFile(args[0]);
		
		
		String envName = allParams.get(BackendConstants.ENV_NAME);
		String backendId = allParams.get(BackendConstants.BACKEND_ID, allParams.getRequired(BACKEND_TOPIC));
		StreamExecutionEnvironment env = createExecutionEnvironment(allParams, backendShortName);
		DataStream<BatchEventWrapper> dsStream = getEventStream(allParams, eventInput, env,startDate,endDate,game);
		DataStream<Configuration> backendConfigStream = getConfigStream(jobInput, env);
		
		RBEAOutput output = RBEA.run(dsStream, backendConfigStream, allParams,
				RBEABaseUtils.getAllBaseProcesors(allParams),
			//	 IgnoringOutputWriter.INSTANCE,
				FileWriter.INSTANCE,
				false, backendId, envName);
		//dsStream.addSink(new PrintSinkFunction<>());
		env.execute("batch");

	}

	private DataStream<Configuration> getConfigStream(String inputFile, StreamExecutionEnvironment env) {
		try {
			Job job = Job.getInstance();
			Path inputPath = new Path(inputFile);
			HadoopInputFormat<Void, GenericRecord> hadoopInputFormat = new HadoopInputFormat<Void, GenericRecord>(
					new WholeFileInputStream(), Void.class, GenericRecord.class, job);

			FileInputFormat.addInputPath(job,
					inputPath);

			DataStream<Tuple2<Void, GenericRecord>> createInput = env.createInput(hadoopInputFormat,
					new TypeHint<Tuple2<Void, GenericRecord>>() {}.getTypeInfo()).setParallelism(1)
					.assignTimestampsAndWatermarks(new MaxWatermark<>())
					.name("Max watermark").setParallelism(1);
			return createInput.flatMap(new DeploymentFuntion()).setParallelism(1).uid("Conversion to Deployment");
		} catch (Exception ex) {
			throw new RuntimeException("Unable to create deployment stream " + ex.getMessage());
		}
	}

	private DataStream<BatchEventWrapper> getEventStream(ParameterTool params, String inputPath,
			StreamExecutionEnvironment env,String startDate,String endDate, String game) {

		int sourceParallelism = params.getInt(SOURCE_PARALLELISM, env.getParallelism());
		
		return env.addSource(new EventFileRawSource(inputPath, FileSourceTypes.HADOOP,startDate,endDate,game),TypeExtractor.createTypeInfo(BatchEventWrapper.class))
				.setParallelism(sourceParallelism)
				.assignTimestampsAndWatermarks(new AssignerWithPeriodicWatermarks<BatchEventWrapper>() {

					private final long maxOutOfOrderness = 3500; // 3.5 seconds

					private long currentMaxTimestamp;

					@Override
					public long extractTimestamp(BatchEventWrapper element, long previousElementTimestamp) {

						long timestamp = element.getTimestamp();
						currentMaxTimestamp = Math.max(timestamp, currentMaxTimestamp);
						return timestamp;
					}

					@Override
					public Watermark getCurrentWatermark() {
						return new Watermark(currentMaxTimestamp - 1000l);
					}
				}).setParallelism(sourceParallelism);

	}

	@SuppressWarnings("deprecation")
	private StreamExecutionEnvironment createExecutionEnvironment(ParameterTool params, String backendName)
			throws Exception {
		StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
		env.getConfig().disableSysoutLogging();
		env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime);
		
		env.setStateBackend(createRocksDBBackend(params, backendName));

		if (params.has(BackendConstants.MAX_PARALLELISM)) {
			env.setMaxParallelism(params.getInt(BackendConstants.MAX_PARALLELISM));
		}

		return env;
	}

	public static RocksDBStateBackend createRocksDBBackend(ParameterTool params, String backendName) throws Exception {

		String cpDir = params.getRequired(CHECKPOINT_DIR);
		cpDir = cpDir.endsWith("/") ? cpDir : cpDir + "/";
		cpDir += backendName;

		RocksDBStateBackend backend = new TestStateBackend(
				new FsStateBackend(cpDir),
				params.getBoolean(INCREMENTAL_CHECKPOINTS, true),
				params.has("droppedState") ? Sets.newHashSet(params.get("droppedState").split(","))
						: Sets.newHashSet());

		backend.setOptions(new OptionsFactory() {
			private static final long serialVersionUID = 1L;

			@Override
			public ColumnFamilyOptions createColumnOptions(ColumnFamilyOptions options) {

				long blockSize = 8 * 1024;
				long blockCacheSize = 1024 * 1024 * 1024;

				long writeBufferSize = 512 * 1024 * 1024;

				int minWriteBufferToMerge = 4;
				int maxWriteBufferNumber = 16;

				long targetFileSize = 256 * 1024 * 1024;

			//	options.setCompactionStyle(CompactionStyle.LEVEL)
				options.setCompactionStyle(CompactionStyle.UNIVERSAL)
					/*	.setLevelCompactionDynamicLevelBytes(true)
						.setTargetFileSizeBase(targetFileSize)
						.setMaxBytesForLevelBase(8 * targetFileSize)
						.setWriteBufferSize(writeBufferSize)
						.setLevelZeroSlowdownWritesTrigger(48)
						.setLevelZeroStopWritesTrigger(56) */
						.setNumLevels(5)
						.setMaxWriteBufferNumber(maxWriteBufferNumber)
						.setMinWriteBufferNumberToMerge(minWriteBufferToMerge)
						.setCompressionType(CompressionType.NO_COMPRESSION)
					
						.setTableFormatConfig(
								new BlockBasedTableConfig()
										.setBlockCacheSize(blockCacheSize)
										.setBlockSize(blockSize));

			
				return options;
			}

			@Override
			public DBOptions createDBOptions(DBOptions options) {
				options
						.setUseFsync(false)
						.setAllowMmapReads(true)
						.setMaxOpenFiles(-1)
						.setTableCacheNumshardbits(6)
						.setBytesPerSync(512 * 1024)
						.createStatistics();

				return options;
			}
		});

		return backend;
	}

	public static class DeploymentFuntion implements FlatMapFunction<Tuple2<Void, GenericRecord>, Configuration> {

		@Override
		public void flatMap(Tuple2<Void, GenericRecord> value, Collector<Configuration> out) throws Exception {
			out.collect(Deployment.newJavaCodeProcessor("ForBatchProcessor", 1000l,
					value.f1.get("value").toString(), BATCHTOPIC, System.currentTimeMillis()));

		}

	}
	
	
}
