package com.king.rbea.backend.operators;

import java.util.Collections;
import java.util.List;

import org.apache.flink.streaming.api.collector.selector.OutputSelector;

import com.king.rbea.backend.types.bea.Aggregate;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.backend.types.bea.KafkaOutput;
import com.king.rbea.backend.utils.BackendConstants;

public class BEAOutputSelector implements OutputSelector<BEA> {
	private static final long serialVersionUID = 1L;

	private final List<String> kafka = Collections.singletonList(BackendConstants.KAFKA_TAG);
	private final List<String> aggregate = Collections.singletonList(BackendConstants.AGGREGATE_TAG);

	@Override
	public Iterable<String> select(BEA t) {
		if (t instanceof Aggregate) {
			return aggregate;
		} else if (t instanceof KafkaOutput) {
			return kafka;
		}  else {
			throw new RuntimeException("Unrecognized output type: " + t);
		}
	}
}