package com.king.rbea.backend.output;

import java.util.Properties;

import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaProducer010;

import com.king.rbea.backend.types.bea.KafkaOutput;
import com.king.rbea.configuration.Configuration;
import com.king.rbea.utils.Constants;

/**
 * {@code OutputWriter} is part of the RBEA Flink-job that produces to Kafka and
 * MySQL.
 */
public interface OutputWriter {
	public static final OutputWriter INSTANCE = new OutputWriter() {};

	default DataStream<Configuration> writeKafkaOutput(ParameterTool params,
			DataStream<KafkaOutput> kafkaOutput, DataStream<KafkaOutput> aggrigatoStream) {
		String kafkaBroker = params.getRequired(Constants.KAFKA_BROKER);

		Properties props = FlinkKafkaProducer010.getPropertiesFromBrokerList(kafkaBroker);
		props.setProperty("retries", "5");
		props.setProperty("flink.disable-metrics", "true");

		DataStream<KafkaOutput> allKafkaOutput = aggrigatoStream != null ? kafkaOutput.union(aggrigatoStream)
				: kafkaOutput;

		allKafkaOutput
				.keyBy(new KeySelector<KafkaOutput, String>() {
					private static final long serialVersionUID = 1L;

					@Override
					public String getKey(KafkaOutput k) throws Exception {
						return k.getTopic();
					}
				})
				.addSink(new FlinkKafkaProducer010<>("default", new BEAKafkaSchema(), props,
						new HashingKafkaPartitioner<>()))
				.uid("RbeaKafkaSink")
				.name("Kafka output");

		return kafkaOutput
				.keyBy(new KeySelector<KafkaOutput, String>() {
					private static final long serialVersionUID = 1L;

					@Override
					public String getKey(KafkaOutput k) throws Exception {
						return k.getTopic();
					}
				})
				.flatMap(new KafkaOutputDataMapper())
				.name("Kafka output info"); 

	}
}
