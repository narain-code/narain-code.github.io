package com.king.rbea.backend.batch;

import java.text.MessageFormat;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.apache.flink.configuration.Configuration;
import org.apache.flink.metrics.Counter;
import org.apache.flink.streaming.api.functions.source.RichParallelSourceFunction;
import org.apache.flink.streaming.api.operators.StreamingRuntimeContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.king.event.Event;

public class EventFileRawSource extends RichParallelSourceFunction<BatchEventWrapper> {

	private static final long serialVersionUID = 1L;
	int indexOfThisSubTask;
	int numberOfParrallelTasks;
	List<FileWrapper> all;

	private final String inputPath;
	private final FileSourceTypes type;
	private final String startDate;
	private final String endDate;
	private final String game;
	

	protected static final Logger LOG = LoggerFactory.getLogger(EventFileRawSource.class);

	public EventFileRawSource(String inputPath, FileSourceTypes type , String startDate , String endDate, String game) {
		this.inputPath = inputPath;
		this.type = type;
		this.startDate =startDate;
		this.endDate = endDate;
		this.game = game;
	}

	Counter parsingErrors;

	@Override
	public void run(org.apache.flink.streaming.api.functions.source.SourceFunction.SourceContext<BatchEventWrapper> ctx)
			throws Exception {
		
		
		

		for (int i = 0; i < this.all.size(); i++) {
			if (i % numberOfParrallelTasks == indexOfThisSubTask) {
				
				FileWrapper split = this.all.get(i);
				LOG.info(" file being read now is  " + split.toString());
				split.consume(s -> {
					try {
						Event e = LazyEventParser.parse(s);
						long cuid = e.getLong(1);
						if (cuid >= 1_000_000) {
							ctx.collect(new BatchEventWrapper(e, cuid));
						}
					} catch (Exception ex) {
						ex.printStackTrace();
						/*LOG.error("Parsing error no. " + numberofParsingErrors + " error msg " + ex.getMessage()
								+ " event " + s);*/
						parsingErrors.inc();
					}

				});
				
				
			}
		}
		ctx.close();
	}

	@Override
	public void cancel() {
		// TODO Auto-generated method stub

	}

	@Override
	public void open(Configuration parameters) throws Exception {

		StreamingRuntimeContext context = (StreamingRuntimeContext) this.getRuntimeContext();
		this.indexOfThisSubTask = context.getIndexOfThisSubtask();
		this.numberOfParrallelTasks = context.getNumberOfParallelSubtasks();
		this.parsingErrors =context.getMetricGroup().counter("PARSINGERRORS");
		LocalDate startDt = LocalDate.parse(startDate);
		LocalDate endDt = LocalDate.parse(endDate);
		long numOfDaysBetween = ChronoUnit.DAYS.between(startDt, endDt);
		List<String> allDatesBetween =IntStream.iterate(0, i -> i + 1)
	      .limit(numOfDaysBetween + 1)
	      .mapToObj(i -> startDt.plusDays(i))
	      .map(dt -> dt.toString())
	      .collect(Collectors.toList());
		
		all = new ArrayList<>();
		for(String dt:allDatesBetween){
			String inputPathSane =MessageFormat.format(inputPath, dt,game);
			LOG.info(" splits for  " + inputPathSane);
			List<FileWrapper> wps =FileWrapper.getWrapperForType(FileSourceTypes.HADOOP).getSplitDirectories(inputPathSane);
			all.addAll(wps);
		}
		
		//all = FileWrapper.getWrapperForType(FileSourceTypes.HADOOP).getSplitDirectories(inputPath);

	}

}
