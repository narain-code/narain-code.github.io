package com.king.rbea.state.baseprocessors;

import java.util.ArrayList;
import java.util.List;

import com.king.rbea.configuration.processor.Deployment;
import com.king.rbea.state.abstate.ABTestBaseProcessor;
import com.king.rbea.state.globalstate.GlobalStateProvider;

public enum DefaultBaseProcessorProvider implements BaseProcessorProvider {

	INSTANCE;

	@Override
	public List<Deployment> getBaseProcessors() {
		List<Deployment> all = new ArrayList<>();
		all.add(ABTestBaseProcessor.DEPLOYMENT);
		all.addAll(GlobalStateProvider.INSTANCE.getBaseProcessors());
		return all;
	}

}
