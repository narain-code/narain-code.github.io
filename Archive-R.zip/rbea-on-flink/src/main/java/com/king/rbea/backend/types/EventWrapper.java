package com.king.rbea.backend.types;

import java.lang.reflect.Type;
import java.util.Map;
import java.util.Optional;

import org.apache.flink.api.common.typeinfo.BasicTypeInfo;
import org.apache.flink.api.common.typeinfo.TypeInfo;
import org.apache.flink.api.common.typeinfo.TypeInfoFactory;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.api.java.typeutils.TupleTypeInfo;

import com.king.event.Event;
import com.king.flink.utils.CoreUserIdFetcher;
import com.king.flink.utils.types.EventTypeInfo;
import com.king.flink.utils.types.NullHandlerTypeInfo;

@TypeInfo(EventWrapper.WrapperTypeFactor.class)
public  class EventWrapper extends Tuple3<Long, Long, Event> {
	private static final long serialVersionUID = -1315956836059285269L;

	public EventWrapper() {
		super();
	}

	public EventWrapper(Event e, Long coreId) {
		super(e.getTimeStamp(), coreId, e);
	}

	public EventWrapper(Event e) {
		super(e.getTimeStamp(), CoreUserIdFetcher.getCoreUserId(e).orElse(null), e);
	}

	public Optional<Long> getCoreUserId() {
		return Optional.ofNullable(f1);
	}

	public long getPartitionKey() {
		return getCoreUserId().orElse(getTimestamp());
	}

	public long getTimestamp() {
		return f0;
	}

	public Event getEvent() {
		return f2;
	}

	public static TypeInformation<EventWrapper> TYPE = new TupleTypeInfo<>(
			EventWrapper.class,
			BasicTypeInfo.LONG_TYPE_INFO,
			new NullHandlerTypeInfo<>(BasicTypeInfo.LONG_TYPE_INFO),
			new EventTypeInfo());

	public static class WrapperTypeFactor extends TypeInfoFactory<EventWrapper> {

		@Override
		public TypeInformation<EventWrapper> createTypeInfo(Type t, Map<String, TypeInformation<?>> genericParameters) {
			
			return TYPE;
		}

	}
}
