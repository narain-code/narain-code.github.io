package com.king.rbea.backend.operators.scriptexecution.metrics;

import java.util.concurrent.TimeUnit;

import com.google.common.base.Stopwatch;
import com.google.common.base.Ticker;

public class MetricTimer implements Watch {

	private final ExponentialMovingAverage ema;
	private final Stopwatch watch;

	public MetricTimer(ExponentialMovingAverage ema, Ticker ticker) {
		this.ema = ema;
		this.watch = Stopwatch.createUnstarted(ticker);
	}

	@Override
	public void restart() {
		watch.reset();
		watch.start();
	}

	@Override
	public void reset() {
		watch.reset();
	}

	@Override
	public void stopAndRecord() {
		ema.stopAndAddElapsed(watch);
	}

	@Override
	public long getElapsedNanos() {
		return watch.elapsed(TimeUnit.NANOSECONDS);
	}
}