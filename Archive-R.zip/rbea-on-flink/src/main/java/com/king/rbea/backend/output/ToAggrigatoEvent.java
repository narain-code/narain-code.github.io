package com.king.rbea.backend.output;

import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.typeutils.ResultTypeQueryable;
import org.apache.flink.util.Collector;

import com.king.event.Event;
import com.king.rbea.backend.operators.FailureHandlingSchema;
import com.king.rbea.backend.types.bea.Aggregate;
import com.king.rbea.backend.types.bea.BEATypeInfo;
import com.king.rbea.backend.types.bea.HLLAggregate;
import com.king.rbea.backend.types.bea.KafkaOutput;
import com.king.rbea.backend.types.bea.RatioAggregate;

public class ToAggrigatoEvent implements FlatMapFunction<Aggregate, KafkaOutput>, ResultTypeQueryable<KafkaOutput> {

	private static final long serialVersionUID = 1L;

	private String aggrigatoTopic;

	private final AggrigatoEventFactory aggrigatoEventFactory;

	public ToAggrigatoEvent(String aggrigatoTopic) {
		aggrigatoEventFactory = new AggrigatoEventFactory();
		
		this.aggrigatoTopic = aggrigatoTopic;
	}

	@Override
	public void flatMap(Aggregate agg, Collector<KafkaOutput> out) throws Exception {
		String dim = agg.getDimensions();
		if (!dim.startsWith("{") || !dim.endsWith("}")) {
			return;
		}

		long procId = agg.getProcessorId();
		String key = getKafkaKey(agg);

		if (agg instanceof HLLAggregate) {
			out.collect(createKafkaOutput(procId, key, aggrigatoEventFactory.createAggrigatoHyperLogLogEvent((HLLAggregate) agg), aggrigatoTopic));	
		} else {
			out.collect(createKafkaOutput(procId, key, aggrigatoEventFactory.createAggrigatoLongEvent(agg), aggrigatoTopic));
			if (agg instanceof RatioAggregate) {
				out.collect(createKafkaOutput(procId, key, aggrigatoEventFactory.createAggrigatoRatioEvent((RatioAggregate) agg), aggrigatoTopic));
			}
		}
	}

	private String getKafkaKey(Aggregate agg) {
		return "" +
				agg.getName() +
				(agg.getTimestamp() - agg.getWindowSize()) +
				agg.getDimensions() +
				agg.getWindowSize() +
				agg.getType();
	}

	public static KafkaOutput createKafkaOutput(long procId, String key, Event event, String aggrigatoTopic) {
		return new KafkaOutput(
				procId,
				aggrigatoTopic,
				key.getBytes(),
				FailureHandlingSchema.eventFormat.format(event).getBytes());
	}

	@Override
	public TypeInformation<KafkaOutput> getProducedType() {
		return new BEATypeInfo<>();
	}

}
