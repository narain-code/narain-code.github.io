package com.king.rbea.backend.utils;

import java.util.List;

import com.king.rbea.backend.operators.scriptexecution.ContextManager;
import com.king.rbea.exceptions.BackendException;
import com.king.rbea.exceptions.ProcessorException;

public interface ContextRunner {
	List<ProcessorException> execute(ContextManager ctx) throws BackendException;
}