package com.king.rbea.backend.operators.scriptexecution;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Optional;

import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.runtime.state.VoidNamespace;
import org.apache.flink.runtime.state.VoidNamespaceSerializer;
import org.apache.flink.streaming.api.operators.InternalTimer;
import org.apache.flink.streaming.api.operators.InternalTimerService;
import org.apache.flink.streaming.api.operators.Triggerable;
import org.apache.flink.util.InstantiationUtil;

import com.king.flink.utils.Unchecked;
import com.king.flink.utils.types.HashMapTypeInfo;
import com.king.rbea.EventProcessor;
import com.king.rbea.TimerContext;
import com.king.rbea.Timers;
import com.king.rbea.backend.operators.scriptexecution.metrics.ExecutionStats;
import com.king.rbea.backend.operators.scriptexecution.metrics.RBEAMetricsTracker;
import com.king.rbea.exceptions.BackendException;
import com.king.rbea.exceptions.ProcessorException;

public class FlinkTimers implements Timers, Triggerable<Long, VoidNamespace> {

	public InternalTimerService<VoidNamespace> newTimerService;
	public ValueState<HashMap<Tuple2<Long, Integer>, Tuple2<Long, Object>>> newTimerState;
	public ValueState<Long> nextTimer;

	public RBEAOperator rbeaOp;

	private long procId = -1;
	protected RBEAMetricsTracker metrics;

	private Thread mainThread;

	public FlinkTimers(RBEAOperator rbeaOp) {
		this.rbeaOp = rbeaOp;
		init(rbeaOp);
		mainThread = Thread.currentThread();
	}

	private void validateMainThread() throws ProcessorException {
		if (Thread.currentThread() != mainThread) {
			throw new ProcessorException("Invalid operation in async thread.");
		}
	}

	public void init(RBEAOperator rbeaOp) {
		this.newTimerService = rbeaOp.getInternalTimerService("user-timers-new",
				VoidNamespaceSerializer.INSTANCE,
				this);
		this.newTimerState = rbeaOp.getRuntimeContext()
				.getState(new ValueStateDescriptor<>("new-timer-state",
						new HashMapTypeInfo<>(
								new TypeHint<Tuple2<Long, Integer>>() {}.getTypeInfo(),
								new TypeHint<Tuple2<Long, Object>>() {}.getTypeInfo())));
		this.nextTimer = rbeaOp.getRuntimeContext().getState(new ValueStateDescriptor<>("next-timer", Long.class));
		metrics = rbeaOp.metrics;
	}

	public void setProcId(long procId) {
		this.procId = procId;
	}

	@Override
	public void registerTimerWithId(int timerId, long timestamp, Object params) throws ProcessorException {
		validateMainThread();
		metrics.registerTimerWatch.restart();
		try {
			if (params != null) {
				try {
					byte[] bytes = InstantiationUtil.serializeObject(params);
					InstantiationUtil.deserializeObject(bytes, rbeaOp.getUserCodeClassloader());
				} catch (Throwable e) {
					throw new ProcessorException(e, "Timer paramater must be serializable");
				}
			}

			try {
				HashMap<Tuple2<Long, Integer>, Tuple2<Long, Object>> state = getTimerState();
				state.put(Tuple2.of(procId, timerId), Tuple2.of(timestamp, params));

				Long nextTs = nextTimer.value();

				if (nextTs == null || timestamp < nextTs) {
					nextTs = timestamp;
					newTimerService.registerEventTimeTimer(VoidNamespace.INSTANCE, timestamp);
					nextTimer.update(nextTs);
				}

				newTimerState.update(state);
			} catch (IOException e) {
				Unchecked.throwSilently(new BackendException(e, "Could not access timer state"));
			}
		} finally {
			metrics.registerTimerWatch.stopAndRecord();
		}
	}

	@Override
	public void removeTimer(int timerId) throws ProcessorException {
		validateMainThread();
		metrics.removeTimerWatch.restart();
		HashMap<Tuple2<Long, Integer>, Tuple2<Long, Object>> state = getTimerState();
		Tuple2<Long, Object> prev = state.remove(Tuple2.of(procId, timerId));
		if (prev != null) {
			try {
				if (state.isEmpty()) {
					newTimerState.clear();
				} else {
					newTimerState.update(state);
				}
			} catch (IOException e) {
				Unchecked.throwSilently(new BackendException(e, "Could not update timer state"));
			}
		}
		metrics.removeTimerWatch.stopAndRecord();
	}

	@Override
	public void removeAllTimers() throws ProcessorException {
		validateMainThread();
		metrics.removeAllTimersWatch.restart();
		HashMap<Tuple2<Long, Integer>, Tuple2<Long, Object>> state = getTimerState();

		boolean removedAny = false;
		Iterator<Entry<Tuple2<Long, Integer>, Tuple2<Long, Object>>> iterator = state.entrySet().iterator();
		while (iterator.hasNext()) {
			if (procId == iterator.next().getKey().f0) {
				iterator.remove();
				removedAny = true;
			}
		}

		if (removedAny) {
			try {
				if (state.isEmpty()) {
					newTimerState.clear();
				} else {
					newTimerState.update(state);
				}
			} catch (IOException e) {
				Unchecked.throwSilently(new BackendException(e, "Could not update timer state"));
			}
		}
		metrics.removeAllTimersWatch.stopAndRecord();
	}

	@Override
	public void onEventTime(InternalTimer<Long, VoidNamespace> timer) throws BackendException, IOException {
		HashMap<Tuple2<Long, Integer>, Tuple2<Long, Object>> state = getTimerState();
		Iterator<Entry<Tuple2<Long, Integer>, Tuple2<Long, Object>>> iterator = state.entrySet().iterator();
		List<Tuple4<Long, Long, Integer, Object>> toRun = new ArrayList<>();

		long nextMin = Long.MAX_VALUE;

		while (iterator.hasNext()) {
			Entry<Tuple2<Long, Integer>, Tuple2<Long, Object>> entry = iterator.next();
			Tuple2<Long, Integer> procAndTimerId = entry.getKey();
			procId = procAndTimerId.f0;
			Tuple2<Long, Object> tsAndParam = entry.getValue();
			long ts = tsAndParam.f0;
			if (ts >= 0 && rbeaOp.processors.has(procAndTimerId.f0)) {
				if (ts == timer.getTimestamp()) {
					iterator.remove();
					toRun.add(Tuple4.of(procId, timer.getKey(), procAndTimerId.f1, tsAndParam.f1));
				} else if (ts < nextMin) {
					nextMin = ts;
				}
			} else {
				iterator.remove();
			}
		}

		if (state.isEmpty()) {
			newTimerState.clear();
			nextTimer.clear();
		} else {
			newTimerState.update(state);

			if (nextMin == Long.MAX_VALUE) {
				throw new BackendException("Looks like a bug");
			} else {
				nextTimer.update(nextMin);
				newTimerService.registerEventTimeTimer(VoidNamespace.INSTANCE, nextMin);
			}
		}

		rbeaOp.collector.setAbsoluteTimestamp(timer.getTimestamp());

		metrics.userStateReadWatch.reset();
		metrics.baseStateReadWatch.reset();
		Tuple2<Boolean, Boolean> stateFetched = Tuple2.of(false, false);

		metrics.onTimerWatch.restart();
		toRun.forEach(
				Unchecked.consumer(t -> runTimerForProc(t.f0, timer.getTimestamp(), t.f1, t.f2, t.f3, stateFetched)));
		metrics.onTimerWatch.stopAndRecord();

	}

	public void runTimerForProc(long pid, long ts, long coreUserId, int timerId, Object timerParam,
			Tuple2<Boolean, Boolean> stateFetched) throws BackendException {

		Tuple3<Long, EventProcessor, ExecutionStats> t = rbeaOp.processors.getForId(pid);
		if (t == null) {
			// The processor can be removed by the time this is triggered
			return;
		}

		rbeaOp.runWithContext(Optional.of(coreUserId), null, ctxMgr -> {
			ctxMgr.setProcessorId(pid);
			TimerContext timerContext = new TimerContext(ctxMgr.getContext(), ts, timerId, timerParam);

			Optional<ProcessorException> err = metrics.callAndMeasure(t.f2, stateFetched,
					() -> RBEAOperator.run(procId, "OnTimer function", true, () -> t.f1.onTimer(timerContext)));

			// We have to manually call the erro handler here
			err.ifPresent(pe -> {
				try {
					rbeaOp.handleProcessorError(pe, ctxMgr);
				} catch (BackendException e) {
					Unchecked.throwSilently(e);
				}
			});
			return Collections.emptyList();
		});
	}

	private HashMap<Tuple2<Long, Integer>, Tuple2<Long, Object>> getTimerState() {
		HashMap<Tuple2<Long, Integer>, Tuple2<Long, Object>> state = null;
		try {
			state = newTimerState.value();
			if (state == null) {
				state = new HashMap<>();
			}
		} catch (IOException e) {
			Unchecked.throwSilently(new BackendException(e, "Could not fetch timer state"));
		}
		return state;
	}

	@Override
	public void onProcessingTime(InternalTimer<Long, VoidNamespace> arg0) throws Exception {}
}