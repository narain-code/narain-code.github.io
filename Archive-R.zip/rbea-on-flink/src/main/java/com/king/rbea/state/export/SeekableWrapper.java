package com.king.rbea.state.export;

import java.io.IOException;

import org.apache.avro.file.SeekableInput;
import org.apache.hadoop.fs.FSDataInputStream;

public class SeekableWrapper implements SeekableInput {

	private final FSDataInputStream in;

	public SeekableWrapper(FSDataInputStream in) {
		this.in = in;
	}

	@Override
	public void close() throws IOException {
		in.close();
	}

	@Override
	public void seek(long p) throws IOException {
		in.seek(p);
	}

	@Override
	public long tell() throws IOException {
		return in.getPos();
	}

	@Override
	public long length() throws IOException {
		return in.available();
	}

	@Override
	public int read(byte[] b, int off, int len) throws IOException {
		return in.read(b, off, len);
	}
}