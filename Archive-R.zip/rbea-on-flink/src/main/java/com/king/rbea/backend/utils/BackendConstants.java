package com.king.rbea.backend.utils;

import java.time.Duration;

public class BackendConstants {
	public static final String SUM_PREFIX = "SUM";
	public static final String KAFKA_PREFIX = "KAFKA";

	public static final String AGGREGATE_TAG = "AGG";
	public static final String KAFKA_TAG = "KAFKA";
	public static final String MYSQL_TAG = "MYSQL";
	public static final String PRINT_TAG = "PRINT";

	// BEA type identifiers
	public static final byte BEA_LONG_AGGREGATE_TYPE = 0;
	public static final byte BEA_KAFKA_OUTPUT_TYPE = 1;
	public static final byte BEA_RATIO_AGGREGATE_TYPE = 2;
	public static final byte BEA_HLL_AGGREGATE_TYPE = 3;

	public static final String BASE_FIELDS_NAME = "baseFields";
	public static final String USER_FIELDS_NAME = "userFields";

	/**
	 * A key in properties file. Indicates whether to produce to Kafka.
	 */
	public static final String WRITE_TO_KAFKA = "writeToKafka";

	/**
	 * A key in properties file. If true, JobSummary-objects are produced to Kafka
	 * _even if_ WRITE_TO_KAFKA is false.
	 */
	public static final String FORCE_JOB_SUMMARY_WRITE_TO_KAFKA = "forceJobSummaryWriteToKafka";

	/**
	 * A key in properties file. If true, JobSummary-objects are printed to the
	 * stdout of the TM
	 */
	public static final String PRINT_JOB_SUMMARY_TO_STDOUT = "printJobSummary";

	public static final long SESSION_TIMEOUT = Duration.ofMinutes(15).toMillis();
	public static final String INCREMENTAL_CHECKPOINTS = "incremental";

	/**
	 * A key in properties file. Indicates whether to produce Aggrigato-events. If
	 * enabled, whether the events actually are produced to Kafka depends on
	 * WRITE_TO_KAFKA.
	 */
	public static final String WRITE_TO_AGGRIGATO = "writeToAggrigato";
	public static final String WRITE_METRICS_TO_KAFKA = "writeMetricsToKafka";
	/**
	 * A key in properties file. Identifies the Aggrigato topic when producing
	 * Aggrigato-events to Kafka. See WRITE_TO_AGGRIGATO.
	 */
	public static final String AGGRIGATO_TOPIC = "aggrigatoTopic";

	public static final String CHECKPOINT_DIR = "checkpointDir";

	public static final String BACKEND_TOPIC = "kafkaTopic";

	public static final String STATE_CACHE_SIZE = "stateCacheSize";

	public static final String RECEIVED_PROCESSORS = "receivedScriptLog";

	public static final String CHECKPOINT_INTERVAL_SECONDS = "checkpointIntervalSeconds";
	public static final String SOURCE_PARALLELISM = "sourceParallelism";

	public static final String WATERMARK_BUCKET_SIZE = "watermarkBucketSize";
	public static final String WATERMARKS_PER_PARTITION = "watermarksPerPartition";

	public static final String TEST_SOURCE_QUERY_SECS = "runTestSourceFor";
	public static final String TEST_ITER_TIMEOUT = "testIterTimeout";

	public static final String JAR_FILE_PARENT_DIR = "jarDownloadDir";

	public static final String DISABLE_GLOBAL_STATES = "disableGlobalStates";
	public static final String DISABLE_DEFAULT_PROCESSORS = "disableDefaultProcessors";

	public static final long DEFAULT_RUNTIME_STATISTICS_INTERVAL_MILLIS = 60 * 1000;
	public static final long DUMMY_PROC_ID = -1L;

	public static final String STATE_FEED_IN_ENABLED = "stateFeedInEnabled";
	public static final String STATE_FEED_TOPIC = "stateFeedTopic";

	public static final String MAX_FEEDBACK_PER_SEC = "feedbackRatePerSec";
	public static final String THROTTLE_FEEDBACK = "throttleFeedback";

	public static final String DEPLOYMENT_STATE_NAME = "deploymentStateName";

	public static final String BASE_FIELD_PROVIDERS = "baseFieldProviders";
	public static final String BASE_PROC_PROVIDERS = "baseProcessorProviders";
	public static final String DEPLOYMENT_SOURCE_UID = "deploymentSourceUid";

	public static final String MAX_PARALLELISM = "maxParallelism";

	public static final String BACKEND_ID = "backendId";
	public static final String PARTITION_KEY = "partitionKey";

	public static final String ENABLE_ASYNC_EXECUTION = "enableAsyncExecution";
	public static final String NUM_ASYNC_THREADS = "numAsyncThreads";
	public static final String ASYNC_QUEUE_SIZE = "asyncQueueSize";

	public static final String ENV_NAME = "envName";
	
	public static final String CLEAN_STATE_ON_SAVEPOINT = "cleanStateOnSavepoint";
	public static final String AB_STATE_ID = "abStateId";
	
	public static final String STATE_EXPORT_TOPIC = "stateExportTopic";
	public static final String STATE_SCHEMA_TOPIC = "stateSchemaTopic";

}
