package com.king.rbea.backend.batch;

import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

import com.king.event.TypedEventFieldAccessor;
import com.king.event.format.Decoder;
import com.king.event.format.util.HTMLEntityDecoder;
import com.king.event.format.util.NumberParser;

public class BatchEvent extends TypedEventFieldAccessor {
	private static final Decoder decoder = new HTMLEntityDecoder();
	private final String event;
	private final int eventLength;
	private final long timeStamp;
	private final int flavourId;
	private final long eventType;
	private final long uniqueEventId;
	private final long uacid; // unique application client id.
	private final int hostnameBeginIndex;
	private final int hostnameEndIndex;
	private final int fieldsStartIndex;
	private int currentFieldIndex;

	public BatchEvent(String event, long timeStamp, int flavourId, long eventType, long uniqueEventId,
			int hostnameBeginIndex, int hostnameEndIndex, long uacid, int fieldsStartIndex) {

		this.event = event;
		this.eventLength = event.length();
		this.timeStamp = timeStamp;
		this.flavourId = flavourId;
		this.eventType = eventType;
		this.uniqueEventId = uniqueEventId;
		this.hostnameBeginIndex = hostnameBeginIndex;
		this.uacid = uacid;
		this.hostnameEndIndex = hostnameEndIndex;
		this.fieldsStartIndex = fieldsStartIndex;
	}

	@Override
	public long getTimeStamp() {
		return timeStamp;
	}

	@Override
	public int getFlavourId() {
		return flavourId;
	}

	@Override
	public long getEventType() {
		return eventType;
	}

	@Override
	public long getUniqueId() {
		return uniqueEventId;
	}

	@Override
	public String getHostname() {
		return event.substring(hostnameBeginIndex, hostnameEndIndex);
	}

	public long getUacid() {
		return uacid;
	}

	public byte[] toBytes() {

		ByteBuffer buf = ByteBuffer.allocate(5130);
		byte[] eventB = event.getBytes();
		int blen = eventB.length;
		buf.putInt(blen);

		buf.put(eventB);

		buf.putLong(timeStamp);

		buf.putInt(flavourId);

		buf.putLong(eventType);
		buf.putLong(uniqueEventId);
		buf.putInt(hostnameBeginIndex);
		buf.putInt(hostnameEndIndex);
		buf.putLong(uacid);
		buf.putInt(fieldsStartIndex);
		int len = buf.position();
		buf.flip();

		byte[] all = new byte[len];
		buf.get(all);

		return all;
	}

	public String toString() {

		return event;
	}

	@Override
	public String getString(int index) {
		int startOffset = getFieldOffset(index);
		return decoder.decode(event.substring(startOffset, getFieldEndOffset(startOffset)));
	}

	@Override
	public int getInt(int index) {
		int startOffset = getFieldOffset(index);
		return NumberParser.parseInt(event, startOffset, getFieldEndOffset(startOffset));
	}

	@Override
	public long getLong(int index) {
		int startOffset = getFieldOffset(index);
		try {
			return NumberParser.parseLong(event, startOffset, getFieldEndOffset(startOffset));
		} catch (Exception ex) {
			return 0l;
		}
	}

	@Override
	public double getDouble(int index) {
		return Double.parseDouble(getString(index));
	}

	@Override
	public boolean getBoolean(int index) {
		return Boolean.parseBoolean(getString(index));
	}

	@Override
	public float getFloat(int index) {
		return Float.parseFloat(getString(index));
	}

	private int getFieldOffset(int index) {
		int offset = fieldsStartIndex;
		for (int i = 0; i < index; i++) {
			offset = event.indexOf('\t', offset);
			if (offset == -1) {
				throw new ArrayIndexOutOfBoundsException(index);
			}
			offset++;
		}

		return offset;
	}

	private int getFieldEndOffset(int fieldStartOffset) {
		int fieldEndOffset = event.indexOf('\t', fieldStartOffset);
		if (fieldEndOffset > 0) {
			return fieldEndOffset;
		} else {
			return event.length();
		}
	}

	@Override
	public Iterable<String> fields() {
		return null;
	}

}
