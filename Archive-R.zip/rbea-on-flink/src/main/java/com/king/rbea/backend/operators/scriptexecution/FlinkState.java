package com.king.rbea.backend.operators.scriptexecution;

import com.king.flink.utils.Unchecked;
import com.king.rbea.EventProcessor;
import com.king.rbea.State;
import com.king.rbea.exceptions.BackendException;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.state.abstate.ABTestBaseProcessor;
import com.king.rbea.state.abstate.DelegatingABTestAssignments;
import com.king.rbea.state.basefields.ABTestAssignments;

public class FlinkState implements State {

	public final States states;

	public long procId = -1L;
	private EventProcessor proc;

	public final Fields fields;

	private boolean isBaseProc;

	private final Thread mainThread;

	public FlinkState(States states, Fields fields) {
		this.states = states;
		this.fields = fields;
		this.mainThread = Thread.currentThread();
	}

	private void validateMainThread() throws ProcessorException {
		if (Thread.currentThread() != mainThread) {
			throw new ProcessorException("Invalid operation in async thread.");
		}
	}

	public void setProcessor(long procId, EventProcessor proc) {
		this.procId = procId;
		this.proc = proc;
		this.isBaseProc = Processors.isBaseProcessor(procId);
	}

	@Override
	public void export(Object... leadingFields) throws ProcessorException {
		validateMainThread();
		try {
			proc.exportStates(leadingFields);
		} catch (Exception e) {
			throw new ProcessorException(e);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> T get(long rbeaJobId, String fieldName) throws ProcessorException {
		validateMainThread();
		Short id = fields.getIdForName(isBaseProc ? fieldName : fieldName + rbeaJobId);
		if (id == null) {
			if (procId != -1 && !isBaseProc) {
				throw new ProcessorException("No field registered for name " + fieldName + " for job " + rbeaJobId);
			} else {
				Unchecked.throwSilently(
						new BackendException("No field registered for name " + fieldName));
				return null;
			}
		} else {
			return (T) states.getFieldValue(id, false, false);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> T get(String fieldName) throws ProcessorException {
		validateMainThread();
		boolean baseFieldAccess = true;
		Short id = null;

		if (procId == -1 || isBaseProc) {
			id = fields.getIdForName(fieldName);
		} else {
			id = fields.getIdForName(fieldName + procId);
			if (id != null) {
				baseFieldAccess = false;
			} else {
				id = fields.getIdForName(fieldName);

			}
		}

		if (id == null) {
			if (procId != -1 && !isBaseProc) {
				throw new ProcessorException("There is no base or user field: " + fieldName);
			} else {
				Unchecked.throwSilently(
						new BackendException("There is no base or user field: " + fieldName));
				return null;
			}
		}

		return (T) states.getFieldValue(id, baseFieldAccess, isBaseProc);
	}

	@Override
	public void update(String name, Object value) throws ProcessorException {
		validateMainThread();
		Short id = fields.getIdForName(isBaseProc ? name : name + procId);
		if (id == null) {
			throw new ProcessorException(procId, "Missing local state: " + name);
		}
		states.updateFieldValue(id, value, isBaseProc, isBaseProc);
	}

	@Override
	public void clearAll() throws ProcessorException {
		validateMainThread();
		fields.getAllForProcId(procId).forEach(Unchecked.consumer(name -> {
			states.updateFieldValue(fields.getIdForName(name), null, isBaseProc, isBaseProc);
		}));
	}

	@Override
	public ABTestAssignments getABTestAssignments() throws ProcessorException {
		validateMainThread();
		return new DelegatingABTestAssignments(get(ABTestBaseProcessor.AB_ASSIGNMENTS_FIELD_NAME));
	}
}
