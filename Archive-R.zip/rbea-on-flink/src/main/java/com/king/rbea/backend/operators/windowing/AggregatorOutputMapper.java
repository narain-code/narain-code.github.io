package com.king.rbea.backend.operators.windowing;

import org.apache.flink.api.common.functions.MapFunction;

import com.king.rbea.aggregators.OutputType;
import com.king.rbea.backend.types.bea.Aggregate;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.backend.types.bea.KafkaOutput;

public final class AggregatorOutputMapper implements MapFunction<Aggregate, BEA> {
	private static final long serialVersionUID = 1L;

	@Override
	public BEA map(Aggregate agg) throws Exception {
		OutputType type = agg.getOutputType();
		switch (type) {
		case KAFKA:
			return new KafkaOutput(agg.getProcessorId(), agg.getName(), null, getWriteValueWithDim(agg).getBytes());
		case PRINT:
			return new KafkaOutput(agg.getProcessorId(), "PRINT_" + agg.getProcessorId(), null,
					(agg.getName() + "\t" + getWriteValueWithDim(agg)).getBytes());
		case MYSQL:
			return agg;
		default:
			throw new RuntimeException("Unkown output type: " + type);
		}
	}

	private static String getWriteValueWithDim(Aggregate agg) {
		return agg.getTimestamp() + "\t" + agg.getDimensions() + "\t" + agg.getValue();
	}
}