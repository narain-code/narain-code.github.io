package com.king.rbea.state.export;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import org.apache.avro.Schema;
import org.apache.avro.Schema.Parser;
import org.apache.avro.generic.GenericDatumReader;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.io.DatumReader;
import org.apache.commons.io.IOUtils;
import org.apache.flink.api.common.state.ListState;
import org.apache.flink.api.common.state.ListStateDescriptor;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.core.fs.FSDataInputStream;
import org.apache.flink.core.fs.FSDataOutputStream;
import org.apache.flink.core.fs.FileSystem;
import org.apache.flink.core.fs.FileSystem.WriteMode;
import org.apache.flink.core.fs.Path;
import org.apache.flink.runtime.state.StateInitializationContext;
import org.apache.flink.runtime.state.StateSnapshotContext;
import org.apache.flink.streaming.api.operators.AbstractStreamOperator;
import org.apache.flink.streaming.api.operators.TimestampedCollector;
import org.apache.flink.streaming.api.operators.TwoInputStreamOperator;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.king.rbea.exceptions.BackendException;

public class StateExportOperator extends AbstractStreamOperator<GenericRecord>
		implements TwoInputStreamOperator<Tuple2<Long, Schema>, Tuple2<String, byte[]>, GenericRecord>,
		StateExportDeserializer {

	protected static final Logger LOG = LoggerFactory.getLogger(StateExportOperator.class);
	private static final long serialVersionUID = 1L;

	private transient TimestampedCollector<GenericRecord> out;
	private transient Map<String, Tuple3<Set<Long>, Schema, DatumReader<GenericRecord>>> schemaState;
	private transient ListState<Tuple2<Set<Long>, String>> broadcastState;

	private final Path schemaStorePath;
	private transient FileSystem fs;

	public StateExportOperator(ParameterTool allParams) {
		schemaStorePath = new Path(allParams.get(StateExportWriterJob.EXPORT_BASE_PATH) + "/schemas");
	}

	@Override
	public void processElement1(StreamRecord<Tuple2<Long, Schema>> record) {
		Tuple2<Long, Schema> value = record.getValue();
		String schemaName = value.f1.getFullName();
		Long procId = value.f0;
		Tuple3<Set<Long>, Schema, DatumReader<GenericRecord>> t = schemaState.get(schemaName);
		if (t == null || (!t.f1.equals(value.f1) && t.f0.isEmpty())) {
			Set<Long> ids = new HashSet<>();
			ids.add(procId);
			schemaState.put(schemaName, Tuple3.of(ids, value.f1, new GenericDatumReader<>(value.f1)));
			StateExportWriterJob.LOG.info("Received new state schema from {}: {}", procId, value.f1.toString(true));
			writeSchema(value.f1, true);
		} else if (t.f1.equals(value.f1)) {
			t.f0.add(procId);
		} else {
			StateExportWriterJob.LOG.error("State schema doesnt match for {}. Correct: {}, Current: {}", schemaName,
					value.f1);
		}
	}

	public Optional<DatumReader<GenericRecord>> getReader(String schemaName) {
		Tuple3<Set<Long>, Schema, DatumReader<GenericRecord>> tuple = schemaState.get(schemaName);
		if (tuple == null) {
			tuple = readSchemaFromDisk(schemaName);
		}
		return Optional.ofNullable(tuple).map(t -> t.f2);
	}

	private void writeSchema(Schema schema, boolean overwrite) {
		// Write schema to file on a single subtask
		if (getRuntimeContext().getIndexOfThisSubtask() == 0) {
			Path schemaFile = new Path(schemaStorePath, schema.getFullName() + ".schema");
			try {
				if (fs.exists(schemaFile)) {
					if (overwrite) {
						fs.delete(schemaFile, false);
					} else {
						return;
					}
				}
				try (FSDataOutputStream out = fs.create(schemaFile, WriteMode.NO_OVERWRITE)) {
					IOUtils.write(schema.toString(true), out, StandardCharsets.UTF_8);
					LOG.info("Successfully written schema {} to disk", schema.getFullName());
				}
			} catch (IOException ioe) {
				LOG.error("Error while writing schema " + schema.getFullName() + " to disk:", ioe);
			}
		}
	}

	private Tuple3<Set<Long>, Schema, DatumReader<GenericRecord>> readSchemaFromDisk(String schemaName) {
		// Try to read it from schema storage dir
		Path schemaFile = new Path(schemaStorePath, schemaName + ".schema");
		Tuple3<Set<Long>, Schema, DatumReader<GenericRecord>> tuple = null;
		try {
			if (fs.exists(schemaFile)) {
				try (FSDataInputStream in = fs.open(schemaFile)) {
					Parser parser = new Schema.Parser();
					Schema schema = parser.parse(in);
					tuple = Tuple3.of(new HashSet<>(), schema, new GenericDatumReader<>(schema));
					schemaState.put(schemaName, tuple);
					LOG.info("Successfully read schema {} from disk", schemaName);
				}
			}
		} catch (Exception ioe) {
			LOG.error("Error while reading schema " + schemaName + " from disk:", ioe);
		}
		return tuple;
	}

	@Override
	public void processElement2(StreamRecord<Tuple2<String, byte[]>> record) throws BackendException {
		Tuple2<String, byte[]> value = record.getValue();
		try {
			deserializeRecord(value).ifPresent(r -> {
				LOG.trace("Received record: {}", r);
				out.collect(r);
			});
		} catch (Throwable err) {
			StateExportWriterJob.LOG.error("Error while deserializing record for schema " + value.f0, err);
		}
	}

	@Override
	public void open() throws Exception {
		super.open();
		fs = FileSystem.get(schemaStorePath.toUri());
		schemaState = new HashMap<>();
		out = new TimestampedCollector<>(output);
		Iterator<Tuple2<Set<Long>, String>> it = broadcastState.get().iterator();
		while (it.hasNext()) {
			Tuple2<Set<Long>, String> next = it.next();
			Schema schema = new Schema.Parser().parse(next.f1);
			schemaState.put(schema.getFullName(), Tuple3.of(next.f0, schema, new GenericDatumReader<>(schema)));
		}
	}

	@Override
	public void snapshotState(StateSnapshotContext context) throws Exception {
		broadcastState.clear();
		if (getRuntimeContext().getIndexOfThisSubtask() == 0) {
			for (Tuple3<Set<Long>, Schema, DatumReader<GenericRecord>> t : schemaState.values()) {
				broadcastState.add(Tuple2.of(t.f0, t.f1.toString(true)));
			}
		}
		super.snapshotState(context);
	}

	@Override
	public void initializeState(StateInitializationContext context) throws Exception {
		super.initializeState(context);
		broadcastState = context.getOperatorStateStore()
				.getUnionListState(new ListStateDescriptor<>("SchemaState",
						new TypeHint<Tuple2<Set<Long>, String>>() {}.getTypeInfo()));
	}
}
