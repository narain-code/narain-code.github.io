package com.king.rbea.backend.operators.scriptexecution;

import java.io.IOException;
import java.util.Optional;

import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.runtime.state.VoidNamespace;
import org.apache.flink.runtime.state.VoidNamespaceSerializer;
import org.apache.flink.streaming.api.operators.InternalTimer;
import org.apache.flink.streaming.api.operators.InternalTimerService;
import org.apache.flink.streaming.api.operators.Triggerable;

import com.king.constants.external.EventType;
import com.king.event.Event;
import com.king.flink.utils.types.EventTypeInfo;
import com.king.rbea.backend.batch.BatchEventTypeInfo;
import com.king.rbea.backend.utils.BackendConstants;
import com.king.rbea.exceptions.BackendException;

public class UserSessionManager implements Triggerable<Long, VoidNamespace> {

	private RBEAOperator op;
	private InternalTimerService<VoidNamespace> sessionTimers;
	private ValueState<Event> lastEvent;

	public UserSessionManager(RBEAOperator op, boolean isBatch) {
		this.op = op;
		if(isBatch){
			this.lastEvent = op.wrapWithCache(
					op.getRuntimeContext().getState(new ValueStateDescriptor<>("SessionState", new BatchEventTypeInfo())),
					null, null, null, null);
		}else{
		this.lastEvent = op.wrapWithCache(
				op.getRuntimeContext().getState(new ValueStateDescriptor<>("SessionState", new EventTypeInfo())),
				null, null, null, null);
		}
		this.sessionTimers = op.getInternalTimerService("session-timers", VoidNamespaceSerializer.INSTANCE, this);
	}

	
	
	/**
	 * Extends the session of the current user if the event is client side event.
	 * 
	 * 
	 */
	public void extendSession(Event nextEvent, long currentWatermark) throws BackendException {
		if (nextEvent.getEventType() == EventType.RbeaStateUpdate) {
			// These are server side events
			return;
		}

		if (currentWatermark == 0) {
			// Watermark initialization when the processing starts
			currentWatermark = nextEvent.getTimeStamp();
		}

		// Register Timer at the end of next session_timeout wide window. This is an
		// optimization to reduce the number of active timers to the minimum.
		sessionTimers.registerEventTimeTimer(VoidNamespace.INSTANCE,
				currentWatermark
						- (currentWatermark % BackendConstants.SESSION_TIMEOUT)
						+ BackendConstants.SESSION_TIMEOUT);

		try {
			lastEvent.update(nextEvent);
		} catch (IOException e) {
			throw new BackendException(e, "Error while extending the user session.");
		}
	}

	@Override
	public void onEventTime(InternalTimer<Long, VoidNamespace> timer) throws Exception {
		triggerSessionEnd(timer.getTimestamp(), timer.getKey());
	}

	private void triggerSessionEnd(long ts, Long coreUserId) throws BackendException, IOException {
		Event event = lastEvent.value();
		if (event == null) {
			return;
		}

		long lastTs = event.getTimeStamp();
		// As we registered timers so that ts % SESSION_TIMEOUT = 0, now we have to
		// actually check whether it's the end of session or not
		if (ts >= lastTs + BackendConstants.SESSION_TIMEOUT) {
			op.runWithContext(Optional.of(coreUserId), event,
					ctx -> {
						op.handleProcessorErrors(op.processors.runAllOnSessionEnd(event, ctx, op.metrics), ctx);
						return null;
					});
			lastEvent.clear();
		} else {
			sessionTimers.registerEventTimeTimer(VoidNamespace.INSTANCE, lastTs + BackendConstants.SESSION_TIMEOUT);
		}
	}

	@Override
	public void onProcessingTime(InternalTimer<Long, VoidNamespace> arg0) throws Exception {}
}