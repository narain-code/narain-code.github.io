package com.king.rbea.backend.operators.scriptexecution;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.function.Function;

import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple3;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Ticker;
import com.king.flink.utils.Unchecked;
import com.king.flink.utils.Unchecked.ThrowingFunction;
import com.king.rbea.EventProcessor;
import com.king.rbea.backend.operators.scriptexecution.metrics.ExecutionStats;
import com.king.rbea.backend.operators.scriptexecution.metrics.SlidingWindowCounter;
import com.king.rbea.backend.utils.ContextRunner;
import com.king.rbea.configuration.processor.Deployment;
import com.king.rbea.configuration.processor.DeploymentWithFields;
import com.king.rbea.configuration.processor.JobConfig;
import com.king.rbea.configuration.processor.Pause;
import com.king.rbea.configuration.processor.ProcessorInfo;
import com.king.rbea.configuration.processor.Removal;
import com.king.rbea.configuration.processor.Resume;
import com.king.rbea.exceptions.BackendException;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.scripts.ProcessorFactory;

public class DeploymentManager {

	protected static final Logger LOG = LoggerFactory.getLogger(DeploymentManager.class);

	protected final Processors processors;
	protected final Fields fields;
	protected final ProcessorFactory executorFactory;

	/**
	 * Contains an entry for each procId that is deployed, having as value the
	 * corresponding DeploymentWithFields. Also failed and
	 */
	protected final Map<Long, DeploymentWithFields> deployedProcs = new HashMap<>();
	protected final Map<Long, Tuple2<Integer, SlidingWindowCounter>> failureTrackers = new HashMap<>();
	protected final Set<Long> removedProcs = new HashSet<>();

	private int subtaskIndex;

	private Function<ContextRunner, List<ProcessorException>> contextRunner;

	private Ticker ticker;

	private ExecutorService asyncExec;

	public DeploymentManager(Processors processors, Fields fields, int subtaskIndex,
			ThrowingFunction<ContextRunner, List<ProcessorException>> contextRunner, Ticker ticker,
			ExecutorService asyncExec, ProcessorFactory executorFactory) {
		this.processors = processors;
		this.fields = fields;
		this.subtaskIndex = subtaskIndex;
		this.ticker = ticker;
		this.asyncExec = asyncExec;
		this.contextRunner = Unchecked.function(contextRunner);
		this.executorFactory = executorFactory;
	}

	/**
	 * Handles ProcessorInfo messages: Deployment, Update, JobConfig, Removal etc
	 * and forwards any errors that happened during the operation (deployment,
	 * config update errors, etc.)
	 */
	public Optional<ProcessorException> applyProcessorInfo(ProcessorInfo info) throws BackendException {
		if (removedProcs.contains(info.getProcessorId())) {
			return Optional.empty();
		}

		if (info instanceof Removal) {
			Removal removal = (Removal) info;
			removeProcessor(removal.getProcessorId(), removal.shouldDeleteState());
			return Optional.empty();
		} else if (info instanceof Pause) {
			Pause pause = (Pause) info;
			removeProcessor(pause.getProcessorId(), false);
			return Optional.empty();
		} else if (info instanceof Resume) {
			Resume resume = (Resume) info;
			Optional<ProcessorException> err = resumeProcessor(resume.getProcessorId());
			if (err.isPresent()) {
				LOG.error("Resume failed for {} with: {}", info.getProcessorId(), err.get().getMessage());
				return err;
			}
			return Optional.empty();
		} else if (info instanceof DeploymentWithFields) {
			DeploymentWithFields deploymentWithFields = (DeploymentWithFields) info;
			Optional<ProcessorException> err = deployOrUpdateProcessor(deploymentWithFields);
			if (err.isPresent()) {
				LOG.error("Deployment failed for {} with: {}", info.getProcessorId(), err.get().getMessage());
				return err;
			}
			return Optional.empty();
		} else if (info instanceof JobConfig) {
			return updateJobConfig((JobConfig) info);
		} else {
			LOG.info("Received unkown configuration type: " + info.getClass().getSimpleName());
			return Optional.empty();
		}
	}

	private Optional<ProcessorException> resumeProcessor(long processorId) throws BackendException {
		DeploymentWithFields deploymentWithFields = deployedProcs.get(processorId);
		if (deploymentWithFields == null) {
			return Optional.empty();
		}

		Deployment deployment = deploymentWithFields.getDeployment();
		deployment.enable();
		deployment.asUpdate();

		return deployOrUpdateProcessor(deploymentWithFields);
	}

	/**
	 * Deploys a new processor or updates an existing one by compiling code,
	 * registering any fields and callbacks that the processor declares and running
	 * any initial configuration. This method should not do any cleanup, only
	 * forwards exceptions to the caller.
	 */
	private Optional<ProcessorException> deployOrUpdateProcessor(DeploymentWithFields depWithFields)
			throws BackendException {

		long procId = depWithFields.getProcessorId();
		Deployment dep = depWithFields.getDeployment();
		boolean baseProc = Processors.isBaseProcessor(procId);
		// We have already deployed this processor (and not marked as update)
		if (!dep.isUpdate() && deployedProcs.containsKey(procId)) {
			return Optional.empty();
		}

		if (dep.isTest() && dep.isUpdate()) {
			// Update and test deployment unsupported.
			return Optional.empty();
		}

		// First thing is to add to the map (some other methods depend on this)
		DeploymentWithFields prevDeployment = deployedProcs.put(procId, depWithFields);
		Optional<Integer> maxErrorsPerMin = depWithFields.getDeployment().getMaxErrorsPerMin();

		if (maxErrorsPerMin.orElse(0) > 0) {
			failureTrackers.put(procId, Tuple2.of(maxErrorsPerMin.get(), new SlidingWindowCounter(60)));
		} else {
			failureTrackers.remove(procId);
		}

		// Update the registered fields according to the new info + remove any
		// previous callbacks as those will be re-registered in initialized
		depWithFields.updateFieldMapping(fields.registerFieldInfo(procId, depWithFields.getFieldMapping()));

		// We store the previous configuration if the update doesn't have any
		if (!dep.getJobConfig().isPresent() && prevDeployment != null) {
			prevDeployment
					.getDeployment()
					.getJobConfig()
					.ifPresent(dep::withInitialConfig);
		}

		// The deployment has been disabled for this processor probably due to failure,
		// so we don't proceed further
		if (dep.isDisabled()) {
			return Optional.empty();
		}

		// Instantiate and initialize the new processor catching any errors
		Optional<ProcessorException> err = RBEAOperator.run(procId, "Initialize", false,
				() -> {
					FlinkRegistry registry = new FlinkRegistry(fields, procId, baseProc);
					EventProcessor processor = dep.getProcessor(executorFactory);

					// Set up async executor that wraps all errors in a ProcessorException
					Thread mainThread = Thread.currentThread();
					if (asyncExec != null) {
						processor.setAsyncExecutor(asyncCall -> {
							if (Thread.currentThread() != mainThread) {
								Unchecked
										.throwSilently(new ProcessorException(procId, "Cannot nest async operations."));
							}
							asyncExec.execute(asyncCall);
						});
					}

					processors.addProcessor(procId, processor);

					contextRunner.apply(
							ctxMgr -> {
								ctxMgr.setProcessorId(procId);
								return RBEAOperator.run(procId, "Initialize", false,
										() -> {
											processor.initialize(registry, ctxMgr.getContext());
											registry.finalizeRegistration();

										})
										.map(pe -> Collections.singletonList(pe))
										.orElse(Collections.emptyList());
							})
							.stream()
							.findFirst()
							.ifPresent(Unchecked::throwSilently);

					processor.getInfo().ifPresent(dep::updateWithProcInfo);

					if (!maxErrorsPerMin.isPresent()) {
						processor.getInfo().ifPresent(pi -> {
							pi.getMaxErrorsPerMin().ifPresent(mepm -> {
								failureTrackers.put(procId, Tuple2.of(mepm, new SlidingWindowCounter(60)));
							});
						});
					}
				});

		if (err.isPresent()) {
			return err;
		}

		err = dep.getJobConfig().flatMap(Unchecked.function(conf -> runConfigUpdate(procId, conf)));

		if (!err.isPresent()) {
			LOG.info("Succesfully " + (dep.isUpdate() ? "updated" : "deployed")
					+ " processor {} at subtask {} for backend {}",
					procId, subtaskIndex, dep.getBackendId());
		}

		return err;
	}

	/**
	 * Completely removes a processor and all it's registered field definitions,
	 * callbacks etc. This is an idempotent operation.
	 * 
	 * @param deleteState
	 *            if false, the field states are preserved until this method is
	 *            called again with a true flag.
	 */
	public DeploymentWithFields removeProcessor(long processorId, boolean deleteState) throws BackendException {
		DeploymentWithFields dep = deployedProcs.get(processorId);
		if (dep == null) {
			return null;
		}

		// Remove any processing or state logic
		Tuple3<Long, EventProcessor, ExecutionStats> removedProcessor = processors.remove(processorId);
		// Run termination method and log errors
		if (removedProcessor != null) {
			Optional<ProcessorException> err = RBEAOperator.run(processorId, "Close", false,
					() -> removedProcessor.f1.close());
			err.ifPresent(e -> LOG.info("Error terminating processor {}", processorId, e));
		}

		fields.removeFieldsForProcessor(processorId, deleteState);
		failureTrackers.remove(processorId);

		// Remove completely if delete state is true, disable otherwise
		if (deleteState) {
			removedProcs.add(processorId);
			deployedProcs.remove(processorId);
		} else {
			dep.getDeployment().disable();
		}

		LOG.info("Removed process {} from subtask {}. State deletion: {}", processorId, subtaskIndex, deleteState);
		return dep;
	}

	/**
	 * Updates the configuration of a deployed rbea processor. This operation will
	 * not do any cleanup if the update fails.
	 */
	private Optional<ProcessorException> updateJobConfig(JobConfig conf) throws BackendException {
		long procId = conf.getProcessorId();
		if (deployedProcs.containsKey(procId)) {
			LOG.info("Updating configuration for processor {}", procId);
			String jobConfig = conf.getJobConfig();
			deployedProcs.get(procId).getDeployment().withInitialConfig(jobConfig);
			return runConfigUpdate(procId, jobConfig);
		} else {
			return Optional.empty();
		}
	}

	/**
	 * Executes the user defined OnSessionEnd logic and also applies any field
	 * bindings.
	 */
	private Optional<ProcessorException> runConfigUpdate(long procId, String jobConfig)
			throws BackendException {

		return contextRunner.apply(
				ctxMgr -> {
					ctxMgr.setProcessorId(procId);
					return RBEAOperator.run(procId, "OnConfigUpdate", false,
							() -> processors.getForId(procId).f1.onConfigUpdate(jobConfig, ctxMgr.getContext()))
							.map(pe -> Collections.singletonList(pe))
							.orElse(Collections.emptyList());
				})
				.stream()
				.findFirst();
	}

	public Collection<DeploymentWithFields> getDeployedProcs() {
		return deployedProcs.values();
	}

	public DeploymentWithFields getDeployedProc(long procId) {
		return deployedProcs.get(procId);
	}

	public boolean trackFailure(long pid) {
		Tuple2<Integer, SlidingWindowCounter> t = failureTrackers.get(pid);
		if (t == null) {
			return false;
		}
		long now = ticker.read() / 1000_000;
		t.f1.increment(now);
		return t.f1.getValue(now) <= t.f0;
	}

	@Override
	public String toString() {
		return "DeploymentManager [deployedProcs=" + deployedProcs + ", removedProcs=" + removedProcs + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((deployedProcs == null) ? 0 : deployedProcs.hashCode());
		result = prime * result + ((fields == null) ? 0 : fields.hashCode());
		result = prime * result + ((processors == null) ? 0 : processors.hashCode());
		return result;
	}

	/**
	 * This method is mostly intended for testing purposes
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DeploymentManager other = (DeploymentManager) obj;
		if (deployedProcs == null) {
			if (other.deployedProcs != null)
				return false;
		} else if (!deployedProcs.equals(other.deployedProcs))
			return false;
		if (fields == null) {
			if (other.fields != null)
				return false;
		} else if (!fields.equals(other.fields))
			return false;
		if (processors == null) {
			if (other.processors != null)
				return false;
		} else if (!processors.equals(other.processors))
			return false;
		return true;
	}
}
