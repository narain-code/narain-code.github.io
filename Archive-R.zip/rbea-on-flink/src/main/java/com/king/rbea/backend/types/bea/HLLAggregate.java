package com.king.rbea.backend.types.bea;

import org.apache.flink.api.common.ExecutionConfig;
import org.apache.flink.api.common.typeutils.TypeSerializer;
import org.apache.flink.api.java.typeutils.TypeExtractor;

import com.clearspring.analytics.hash.MurmurHash;
import com.clearspring.analytics.stream.cardinality.CardinalityMergeException;
import com.clearspring.analytics.stream.cardinality.HyperLogLog;
import com.king.rbea.backend.utils.BackendConstants;

/**
 * A HyperLogLog {@link Aggregate}.
 */
public class HLLAggregate extends Aggregate {
	private static final long serialVersionUID = 1L;

	private static final int HLL_LOG2M = 14;

	public static final TypeSerializer<HLLAggregate> serializer = TypeExtractor.getForClass(HLLAggregate.class).createSerializer(new ExecutionConfig());

	public int hashedValue;

	/**
	 * We use a container class for serialization reasons
	 */
	public HLLContainer container;

	public HLLAggregate(long processorId, long windowSizeMillis, String aggregatorName, String dimensions, Object toAdd) {
		super(BackendConstants.BEA_HLL_AGGREGATE_TYPE, windowSizeMillis, processorId, aggregatorName, dimensions);
		this.hashedValue = MurmurHash.hash(toAdd);
	}

	/**
	 * Empty constructor for deserialization.
	 */
	public HLLAggregate() {
	}

	@Override
	public void update(Aggregate agg) {
		container = getOrCreateContainer();
		HLLAggregate other = (HLLAggregate) agg;
		if (other.container == null) {
			container.hll.offerHashed(other.hashedValue);
		} else {
			try {
				container = new HLLContainer((HyperLogLog) container.hll.merge(other.container.hll));
			} catch (CardinalityMergeException e) {
				throw new RuntimeException(e);
			}
		}
	}

	@Override
	public HyperLogLog getValue() {
		return getOrCreateContainer().hll;
	}

	@Override
	public long getLongValue() {
		return getValue().cardinality();
	}
	
	private HLLContainer getOrCreateContainer() {
		if (container == null) {
			container = new HLLContainer(new HyperLogLog(HLL_LOG2M));
			container.hll.offerHashed(hashedValue);
		}
		return container;
	}
}