package com.king.rbea.backend.batch;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.function.Consumer;

public class LocalFileWrapper implements FileWrapper {
	
	private File filePath;
	
	
	public LocalFileWrapper(){
		
	}
	
	 public LocalFileWrapper(File dir) {
		this.filePath =dir;
	}
	

	@Override
	public  List<FileWrapper> getSplitDirectories(String path) {
		List<FileWrapper> splitDir = new ArrayList<>();
		List<File> allDirs = new LinkedList<>();
		allDirs.add(new File(path));
		File f;
		do{
			f=allDirs.get(0);
			if(f.exists() && f.isDirectory()){
				allDirs.addAll(Arrays.asList(f.listFiles(dir->dir.isDirectory())));
				File[] gzipFiles =f.listFiles(dir->dir.getName().endsWith("gz"));
				if(gzipFiles!=null && gzipFiles.length > 0)
					splitDir.add(new LocalFileWrapper(f));
				allDirs.remove(0);
			}
			
		}while(allDirs.size()>0);
		
		return splitDir;
	}


	@Override
	public void consume( Consumer<String> consume) {
		
		long start = System.currentTimeMillis();
		Arrays.asList(FileUtils.getGzipFiles(filePath)).stream().forEach(gz->FileUtils.decompressGzipFile(gz, consume));
		System.out.println(System.currentTimeMillis() -start);
	}

	
	
}
