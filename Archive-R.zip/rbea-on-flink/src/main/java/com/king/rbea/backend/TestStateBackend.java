package com.king.rbea.backend;

import java.io.IOException;
import java.io.Serializable;
import java.util.Collection;
import java.util.Set;
import java.util.concurrent.RunnableFuture;

import org.apache.flink.api.common.state.ListState;
import org.apache.flink.api.common.state.ListStateDescriptor;
import org.apache.flink.contrib.streaming.state.RocksDBStateBackend;
import org.apache.flink.runtime.checkpoint.CheckpointOptions;
import org.apache.flink.runtime.execution.Environment;
import org.apache.flink.runtime.state.AbstractStateBackend;
import org.apache.flink.runtime.state.CheckpointStreamFactory;
import org.apache.flink.runtime.state.DefaultOperatorStateBackend;
import org.apache.flink.runtime.state.OperatorStateBackend;
import org.apache.flink.runtime.state.OperatorStateHandle;
import org.apache.flink.runtime.state.OperatorStateHandle.StateMetaInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TestStateBackend extends RocksDBStateBackend {

	private static final long serialVersionUID = 1L;
	private Collection<String> droppedStates;

	public TestStateBackend(AbstractStateBackend checkpointStreamBackend, boolean enableIncrementalCheckpointing,
			Collection<String> droppedStates) {
		super(checkpointStreamBackend, enableIncrementalCheckpointing);
		this.droppedStates = droppedStates;
	}

	protected static final Logger LOG = LoggerFactory.getLogger(TestStateBackend.class);

	@Override
	public OperatorStateBackend createOperatorStateBackend(
			Environment env,
			String operatorIdentifier) throws Exception {

		// the default for RocksDB; eventually there can be a operator state backend
		// based on RocksDB, too.
		final boolean asyncSnapshots = true;

		return new OperatorStateBackend() {

			DefaultOperatorStateBackend backend = new DefaultOperatorStateBackend(
					env.getUserClassLoader(),
					env.getExecutionConfig(),
					asyncSnapshots);;

			@Override
			public void close() throws IOException {
				backend.close();
			}

			@Override
			public RunnableFuture<OperatorStateHandle> snapshot(long checkpointId, long timestamp,
					CheckpointStreamFactory streamFactory, CheckpointOptions checkpointOptions) throws Exception {
				return backend.snapshot(checkpointId, timestamp, streamFactory, checkpointOptions);
			}

			@Override
			public void restore(Collection<OperatorStateHandle> state) throws Exception {
				for (OperatorStateHandle handle : state) {
					LOG.info("OP States:" + handle.getStateNameToPartitionOffsets().toString());
					for (String name : droppedStates) {
						StateMetaInfo remove = handle.getStateNameToPartitionOffsets().remove(name);
						if (remove != null) {
							LOG.info("Dropped {}", remove);
						}
					}
				}
				backend.restore(state);
			}

			@Override
			public <S> ListState<S> getUnionListState(ListStateDescriptor<S> stateDescriptor) throws Exception {
				return backend.getUnionListState(stateDescriptor);
			}

			@Override
			public <T extends Serializable> ListState<T> getSerializableListState(String stateName) throws Exception {
				return backend.getSerializableListState(stateName);
			}

			@Override
			public Set<String> getRegisteredStateNames() {
				return backend.getRegisteredStateNames();
			}

			@Override
			public <S> ListState<S> getOperatorState(ListStateDescriptor<S> stateDescriptor) throws Exception {
				return backend.getOperatorState(stateDescriptor);
			}

			@Override
			public <S> ListState<S> getListState(ListStateDescriptor<S> stateDescriptor) throws Exception {
				return backend.getListState(stateDescriptor);
			}

			@Override
			public void dispose() {
				backend.dispose();
			}
		};
	}

}
