package com.king.rbea.state;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Consumer;

public class LRUMap<K, V> extends LinkedHashMap<K, V> {
	private static final long serialVersionUID = 1L;
	private final int cacheSize;
	private final Consumer<Map.Entry<K, V>> removalHook;

	public LRUMap(int cacheSize, Consumer<Map.Entry<K, V>> removalHook) {
		super((int) Math.round(cacheSize * 1.1), 0.75f, true);
		this.cacheSize = cacheSize;
		this.removalHook = removalHook;
	}

	@Override
	protected boolean removeEldestEntry(Map.Entry<K, V> eldest) {
		if (size() > cacheSize) {
			removalHook.accept(eldest);
			return true;
		}
		return false;
	}
}