package com.king.rbea.backend.types.bea;

import org.apache.commons.lang3.Validate;
import org.apache.flink.api.common.functions.ReduceFunction;
import org.apache.flink.api.java.tuple.Tuple4;

import com.king.rbea.aggregators.OutputType;

/**
 * {@code Aggregate} is a abstract class {@link BEA} that represents an
 * aggregate. The subclasses do the actual aggregation by implementing the
 * abstract methods {@link #update(Aggregate)} and {@link #getValue()}.
 */
public abstract class Aggregate extends BEA {
	private static final long serialVersionUID = 1L;

	public static ReduceFunction<Aggregate> REDUCER = (agg1, agg2) -> {
		if (agg1.getType() == agg2.getType()) {
			agg1.update(agg2);
		} else {
			throw new RuntimeException("Incompatible aggregate types. This indicates a bug.");
		}
		return agg1;
	};

	public long windowSizeMillis;
	public String aggregatorName;
	public String dimensionString;
	public OutputType outputType = OutputType.MYSQL;
	public long timestamp;

	protected Aggregate(byte beaType, long windowSizeMillis, long processorId, String aggregatorName,
			String dimensions) {
		super(beaType, processorId);
		this.windowSizeMillis = windowSizeMillis;
		this.aggregatorName = Validate.notNull(aggregatorName);
		this.dimensionString = Validate.notNull(dimensions);
	}

	public abstract long getLongValue();

	public Aggregate() {
		// Empty constructor for deserialization
	}

	/**
	 * 
	 * @param aggregate
	 */
	public abstract void update(Aggregate aggregate);

	public abstract Object getValue();

	public long getTimestamp() {
		return timestamp;
	}

	public Aggregate setTimestamp(long timestamp) {
		this.timestamp = timestamp;
		return this;
	}

	public long getWindowSize() {
		return windowSizeMillis;
	}

	public String getName() {
		return aggregatorName;
	}

	public String getDimensions() {
		return dimensionString;
	}

	public OutputType getOutputType() {
		return outputType;
	}

	public Tuple4<Byte, String, String, Long> getWindowKey() {
		return Tuple4.of(getType(), getName(), getDimensions(), getWindowSize());
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((aggregatorName == null) ? 0 : aggregatorName.hashCode());
		result = prime * result + ((dimensionString == null) ? 0 : dimensionString.hashCode());
		result = prime * result + ((outputType == null) ? 0 : outputType.hashCode());
		result = prime * result + (int) (timestamp ^ (timestamp >>> 32));
		result = prime * result + (int) (windowSizeMillis ^ (windowSizeMillis >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (!(obj instanceof Aggregate)) {
			return false;
		}
		Aggregate other = (Aggregate) obj;
		if (aggregatorName == null) {
			if (other.aggregatorName != null) {
				return false;
			}
		} else if (!aggregatorName.equals(other.aggregatorName)) {
			return false;
		}
		Object thisVal = getValue();
		Object otherVal = other.getValue();
		if (thisVal == null) {
			if (otherVal != null) {
				return false;
			}
		} else if (!thisVal.equals(otherVal)) {
			return false;
		}

		if (dimensionString == null) {
			if (other.dimensionString != null) {
				return false;
			}
		} else if (!dimensionString.equals(other.dimensionString)) {
			return false;
		}
		if (outputType != other.outputType) {
			return false;
		}
		if (timestamp != other.timestamp) {
			return false;
		}
		if (windowSizeMillis != other.windowSizeMillis) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "Aggregate [windowSizeMillis=" + windowSizeMillis + ", aggregatorName=" + aggregatorName
				+ ", dimensionString=" + dimensionString + ", outputType=" + outputType + ", timestamp=" + timestamp
				+ ", procId=" + procId + ", value=" + getValue() + "]";
	}
}