package com.king.rbea.state.globalstate;

import java.util.Arrays;
import java.util.List;

import com.king.rbea.configuration.processor.Deployment;
import com.king.rbea.state.baseprocessors.BaseProcessorProvider;

public enum GlobalStateProvider implements BaseProcessorProvider {
	
	INSTANCE;

	@Override
	public List<Deployment> getBaseProcessors() {
		return Arrays.asList(
			/*	UniversalGlobalStateScript.DEPLOYMENT,
				GeneralGlobalStateScript.DEPLOYMENT,
				SpendGlobalStateScript.DEPLOYMENT,*/
				LevelGlobalStateScript.DEPLOYMENT
		);
	}

}
