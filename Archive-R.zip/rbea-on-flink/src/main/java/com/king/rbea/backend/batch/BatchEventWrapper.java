package com.king.rbea.backend.batch;

import java.lang.reflect.Type;
import java.util.Map;

import org.apache.flink.api.common.typeinfo.BasicTypeInfo;
import org.apache.flink.api.common.typeinfo.TypeInfo;
import org.apache.flink.api.common.typeinfo.TypeInfoFactory;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.typeutils.TupleTypeInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.king.event.Event;
import com.king.flink.utils.types.NullHandlerTypeInfo;
import com.king.rbea.backend.types.EventWrapper;

@TypeInfo(BatchEventWrapper.WrapperTypeFactor.class)
public class BatchEventWrapper extends EventWrapper {

	private static final long serialVersionUID = -1315956836059285269L;
	protected static final Logger LOG = LoggerFactory.getLogger(BatchEventWrapper.class);
	

	public BatchEventWrapper() {
		super();
	}
	
	public BatchEventWrapper(Event e, Long coreId) {
		super(e, coreId);
	}

	
	public static TypeInformation<BatchEventWrapper> TYPE = new TupleTypeInfo<>(
			BatchEventWrapper.class,
			BasicTypeInfo.LONG_TYPE_INFO,
			new NullHandlerTypeInfo<>(BasicTypeInfo.LONG_TYPE_INFO),
			new BatchEventTypeInfo());

	public static class WrapperTypeFactor extends TypeInfoFactory<BatchEventWrapper> {

		@Override
		public TypeInformation<BatchEventWrapper> createTypeInfo(Type t, Map<String, TypeInformation<?>> genericParameters) {
			LOG.info("return type in batch");
			return TYPE;
		}

	}
}
