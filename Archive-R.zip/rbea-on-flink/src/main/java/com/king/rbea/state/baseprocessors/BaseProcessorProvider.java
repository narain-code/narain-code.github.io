package com.king.rbea.state.baseprocessors;

import java.util.List;

import com.king.rbea.configuration.processor.Deployment;

public interface BaseProcessorProvider {

	List<Deployment> getBaseProcessors();

}
