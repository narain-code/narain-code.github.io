package com.king.rbea.backend.services;

import static com.king.constants.external.EventType.PlayerAddedToSegment;
import static com.king.constants.external.EventType.PlayerRemovedFromSegment;
import static com.king.constants.KingApp.BITERO;
import static com.king.constants.SignInSource.BACK_END;

import com.king.constants.Flavour;
import com.king.event.Event;
import com.king.event.EventBuilder;
import com.king.rbea.Output;
import com.king.rbea.exceptions.ProcessorException;
import com.king.utils.Bitero;

public class BiteroImpl implements Bitero {

	private static final String TOPIC = "work.bitero.store-segment-updates";

	private static final EventBuilder BUILDER = new EventBuilder(Flavour.createFlavour(BITERO, BACK_END));

	private static final int SESSION_ID = 0;

	private final Output output;

	public BiteroImpl(Output output) {
		this.output = output;
	}

	@Override
	public void addPlayerToSegment(long cuid, long segmentId) throws ProcessorException {
		final Event event = BUILDER.buildEvent(PlayerAddedToSegment(cuid, segmentId), SESSION_ID);
		output.writeEventToKafka(TOPIC, Long.toString(cuid), event);
	}

	@Override
	public void removePlayerFromSegment(long cuid, long segmentId) throws ProcessorException {
		final Event event = BUILDER.buildEvent(PlayerRemovedFromSegment(cuid, segmentId), SESSION_ID);
		output.writeEventToKafka(TOPIC, Long.toString(cuid), event);
	}

}
