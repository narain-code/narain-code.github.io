package com.king.rbea.backend.batch;

public enum FileSourceTypes {

	LOCALFILE,
	HADOOP,
	GFS;
	
}
