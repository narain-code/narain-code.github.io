package com.king.rbea.backend.operators.scriptexecution;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.regex.Pattern;

import org.apache.flink.types.Either;
import org.apache.flink.util.Collector;

import com.king.flink.utils.Unchecked;
import com.king.rbea.Aggregators;
import com.king.rbea.aggregators.AggregationWindow;
import com.king.rbea.aggregators.AverageAggregator;
import com.king.rbea.aggregators.Counter;
import com.king.rbea.aggregators.DimensionType;
import com.king.rbea.aggregators.DimensionalAggregator;
import com.king.rbea.aggregators.ApproximateDistinctCounter;
import com.king.rbea.aggregators.RatioAggregator;
import com.king.rbea.aggregators.SumAggregator;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.backend.types.bea.HLLAggregate;
import com.king.rbea.backend.types.bea.RatioAggregate;
import com.king.rbea.backend.types.bea.SumAggregate;
import com.king.rbea.backend.utils.BackendConstants;
import com.king.rbea.configuration.Configuration;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.utils.AggregateUtils;

public class CollectingAggregators implements Aggregators {

	private Collector<Either<BEA, Configuration>> collector;
	private final long processorId;
	private static final Pattern VALID_TABLE_NAME_REGEX = Pattern.compile("^[a-zA-Z_][a-zA-Z0-9_]{0,63}$");
	private static final Pattern WHITESPACE_REGEX = Pattern.compile("\\s+");

	public CollectingAggregators(Collector<Either<BEA, Configuration>> collector, long procId) {
		this.collector = collector;
		this.processorId = procId;
	}

	@Override
	public CollectingCounter getCounter(String name, AggregationWindow windowSize) throws ProcessorException {
		return new CollectingCounter(name, windowSize.toMillis());
	}

	@Override
	public CollectingSum getSumAggregator(String name, AggregationWindow windowSize) throws ProcessorException {
		return new CollectingSum(name, windowSize.toMillis());
	}

	@Override
	public CollectingAvg getAverageAggregator(String name, AggregationWindow windowSize) throws ProcessorException {
		return new CollectingAvg(name, windowSize.toMillis());

	}

	@Override
	public CollectingRatio getRatioAggregator(String name, AggregationWindow windowSize) throws ProcessorException {
		return new CollectingRatio(name, windowSize.toMillis());
	}

	@Override
	public CollectingApproximateDistinctCounter getApproximateDistinctCounter(String name, AggregationWindow windowSize) throws ProcessorException {
		return new CollectingApproximateDistinctCounter(name, windowSize.toMillis());
	}

	protected class CollectingRatio extends FlinkDimAggregator<RatioAggregator> implements RatioAggregator {

		public CollectingRatio(String name, long bucketSizeMillis)
				throws ProcessorException {
			super(name, bucketSizeMillis);
		}

		@Override
		public void addToNumerator(long num) {
			send(new RatioAggregate(procId, windowSizeMillis, name, getDimensionString(), num, 0));
		}

		@Override
		public void addToDenominator(long num) {
			send(new RatioAggregate(procId, windowSizeMillis, name, getDimensionString(), 0, num));
		}
	}

	protected class CollectingAvg extends FlinkDimAggregator<AverageAggregator> implements AverageAggregator {

		public CollectingAvg(String name, long bucketSizeMillis)
				throws ProcessorException {
			super(name, bucketSizeMillis);
		}

		@Override
		public void add(long num) {
			send(new RatioAggregate(procId, windowSizeMillis, name, getDimensionString(), num, 1));

		}

	}

	protected class CollectingCounter extends FlinkDimAggregator<Counter> implements Counter {

		public CollectingCounter(String name, long bucketSizeMillis)
				throws ProcessorException {
			super(name, bucketSizeMillis);
		}

		@Override
		public void decrement() {
			send(new SumAggregate(procId, windowSizeMillis, name, getDimensionString(), -1L));
		}

		@Override
		public void increment() {
			send(new SumAggregate(procId, windowSizeMillis, name, getDimensionString(), 1L));
		}

	}

	protected class CollectingSum extends FlinkDimAggregator<SumAggregator> implements SumAggregator {

		public CollectingSum(String name, long bucketSizeMillis)
				throws ProcessorException {
			super(name, bucketSizeMillis);
		}

		@Override
		public void add(long num) {
			send(new SumAggregate(procId, windowSizeMillis, name, getDimensionString(), num));
		}

	}

	protected class CollectingApproximateDistinctCounter extends FlinkDimAggregator<ApproximateDistinctCounter> implements ApproximateDistinctCounter {

		public CollectingApproximateDistinctCounter(String name, long bucketSizeMillis)
				throws ProcessorException {
			super(name, bucketSizeMillis);
		}

		@Override
		public void offer(Object o) {
			send(new HLLAggregate(procId, windowSizeMillis, name, getDimensionString(), o));
		}

	}

	@SuppressWarnings("unchecked")
	protected class FlinkDimAggregator<T extends DimensionalAggregator<T>> implements DimensionalAggregator<T> {

		String name;
		private String dimensionString = "{}";
		final long windowSizeMillis;

		private Set<String> longDims = new HashSet<>();
		private TreeMap<String, Object> dims = new TreeMap<>();

		protected long procId = CollectingAggregators.this.processorId;

		public FlinkDimAggregator(String name, long bucketSizeMillis) throws ProcessorException {
			ProcessorException pe = null;
			if (bucketSizeMillis < 1) {
				pe = new ProcessorException("Bucket size must be greater than zero.");
			}

			if (name.equals("")) {
				pe = new ProcessorException("Aggregator name cannot be empty.");
			}

			if (pe != null) {
				throw pe;
			}

			this.name = WHITESPACE_REGEX.matcher(name.trim()).replaceAll("_") + "_" + processorId;
			this.windowSizeMillis = bucketSizeMillis;
		}

		protected void send(BEA bea) {
			validateTableName();
			collector.collect(Either.Left(bea));
		}

		private void validateTableName() {
			if (!VALID_TABLE_NAME_REGEX.matcher(this.name).matches() || this.name.length() > 64) {
				ProcessorException pe = new ProcessorException(processorId,
						"Aggregator name (" + this.name
								+ ") needs to be a valid MySQL table name.");
				Unchecked.throwSilently(pe);
			}
		}

		@Override
		public T setTableName(String table) throws ProcessorException {
			this.name = table;
			return (T) this;
		}

		public T asBackendAggregate() {
			this.procId = BackendConstants.DUMMY_PROC_ID;
			return (T) this;
		}

		@Override
		public T groupBy(Map<String, ?> dims) throws ProcessorException {
			dimensionString = null;
			this.dims = new TreeMap<>(dims);
			return (T) this;
		}

		@Override
		public T setGroupTypes(Map<String, DimensionType> types) throws ProcessorException {
			dimensionString = null;
			longDims = new HashSet<>();
			types.entrySet().stream().filter(e -> e.getValue().equals(DimensionType.LONG))
					.forEach(e -> longDims.add(e.getKey()));
			return (T) this;
		}

		public String getDimensionString() {
			if (dimensionString == null) {
				try {
					dimensionString = AggregateUtils.createDimJSON(dims, longDims);
				} catch (ProcessorException e) {
					Unchecked.throwSilently(e);
				}
			}
			return dimensionString;
		}

		@Override
		public T setDimension(String columnName, DimensionType type, Object value) throws ProcessorException {
			dimensionString = null;
			this.dims.put(columnName, value);
			if (type.equals(DimensionType.LONG)) {
				longDims.add(columnName);
			}
			return (T) this;
		}
	}

}
