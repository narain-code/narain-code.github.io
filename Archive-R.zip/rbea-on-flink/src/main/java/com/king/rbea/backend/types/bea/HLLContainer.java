package com.king.rbea.backend.types.bea;

import java.io.IOException;

import org.apache.flink.api.common.typeinfo.TypeInfo;

import com.clearspring.analytics.stream.cardinality.HyperLogLog;

@TypeInfo(HLLTypeFactory.class)
public class HLLContainer {
	public final HyperLogLog hll;

	public HLLContainer(HyperLogLog hll) {
		this.hll = hll;
	}

	public HLLContainer(byte[] bytes) {
		try {
			hll = HyperLogLog.Builder.build(bytes);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
}
