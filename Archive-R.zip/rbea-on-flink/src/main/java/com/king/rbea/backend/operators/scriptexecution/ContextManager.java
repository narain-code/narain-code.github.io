package com.king.rbea.backend.operators.scriptexecution;

import java.util.Optional;

import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.types.Either;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.king.event.Event;
import com.king.rbea.EventProcessor;
import com.king.rbea.backend.operators.scriptexecution.metrics.ExecutionStats;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.backend.utils.BackendConstants;
import com.king.rbea.configuration.Configuration;
import com.king.rbea.state.export.StateExporter;

public class ContextManager {
	
	

	protected FlinkState state = null;
	protected FlinkRBEAUtils utils;

	public long coreId;
	public boolean hasCoreId;

	public final Fields fields;
	public final Collector<Either<BEA, Configuration>> collector;
	public final FlinkTimers flinkTimers;

	public long procId;
	public Event event;
	public final int subtaskIndex;
	private Processors procs;
	private final String stateExportTopic;
	private final String stateSchemaTopic;

	public ContextManager(Fields fields,
			Processors procs,
			Collector<Either<BEA, Configuration>> collector,
			FlinkTimers timers,
			int subtaskIndex,
			ParameterTool params) {

		this.fields = fields;
		this.procs = procs;
		this.collector = collector;
		this.flinkTimers = timers;
		this.subtaskIndex = subtaskIndex;
		this.stateExportTopic = params.get(BackendConstants.STATE_EXPORT_TOPIC, "rbea.exportstate.test.log");
		this.stateSchemaTopic = params.get(BackendConstants.STATE_SCHEMA_TOPIC, "rbea.exportschema.test.log");
		
	}

	public void setForCurrentUser(Optional<Long> coreIdOption, States states, Event event) {
		if (coreIdOption.isPresent()) {
			coreId = coreIdOption.get();
			hasCoreId = true;
		} else {
			coreId = -1;
			hasCoreId = false;
		}

		if (states != null) {
			this.state = new FlinkState(states, fields);
		} else {
			this.state = null;
		}

		this.event = event;
	}

	public void setProcessorId(long procId) {
		this.procId = procId;

		if (state != null) {
			Tuple3<Long, EventProcessor, ExecutionStats> t = procs.getForId(procId);
			state.setProcessor(procId, t == null ? null : t.f1);
		}
		flinkTimers.setProcId(procId);
	}

	public FlinkContext getContext() {
		return new FlinkContext(coreId, hasCoreId, collector, flinkTimers, procId, event, state, subtaskIndex,
				stateExportTopic, stateSchemaTopic);
	}
}
