package com.king.rbea.backend.operators.scriptexecution.metrics;

import java.util.Collection;
import java.util.concurrent.TimeUnit;

import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.metrics.Gauge;
import org.apache.flink.metrics.Histogram;
import org.apache.flink.metrics.HistogramStatistics;
import org.apache.flink.metrics.MetricGroup;
import org.apache.flink.types.Either;
import org.apache.flink.util.Collector;
import org.rocksdb.HistogramType;
import org.rocksdb.Statistics;
import org.rocksdb.TickerType;

import com.codahale.metrics.SlidingTimeWindowReservoir;
import com.google.common.base.Stopwatch;
import com.google.common.base.Ticker;
import com.google.common.collect.Lists;
import com.king.rbea.EventProcessor;
import com.king.rbea.backend.operators.scriptexecution.Fields;
import com.king.rbea.backend.operators.scriptexecution.Processors;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.backend.types.processorinfo.RuntimeStatistics;
import com.king.rbea.backend.utils.BackendCallable;
import com.king.rbea.backend.utils.BackendConstants;
import com.king.rbea.configuration.Configuration;
import com.king.rbea.exceptions.BackendException;

/**
 * Class for creating and managing the different runtime metrics tracked by the
 * RBEA applications. Responsible for managing Flink Metrics (Gauges) and also
 * creating the {@link RuntimeStatistics} objects.
 *
 */
@SuppressWarnings("unused")
public class RBEAMetricsTracker {

	public static long runtimeStatsIntervalMillis = BackendConstants.DEFAULT_RUNTIME_STATISTICS_INTERVAL_MILLIS;
	private static int histogramInvervalInSeconds = 30;

	public final Watch processWatch;
	public final Watch fieldUpdateWatch;
	public final Watch userStateReadWatch;
	public final Watch baseStateReadWatch;
	public final Watch userStateWriteWatch;
	public final Watch baseStateWriteWatch;
	public final Watch registerTimerWatch;
	public final Watch removeTimerWatch;
	public final Watch removeAllTimersWatch;
	public final Watch onTimerWatch;

	public final ExponentialMovingAverage baseStateAccessRate;
	public final ExponentialMovingAverage userStateAccessRate;
	public final ExponentialMovingAverage baseStateCacheHitRate;
	public final ExponentialMovingAverage userStateCacheHitRate;
	public final ExponentialMovingAverage userStateSize;
	public final ExponentialMovingAverage baseStateSize;

	public final Collection<Watch> allWatches;

	private final int subtaskIndex;
	private final Processors processors;
	private final Ticker ticker;

	private long nextRuntimeStatisticsCollect;

	// histogram
	protected final SlidingWindowHistogram processScriptsHistogram;
	protected final Stopwatch totalProcessTime;
	public SlidingWindowHistogram processLatencyHistogram;

	// RocksdbHistogram
	private Gauge<Long> stallRocksGuage;
	private Gauge<Long> stallRocksL0Guage;
	private Gauge<Long> stallRocksMemTableGuage;
	private Gauge<Double> compactionRocks;
	private Gauge<Double> writeStallRocks;
	private Gauge<Long> numberOfKeysReadRocks;
	private Gauge<Long> numberOfKeysUpdatedRocks;
	private Gauge<Long> numberOfKeysWrittenRocks;
	private Gauge<Long> bytesReadRocks;

	public final SlidingWindowCounter eventsProcessedPerMin;

	public RBEAMetricsTracker(int subtaskIndex, MetricGroup mg, Ticker ticker, Processors proc, Fields fields,
			Statistics rocksStats) {

		if (rocksStats != null) {

			stallRocksGuage = mg.gauge("stallRocks", new RocksDbGuage(TickerType.STALL_MICROS, rocksStats));
			stallRocksL0Guage = mg.gauge("stallRocksL0Guage",
					new RocksDbGuage(TickerType.STALL_L0_SLOWDOWN_MICROS, rocksStats));
			stallRocksMemTableGuage = mg.gauge("stallMemtableGuage",
					new RocksDbGuage(TickerType.STALL_MEMTABLE_COMPACTION_MICROS, rocksStats));
			compactionRocks = mg.gauge("compactionRocks",
					new RocksDbGuageFromHisto(HistogramType.COMPACTION_TIME, rocksStats));
			numberOfKeysReadRocks = mg.gauge("numberOfKeysReadRocks",
					new RocksDbGuage(TickerType.NUMBER_KEYS_READ, rocksStats));
			numberOfKeysUpdatedRocks = mg.gauge("numberOfKeysUpdatedRocks",
					new RocksDbGuage(TickerType.NUMBER_KEYS_UPDATED, rocksStats));
			numberOfKeysWrittenRocks = mg.gauge("numberOfKeysWrittenRocks",
					new RocksDbGuage(TickerType.NUMBER_KEYS_WRITTEN, rocksStats));
			writeStallRocks = mg.gauge("writeStallRocks",
					new RocksDbGuageFromHisto(HistogramType.WRITE_STALL, rocksStats));
			bytesReadRocks = mg.gauge("bytesReadRocks", new RocksDbGuage(TickerType.BYTES_READ, rocksStats));
		}

		this.subtaskIndex = subtaskIndex;
		this.ticker = ticker;
		this.processors = proc;
		baseStateAccessRate = createEMAGauge(mg, "baseStateAccessRate", 0.001).noInitPeriod();
		userStateAccessRate = createEMAGauge(mg, "userStateAccessRate", 0.001).noInitPeriod();
		baseStateCacheHitRate = createEMAGauge(mg, "baseStateCacheHitRate", 0.001).noInitPeriod();
		userStateCacheHitRate = createEMAGauge(mg, "userStateCacheHitRate", 0.001).noInitPeriod();
		userStateSize = createEMAGauge(mg, "userStateSizeEMA", 0.001).noInitPeriod();
		baseStateSize = createEMAGauge(mg, "baseStateSizeEMA", 0.001).noInitPeriod();

		processWatch = createWatch(mg, ticker, "processTimeEMA", 0.0001);
		fieldUpdateWatch = createWatch(mg, ticker, "fieldUpdateTimeEMA", 0.0001);
		userStateReadWatch = createWatch(mg, ticker, "userStateReadTimeEMA", 0.0001);
		userStateWriteWatch = createWatch(mg, ticker, "userStateWriteTimeEMA", 0.0001);
		baseStateReadWatch = createWatch(mg, ticker, "baseStateReadTimeEMA", 0.0001);
		baseStateWriteWatch = createWatch(mg, ticker, "baseStateWriteTimeEMA", 0.0001);
		registerTimerWatch = createWatch(mg, ticker, "registerTimerEMA", 0.0001);
		removeTimerWatch = createWatch(mg, ticker, "removeTimerEMA", 0.0001);
		removeAllTimersWatch = createWatch(mg, ticker, "removeAllTimersEMA", 0.0001);
		onTimerWatch = createWatch(mg, ticker, "onTimerEMA", 0.0001);

		allWatches = Lists.newArrayList(
				processWatch, fieldUpdateWatch, userStateReadWatch,
				userStateWriteWatch, baseStateReadWatch, baseStateWriteWatch,
				registerTimerWatch, removeTimerWatch, removeAllTimersWatch,
				onTimerWatch);

		if (subtaskIndex == 0) {
			mg.gauge("scriptCount", () -> proc.size());
			mg.gauge("baseFieldCount", () -> fields.getBaseFields().size());
			mg.gauge("userFieldCount", () -> fields.getUserFields().size());
		}

		nextRuntimeStatisticsCollect = ticker.read() + TimeUnit.MILLISECONDS.toNanos(runtimeStatsIntervalMillis);

		// histogram
		totalProcessTime = Stopwatch.createUnstarted(ticker);
		processScriptsHistogram = mg.histogram("processScriptsHisto",
				new SlidingWindowHistogram(histogramInvervalInSeconds, TimeUnit.SECONDS));

		processLatencyHistogram = mg.histogram("latencyHisto",
				new SlidingWindowHistogram(histogramInvervalInSeconds, TimeUnit.SECONDS));

		eventsProcessedPerMin = mg.gauge("eventsProcessedPerMin", new SlidingWindowCounter(60));
	}

	/**
	 * If it is not time to collect {@code RuntimeStatistics}, a no-op. Otherwise
	 * sets the timer and collects a {@code RuntimeStatistics} for each processor
	 * and resets them.
	 */
	public void conditionallyCollectRuntimeStatistics(Collector<Either<BEA, Configuration>> collector) {
		long currentNanos = ticker.read();
		if (currentNanos < nextRuntimeStatisticsCollect) {
			return;
		}

		this.nextRuntimeStatisticsCollect = currentNanos + TimeUnit.MILLISECONDS.toNanos(runtimeStatsIntervalMillis);

		long now = System.currentTimeMillis();
		long minuteEnd = now - (now % 60_000) + 60_000;
		for (Tuple3<Long, EventProcessor, ExecutionStats> ep : processors.getAll()) {
			ExecutionStats stats = ep.f2;
			collector.collect(Either.<BEA, Configuration> Right(
					new RuntimeStatistics(minuteEnd, ep.f0, subtaskIndex, stats.count, stats.totalTimeNanos,
							stats.maxTimeNanos, TimeUnit.MILLISECONDS.toNanos(runtimeStatsIntervalMillis))));
			stats.reset();
		}
	}

	/**
	 * Calls a function and adds the execution time to the provided ExecutionStats
	 * object.
	 * 
	 * @throws BackendException
	 */
	public <T> T callAndMeasure(ExecutionStats stats, Tuple2<Boolean, Boolean> stateFetched,
			BackendCallable<T> callable) throws BackendException {
		long before = ticker.read();
		T result = callable.call();
		long duration = ticker.read() - before;
		if (!stateFetched.f0) {
			long fetchTime = userStateReadWatch.getElapsedNanos();
			if (fetchTime > 0) {
				duration -= fetchTime;
				stateFetched.f0 = true;
			}
		}
		if (!stateFetched.f1) {
			long fetchTime = baseStateReadWatch.getElapsedNanos();
			if (fetchTime > 0) {
				duration -= fetchTime;
				stateFetched.f1 = true;
			}
		}
		stats.add(duration);
		return result;
	}

	private static Watch createWatch(MetricGroup mg, Ticker ticker, String name, double alpha) {
		return new MetricTimer(createEMAGauge(mg, name, alpha), ticker);
	}

	private static ExponentialMovingAverage createEMAGauge(MetricGroup mg, String name, double alpha) {
		return mg.gauge(name, new ExponentialMovingAverage(alpha));
	}

	// Histogram
	public void startTotalProcessTimeMeasurement() {
		totalProcessTime.reset();
		totalProcessTime.start();
	}

	public void stopAndRecordTotalProcessTimeMeasurement() {
		totalProcessTime.stop();
		processScriptsHistogram.update(totalProcessTime.elapsed(TimeUnit.NANOSECONDS));

	}

	public static final class SlidingWindowHistogram implements Histogram {

		private final com.codahale.metrics.Histogram dropwizardHistogram;

		public SlidingWindowHistogram(long window, TimeUnit windowUnit) {
			this.dropwizardHistogram = new com.codahale.metrics.Histogram(
					new SlidingTimeWindowReservoir(window, windowUnit));
		}

		@Override
		public void update(long value) {
			dropwizardHistogram.update(value);

		}

		@Override
		public long getCount() {
			return dropwizardHistogram.getCount();
		}

		@Override
		public HistogramStatistics getStatistics() {
			return new SlidingHistogramStatistics(dropwizardHistogram.getSnapshot());
		}

	}

	static class SlidingHistogramStatistics extends HistogramStatistics {

		private final com.codahale.metrics.Snapshot snapshot;

		SlidingHistogramStatistics(com.codahale.metrics.Snapshot snapshot) {
			this.snapshot = snapshot;
		}

		@Override
		public double getQuantile(double quantile) {
			return snapshot.getValue(quantile);
		}

		@Override
		public long[] getValues() {
			return snapshot.getValues();
		}

		@Override
		public int size() {
			return snapshot.size();
		}

		@Override
		public double getMean() {
			return snapshot.getMean();
		}

		@Override
		public double getStdDev() {
			return snapshot.getStdDev();
		}

		@Override
		public long getMax() {
			return snapshot.getMax();
		}

		@Override
		public long getMin() {
			return snapshot.getMin();
		}
	}

	static class RocksDbGuage implements Gauge<Long> {

		TickerType ticker;
		Statistics stats;

		public RocksDbGuage(TickerType ticker, Statistics stats) {
			this.ticker = ticker;
			this.stats = stats;
		}

		@Override
		public Long getValue() {

			return stats.getTickerCount(ticker);
		}

	}

	static class RocksDbGuageFromHisto implements Gauge<Double> {

		HistogramType histoType;
		Statistics stats;

		public RocksDbGuageFromHisto(HistogramType histoType, Statistics stats) {
			this.histoType = histoType;
			this.stats = stats;
		}

		@Override
		public Double getValue() {

			return stats.getHistogramData(histoType).getPercentile99();
		}

	}

}
