package com.king.rbea.backend.operators.scriptexecution.metrics;

import java.util.Iterator;
import java.util.TreeMap;

import org.apache.flink.metrics.Gauge;

public class SlidingWindowCounter implements Gauge<Long> {

	private final TreeMap<Long, Long> secondCounts = new TreeMap<>();
	private final int maxSecs;

	public SlidingWindowCounter(int maxSecs) {
		this.maxSecs = maxSecs;
	}

	public SlidingWindowCounter() {
		this(60);
	}

	@Override
	public synchronized Long getValue() {
		return getValue(System.currentTimeMillis());
	}

	public synchronized Long getValue(long currentTime) {
		trimTime(currentTime);
		return secondCounts.values().stream().reduce(0l, (x, y) -> x + y);
	}

	private void trimTime(long currentTimeMillis) {
		long seconds = (currentTimeMillis - 1) / 1000;
		Iterator<Long> iterator = secondCounts.keySet().iterator();
		while (iterator.hasNext() && iterator.next() <= seconds - maxSecs) {
			iterator.remove();
		}
	}

	private void trimSize() {
		if (secondCounts.size() > maxSecs) {
			Iterator<Long> iterator = secondCounts.keySet().iterator();
			while (secondCounts.size() > maxSecs && iterator.hasNext()) {
				iterator.next();
				iterator.remove();
			}
		}
	}

	public synchronized void increment(long currentTimeMillis) {
		long seconds = currentTimeMillis / 1000;
		secondCounts.put(
				seconds,
				secondCounts.getOrDefault(seconds, (long) 0)
						+ 1);
		trimSize();
	}

}