package com.king.rbea.backend.operators.common;

import org.apache.flink.streaming.api.functions.source.SourceFunction;

/**
 * A Flink {@link SourceFunction} that periodically emits a Boolean true.
 */
public final class PeriodicBooleanSource implements SourceFunction<Boolean> {
	private static final long serialVersionUID = 1L;
	
	private volatile boolean isRunning = false;
	private final int sleep;

	/**
	 * 
	 * @param sleep milliseconds to sleep between emits
	 */
	public PeriodicBooleanSource(int sleep) {
		this.sleep = sleep;
	}

	@Override
	public void cancel() {
		isRunning = false;
	}

	@Override
	public void run(SourceContext<Boolean> ctx)
			throws Exception {
		isRunning = true;

		while (isRunning) {
			Thread.sleep(sleep);
			ctx.collect(true);
		}
	}
}