package com.king.rbea.backend.batch;

import com.king.rbea.backend.output.OutputWriter;

public class HadoopFileWriter implements OutputWriter {

}
