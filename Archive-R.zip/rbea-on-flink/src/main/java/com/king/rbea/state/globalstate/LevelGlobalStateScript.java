package com.king.rbea.state.globalstate;

import static com.king.rbea.state.globalstate.GlobalState.FAILED_ATTEMPTS_HIGHEST_LEVEL;
import static com.king.rbea.state.globalstate.GlobalState.HIGHEST_LEVEL;
import static com.king.rbea.state.globalstate.GlobalState.HIGHEST_SUCCESS_LEVEL;

import java.io.IOException;
import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple3;

import com.fasterxml.jackson.core.type.TypeReference;
import com.king.kgk.SCGameEnd;
import com.king.kgk.SCGameStart;
import com.king.rbea.Registry;
import com.king.rbea.State;
import com.king.rbea.annotations.Initialize;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.backend.utils.JsonCache;
import com.king.rbea.configuration.processor.Deployment;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.state.globalstate.GlobalStateUtility.JuegoLevelMetadata;
import com.king.rbea.state.globalstate.GlobalStateUtility.SagaLevelMetadata;

public class LevelGlobalStateScript implements Serializable {

	private static final long serialVersionUID = 3L;

	public static final Deployment DEPLOYMENT = Deployment.newJavaProcessor("LevelGlobalStateScript",
			Long.MAX_VALUE - 1335, new LevelGlobalStateScript(), "", 0l, false);

	private static final int MAIN_PROGRESSION_CAP = 10_000;

	private static final JsonCache<List<JuegoLevelMetadata>, Map<Tuple2<Integer, Integer>, Integer>> juegoLevelMetaTable = new JsonCache<>(
			JuegoLevelMetadata.getUrl(), JuegoLevelMetadata.getResourcePath(),
			new TypeReference<List<JuegoLevelMetadata>>() {},
			6, TimeUnit.HOURS,
			list -> new ConcurrentHashMap(
					list.stream().collect(Collectors.toMap(
							m -> Tuple2.of(m.kingAppId, m.level), m -> m.ordinal))));

	private static final JsonCache<List<SagaLevelMetadata>, Map<Tuple3<Integer, Integer, Integer>, Integer>> sagaLevelMetaTable = new JsonCache<>(
			SagaLevelMetadata.getUrl(), SagaLevelMetadata.getResourcePath(),
			new TypeReference<List<SagaLevelMetadata>>() {},
			6, TimeUnit.HOURS,
			list -> new ConcurrentHashMap(
					list.stream().collect(Collectors.toMap(
							m -> Tuple3.of(m.kingAppId, m.episode, m.level), m -> m.ordinal))));

	LevelGlobalStateScript() {}

	// Try to get ordinal from KingAppID+Episode+Level
	private static Integer getOrdinal(Integer kpid, Integer episd, Integer lvl) {
		if (kpid == null || episd == null || lvl == null) {
			return lvl;
		}
		Integer ordinal = juegoLevelMetaTable.getValue().get(Tuple2.of(kpid, lvl));
		if (ordinal == null) {
			ordinal = sagaLevelMetaTable.getValue().get(Tuple3.of(kpid, episd, lvl));
		}
		if (ordinal == null) {
			return lvl;
		}
		return ordinal;
	}

	@ProcessEvent(semanticClass = SCGameStart.class)
	public void onGameStart(SCGameStart gameStart, State state) throws ProcessorException {
		/**
		 * HIGHEST_LEVEL
		 */
		Integer level = getOrdinal(gameStart.getKingAppId(), gameStart.getEpisode(), gameStart.getLevel());

		if (level == null || level >= MAIN_PROGRESSION_CAP) {
			return;
		}

		final Integer stored = state.get(GlobalState.HIGHEST_LEVEL);

		if (stored < level || stored >= MAIN_PROGRESSION_CAP /* fix */) {

			state.update(HIGHEST_LEVEL, level);
			/**
			 * FAILED_ATTEMPTS_HIGHEST_LEVEL
			 */
			state.clear(FAILED_ATTEMPTS_HIGHEST_LEVEL);
		}
	}

	@ProcessEvent(semanticClass = SCGameEnd.class)
	public void onGameEnd(SCGameEnd gameEnd, State state) throws ProcessorException {
		Integer level = getOrdinal(gameEnd.getKingAppId(), gameEnd.getEpisode(), gameEnd.getLevel());
		Integer endReason = gameEnd.getGameEndReason();

		if (level == null || endReason == null || level >= MAIN_PROGRESSION_CAP) {
			return;
		}

		if (endReason == 0) {
			/**
			 * HIGHEST_SUCCESS_LEVEL
			 */
			final Integer stored = state.get(HIGHEST_SUCCESS_LEVEL);
			if (stored < level || stored >= MAIN_PROGRESSION_CAP /* fix */) {
				state.update(HIGHEST_SUCCESS_LEVEL, level);
			}
		} else {
			/**
			 * FAILED_ATTEMPTS_HIGHEST_LEVEL
			 */
			if (state.get(HIGHEST_LEVEL) == level) {
				state.update(FAILED_ATTEMPTS_HIGHEST_LEVEL,
						state.get(FAILED_ATTEMPTS_HIGHEST_LEVEL) + 1);
			}
		}
	}

	/**
	 * All states have to be initialized here (incl. default value)
	 */
	@Initialize
	public void init(Registry reg) throws ProcessorException, IOException {
		reg.registerState(HIGHEST_LEVEL);
		reg.registerState(FAILED_ATTEMPTS_HIGHEST_LEVEL);
		reg.registerState(HIGHEST_SUCCESS_LEVEL);
	}
}
