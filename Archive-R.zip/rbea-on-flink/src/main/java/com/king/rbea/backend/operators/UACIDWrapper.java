package com.king.rbea.backend.operators;

import org.apache.flink.api.common.functions.MapFunction;

import com.king.event.Event;
import com.king.rbea.backend.types.EventWrapper;

public enum UACIDWrapper implements MapFunction<Event, EventWrapper> {

	INSTANCE;

	@Override
	public EventWrapper map(Event input) throws Exception {
		long uacid = input.getUacid();
		return new EventWrapper(input, uacid > 0 ? uacid : null);
	}
}
