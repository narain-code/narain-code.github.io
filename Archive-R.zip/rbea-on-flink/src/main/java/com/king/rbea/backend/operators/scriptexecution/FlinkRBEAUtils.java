package com.king.rbea.backend.operators.scriptexecution;

import com.king.rbea.Context;
import com.king.rbea.Utils;
import com.king.rbea.backend.services.BiteroImpl;
import com.king.utils.Bitero;

class FlinkRBEAUtils implements Utils {

	private final Bitero bitero;

	FlinkRBEAUtils(Context context) {
		this.bitero = new BiteroImpl(context.getOutput());
	}

	@Override
	public Bitero getBitero() {
		return bitero;
	}

}
