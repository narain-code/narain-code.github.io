package com.king.rbea.backend.output;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import org.apache.commons.codec.binary.Base64OutputStream;
import org.xerial.snappy.SnappyOutputStream;

import com.clearspring.analytics.stream.cardinality.HyperLogLog;
import com.king.constants.Flavour;
import com.king.constants.KingApp;
import com.king.constants.SignInSource;
import com.king.constants.external.EventType;
import com.king.event.Event;
import com.king.event.EventBuilder;
import com.king.rbea.backend.types.bea.Aggregate;
import com.king.rbea.backend.types.bea.HLLAggregate;
import com.king.rbea.backend.types.bea.RatioAggregate;

/**
 * {@code AggrigatoEventFactory} contains methods to create an {@link Event} 
 * from an {@link AggrigatoEventFactory}, specifically the created
 * event being one of the Aggrigato-supported events.
 */
public class AggrigatoEventFactory implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private static final int RBEA_FLAVOUR = Flavour.createFlavour(KingApp.RBEA, SignInSource.BACK_END);

	public Event createAggrigatoLongEvent(Aggregate agg) {
		Event aggrigatoEvent = new EventBuilder(RBEA_FLAVOUR)
				.buildEvent(
						EventType.AggrigatoLong(
								agg.getTimestamp() - agg.getWindowSize(),
								agg.getWindowSize(),
								agg.getName(),
								agg.getDimensions(),
								agg.getLongValue()),
						0);
		return aggrigatoEvent;
	}

	public Event createAggrigatoRatioEvent(RatioAggregate ratio) {
		return new EventBuilder(RBEA_FLAVOUR)
				.buildEvent(
						EventType.AggrigatoLongRatio(
								ratio.getTimestamp() - ratio.getWindowSize(),
								ratio.getWindowSize(),
								ratio.getName(),
								ratio.getDimensions(),
								ratio.getNumerator(),
								ratio.getDenominator()),
						0);
	}
	
	public Event createAggrigatoHyperLogLogEvent(HLLAggregate hll) {
		return new EventBuilder(RBEA_FLAVOUR)
				.buildEvent(
						EventType.AggrigatoHyperLogLog(
								hll.getTimestamp() - hll.getWindowSize(),
								hll.getWindowSize(),
								hll.getName(),
								hll.getDimensions(),
								serializeHyperLogLog(hll.getValue())),
						0);
	}
	
	public String serializeHyperLogLog(HyperLogLog hll) {
		try {
			ByteArrayOutputStream baos = new ByteArrayOutputStream(512);
			// Base64: by default creates multi-line output. Disable that.
			try (ObjectOutputStream out = new ObjectOutputStream(new SnappyOutputStream(new Base64OutputStream(baos, true, -1, new byte[] {})))) {
				out.writeObject(hll);
			}
			return baos.toString("UTF-8");
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
}
