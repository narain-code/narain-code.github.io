package com.king.rbea.backend.operators.heartbeat;

import org.apache.flink.api.common.functions.RichFlatMapFunction;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.util.Collector;

import com.king.rbea.configuration.processor.Heartbeat;

/**
 * A Flink operator that collects Heartbeat (in a Tuple2 wrapper).
 */
public class HeartbeatCreator extends RichFlatMapFunction<Boolean, Tuple2<String, Heartbeat>> {
	private static final long serialVersionUID = 1L;
	
	private final String backendId;

	public HeartbeatCreator(String backendId) {
		this.backendId = backendId;
	}
	
	/**
	 * Collects a Heartbeat timestamp to current time.
	 */
	@Override
	public void flatMap(Boolean value, Collector<Tuple2<String, Heartbeat>> out) throws Exception {
		out.collect(Tuple2.of(backendId, new Heartbeat(System.currentTimeMillis())));
	}
}
