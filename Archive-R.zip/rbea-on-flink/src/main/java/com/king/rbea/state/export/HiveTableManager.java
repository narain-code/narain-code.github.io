package com.king.rbea.state.export;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.king.flink.utils.Retrier;

public class HiveTableManager implements FileCommitCallback {

	private static final long serialVersionUID = 1L;

	protected static final Logger LOG = LoggerFactory.getLogger(HiveTableManager.class);

	private final String connectionUrl;
	private final String basePath;
	private final String rawBasePath;

	private transient Connection connection;

	public HiveTableManager(String connectionUrl, String basePath) {
		this.connectionUrl = connectionUrl;
		this.basePath = basePath;
		this.rawBasePath = Path.getPathWithoutSchemeAndAuthority(new Path(basePath)).toString();
	}

	private void checkConnection() throws Exception {
		boolean validConnection = false;
		if (connection != null) {
			validConnection = !connection.isClosed();
			if (!validConnection) {
				try {
					connection.close();
				} catch (SQLException ignore) {}
				connection = null;
			}
		}

		if (validConnection) {
			return;
		}

		connection = Retrier.retry(() -> {
			Class.forName("org.apache.hive.jdbc.HiveDriver");
			return DriverManager.getConnection(connectionUrl, "narain_ramaswamy", "");
		}, 12, 5000);

	}

	private static final String CREATE_TABLE = "create external table if not exists TABLE_NAME " +
			"partitioned by (dt string, bucket string) " +
			"row format serde 'org.apache.hadoop.hive.serde2.avro.AvroSerDe' " +
			"STORED AS INPUTFORMAT 'org.apache.hadoop.hive.ql.io.avro.AvroContainerInputFormat' " +
			"OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.avro.AvroContainerOutputFormat' " +
			"LOCATION 'BASE_PATH/final/TABLE_NAME' " +
			"TBLPROPERTIES ('avro.schema.url'='BASE_PATH/schemas/TABLE_NAME.schema')";

	public boolean createAvroTable(String tableName) throws Exception {
		checkConnection();
		try (Statement smt = connection.createStatement()) {
			String sql = CREATE_TABLE.replace("TABLE_NAME", tableName).replace("BASE_PATH", basePath);
			LOG.info("Executing Hive command: {}", sql);
			return smt.execute(sql);
		}
	}

	private static final String INSERT_BUCKET = "LOAD DATA "
			+ "INPATH 'RAW_BASE_PATH/final/TABLE_NAME/dt=BUCKET_DT/bucket=BUCKET_TIME' "
			+ "INTO TABLE TABLE_NAME "
			+ "PARTITION (dt='BUCKET_DT', bucket='BUCKET_TIME')";

	public boolean insertBucket(String tableName, String bucketDt, String bucketTime) throws Exception {
		checkConnection();
		try (Statement smt = connection.createStatement()) {
			String sql = INSERT_BUCKET.replace("TABLE_NAME", tableName).replace("RAW_BASE_PATH", rawBasePath)
					.replace("BUCKET_DT", bucketDt).replace("BUCKET_TIME", bucketTime);
			LOG.info("Executing Hive command: {}", sql);
			return smt.execute(sql);
		}
	}

	@Override
	public void close() throws IOException {
		if (connection != null) {
			try {
				connection.close();
			} catch (SQLException ignore) {}
			connection = null;
		}
	}

	@Override
	public void accept(FileSystem fs, Path path) {
		Path bucket = path.getParent();
		String bucketTime = bucket.getName().split("=")[1];
		Path dt = bucket.getParent();
		String bucketDt = dt.getName().split("=")[1];
		String tableName = dt.getParent().getName();

		try {
			RBEABucketingSink.setAllPermissionsRecursively(fs, path.getParent());
			createAvroTable(tableName);
			insertBucket(tableName, bucketDt, bucketTime);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
}
