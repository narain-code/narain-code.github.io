package com.king.rbea.state.globalstate;

import java.io.IOException;
import java.io.Serializable;
import java.util.TreeMap;

import com.king.event.Event;
import com.king.kgk.SCPurchase;
import com.king.kgk.SCStoreOpen;
import com.king.rbea.Output;
import com.king.rbea.Registry;
import com.king.rbea.State;
import com.king.rbea.Utils;
import com.king.rbea.annotations.Initialize;
import com.king.rbea.annotations.OnError;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.configuration.processor.Deployment;
import com.king.rbea.exceptions.ProcessorException;

public class SpendGlobalStateScript implements Serializable {

	private static final long serialVersionUID = 2L;

	public static final Deployment DEPLOYMENT = Deployment.newJavaProcessor("SpendGlobalStateScript",
			Long.MAX_VALUE - 1336, new SpendGlobalStateScript(), "", 0l, false);

	private SpendGlobalStateScript() {}

	@OnError(maxErrorsPerMin = Integer.MAX_VALUE)
	public void handleErr(Throwable err, Output out) throws ProcessorException {
		GlobalStateUtility.log("SpendGlobalStateScript error", err, out);
	}

	@ProcessEvent(semanticClass = SCPurchase.class)
	public void onPurchase(SCPurchase purchase, State state, Event event, Utils utils, Output out)
			throws Exception {
		/**
		 * FIRST_SPEND_MSTS
		 */
		if (state.get(GlobalState.FIRST_SPEND_MSTS) < 1) {
			state.update(GlobalState.FIRST_SPEND_MSTS, event.getTimeStamp());
		}

		/**
		 * TOTAL_SPEND_USD
		 */
		Double totalSpendUSD = state.get(GlobalState.TOTAL_SPEND_USD);
		Double usdAmount = utils.getCurrencyManager()
				.convertToUsd(event.getTimeStamp(), purchase.getCurrency_local(), purchase.getSpend_local())
				.doubleValue();

		totalSpendUSD += usdAmount;
		state.update(GlobalState.TOTAL_SPEND_USD, totalSpendUSD);

		/**
		 * SPEND_USD_HISTORY_30DAYS
		 */
		TreeMap<Long, Double> spendUsdHistory = state.get(GlobalState.SPEND_USD_HISTORY_30DAYS);
		long now = GlobalState.getClock().millis();
		spendUsdHistory.put(now, usdAmount);
		// Act: remove entries older than 30 days, while keeping at least one entry
		GlobalStateUtility.historyCleanup(spendUsdHistory, now, GlobalStateUtility.hrsPer30Days,
				GlobalStateUtility.maxSpendNum);
	}

	@ProcessEvent(semanticClass = SCStoreOpen.class)
	public void onStoreOpen(SCStoreOpen storeOpen, State state, Event event) throws ProcessorException {
		/**
		 * LAST_STORE_OPEN_MSTS
		 */
		state.update(GlobalState.LAST_STORE_OPEN_MSTS, event.getTimeStamp());
	}

	@Initialize
	public void init(Registry reg) throws ProcessorException, IOException {
		reg.registerState(GlobalState.TOTAL_SPEND_USD);
		reg.registerState(GlobalState.FIRST_SPEND_MSTS);
		reg.registerState(GlobalState.LAST_STORE_OPEN_MSTS);
		reg.registerState(GlobalState.SPEND_USD_HISTORY_30DAYS);
	}
}
