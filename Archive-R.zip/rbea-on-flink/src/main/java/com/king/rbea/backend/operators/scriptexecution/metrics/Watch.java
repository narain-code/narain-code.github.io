package com.king.rbea.backend.operators.scriptexecution.metrics;

import com.google.common.base.Stopwatch;

/**
 * Basically an interface for wrapping a {@link Stopwatch} with some additional
 * behavior that come in handy for metrics tracking.
 */
public interface Watch {

	public void restart();

	public void reset();

	public void stopAndRecord();

	public long getElapsedNanos();
}
