package com.king.rbea.backend.operators.windowing;

import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.streaming.api.functions.windowing.WindowFunction;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.util.Collector;

import com.king.rbea.backend.types.bea.Aggregate;

public class TimestampSetter implements WindowFunction<Aggregate, Aggregate, Tuple4<Byte, String, String, Long>, TimeWindow> {
	private static final long serialVersionUID = 1L;

	@Override
	public void apply(Tuple4<Byte,String, String, Long> key, TimeWindow window, Iterable<Aggregate> aggregated,
			Collector<Aggregate> out) throws Exception {
		Aggregate agg = aggregated.iterator().next();
		agg.setTimestamp(window.getEnd());
		out.collect(agg);
	}
}