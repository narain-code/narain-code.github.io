package com.king.rbea.state.export;

import org.apache.avro.Schema;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.util.Collector;

public class ReadSchema implements FlatMapFunction<byte[], Tuple2<Long, Schema>> {
	private static final long serialVersionUID = 1L;

	@Override
	public void flatMap(byte[] bytes, Collector<Tuple2<Long, Schema>> out) throws Exception {
		try {
			out.collect(StateExportDeserializer.deserializeSchema(bytes));
		} catch (Throwable t) {
			StateExportWriterJob.LOG.error("Error while deserializing schema message", t);
		}
	}
}