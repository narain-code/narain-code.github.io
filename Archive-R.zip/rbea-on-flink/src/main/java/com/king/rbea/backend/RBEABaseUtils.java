package com.king.rbea.backend;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.flink.api.java.utils.ParameterTool;

import com.king.rbea.backend.utils.BackendConstants;
import com.king.rbea.configuration.processor.Deployment;
import com.king.rbea.state.baseprocessors.BaseProcessorProvider;
import com.king.rbea.state.baseprocessors.DefaultBaseProcessorProvider;

public class RBEABaseUtils {

	public static List<Deployment> getAllBaseProcesors(ParameterTool params) throws Exception {
		if (params.getBoolean(BackendConstants.DISABLE_GLOBAL_STATES, false)) {
			return Collections.emptyList();
		}

		List<Deployment> all = new ArrayList<>();

		if (!params.getBoolean(BackendConstants.DISABLE_DEFAULT_PROCESSORS, false)) {
			all.addAll(DefaultBaseProcessorProvider.INSTANCE.getBaseProcessors());
		}

		if (params.has(BackendConstants.BASE_PROC_PROVIDERS)) {
			for (String providerName : params.get(BackendConstants.BASE_PROC_PROVIDERS).split(",")) {
				BaseProcessorProvider provider = (BaseProcessorProvider) Class.forName(providerName).newInstance();
				all.addAll(provider.getBaseProcessors());
			}
		}

		return all;
	}
}
