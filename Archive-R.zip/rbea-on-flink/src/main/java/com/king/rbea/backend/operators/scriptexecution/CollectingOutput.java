package com.king.rbea.backend.operators.scriptexecution;

import java.nio.ByteBuffer;
import java.util.regex.Pattern;

import org.apache.flink.types.Either;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Charsets;
import com.king.event.Event;
import com.king.flink.utils.Unchecked;
import com.king.rbea.Output;
import com.king.rbea.backend.operators.FailureHandlingSchema;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.backend.types.bea.KafkaOutput;
import com.king.rbea.configuration.Configuration;
import com.king.rbea.exceptions.BackendException;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.state.export.StateExporter;

public class CollectingOutput implements Output {


	private static final String TOPIC_BLACKLIST_REGEX = "^event\\..*\\.log$";

	private Collector<Either<BEA, Configuration>> collector;
	private final long processorId;
	private byte[] subtaskKey;
	private String exportTopic;
	private String schemaTopic;

	public CollectingOutput(Collector<Either<BEA, Configuration>> collector, long procId, int subtaskIndex) {
		this(collector, procId, subtaskIndex, null, null);
	}

	public CollectingOutput(Collector<Either<BEA, Configuration>> collector, long procId, int subtaskIndex,
			String exportTopic, String schemaTopic) {
		this.collector = collector;
		this.processorId = procId;
		
		this.exportTopic = exportTopic;
		this.schemaTopic = schemaTopic;
		subtaskKey = ByteBuffer.allocate(4).putInt(subtaskIndex).array();
	}

	@Override
	public void writeBytesToKafka(String topic, byte[] key, byte[] data) throws ProcessorException {
		validateTopic(topic);
		collector.collect(Either.Left(new KafkaOutput(processorId, topic, key, data)));
	}

	@Override
	public void print(Object obj) {
		try {
			writeBytesToKafka("PRINT_" + processorId, subtaskKey, obj.toString().getBytes(Charsets.UTF_8));
		} catch (ProcessorException shouldNotHappen) {
			Unchecked.throwSilently(new BackendException(shouldNotHappen.getMessage()));
		}
	}

	@Override
	public String formatEvent(Event event) {
		return FailureHandlingSchema.eventFormat.format(event);
	}

	@Override
	public String getStateExportTopic() {
		
		return exportTopic;
	}

	@Override
	public String getStateSchemaExportTopic() {
		return schemaTopic;
	}

	private static final Pattern TOPIC_NAME_TEGEX = Pattern.compile("[a-zA-Z0-9\\._\\-]+");
	private static final long maxTopicLen = 255;

	public static void validateTopic(String topic) throws ProcessorException {
		ProcessorException pe = null;

		if (topic.matches(TOPIC_BLACKLIST_REGEX)) {
			pe = new ProcessorException("Illegal output Kafka topic: " + topic);
		}
		if (topic.length() <= 0)
			pe = new ProcessorException("topic name is illegal, can't be empty");
		else if (topic.equals(".") || topic.equals(".."))
			pe = new ProcessorException("topic name cannot be \".\" or \"..\"");
		else if (topic.length() > maxTopicLen)
			pe = new ProcessorException("topic name is illegal, can't be longer than " + maxTopicLen + " characters");

		if (!TOPIC_NAME_TEGEX.matcher(topic).matches()) {
			pe = new ProcessorException("topic name " + topic
					+ " is illegal, contains a character other than ASCII alphanumerics, '.', '_' and '-'");
		}
		if (pe != null) {
			throw pe;
		}
	}

}
