package com.king.rbea.backend;

import static com.king.rbea.backend.utils.BackendConstants.BACKEND_TOPIC;
import static com.king.rbea.backend.utils.BackendConstants.CHECKPOINT_DIR;
import static com.king.rbea.backend.utils.BackendConstants.CHECKPOINT_INTERVAL_SECONDS;
import static com.king.rbea.backend.utils.BackendConstants.INCREMENTAL_CHECKPOINTS;
import static com.king.rbea.backend.utils.BackendConstants.WRITE_TO_KAFKA;
import static org.apache.flink.api.java.utils.ParameterTool.fromPropertiesFile;

import java.io.File;

import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.contrib.streaming.state.OptionsFactory;
import org.apache.flink.contrib.streaming.state.RocksDBStateBackend;
import org.apache.flink.runtime.state.filesystem.FsStateBackend;
import org.apache.flink.shaded.guava18.com.google.common.collect.Sets;
import org.apache.flink.streaming.api.CheckpointingMode;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.CheckpointConfig;
import org.apache.flink.streaming.api.environment.CheckpointConfig.ExternalizedCheckpointCleanup;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.rocksdb.BlockBasedTableConfig;
import org.rocksdb.ColumnFamilyOptions;
import org.rocksdb.CompactionStyle;
import org.rocksdb.DBOptions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.king.rbea.backend.configuration.KafkaParams;
import com.king.rbea.backend.output.IgnoringOutputWriter;
import com.king.rbea.backend.output.OutputWriter;
import com.king.rbea.backend.output.RBEAOutput;
import com.king.rbea.backend.types.EventWrapper;
import com.king.rbea.backend.utils.BackendConstants;
import com.king.rbea.backend.utils.RBEAStreamUtils;
import com.king.rbea.configuration.Configuration;

/**
 * {@code RBEAFlinkBackend} is the main entry point of RBEA backend with
 * {@link #main(String[])} method responsible of starting the backend.
 */
public class RBEAFlinkBackend {
	private static final Logger LOG = LoggerFactory.getLogger(RBEAFlinkBackend.class);

	public static void main(String[] args) throws Exception {
		new RBEAFlinkBackend().start(args);
	}

	public void start(String[] args) throws Exception {
		if (args.length != 1) {
			System.out.println("Need to specify properties file");
			return;
		}

		String backendShortName = new File(args[0]).getName().split("\\.")[0];

		ParameterTool allParams = fromPropertiesFile(args[0]);
		String envName = allParams.get(BackendConstants.ENV_NAME);
		KafkaParams kafkaParams = new KafkaParams(allParams);
		String backendId = allParams.get(BackendConstants.BACKEND_ID, allParams.getRequired(BACKEND_TOPIC));

		StreamExecutionEnvironment env = createExecutionEnvironment(allParams, backendShortName);

		// Read input streams
		DataStream<EventWrapper> allEvents = RBEAEventInput.getEventStream(allParams, kafkaParams, env);
		DataStream<Configuration> jobUpdateDataStream = RBEAConfigInput.getEventStream(allParams, kafkaParams, env);

		// Run BEA processing logic
		RBEAOutput output = RBEA.run(allEvents, jobUpdateDataStream, allParams,
				RBEABaseUtils.getAllBaseProcesors(allParams),
				allParams.getBoolean(WRITE_TO_KAFKA, true) ? OutputWriter.INSTANCE : IgnoringOutputWriter.INSTANCE,
				false, backendId, envName);

		// Write job info
		output.writeOutputStreams(allParams, kafkaParams);

		printExecutionGraph(env);
		env.execute(RBEAStreamUtils.removeDots(backendId));
	}

	/**
	 * Creates a Flink {@link StreamExecutionEnvironment} based on {@code params}.
	 * 
	 * @param params
	 *            configuration parameters
	 * @return the instance
	 * @throws Exception
	 */
	@SuppressWarnings("deprecation")
	private StreamExecutionEnvironment createExecutionEnvironment(ParameterTool params, String backendName)
			throws Exception {
		StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
		env.getConfig().disableSysoutLogging();
		env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime);
		env.setStateBackend(createRocksDBBackend(params, backendName));

		if (params.has(BackendConstants.MAX_PARALLELISM)) {
			env.setMaxParallelism(params.getInt(BackendConstants.MAX_PARALLELISM));
		}

		long cpInterval = params.getLong(CHECKPOINT_INTERVAL_SECONDS) * 1000;
		if (cpInterval > 0) {
			LOG.info("Checkpointing enabled with cp interval = {} s", cpInterval / 1000);

			CheckpointConfig checkpointConf = env.getCheckpointConfig();
			checkpointConf.setForceCheckpointing(true);
			checkpointConf.setCheckpointInterval(cpInterval);
			checkpointConf.setMinPauseBetweenCheckpoints(cpInterval);
			checkpointConf.setCheckpointingMode(CheckpointingMode.EXACTLY_ONCE);
			checkpointConf.setCheckpointTimeout(10 * 60 * 60 * 1000);
			checkpointConf.setMaxConcurrentCheckpoints(1);
			checkpointConf.enableExternalizedCheckpoints(ExternalizedCheckpointCleanup.RETAIN_ON_CANCELLATION);
		}
		return env;
	}

	public static RocksDBStateBackend createRocksDBBackend(ParameterTool params, String backendName) throws Exception {

		String cpDir = params.getRequired(CHECKPOINT_DIR);
		cpDir = cpDir.endsWith("/") ? cpDir : cpDir + "/";
		cpDir += backendName;

		RocksDBStateBackend backend = new TestStateBackend(
				new FsStateBackend(cpDir),
				params.getBoolean(INCREMENTAL_CHECKPOINTS, true),
				params.has("droppedState") ? Sets.newHashSet(params.get("droppedState").split(",")) : Sets.newHashSet());

		backend.setOptions(new OptionsFactory() {
			private static final long serialVersionUID = 1L;

			@Override
			public ColumnFamilyOptions createColumnOptions(ColumnFamilyOptions options) {

				long blockSize = 8 * 1024;
				long blockCacheSize = 1024 * 1024 * 1024;

				long writeBufferSize = 512 * 1024 * 1024;

				int minWriteBufferToMerge = 4;
				int maxWriteBufferNumber = 16;

				long targetFileSize = 256 * 1024 * 1024;

				options.setCompactionStyle(CompactionStyle.LEVEL)
						.setLevelCompactionDynamicLevelBytes(true)
						.setTargetFileSizeBase(targetFileSize)
						.setMaxBytesForLevelBase(8 * targetFileSize)
						.setWriteBufferSize(writeBufferSize)
						.setLevelZeroSlowdownWritesTrigger(48)
						.setLevelZeroStopWritesTrigger(56)
						.setMaxWriteBufferNumber(maxWriteBufferNumber)
						.setMinWriteBufferNumberToMerge(minWriteBufferToMerge)
						.setTableFormatConfig(
								new BlockBasedTableConfig()
										.setBlockCacheSize(blockCacheSize)
										.setBlockSize(blockSize));
				return options;
			}

			@Override
			public DBOptions createDBOptions(DBOptions options) {
				options
						.setUseFsync(false)
						.setAllowMmapReads(true)
						.setMaxOpenFiles(-1)
						.setTableCacheNumshardbits(6)
						.setBytesPerSync(512 * 1024)
						.createStatistics();

				return options;
			}
		});

		return backend;
	}

	private void printExecutionGraph(StreamExecutionEnvironment env) {
		env.getStreamGraph().getJobGraph().getVertices().forEach(v -> {
			System.out.println(v.getID() + " " + v.getName() + " " + v.getOperatorName());
		});
	}
}
