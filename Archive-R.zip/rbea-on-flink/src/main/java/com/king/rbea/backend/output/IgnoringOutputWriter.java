package com.king.rbea.backend.output;

import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;

import com.king.rbea.backend.types.bea.KafkaOutput;
import com.king.rbea.configuration.Configuration;

/**
 * {@code IgnoringOutputWriter} is a no-op {@link OutputWriter}. It's use case
 * is to act as an {@code OutputWrite} but not actually output anything, e.g.
 * while testing with production Kafka but not wanting to output anything there.
 */
public enum IgnoringOutputWriter implements OutputWriter {
	INSTANCE;

	@Override
	public SingleOutputStreamOperator<Configuration> writeKafkaOutput(ParameterTool params,
			DataStream<KafkaOutput> kafkaOutput, DataStream<KafkaOutput> mysqlOutput) {
		return null;
	}
}
