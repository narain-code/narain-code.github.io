package com.king.rbea.backend.output;

import java.util.Arrays;
import java.util.Random;

import org.apache.flink.streaming.connectors.kafka.partitioner.FlinkKafkaPartitioner;

public class HashingKafkaPartitioner<T> extends FlinkKafkaPartitioner<T> {

	private static final long serialVersionUID = -5073273587605637390L;

	private final Random rnd = new Random();

	@Override
	public int partition(T next, byte[] serializedKey, byte[] serializedValue, String topic, int[] partitions) {
		int numPartitions = partitions.length;
		if (serializedKey == null) {
			return rnd.nextInt(numPartitions);
		} else {
			return Math.abs(Arrays.hashCode(serializedKey)) % numPartitions;
		}
	}

}
