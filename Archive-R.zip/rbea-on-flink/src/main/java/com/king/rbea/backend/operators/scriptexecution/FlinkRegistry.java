package com.king.rbea.backend.operators.scriptexecution;

import java.util.LinkedHashMap;
import java.util.Map;

import com.king.rbea.Registry;
import com.king.rbea.exceptions.BackendException;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.state.LocalState;
import com.king.rbea.state.StateDescriptor;

public class FlinkRegistry implements Registry {

	public final long processorId;
	public final Fields fields;

	private final Map<String, LocalState<?>> fieldsToRegister = new LinkedHashMap<>();
	private boolean isBaseProc;

	public FlinkRegistry(Fields fields, long porcId, boolean isBaseProc) {
		this.fields = fields;
		this.processorId = porcId;
		this.isBaseProc = isBaseProc;
	}

	@Override
	public <T> StateDescriptor<T> registerState(LocalState<T> field) throws ProcessorException {
		String fieldName = isBaseProc ? field.getStateName() : field.getStateName() + processorId;
		if (fieldsToRegister.containsKey(fieldName)) {
			throw new ProcessorException("Cannot register 2 states with the same name");
		}

		fieldsToRegister.put(fieldName, field);
		return field;
	}

	public void finalizeRegistration() throws ProcessorException, BackendException {
		for (Map.Entry<String, LocalState<?>> e : fieldsToRegister.entrySet()) {
			fields.addUserField(processorId, e.getValue(), e.getKey());
		}

		fieldsToRegister.clear();
	}

	@Override
	public void registerStateDependency(long rbeaJobId, String fieldName) {
		if (fields.getIdForName(fieldName + rbeaJobId) == null) {
			throw new RuntimeException("No field registered for name " + fieldName + " for job " + rbeaJobId);
		}
	}
}
