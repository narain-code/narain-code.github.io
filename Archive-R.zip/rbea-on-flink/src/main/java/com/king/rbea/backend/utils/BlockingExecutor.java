package com.king.rbea.backend.utils;

import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.Semaphore;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.function.BiConsumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.scripts.proxy.AsyncMethodCall.ExceptionWrapper;

/**
 * An executor which blocks and prevents further tasks from being submitted to
 * the pool when the queue is full.
 * <p>
 * Based on the BoundedExecutor example in: Brian Goetz, 2006. Java Concurrency
 * in Practice. (Listing 8.4)
 */
public class BlockingExecutor extends ThreadPoolExecutor {

	public static int TIMEOUT_SECONDS = 10;
	private static final Logger LOGGER = LoggerFactory.getLogger(BlockingExecutor.class);
	private final Semaphore semaphore;
	private final int totalPermits;
	private BiConsumer<Runnable, Throwable> errorHandler;
	private ExecutorService timeoutExecutor;

	/**
	 * Creates a BlockingExecutor which will block and prevent further submission to
	 * the pool when the specified queue size has been reached.
	 *
	 * @param poolSize
	 *            the number of the threads in the pool
	 * @param queueSize
	 *            the size of the queue
	 */
	public BlockingExecutor(final int poolSize, final int queueSize, BiConsumer<Runnable, Throwable> errorHandler) {
		super(poolSize, poolSize, 0L, TimeUnit.MILLISECONDS,
				new LinkedBlockingQueue<Runnable>());
		this.errorHandler = errorHandler;

		// the semaphore is bounding both the number of tasks currently executing
		// and those queued up
		totalPermits = poolSize + queueSize;
		semaphore = new Semaphore(totalPermits);
		timeoutExecutor = Executors.newCachedThreadPool();
	}

	/**
	 * Executes the given task. This method will block when the semaphore has no
	 * permits i.e. when the queue has reached its capacity.
	 */
	@Override
	public void execute(final Runnable task) {
		boolean acquired = false;
		do {
			try {
				semaphore.acquire();
				acquired = true;
			} catch (final InterruptedException e) {
				LOGGER.warn("InterruptedException whilst aquiring semaphore", e);
			}
		} while (!acquired);

		try {
			WrapperFutureTask<Void> ftask = new WrapperFutureTask<>(task, null);
			super.execute(ftask);
			applyTimeout(ftask);
		} catch (final RejectedExecutionException e) {
			semaphore.release();
			throw e;
		}
	}

	private void applyTimeout(WrapperFutureTask<Void> ftask) {
		timeoutExecutor.execute(() -> {
			try {
				ftask.get(TIMEOUT_SECONDS, TimeUnit.SECONDS);
			} catch (TimeoutException e) {
				ftask.cancel(true);
				errorHandler.accept(ftask.getRunnable(),
						new ProcessorException("Async called timed out after " + TIMEOUT_SECONDS + " seconds"));
			} catch (Throwable ignore) {}
		});
	}

	public void waitForAllTasks() {
		boolean acquired = false;
		do {
			try {
				semaphore.acquire(totalPermits);
				acquired = true;
			} catch (InterruptedException e) {
				LOGGER.warn("InterruptedException whilst aquiring semaphore", e);
			}
		} while (!acquired);
		semaphore.release(totalPermits);
	}

	/**
	 * Method invoked upon completion of execution of the given Runnable, by the
	 * thread that executed the task. Releases a semaphore permit.
	 */
	@Override
	protected void afterExecute(final Runnable r, Throwable t) {
		super.afterExecute(r, t);
		semaphore.release();
		if (t == null && r instanceof Future<?>) {
			try {
				Future<?> future = (Future<?>) r;
				if (future.isDone()) {
					future.get();
				}
			} catch (CancellationException ce) {
				t = ce;
			} catch (ExecutionException ee) {
				t = ee.getCause();
			} catch (InterruptedException ie) {
				Thread.currentThread().interrupt(); // ignore/reset
			}
		}

		if (t != null && t instanceof ExceptionWrapper) {
			errorHandler.accept(((WrapperFutureTask<?>) r).getRunnable(), t.getCause());
		}
	}

	@Override
	public <C> Future<C> submit(final Callable<C> task) {
		throw new UnsupportedOperationException();
	}

	private static class WrapperFutureTask<T> extends FutureTask<T> {

		private final Runnable runnable;

		public WrapperFutureTask(Runnable runnable, T result) {
			super(runnable, result);
			this.runnable = runnable;
		}

		public Runnable getRunnable() {
			return runnable;
		}
	}
}