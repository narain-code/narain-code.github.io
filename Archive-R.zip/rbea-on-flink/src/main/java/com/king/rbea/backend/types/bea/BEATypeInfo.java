package com.king.rbea.backend.types.bea;

import org.apache.flink.api.common.ExecutionConfig;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeutils.TypeSerializer;

public class BEATypeInfo<B extends BEA> extends TypeInformation<B> {

	private static final long serialVersionUID = 1L;

	@Override
	public boolean canEqual(Object other) {
		return other instanceof BEATypeInfo;
	}

	@Override
	public TypeSerializer<B> createSerializer(ExecutionConfig arg0) {
		return new BEASerializer<>();
	}

	@Override
	public boolean equals(Object other) {
		return other instanceof BEATypeInfo;
	}

	@Override
	public int getArity() {
		return 0;
	}

	@Override
	public int getTotalFields() {
		return 0;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Class<B> getTypeClass() {
		return (Class<B>) BEA.class;
	}

	@Override
	public int hashCode() {
		return 0;
	}

	@Override
	public boolean isBasicType() {
		return false;
	}

	@Override
	public boolean isKeyType() {
		return false;
	}

	@Override
	public boolean isTupleType() {
		return false;
	}

	@Override
	public String toString() {
		return "BEA TypeInfo";
	}
}
