package com.king.rbea.backend.types.bea;

import java.io.IOException;

import org.apache.flink.api.common.typeutils.base.ByteSerializer;
import org.apache.flink.api.common.typeutils.base.TypeSerializerSingleton;
import org.apache.flink.core.memory.DataInputView;
import org.apache.flink.core.memory.DataOutputView;

@SuppressWarnings({ "unchecked" })
public class BEASerializer<B extends BEA> extends TypeSerializerSingleton<B> {
	private static final long serialVersionUID = 1L;
	private static final ByteSerializer bs = ByteSerializer.INSTANCE;

	@Override
	public B copy(B bea) {
		return (B) BEA.getSerializerForType(bea.type).copy(bea);
	}

	@Override
	public B copy(B bea, B reuse) {
		return copy(bea);
	}

	@Override
	public void copy(DataInputView arg0, DataOutputView arg1) throws IOException {
		throw new UnsupportedOperationException();
	}

	@Override
	public B createInstance() {
		return null;
	}

	@Override
	public B deserialize(DataInputView in) throws IOException {
		byte type = bs.deserialize(in);
		return (B) BEA.getSerializerForType(type).deserialize(in);
	}

	@Override
	public B deserialize(B reuse, DataInputView in) throws IOException {
		return deserialize(in);
	}

	@Override
	public int getLength() {
		return 0;
	}

	@Override
	public void serialize(B bea, DataOutputView out) throws IOException {
		bs.serialize(bea.getType(), out);
		BEA.getSerializerForType(bea.type).serialize(bea, out);
	}

	@Override
	public boolean canEqual(Object other) {
		return other instanceof BEASerializer;
	}

	@Override
	public boolean equals(Object other) {
		return other instanceof BEASerializer;
	}

	@Override
	public int hashCode() {
		return 0;
	}

	@Override
	public boolean isImmutableType() {
		return false;
	}

}
