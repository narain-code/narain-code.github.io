package com.king.rbea.backend.operators.scriptexecution;

import org.apache.flink.streaming.api.operators.Output;
import org.apache.flink.streaming.api.watermark.Watermark;
import org.apache.flink.streaming.runtime.streamrecord.LatencyMarker;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.apache.flink.util.OutputTag;

public class SyncedOutput<T> implements Output<T> {

	private final Output<T> out;

	public SyncedOutput(Output<T> out) {
		this.out = out;
	}

	@Override
	public synchronized void collect(T record) {
		out.collect(record);
	}

	@Override
	public synchronized void close() {
		out.close();
	}

	@Override
	public synchronized void emitWatermark(Watermark mark) {
		out.emitWatermark(mark);
	}

	@Override
	public synchronized <X> void collect(OutputTag<X> outputTag, StreamRecord<X> record) {
		out.collect(outputTag, record);
	}

	@Override
	public synchronized void emitLatencyMarker(LatencyMarker latencyMarker) {
		out.emitLatencyMarker(latencyMarker);
	}

}
