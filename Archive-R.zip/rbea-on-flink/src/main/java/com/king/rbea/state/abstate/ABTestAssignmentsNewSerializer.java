package com.king.rbea.state.abstate;

import java.io.IOException;
import java.util.HashMap;

import org.apache.flink.api.common.ExecutionConfig;
import org.apache.flink.api.common.typeinfo.BasicTypeInfo;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeutils.CompatibilityResult;
import org.apache.flink.api.common.typeutils.ParameterlessTypeSerializerConfig;
import org.apache.flink.api.common.typeutils.TypeSerializer;
import org.apache.flink.api.common.typeutils.TypeSerializerConfigSnapshot;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.core.memory.DataInputView;
import org.apache.flink.core.memory.DataOutputView;

import com.king.flink.utils.types.ArrayListSerializer;
import com.king.flink.utils.types.HashMapTypeInfo;

public class ABTestAssignmentsNewSerializer extends TypeSerializer<ABTestAssignmentsNew> {

	private static final long serialVersionUID = 1L;

	public static final TypeSerializer<HashMap<String, Tuple2<Integer, Integer>>> serializer = new HashMapTypeInfo<>(
			BasicTypeInfo.STRING_TYPE_INFO, new TypeHint<Tuple2<Integer, Integer>>() {}.getTypeInfo())
					.createSerializer(new ExecutionConfig());

	@Override
	public boolean canEqual(Object o) {
		return o instanceof ArrayListSerializer || o instanceof ABTestAssignmentsNewSerializer;
	}

	@Override
	public void serialize(ABTestAssignmentsNew ab, DataOutputView out) throws IOException {
		serializer.serialize(ab.state, out);
	}

	@Override
	public ABTestAssignmentsNew copy(ABTestAssignmentsNew ab) {
		return ab;
	}

	@Override
	public ABTestAssignmentsNew copy(ABTestAssignmentsNew ab, ABTestAssignmentsNew reuse) {
		return ab;
	}

	@Override
	public void copy(DataInputView in, DataOutputView out) throws IOException {
		serializer.copy(in, out);

	}

	@Override
	public ABTestAssignmentsNew createInstance() {
		return null;
	}

	@Override
	public ABTestAssignmentsNew deserialize(DataInputView in) throws IOException {
		return new ABTestAssignmentsNew(serializer.deserialize(in));
	}

	@Override
	public ABTestAssignmentsNew deserialize(ABTestAssignmentsNew reuse, DataInputView in) throws IOException {
		return deserialize(in);
	}

	@Override
	public TypeSerializer<ABTestAssignmentsNew> duplicate() {
		return this;
	}

	@Override
	public boolean equals(Object o) {
		return canEqual(o);
	}

	@Override
	public int getLength() {
		return 0;
	}

	@Override
	public int hashCode() {
		return 0;
	}

	@Override
	public boolean isImmutableType() {
		return true;
	}

	@Override
	public TypeSerializerConfigSnapshot snapshotConfiguration() {
		return new ParameterlessTypeSerializerConfig(this.getClass().getSimpleName());
	}

	@Override
	public CompatibilityResult<ABTestAssignmentsNew> ensureCompatibility(TypeSerializerConfigSnapshot arg0) {
		return CompatibilityResult.compatible();
	}
}
