package com.king.rbea.backend.utils;

import com.king.rbea.Registry;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.state.LocalState;
import com.king.rbea.state.StateDescriptor;

public final class DummyRegistry implements Registry {
	@Override
	public <T> StateDescriptor<T> registerState(LocalState<T> state) throws ProcessorException {
		return null;
	}

	@Override
	public void registerStateDependency(long rbeaJobId, String stateName) throws ProcessorException {}
}