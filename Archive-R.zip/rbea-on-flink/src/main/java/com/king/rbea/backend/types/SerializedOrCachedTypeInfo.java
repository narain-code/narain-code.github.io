package com.king.rbea.backend.types;

import java.io.IOException;

import org.apache.flink.api.common.ExecutionConfig;
import org.apache.flink.api.common.typeinfo.PrimitiveArrayTypeInfo;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeutils.TypeSerializer;
import org.apache.flink.api.common.typeutils.base.TypeSerializerSingleton;
import org.apache.flink.api.common.typeutils.base.array.BytePrimitiveArraySerializer;
import org.apache.flink.core.memory.DataInputView;
import org.apache.flink.core.memory.DataOutputView;

public class SerializedOrCachedTypeInfo extends TypeInformation<SerializedOrCached> {

	private static final long serialVersionUID = 1L;

	@Override
	public TypeSerializer<SerializedOrCached> createSerializer(ExecutionConfig arg0) {
		return new SerializedOrCachedSerializer();
	}

	@Override
	public Class<SerializedOrCached> getTypeClass() {
		return SerializedOrCached.class;
	}

	@Override
	public boolean canEqual(Object o) {
		return o instanceof SerializedOrCachedTypeInfo
				|| PrimitiveArrayTypeInfo.BYTE_PRIMITIVE_ARRAY_TYPE_INFO.canEqual(o);
	}

	@Override
	public boolean equals(Object o) {
		return o instanceof SerializedOrCachedTypeInfo
				|| PrimitiveArrayTypeInfo.BYTE_PRIMITIVE_ARRAY_TYPE_INFO.equals(o);
	}

	@Override
	public int getArity() {
		return 0;
	}

	@Override
	public int getTotalFields() {
		return 0;
	}

	@Override
	public int hashCode() {
		return 0;
	}

	@Override
	public boolean isBasicType() {
		return PrimitiveArrayTypeInfo.BYTE_PRIMITIVE_ARRAY_TYPE_INFO.isBasicType();
	}

	@Override
	public boolean isKeyType() {
		return PrimitiveArrayTypeInfo.BYTE_PRIMITIVE_ARRAY_TYPE_INFO.isKeyType();
	}

	@Override
	public boolean isTupleType() {
		return false;
	}

	@Override
	public String toString() {
		return "SerialiazedValueTypeInfo";
	}

	public static class SerializedOrCachedSerializer extends TypeSerializerSingleton<SerializedOrCached> {

		private static final long serialVersionUID = 1L;

		private final TypeSerializer<byte[]> bs = BytePrimitiveArraySerializer.INSTANCE;

		@Override
		public SerializedOrCached copy(SerializedOrCached sv) {
			return sv;
		}

		@Override
		public SerializedOrCached copy(SerializedOrCached sv, SerializedOrCached reuse) {
			return sv;
		}

		@Override
		public SerializedOrCached createInstance() {
			return null;
		}

		@Override
		public SerializedOrCached deserialize(DataInputView in) throws IOException {
			return new SerializedOrCached(bs.deserialize(in));
		}

		@Override
		public SerializedOrCached deserialize(SerializedOrCached reuse, DataInputView in) throws IOException {
			return deserialize(in);
		}

		@Override
		public void serialize(SerializedOrCached sv, DataOutputView out) throws IOException {
			bs.serialize(sv.getBytes(), out);
		}

		@Override
		public boolean canEqual(Object o) {
			return o instanceof SerializedOrCachedSerializer || bs.canEqual(o);
		}

		@Override
		public void copy(DataInputView in, DataOutputView out) throws IOException {
			bs.copy(in, out);
		}

		@Override
		public boolean equals(Object o) {
			return o instanceof SerializedOrCachedSerializer || bs.equals(o);
		}

		@Override
		public int getLength() {
			return 0;
		}

		@Override
		public int hashCode() {
			return 0;
		}

		@Override
		public boolean isImmutableType() {
			return false;
		}

	}

}
