package com.king.rbea.backend.operators.jobinfo;

import org.apache.flink.streaming.api.functions.source.SourceFunction;

public final class SleepingSource implements SourceFunction<Boolean> {
	private static final long serialVersionUID = 1L;
	volatile boolean isRunning;
	private int secs;

	public SleepingSource(int secs) {
		this.secs = secs;
	}

	@Override
	public void cancel() {
		isRunning = false;
	}

	@Override
	public void run(org.apache.flink.streaming.api.functions.source.SourceFunction.SourceContext<Boolean> ctx)
			throws Exception {
		isRunning = true;
		int i = 0;

		while (isRunning && i++ < secs) {
			Thread.sleep(1000);
			synchronized (ctx.getCheckpointLock()) {
				ctx.collect(true);
			}
		}
	}
}