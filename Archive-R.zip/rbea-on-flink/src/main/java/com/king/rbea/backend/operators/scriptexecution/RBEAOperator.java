package com.king.rbea.backend.operators.scriptexecution;

import static com.king.rbea.backend.utils.BackendConstants.BACKEND_TOPIC;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.function.Consumer;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.api.common.state.ListState;
import org.apache.flink.api.common.state.ListStateDescriptor;
import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.api.common.typeinfo.BasicTypeInfo;
import org.apache.flink.api.common.typeinfo.PrimitiveArrayTypeInfo;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeutils.TypeSerializer;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.typeutils.EitherTypeInfo;
import org.apache.flink.api.java.typeutils.ResultTypeQueryable;
import org.apache.flink.api.java.typeutils.TypeExtractor;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.contrib.streaming.state.RocksDBKeyedStateBackend;
import org.apache.flink.runtime.state.StateInitializationContext;
import org.apache.flink.runtime.state.StateSnapshotContext;
import org.apache.flink.streaming.api.operators.AbstractStreamOperator;
import org.apache.flink.streaming.api.operators.HeapInternalTimerService;
import org.apache.flink.streaming.api.operators.TimestampedCollector;
import org.apache.flink.streaming.api.operators.TwoInputStreamOperator;
import org.apache.flink.streaming.api.watermark.Watermark;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.apache.flink.types.Either;
import org.apache.flink.util.InstantiationUtil;
import org.rocksdb.DBOptions;
import org.rocksdb.Statistics;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Ticker;
import com.king.event.Event;
import com.king.flink.utils.Unchecked;
import com.king.flink.utils.Unchecked.ThrowingRunnable;
import com.king.flink.utils.types.HashMapTypeInfo;
import com.king.kgk.SCClientStart;
import com.king.rbea.Context;
import com.king.rbea.backend.operators.FailureHandlingSchema;
import com.king.rbea.backend.operators.scriptexecution.metrics.RBEAMetricsTracker;
import com.king.rbea.backend.operators.scriptexecution.metrics.Watch;
import com.king.rbea.backend.types.EventWrapper;
import com.king.rbea.backend.types.SerializedOrCached;
import com.king.rbea.backend.types.SerializedOrCachedTypeInfo;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.backend.types.bea.BEATypeInfo;
import com.king.rbea.backend.utils.BackendConstants;
import com.king.rbea.backend.utils.BlockingExecutor;
import com.king.rbea.backend.utils.ContextRunner;
import com.king.rbea.configuration.Configuration;
import com.king.rbea.configuration.processor.Deployment;
import com.king.rbea.configuration.processor.DeploymentWithFields;
import com.king.rbea.configuration.processor.Failure;
import com.king.rbea.configuration.processor.JobConfig;
import com.king.rbea.configuration.processor.Notification;
import com.king.rbea.configuration.processor.ProcessorInfo;
import com.king.rbea.configuration.processor.Removal;
import com.king.rbea.exceptions.BackendException;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.scripts.ProcessorFactory;
import com.king.rbea.scripts.proxy.AsyncMethodCall;
import com.king.rbea.scripts.proxy.ProxyExecutorFactory;
import com.king.rbea.state.CachingState;
import com.king.rbea.state.abstate.ABTestBaseProcessor;

/**
 * A Flink operator that runs the RBEA jobs.
 * <p>
 * A {@link TwoInputStreamOperator} that receives {@link EventWrapper} and
 * {@link Configuration} from Kafka and outputs control events
 * ({@link Configuration} or {@link BEA}).
 */
public class RBEAOperator extends AbstractStreamOperator<Either<BEA, Configuration>>
		implements TwoInputStreamOperator<EventWrapper, Configuration, Either<BEA, Configuration>>,
		ResultTypeQueryable<Either<BEA, Configuration>> {

	protected static final Logger LOG = LoggerFactory.getLogger(RBEAOperator.class);
	private static final long serialVersionUID = 1L;

	// State objects
	private transient ProcessorFactory processorFactory;

	// User/Base fields
	private transient CachingState<HashMap<Short, SerializedOrCached>> baseFieldStates;
	private transient CachingState<HashMap<Short, byte[]>> userFieldStates;

	// Broadcast state of deployment / field metadata
	private transient ListState<Tuple2<Short, Map<Short, String>>> broadcastFieldState;
	private transient ListState<List<Tuple2<byte[], byte[]>>> broadcastDeploymentState;
	private transient ListState<HashMap<Long, String>> broadcastBaseProcConfigState;

	public DeploymentManager deploymentManager;

	// Convenience objects for handling the different parts of an RBEA program
	public final Processors processors;
	private final List<Deployment> baseProcDeployments;

	public final Fields fields;

	private transient UserSessionManager userSessionManager;
	private transient ContextManager contextManager;

	// Safeguard against interleaving context execution
	private boolean contextExecution = false;
	private States currentStates;

	public transient RBEAMetricsTracker metrics;

	// Misc fields
	public transient TimestampedCollector<Either<BEA, Configuration>> collector;
	protected final ParameterTool params;
	private long currentWatermark = 0;

	// We need to disable some functionality that is unsupported in the testing
	// harness
	private boolean testHarnessRun = false;
	private final String backendId;

	private transient Ticker ticker;

	private transient ExecutorService asyncExecutor;

	private final ValueStateDescriptor<HashMap<Short, SerializedOrCached>> baseStateDescriptor;

	private final ValueStateDescriptor<HashMap<Short, byte[]>> userStateDescriptor;

	public RBEAOperator(List<Deployment> baseProcs, ParameterTool params) {
		this.params = params;
		this.processors = new Processors();
		this.fields = new Fields();

		this.baseProcDeployments = baseProcs;

		Set<Long> baseProcIds = new HashSet<>();
		for (Deployment d : baseProcs) {
			long processorId = d.getProcessorId();
			if (!baseProcIds.add(processorId)) {
				throw new RuntimeException("Duplicate base script id: " + processorId);
			} else if (processorId <= Integer.MAX_VALUE) {
				throw new RuntimeException("Base script id must be greater than " + Integer.MAX_VALUE);
			}
		}
		backendId = params.get(BackendConstants.BACKEND_ID, params.get(BACKEND_TOPIC, "MISSING"));

		baseStateDescriptor = new ValueStateDescriptor<>(
				BackendConstants.BASE_FIELDS_NAME, new HashMapTypeInfo<>(
						BasicTypeInfo.SHORT_TYPE_INFO,
						new SerializedOrCachedTypeInfo()));

		userStateDescriptor = new ValueStateDescriptor<>(
				params.get(BackendConstants.DEPLOYMENT_STATE_NAME, "") + BackendConstants.USER_FIELDS_NAME,
				new HashMapTypeInfo<>(
						BasicTypeInfo.SHORT_TYPE_INFO,
						PrimitiveArrayTypeInfo.BYTE_PRIMITIVE_ARRAY_TYPE_INFO));
	}

	public void waitForAsyncTasks() {
		if (asyncExecutor != null && asyncExecutor instanceof BlockingExecutor) {
			((BlockingExecutor) asyncExecutor).waitForAllTasks();
		}
	}

	public Ticker getTicker() {
		return ticker == null ? Ticker.systemTicker() : ticker;
	}

	public void setTicker(Ticker ticker) {
		this.ticker = ticker;
	}

	public String getEventTopic() {
		return backendId;
	}

	/**
	 * This is the main processing loop. This is a performance critical code-path,
	 * everything inside should be reasonably fast.
	 */
	@Override
	public void processElement1(StreamRecord<EventWrapper> record) throws BackendException {
		metrics.startTotalProcessTimeMeasurement();
		EventWrapper eventWrapper = record.getValue();
		Event event = eventWrapper.getEvent();
		Optional<Long> cuidOption = eventWrapper.getCoreUserId();

		// This also signals backfill events
		boolean invalidRecordTime = record.getTimestamp() == Long.MAX_VALUE;
		if (invalidRecordTime) {
			record.setTimestamp(System.currentTimeMillis());
		}
		collector.setTimestamp(record);

		runWithContext(cuidOption, event, invalidRecordTime, ctx -> {
			// Call processEvent methods + handle failures
			metrics.processWatch.restart();
			handleProcessorErrors(processors.runAllProcessEvent(event, ctx, metrics), ctx);
			metrics.processWatch.stopAndRecord();

			// Until further improvements, execute state cleanup logic on client starts
			if (currentStates != null && SCClientStart.process(event) != null) {
				currentStates.cleanupStates();
			}

			return null;
		});

		// Again sessions only make sense for events with proper core user id
		if (cuidOption.isPresent()) {
			userSessionManager.extendSession(eventWrapper.getEvent(), currentWatermark);
		}

		long now = System.currentTimeMillis();
		metrics.eventsProcessedPerMin.increment(now);
		if (!invalidRecordTime) {
			metrics.processLatencyHistogram.update(now - eventWrapper.getTimestamp());
		}

		metrics.conditionallyCollectRuntimeStatistics(collector);
		metrics.stopAndRecordTotalProcessTimeMeasurement();
	}

	/**
	 * Method executed for every configuration message (both processor and backend
	 * related). Not performance critical as long as it's not incredibly slow.
	 */
	@Override
	public void processElement2(StreamRecord<Configuration> record) throws BackendException {
		Configuration conf = record.getValue();
		if (!(conf instanceof ProcessorInfo)) {
			// Disregard everything that is not processor related for now
			return;
		}

		collector.setTimestamp(record);

		// We also forward any proc info received for deployed processors (serves as a
		// filter for the job summary operator)
		ProcessorInfo info = (ProcessorInfo) conf;
		if (Processors.isBaseProcessor(info.getProcessorId()) && !(info instanceof JobConfig)) {
			LOG.info("Ignoring proc info with id > than integer.maxint: {}", info);
			return;
		}
		LOG.info("received "+info);
		Optional<ProcessorException> processorExceptionOpt = deploymentManager.applyProcessorInfo(info);
		if (processorExceptionOpt.isPresent()) {
			// Handle errors that happened while deploying/updating processors
			ProcessorException err = processorExceptionOpt.get();

			// For failed test deployments, delete the state. Never needed afterwards.
			boolean deleteState = info instanceof DeploymentWithFields
					&& ((DeploymentWithFields) info).getDeployment().isTest();
			try {
				handleProcessorError(err, null, deleteState,
						info instanceof DeploymentWithFields ? (DeploymentWithFields) info : null);
			} catch (BackendException e) {
				Unchecked.throwSilently(e);
			}
			// Do not collect DeploymentWithFields, the above handleProcessorError() call
			// has already collected a Failure
			if (!info.isPropagated()
					&& (info instanceof Removal || (!(info instanceof DeploymentWithFields)
							&& deploymentManager.getDeployedProc(info.getProcessorId()) != null))) {
				collector.collect(Either.Right(info));
			}
		} else {
			if (!info.isPropagated()
					&& (info instanceof Removal || info instanceof DeploymentWithFields
							|| deploymentManager.getDeployedProc(info.getProcessorId()) != null)) {
				LOG.info("Collecting: {}", info);
				collector.collect(Either.Right(info));
			}
		}

		handleTestDeployment(info);
	}

	/**
	 * Handles undeploy of a test deployment in case {@code info} is a test
	 * Deployment.
	 *
	 * @param info
	 *            the proc info
	 *
	 * @throws BackendException
	 */
	private void handleTestDeployment(ProcessorInfo info) throws BackendException {
		Optional<Removal> removalOpt = createTestDeploymentRemoval(info);
		if (!removalOpt.isPresent()) {
			return;
		}

		Removal removal = removalOpt.get();
		deploymentManager.applyProcessorInfo(removal);
		collector.collect(Either.Right(removal));
	}

	/**
	 * Creates a Removal in case of a test deployment.
	 *
	 * @param info
	 *            the proc info
	 * @return the instance or empty
	 */
	Optional<Removal> createTestDeploymentRemoval(ProcessorInfo info) {
		if (!(info instanceof DeploymentWithFields)) {
			return Optional.empty();
		} else {
			DeploymentWithFields deploymentWithFields = (DeploymentWithFields) info;
			if (!deploymentWithFields.getDeployment().isTest()) {
				return Optional.empty();
			}
			return Optional
					.of(new Removal(info.getProcessorId(), deploymentWithFields.getDeployment().getStartTime()));
		}
	}

	@Override
	public void processWatermark(Watermark mark) throws Exception {
		this.currentWatermark = mark.getTimestamp();
		super.processWatermark(mark);
	}

	@Override
	public void open() throws Exception {
		super.open();
		boolean asyncEnabled = params.getBoolean(BackendConstants.ENABLE_ASYNC_EXECUTION, true);
		if (asyncEnabled) {
			output = new SyncedOutput<>(output);
			asyncExecutor = new BlockingExecutor(
					params.getInt(BackendConstants.NUM_ASYNC_THREADS, 8),
					params.getInt(BackendConstants.ASYNC_QUEUE_SIZE, 8),
					Unchecked.biconsumer(
							(runnable, err) -> handleAsyncError(((AsyncMethodCall) runnable).getProcessorId(), err)));
		} else {
			asyncExecutor = null;
		}
		collector = new TimestampedCollector<>(output);

		processorFactory = ProxyExecutorFactory.builder().build();
		metrics = new RBEAMetricsTracker(getRuntimeContext().getIndexOfThisSubtask(),
				getRuntimeContext().getMetricGroup(), getTicker(), processors, fields, getRocksStats());

		Random rnd = new Random();

		baseFieldStates = wrapWithCache(
				getRuntimeContext().getState(baseStateDescriptor),
				metrics.baseStateCacheHitRate::add,
				metrics.baseStateReadWatch,
				metrics.baseStateWriteWatch,
				map -> {
					if (rnd.nextDouble() < 0.01) {
						int totalBytes = 0;
						totalBytes += map.size() * 2;
						for (SerializedOrCached sOrC : map.values()) {
							totalBytes += sOrC.getBytesSize();
						}
						metrics.baseStateSize.add(totalBytes / 1024.0);
					}
				});

		userFieldStates = wrapWithCache(
				getRuntimeContext()
						.getState(userStateDescriptor),
				metrics.userStateCacheHitRate::add,
				metrics.userStateReadWatch,
				metrics.userStateWriteWatch,
				map -> {
					if (rnd.nextDouble() < 0.01) {
						int totalBytes = 0;
						totalBytes += map.size() * 2;
						for (byte[] bytes : map.values()) {
							totalBytes += bytes.length;
						}
						metrics.userStateSize.add(totalBytes / 1024.0);
					}
				});

		FlinkTimers timers = new FlinkTimers(this);
		contextManager = new ContextManager(fields, processors, collector, timers,
				getRuntimeContext().getIndexOfThisSubtask(), params);
		boolean isBatch = params.getBoolean("BATCHRUN");
		userSessionManager = new UserSessionManager(this,isBatch);

		deploymentManager = new DeploymentManager(processors, fields,
				getRuntimeContext().getIndexOfThisSubtask(), f -> runWithContext(Optional.empty(), null, f),
				getTicker(), asyncExecutor, processorFactory);

		restoreSharedFieldState();

		HashMap<Long, String> baseConfState = mergeBaseConfState();

		for (Deployment d : baseProcDeployments) {
			DeploymentWithFields baseDep = new DeploymentWithFields(d, Collections.emptyMap());
			if (baseConfState.containsKey(d.getProcessorId())) {
				d.withInitialConfig(baseConfState.get(d.getProcessorId()));
			}
			Optional<ProcessorException> err = deploymentManager.applyProcessorInfo(baseDep);

			err.ifPresent(pe -> {
				try {
					handleProcessorError(pe, null);
				} catch (BackendException e) {
					Unchecked.throwSilently(e);
				}
			});
		}

		restoreSharedDeploymentState();
	}

	private StateCleaner baseStateCleaner;
	private StateCleaner userStateCleaner;

	private void resetStateCleaner() {
		try {
			Method method = RocksDBKeyedStateBackend.class.getMethod("setSavpointStateTransformer", String.class,
					MapFunction.class);

			baseStateCleaner = new StateCleaner(fields.getActiveIds());
			userStateCleaner = new StateCleaner(fields.getActiveIds());
			method.invoke(getKeyedStateBackend(), baseStateDescriptor.getName(), baseStateCleaner);
			method.invoke(getKeyedStateBackend(), userStateDescriptor.getName(), userStateCleaner);
		} catch (Throwable e) {
			LOG.error("Error while trying to set state cleaner", e);
		}
	}

	private void handleAsyncError(Long pid, Throwable err) throws BackendException {
		if (pid == BackendConstants.DUMMY_PROC_ID) {
			Unchecked.throwSilently(new BackendException(err));
		} else {
			if (err instanceof BackendException) {
				Unchecked.throwSilently(err);
			} else {
				ProcessorException pe;
				if (err instanceof ProcessorException) {
					pe = (ProcessorException) err;
					pe.setProcessorId(pid);
				} else {
					pe = new ProcessorException(pid, err);
				}

				RBEAOperator.LOG.error(" Async operation failed for {} with: {}", pid,
						ExceptionUtils.getFullStackTrace(err));
				handleProcessorError(pe, null);
			}

		}
	}

	private Statistics getRocksStats() {
		try {
			Field optionsField = RocksDBKeyedStateBackend.class.getDeclaredField("dbOptions");
			optionsField.setAccessible(true);
			return ((DBOptions) optionsField.get(getKeyedStateBackend())).statisticsPtr();
		} catch (Throwable t) {
			return null;
		}
	}

	@Override
	public void snapshotState(StateSnapshotContext context) throws Exception {
		waitForAsyncTasks();
		if (params.getBoolean(BackendConstants.CLEAN_STATE_ON_SAVEPOINT, false)) {
			resetStateCleaner();
		}
		// Before performing the checkpoint operation, we update the state and flush
		// caches for consistency
		updateBroadcastState();
		long start = System.nanoTime();
		((CachingState<?>) userFieldStates).writeAllToDb();
		((CachingState<?>) baseFieldStates).writeAllToDb();
		long afterCache = System.nanoTime();
		super.snapshotState(context);

		long end = System.nanoTime();
		long superCall = (end - afterCache) / 1_000_000_000;
		long cachewrite = (afterCache - start) / 1_000_000_000;
		LOG.info(
				"Subtask {} spent {} s flushing the cache and {} s in super.snapshotState and. Total number of timers: {}",
				getRuntimeContext().getIndexOfThisSubtask(),
				cachewrite,
				superCall,
				((HeapInternalTimerService<?, ?>) contextManager.flinkTimers.newTimerService).numEventTimeTimers());
	}

	@Override
	public void initializeState(StateInitializationContext context) throws Exception {
		super.initializeState(context);

		if (testHarnessRun) {
			return;
		}

		broadcastFieldState = context.getOperatorStateStore()
				.getUnionListState(
						new ListStateDescriptor<>("NewFieldState",
								new TypeHint<Tuple2<Short, Map<Short, String>>>() {}.getTypeInfo()));

		broadcastDeploymentState = context.getOperatorStateStore()
				.getUnionListState(
						new ListStateDescriptor<>(
								params.get(BackendConstants.DEPLOYMENT_STATE_NAME, "DeployedProcState"),
								new TypeHint<List<Tuple2<byte[], byte[]>>>() {}.getTypeInfo()));

		broadcastBaseProcConfigState = context.getOperatorStateStore()
				.getUnionListState(
						new ListStateDescriptor<>(
								"BaseProcConfigState",
								new HashMapTypeInfo<>(BasicTypeInfo.LONG_TYPE_INFO, BasicTypeInfo.STRING_TYPE_INFO)));
	}

	/**
	 * Update the state that will stored only once across all nodes, that is:
	 * Deployed jobs, some metadata about fields.
	 *
	 * @throws BackendException
	 */
	private void updateBroadcastState() throws BackendException {
		broadcastDeploymentState.clear();
		broadcastFieldState.clear();
		broadcastBaseProcConfigState.clear();
		if (getRuntimeContext().getIndexOfThisSubtask() == 0) {
			try {
				List<Tuple2<byte[], byte[]>> procState = new ArrayList<>();
				HashMap<Long, String> baseConfState = new HashMap<>();
				for (DeploymentWithFields dep : deploymentManager.getDeployedProcs()) {
					if (!Processors.isBaseProcessor(dep.getProcessorId())) {
						procState.add(dep.createCheckpoint());
					} else {
						dep.getDeployment().getJobConfig()
								.ifPresent(conf -> baseConfState.put(dep.getProcessorId(), conf));
					}
				}

				broadcastDeploymentState.add(procState);
				broadcastFieldState.add(fields.snapshotState());
				broadcastBaseProcConfigState.add(baseConfState);
			} catch (Exception e) {
				throw new BackendException(e.getMessage());
			}
		}
	}

	private HashMap<Long, String> mergeBaseConfState() throws Exception, BackendException {
		if (testHarnessRun) {
			return new HashMap<>();
		}
		Iterator<HashMap<Long, String>> procStateIt = broadcastBaseProcConfigState.get().iterator();
		if (procStateIt.hasNext()) {
			return procStateIt.next();
		} else {
			return new HashMap<>();
		}
	}

	private void restoreSharedDeploymentState() throws Exception, BackendException {
		if (testHarnessRun) {
			return;
		}
		Iterator<List<Tuple2<byte[], byte[]>>> procStateIt = broadcastDeploymentState.get().iterator();
		if (procStateIt.hasNext()) {
			List<Tuple2<byte[], byte[]>> procState = procStateIt.next();

			for (Tuple2<byte[], byte[]> serializedDep : procState) {
				deploymentManager.applyProcessorInfo(DeploymentWithFields.restoreFromCheckpoint(serializedDep))
						.ifPresent(pe -> {
							try {
								handleProcessorError(pe, null);
							} catch (BackendException e) {
								Unchecked.throwSilently(e);
							}
						});
			}

		}
	}

	private void restoreSharedFieldState() throws Exception {
		if (testHarnessRun) {
			return;
		}
		Iterator<Tuple2<Short, Map<Short, String>>> newStateIt = broadcastFieldState.get().iterator();

		if (newStateIt.hasNext()) {
			Tuple2<Short, Map<Short, String>> state = newStateIt.next();

			Short nbid = state.f0;
			Map<Short, String> fieldIdMapping = new HashMap<>(state.f1);
			if (params.has(BackendConstants.AB_STATE_ID)) {
				Iterator<Entry<Short, String>> iterator = fieldIdMapping.entrySet().iterator();
				while (iterator.hasNext()) {
					if (iterator.next().getValue().equals(ABTestBaseProcessor.AB_ASSIGNMENTS_FIELD_NAME)) {
						iterator.remove();
					}
				}
				fieldIdMapping.put(params.getShort(BackendConstants.AB_STATE_ID),
						ABTestBaseProcessor.AB_ASSIGNMENTS_FIELD_NAME);
			}

			RBEAOperator.LOG.info("Restoring field data: ");
			RBEAOperator.LOG.info("Next base id: " + nbid);
			RBEAOperator.LOG.info("Field names: " + fieldIdMapping);
			fields.initializeFromState(nbid, fieldIdMapping);
		} else {
			fields.initializeClean();
		}

	}

	/**
	 * Execute the provided function making sure that the context is initialized
	 * correctly and that execution is not interleaving with other user.
	 *
	 * @throws BackendException
	 */
	public List<ProcessorException> runWithContext(Optional<Long> cuidOption, Event event, ContextRunner fun)
			throws BackendException {
		return runWithContext(cuidOption, event, false, fun);
	}

	/**
	 * Execute the provided function making sure that the context is initialized
	 * correctly and that execution is not interleaving with other user.
	 */
	public List<ProcessorException> runWithContext(Optional<Long> cuidOption, Event event, boolean bypassCache,
			ContextRunner fun) throws BackendException {

		if (contextExecution) {
			throw new BackendException("Interleaving context execution. This is surely a bug.");
		} else {
			contextExecution = true;
		}

		// States object will be null for events without core user id
		currentStates = cuidOption.isPresent()
				? new States(fields, cuidOption.get(),
						bypassCache ? baseFieldStates.bypassCache() : baseFieldStates,
						bypassCache ? userFieldStates.bypassCache() : userFieldStates,
						metrics)
				: null;

		contextManager.setForCurrentUser(cuidOption, currentStates, event);
		List<ProcessorException> exceptions = fun.execute(contextManager);

		// All potential state modifications have been at this point so we
		// update the state if necessary.
		if (currentStates != null) {
			currentStates.update();
			currentStates = null;
		}

		contextExecution = false;
		return exceptions;
	}

	/**
	 * Removes a list of faulty processors using the exceptions.
	 */
	protected void handleProcessorErrors(List<ProcessorException> faultyProcessors, ContextManager ctxMgr)
			throws BackendException {
		for (ProcessorException pe : faultyProcessors) {
			handleProcessorError(pe, ctxMgr);
		}
	}

	/**
	 * Calls
	 * {@link #handleProcessorError(ProcessorException, ContextManager, boolean)}
	 * with {@code deleteState} false.
	 */
	protected void handleProcessorError(ProcessorException pe, ContextManager ctxMgr) throws BackendException {
		handleProcessorError(pe, ctxMgr, false);
	}

	/**
	 * Removes a faulty processor and sends a Failure downstream
	 */
	protected void handleProcessorError(ProcessorException pe, ContextManager ctxMgr, boolean deleteState)
			throws BackendException {
		handleProcessorError(pe, ctxMgr, deleteState, null);
	}

	/**
	 * Removes a faulty processor and sends a Failure downstream
	 */
	protected void handleProcessorError(ProcessorException pe, ContextManager ctxMgr, boolean deleteState,
			DeploymentWithFields dep)
			throws BackendException {
		long pid = pe.getProcessorId();
		boolean base = Processors.isBaseProcessor(pid);
		if (pe.isRecoverable() && deploymentManager.trackFailure(pid)) {
			LOG.error("Ignoring recoverable error for {}, for now...", pe.getProcessorId());

			if (!base) {
				String notificationMsg = ExceptionUtils.getFullStackTrace(pe);
				if (ctxMgr != null && ctxMgr.event != null) {
					notificationMsg = FailureHandlingSchema.eventFormat.format(ctxMgr.event) + "\n" + notificationMsg;
				}
				collector.collect(Either.Right(new Notification(pid, notificationMsg)));
			}

			Context ctx;
			if (ctxMgr != null) {
				ctxMgr.setProcessorId(pid);
				ctx = ctxMgr.getContext();
			} else {
				ctx = new FlinkContext(-1, false, collector, null, pid, null, null,
						getRuntimeContext().getIndexOfThisSubtask(), null, null);
			}

			run(pid, "OnError", true,
					() -> processors.getForId(pe.getProcessorId()).f1.onError(pe, ctx))
							.ifPresent(err -> {
								try {
									handleProcessorError(err, ctxMgr);
								} catch (BackendException e) {
									Unchecked.throwSilently(e);
								}
							});
		} else if (base) {
			if (ctxMgr != null) {
				LOG.error("Base proc failed on event: {}", ctxMgr.getContext().getEvent());
			}
			//throw new BackendException(pe);
		} else {
			DeploymentWithFields df = deploymentManager.removeProcessor(pid, deleteState);
			if (df == null) {
				df = dep;
			}
			String scriptText = df == null ? null : df.getDeployment().getScriptText().orElse(null);
			Failure failure = new Failure(pid, pe, scriptText, System.currentTimeMillis());
			if (dep != null) {
				failure.withDeployment(dep.getDeployment());
			}
			collector.collect(Either.Right(failure));
		}
	}

	/**
	 * Helper method for creating cached states based on the specified cache size
	 * params from the config
	 */
	protected <T> CachingState<T> wrapWithCache(ValueState<T> state, Consumer<Boolean> cacheHitTracker, Watch getWatch,
			Watch writeWatch, Consumer<T> stateSizeTracker) {
		int cacheSize = params.getInt(BackendConstants.STATE_CACHE_SIZE);

		return new CachingState<>(cacheSize, state, this, cacheHitTracker, getWatch, writeWatch, stateSizeTracker);
	}

	/**
	 * Helper method for executing user code with possible exceptions. Catches and
	 * separates processor and backend (that should cause the streaming job to fail)
	 * exceptions.
	 */
	public static Optional<ProcessorException> run(long pid, String operationForLog, boolean recoverable,
			ThrowingRunnable runnable) throws BackendException {
		try {
			runnable.run();
			return Optional.empty();
		} catch (BackendException bex) {
			throw bex;
		} catch (ProcessorException pe) {
			RBEAOperator.LOG.error(" {} failed for {} with: {}", operationForLog, pid,
					ExceptionUtils.getFullStackTrace(pe));
			pe.setProcessorId(pid);
			if (!recoverable) {
				pe.setNotRecoverable();
			}
			return Optional.of(pe);
		} catch (Throwable ex) {
			// We use the dummy proc id to mark code that is executed on behalf of the
			// backend, such as base state updates
			if (pid == BackendConstants.DUMMY_PROC_ID) {
				throw new BackendException(ex);
			} else {
				RBEAOperator.LOG.error(" {} failed for {} with: {}", operationForLog, pid,
						ExceptionUtils.getFullStackTrace(ex));
				ProcessorException pe = new ProcessorException(pid, ex);
				if (!recoverable) {
					pe.setNotRecoverable();
				}
				return Optional.of(pe);
			}
		}
	}

	@Override
	public TypeInformation<Either<BEA, Configuration>> getProducedType() {
		return new EitherTypeInfo<>(new BEATypeInfo<>(), TypeExtractor.getForClass(Configuration.class));
	}

	public void enableTestMode() {
		testHarnessRun = true;
	}

	private class StateCleaner extends RichMapFunction<byte[], byte[]> {

		private static final long serialVersionUID = 1L;
		final TypeSerializer<HashMap<Short, byte[]>> serializer = userStateDescriptor.getSerializer();
		final Set<Short> activeIds;

		long totalStates = 0;
		long totalBytes = 0;
		long totalUsers = 0;

		public StateCleaner(Set<Short> activeIds) {
			this.activeIds = new HashSet<>(activeIds);
		}

		@Override
		public void close() {
			LOG.info("State cleanup stats - TotalUsers: {} TotalStates: {} TotalBytes: {}", totalUsers, totalStates,
					totalBytes);
		}

		@Override
		public byte[] map(byte[] value) throws Exception {
			HashMap<Short, byte[]> states = InstantiationUtil.deserializeFromByteArray(serializer, value);
			int initialSize = states.size();
			Iterator<Entry<Short, byte[]>> it = states.entrySet().iterator();
			while (it.hasNext()) {
				Entry<Short, byte[]> next = it.next();
				if (!activeIds.contains(next.getKey())) {
					totalStates++;
					totalBytes += next.getValue().length;
					it.remove();
				}
			}
			if (states.size() == initialSize) {
				return value;
			} else {
				totalUsers++;
				return InstantiationUtil.serializeToByteArray(serializer, states);
			}
		}

	}
}
