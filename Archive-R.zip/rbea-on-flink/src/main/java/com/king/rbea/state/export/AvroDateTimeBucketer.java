package com.king.rbea.state.export;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.avro.generic.GenericRecord;
import org.apache.flink.streaming.connectors.fs.Clock;
import org.apache.flink.streaming.connectors.fs.bucketing.Bucketer;
import org.apache.hadoop.fs.Path;

public class AvroDateTimeBucketer implements Bucketer<GenericRecord> {

	private static final long serialVersionUID = 1L;

	private static final String DEFAULT_FORMAT_STRING = "yyyy-MM-dd--HH-mm";

	private final String formatString;

	private transient SimpleDateFormat dateFormatter;

	private final long msGranularity;

	public AvroDateTimeBucketer(int minuteGranularity) {
		this(DEFAULT_FORMAT_STRING, minuteGranularity);
	}

	public AvroDateTimeBucketer(String formatString, int minuteGranularity) {
		this.formatString = formatString;
		this.msGranularity = minuteGranularity * 1000 * 60;
		this.dateFormatter = new SimpleDateFormat(formatString);
	}

	private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
		in.defaultReadObject();
		this.dateFormatter = new SimpleDateFormat(formatString);
	}

	@Override
	public Path getBucketPath(Clock clock, Path basePath, GenericRecord record) {
		long now = clock.currentTimeMillis();
		long adjustedToGranularity = now - (now % msGranularity);
		String newDateTimeString = dateFormatter.format(new Date(adjustedToGranularity));
		String[] split = newDateTimeString.split("--");
		return new Path(basePath + "/" + record.getSchema().getFullName() + "/dt=" + split[0] + "/bucket=" + split[1]);
	}

	@Override
	public String toString() {
		return "AvroDateTimeBucketer{" +
				"formatString='" + formatString + '\'' +
				'}';
	}
}