package com.king.rbea.backend.types.bea;

import java.util.Arrays;

import java.util.Optional;

import org.apache.commons.lang3.Validate;
import org.apache.flink.api.common.ExecutionConfig;
import org.apache.flink.api.common.typeutils.TypeSerializer;
import org.apache.flink.api.java.typeutils.TypeExtractor;

import com.king.rbea.backend.utils.BackendConstants;

/**
 * {@code KafkaOutput} is a BEA that represent publishing to Kafka.
 */
public class KafkaOutput extends BEA {
	private static final long serialVersionUID = 1L;
	
	public static final TypeSerializer<KafkaOutput> serializer = TypeExtractor.getForClass(KafkaOutput.class)
			.createSerializer(new ExecutionConfig());

	public String topic;
	public byte[] key;
	public byte[] bytes;

	/**
	 * Constructs a new instance.
	 * 
	 * @param procId the processor id
	 * @param topic  the Kafka topic
	 * @param key    the Kafka message key
	 * @param bytes  the Kafka message bytes
	 */
	public KafkaOutput(long procId, String topic, byte[] key, byte[] bytes) {
		super(BackendConstants.BEA_KAFKA_OUTPUT_TYPE, procId);
		this.topic = Validate.notNull(topic);
		this.key = key;
		this.bytes = Validate.notNull(bytes);
	}

	public KafkaOutput() {
		// Empty constructor for deserialization
	}

	public String getTopic() {
		return topic;
	}

	public Optional<byte[]> getKey() {
		return Optional.ofNullable(key);
	}

	public byte[] getBytes() {
		return bytes;
	}

	public static KafkaOutput create(long procId, String topic, byte[] bytes, byte[] key) {
		return new KafkaOutput(procId, topic, key, bytes);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Arrays.hashCode(bytes);
		result = prime * result + Arrays.hashCode(key);
		result = prime * result + ((topic == null) ? 0 : topic.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (!(obj instanceof KafkaOutput)) {
			return false;
		}
		KafkaOutput other = (KafkaOutput) obj;
		if (!Arrays.equals(bytes, other.bytes)) {
			return false;
		}
		if (!Arrays.equals(key, other.key)) {
			return false;
		}
		if (topic == null) {
			if (other.topic != null) {
				return false;
			}
		} else if (!topic.equals(other.topic)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "KafkaOutput [topic=" + topic + ", procId=" + procId + ", key=" + (key != null ? new String(key) : "")
				+ ", msg="
				+ new String(bytes)
				+ "]";
	}

}