package com.king.rbea.backend.operators.jobinfo;

import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.checkpoint.ListCheckpointed;
import org.apache.flink.streaming.api.functions.co.RichCoFlatMapFunction;
import org.apache.flink.types.Either;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Function;
import com.google.common.base.Optional;
import com.king.rbea.backend.operators.scriptexecution.Processors;
import com.king.rbea.configuration.Configuration;
import com.king.rbea.configuration.processor.Deployment;
import com.king.rbea.configuration.processor.Failure;
import com.king.rbea.configuration.processor.JobSummariesEnd;
import com.king.rbea.configuration.processor.JobSummariesStart;
import com.king.rbea.configuration.processor.JobSummary;
import com.king.rbea.configuration.processor.ProcessorInfo;
import com.king.rbea.configuration.processor.Removal;

/**
 * {@code JobInfoQueryable} is a {@code CoFlatMapFunction} with two inputs:
 * <ul>
 * <li>1: {@link ProcessorInfo}-objects that causes the instance to update the
 * state and send a message downstream.
 * <li>2: "dummy" objects that just trigger the output. The idea is to
 * periodically receive a message to periodically send a message downstream.
 * </ul>
 * <p>
 * Internally maintains the state (a {@link JobSummary}-instance) per processor.
 */
public final class JobInfoQueryable
		extends
		RichCoFlatMapFunction<Configuration, Boolean, Tuple2<String, Either<JobSummary, Either<JobSummariesStart, JobSummariesEnd>>>>
		implements ListCheckpointed<HashMap<Long, Optional<byte[]>>> {
	private final Logger LOG = LoggerFactory.getLogger(JobInfoQueryable.class);

	private static final long serialVersionUID = 1L;

	/**
	 * The data structure containing the JobSummary-objects. Key is the processorId,
	 * value is the Optional JobSummary. The Optional is absent if the job has been
	 * purged.
	 */
	private final Map<Long, Optional<JobSummary>> userScriptSummaries;

	/**
	 * The backend to keep track of.
	 */
	private final String backendId;

	private transient int counter = 0;

	public JobInfoQueryable(String backendId, Map<Long, JobSummary> baseScriptSummaries) {
		this.backendId = backendId;
		this.userScriptSummaries = new HashMap<>();
		baseScriptSummaries.forEach((k, v) -> userScriptSummaries.put(k, Optional.of(v)));
	}

	@Override
	public void flatMap1(Configuration conf,
			Collector<Tuple2<String, Either<JobSummary, Either<JobSummariesStart, JobSummariesEnd>>>> out)
			throws Exception {
		if (!(conf instanceof ProcessorInfo)) {
			return;
		}

		ProcessorInfo info = (ProcessorInfo) conf;
		long procId = info.getProcessorId();
		if (Processors.isBaseProcessor(procId)) {
			LOG.info("Base processor: {}", info);
			return;
		}

		LOG.debug("Received proc info class {}: {}", info.getClass().getName(), info);

		Optional<JobSummary> summaryOption = userScriptSummaries.get(procId);
		if (summaryOption == null) {
			// A new job, push to summaries
			summaryOption = Optional.of(new JobSummary(procId));
			userScriptSummaries.put(procId, summaryOption);
		} else {
			// A job seen before
			if (!summaryOption.isPresent()) {
				// A removed job
				return;
			}
		}

		if (conf instanceof Removal) {
			Removal removal = (Removal) conf;
			userScriptSummaries.remove(removal.getProcessorId());
			outputJobInfo(out);
		} else {
			if (info.mergeToSummary(summaryOption.get())) {
				outputJobInfo(out);
			}
		}
	}

	@Override
	public void flatMap2(Boolean value,
			Collector<Tuple2<String, Either<JobSummary, Either<JobSummariesStart, JobSummariesEnd>>>> out)
			throws Exception {
		if (counter++ % 10 != 0) {
			// The source produces every second. We want to collect every ten secs.
			return;
		}
		outputJobInfo(out);
	}

	/**
	 * Collects in {@code out} a list of records representing the state, in practice
	 * a {@link JobSummariesStart}, zero or more {@link JobSummary} objects and a
	 * {@link JobSummariesEnd}.
	 * <p>
	 * The start and end messages tell to the listener of the messages when a new
	 * list of jobsummaries is starting and when stopping. This is done instead of
	 * packing all JobSummaries in a single message because Kafka has a maximum
	 * message size which could be exceeded when using a single big message.
	 * 
	 * @param out
	 *            the {@link Collector} where to collect
	 */
	private void outputJobInfo(
			Collector<Tuple2<String, Either<JobSummary, Either<JobSummariesStart, JobSummariesEnd>>>> out) {
		out.collect(Tuple2.of(backendId, Either.Right(Either.Left(new JobSummariesStart()))));
		for (JobSummary jobSummary : userScriptSummaries.values().stream().filter(Optional::isPresent)
				.map(Optional::get)
				.collect(Collectors.toList())) {
			if (jobSummary.getLong(JobSummary.JOB_START_TIME_KEY).get() != -1) {
				// It's possible a ProcessorInfo arrived before job was started (or failed
				// during start).
				// Do not send an not properly initialized entry.
				out.collect(Tuple2.of(backendId, Either.Left(jobSummary)));
			}
		}
		out.collect(Tuple2.of(backendId, Either.Right(Either.Right(new JobSummariesEnd()))));
	}

	@Override
	public void open(org.apache.flink.configuration.Configuration c) throws IOException {
		if (getRuntimeContext().getNumberOfParallelSubtasks() != 1) {
			throw new RuntimeException("Must run with dop = 1");
		}
	}

	@Override
	public void restoreState(List<HashMap<Long, Optional<byte[]>>> stateList) throws Exception {
		if (stateList.size() > 1) {
			throw new RuntimeException("Received more than one state, weird...");
		}

		if (stateList.size() == 0) {
			LOG.info("Resetting job info queryable state.");
		}

		stateList.get(0).forEach((id, opt) -> userScriptSummaries.put(id,
				opt.transform(new Function<byte[], JobSummary>() {

					@Override
					public JobSummary apply(byte[] bytes) {
						try {
							return Configuration.deserialize(bytes);
						} catch (Exception e) {
							throw new RuntimeException(e);
						}
					}
				})));

		// Set JOB_STATE_KEY and JOB_STATE_DESCRIPTION_KEY if missing
		Iterator<Entry<Long, Optional<JobSummary>>> iterator = userScriptSummaries.entrySet().iterator();
		while (iterator.hasNext()) {
			Entry<Long, Optional<JobSummary>> entry = iterator.next();
			if (!entry.getValue().isPresent()) {
				continue;
			}

			JobSummary jobSummary = entry.getValue().get();

			if (Processors.isBaseProcessor(jobSummary.getProcessorId())) {
				continue;
			}

			if (jobSummary.getString(Deployment.TOPIC_KEY).orElse("").equals("")) {
				iterator.remove();
				continue;
			}

			if (jobSummary.getString(JobSummary.JOB_STATE_KEY).isPresent()
					&& jobSummary.getString(JobSummary.JOB_STATE_DESCRIPTION_KEY).isPresent()) {
				continue;
			}

			java.util.Optional<String> jobStatusOptional = jobSummary.getString(JobSummary.JOB_STATUS_KEY);
			java.util.Optional<String> stopReasonOptional = jobSummary.getString(JobSummary.STOP_REASON_KEY);
			if (!jobStatusOptional.isPresent()) {
				// This always exists
				LOG.info("JobSummary without JOB_STATUS_KEY {}", jobSummary);
				continue;
			}

			String jobState = null;
			String jobStateDescription = null;

			String jobStatus = jobStatusOptional.get();
			if (JobSummary.JOB_STATUS_RUNNING.equals(jobStatus)) {
				jobState = JobSummary.JOB_STATE_RUNNING;
				jobStateDescription = "";
			} else if (JobSummary.JOB_STATUS_STOPPED.equals(jobStatus)) {
				if (stopReasonOptional.isPresent()) {
					String stopReason = stopReasonOptional.get();
					if (JobSummary.STOP_REASON_ERROR.equals(stopReason)) {
						jobState = JobSummary.JOB_STATE_FAILED;
						jobStateDescription = jobSummary.getString(Failure.FAILURE_CAUSE_KEY).orElse("");
					} else {
						LOG.info("JobSummary JOB_STATUS_STOPPED having unknown STOP_REASON_KEY {} {} ", stopReason,
								jobSummary);
					}
				} else {
					LOG.info("JobSummary JOB_STATUS_STOPPED without STOP_REASON_KEY {}", jobSummary);
				}
			} else if (JobSummary.JOB_STATE_PAUSED.equals(jobStatus)) {
				// In this case, JOB_STATE_KEY and JOB_STATE_DESCRIPTION_KEY have already been
				// set
				// So this code must never be reached.
				LOG.info("JobSummary JOB_STATE_PAUSED but doeesn't have JOB_STATUS_KEY {}", jobSummary);
			}

			if (jobState != null) {
				jobSummary.setString(JobSummary.JOB_STATE_KEY, jobState);
				jobSummary.setString(JobSummary.JOB_STATE_DESCRIPTION_KEY, jobStateDescription);

				LOG.info("Updated jobSummary {}", jobSummary);
			}
		}
	}

	@Override
	public List<HashMap<Long, Optional<byte[]>>> snapshotState(long cpId, long cpTs) throws Exception {
		HashMap<Long, Optional<byte[]>> checkpoint = new HashMap<>();
		userScriptSummaries.forEach((id, summary) -> {
			if (!Processors.isBaseProcessor(id)) {
				checkpoint.put(id,
						summary.transform(new Function<JobSummary, byte[]>() {

							@Override
							public byte[] apply(JobSummary input) {
								try {
									return input.serialize();
								} catch (IOException e) {
									throw new RuntimeException(e);
								}
							}
						}));
			}

		});

		return Collections.singletonList(checkpoint);
	}
}