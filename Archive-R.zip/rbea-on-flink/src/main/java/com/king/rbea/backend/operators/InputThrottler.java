package com.king.rbea.backend.operators;

import java.util.concurrent.TimeUnit;

import org.apache.flink.api.common.functions.RichFilterFunction;
import org.apache.flink.configuration.Configuration;

public class InputThrottler<T> extends RichFilterFunction<T> {

	private static final long serialVersionUID = 1L;
	private static final long ONE_SEC = TimeUnit.SECONDS.toMillis(1);

	private int maxCountAll;

	private int maxCount;

	private long nextWindowEnd;
	private int windowCount;

	public InputThrottler(int maxCountAll) {
		this.maxCountAll = maxCountAll;
	}

	@Override
	public boolean filter(T value) throws Exception {
		long now = System.currentTimeMillis();
		if (now >= nextWindowEnd) {
			resetWindow(now);
		}

		if (++windowCount > maxCount) {
			Thread.sleep(nextWindowEnd - now);
		}

		return true;
	}

	private void resetWindow(long now) {
		nextWindowEnd = now - (now % ONE_SEC) + ONE_SEC;
		windowCount = 0;
	}

	@Override
	public void open(Configuration conf) {
		maxCount = maxCountAll / getRuntimeContext().getNumberOfParallelSubtasks();
		resetWindow(System.currentTimeMillis());
	}

}
