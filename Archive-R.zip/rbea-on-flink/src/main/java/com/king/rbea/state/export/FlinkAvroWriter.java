package com.king.rbea.state.export;

import java.io.IOException;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.reflect.Field;

import org.apache.avro.file.DataFileWriter;
import org.apache.avro.generic.GenericDatumWriter;
import org.apache.avro.generic.GenericRecord;
import org.apache.flink.streaming.connectors.fs.Writer;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.king.rbea.backend.batch.RBEABatchBackend;

public class FlinkAvroWriter implements Writer<GenericRecord> {
	
	private static final Logger LOG = LoggerFactory.getLogger(FlinkAvroWriter.class);

	private static final long serialVersionUID = 1L;

	private transient DataFileWriter<GenericRecord> writer;
	private transient FileSystem fs;
	private transient Path path;
	private transient FSDataOutputStream outputStream;

	@Override
	public void open(FileSystem fs, Path path) throws IOException {
		this.fs = fs;
		this.path = path;
	}

	@Override
	public void write(GenericRecord element) throws IOException {
		lazyOpen(element);
		writer.append(element);
	}

	@Override
	public long flush() throws IOException {
		LOG.info("flush");
		if (isWriterOpen()) {
			writer.flush();
			return getPos();
		} else {
			return 0l;
		}

	}

	@Override
	public long getPos() throws IOException {
		return outputStream.getPos();
	}

	@Override
	public void close() throws IOException {
		if (isWriterOpen()) {
			writer.close();
		}
	}

	private boolean isWriterOpen() {
		try {
			return writer == null ? false : (boolean) writerOpenHandle.invoke(writer);
		} catch (Throwable e) {
			throw new RuntimeException(e);
		}
	}

	private static MethodHandle writerOpenHandle = createIsOpenGetter();

	private static MethodHandle createIsOpenGetter() {
		try {
			Field isOpen = DataFileWriter.class.getDeclaredField("isOpen");
			isOpen.setAccessible(true);
			return MethodHandles.lookup().unreflectGetter(isOpen);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	private void lazyOpen(GenericRecord record) throws IOException {
		if (isWriterOpen()) {
			return;
		}

		@SuppressWarnings("resource")
		DataFileWriter<GenericRecord> dfw = new DataFileWriter<>(new GenericDatumWriter<>(record.getSchema()));
		FSDataOutputStream os;
		if (fs.exists(path)) {
			os = fs.append(path);
			writer = dfw.appendTo(new SeekableWrapper(fs.open(path)), os);
		} else {
			os = fs.create(path);
			writer = dfw.create(record.getSchema(), os);
		}
		this.outputStream = os;
	}

	@Override
	public Writer<GenericRecord> duplicate() {
		return new FlinkAvroWriter();
	}
}
