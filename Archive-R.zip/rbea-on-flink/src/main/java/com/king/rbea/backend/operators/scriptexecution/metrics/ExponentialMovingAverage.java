package com.king.rbea.backend.operators.scriptexecution.metrics;

import java.util.concurrent.TimeUnit;

import org.apache.flink.metrics.Gauge;

import com.google.common.base.Stopwatch;

public class ExponentialMovingAverage implements Gauge<Double> {

	private static final int SMOOTH_COUNT = 1500;
	private static final int MIN_COUNT = 2000;
	
	private final double alpha;
	private Double oldValue;
	private long count = 0;
	
	private boolean disableInitSmooth = false;

	public ExponentialMovingAverage(double alpha) {
		this.alpha = alpha;
	}

	public void stopAndAddElapsed(Stopwatch watch) {
		watch.stop();
		add(watch.elapsed(TimeUnit.NANOSECONDS));
	}
	
	public ExponentialMovingAverage noInitPeriod() {
		disableInitSmooth = true;
		return this;
	}

	public void add(double value) {
		if (oldValue == null) {
			oldValue = value;
		}
		double alpha = disableInitSmooth || count > SMOOTH_COUNT ? this.alpha : 0.1;
		double newValue = oldValue + alpha * (value - oldValue);
		oldValue = newValue;
		count++;
	}

	public void add(boolean b) {
		add(b ? 1 : 0);
	}

	@Override
	public Double getValue() {
		return (oldValue != null && (disableInitSmooth || count > MIN_COUNT)) ? oldValue : 0;
	}

	@Override
	public String toString() {
		return "ExponentialMovingAverage [alpha=" + alpha + ", value=" + oldValue + "]";
	}
}