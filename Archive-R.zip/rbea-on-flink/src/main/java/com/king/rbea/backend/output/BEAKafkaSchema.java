package com.king.rbea.backend.output;

import org.apache.flink.streaming.util.serialization.KeyedSerializationSchema;

import com.king.rbea.backend.types.bea.KafkaOutput;

public class BEAKafkaSchema implements KeyedSerializationSchema<KafkaOutput> {
	private static final long serialVersionUID = 1L;

	@Override
	public String getTargetTopic(KafkaOutput kafkaOutput) {
		return kafkaOutput.getTopic();
	}

	@Override
	public byte[] serializeKey(KafkaOutput kafkaOutput) {
		return kafkaOutput.getKey().orElse(null);
	}

	@Override
	public byte[] serializeValue(KafkaOutput kafkaOutput) {
		return kafkaOutput.getBytes();
	}
}