package com.king.rbea.state.globalstate;

import java.io.IOException;
import java.io.Serializable;

import com.king.constants.external.EventType;
import com.king.event.Event;
import com.king.kgk.SCClientStart;
import com.king.kgk.SCCommunityDataUpdated;
import com.king.kgk.SCDeviceInfo;
import com.king.kgk.SCGameEnd;
import com.king.kgk.SCGameStart;
import com.king.kgk.SCPurchase;
import com.king.kgk.SCStoreOpen;
import com.king.rbea.Registry;
import com.king.rbea.State;
import com.king.rbea.annotations.Initialize;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.configuration.processor.Deployment;
import com.king.rbea.exceptions.ProcessorException;

public class UniversalGlobalStateScript implements Serializable {

	private static final long serialVersionUID = 4L;

	public static final Deployment DEPLOYMENT = Deployment.newJavaProcessor("UniversalGlobalStateScript",
			Long.MAX_VALUE - 1334, new UniversalGlobalStateScript(), "", 0l, false);

	private UniversalGlobalStateScript() {}

	@ProcessEvent(semanticClass = { SCClientStart.class, SCDeviceInfo.class, SCCommunityDataUpdated.class,
			SCGameStart.class, SCGameEnd.class, SCPurchase.class,
			SCStoreOpen.class }, eventType = { EventType.AppCustomMessage, EventType.SignInUser2 })
	public void onAppCustomMessage(Event event, State state) throws ProcessorException {
		/**
		 * FIRST_ACTIVITY_MSTS
		 */
		if (state.get(GlobalState.FIRST_ACTIVITY_MSTS) < 1) {
			state.update(GlobalState.FIRST_ACTIVITY_MSTS, event.getTimeStamp());
		}
	}

	/**
	 * All states have to be initialized here (incl. default value)
	 */
	@Initialize
	public void init(Registry reg) throws ProcessorException, IOException {
		reg.registerState(GlobalState.FIRST_ACTIVITY_MSTS);
	}
}
