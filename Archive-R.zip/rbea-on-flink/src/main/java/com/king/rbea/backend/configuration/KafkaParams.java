package com.king.rbea.backend.configuration;

import static com.king.rbea.utils.Constants.GROUP_ID;
import static com.king.rbea.utils.Constants.KAFKA_BROKER;
import static com.king.rbea.utils.Constants.TOPIC_SUFFIX;
import static com.king.rbea.utils.Constants.ZOOKEEPER_HOST;

import java.util.Properties;

import org.apache.flink.api.java.utils.ParameterTool;

import com.king.flink.utils.source.Kafka;

public class KafkaParams {

	public final String topicSuffix;
	public final String kafkaBroker;
	public final String zkHost;
	public final String groupId;

	public KafkaParams(ParameterTool params) {
		topicSuffix = params.get(TOPIC_SUFFIX, "dev" + System.getProperty("user.name"));
		kafkaBroker = params.getRequired(KAFKA_BROKER);
		zkHost = params.getRequired(ZOOKEEPER_HOST);
		groupId = "rbea-flink-" + params.get(GROUP_ID, topicSuffix);
	}

	public Properties getKafkaProps() {
		return Kafka.getKafkaProps(kafkaBroker, zkHost, groupId);
	}
}
