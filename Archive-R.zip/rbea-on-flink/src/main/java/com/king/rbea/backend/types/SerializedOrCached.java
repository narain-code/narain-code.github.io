package com.king.rbea.backend.types;

import java.io.IOException;
import java.util.Arrays;

import org.apache.flink.api.common.typeutils.TypeSerializer;
import org.apache.flink.util.InstantiationUtil;

import com.king.flink.utils.Unchecked;

public class SerializedOrCached {

	private byte[] bytes = null;
	private Object cached = null;
	@SuppressWarnings("rawtypes")
	private TypeSerializer serializer = null;
	public boolean isCached;

	public SerializedOrCached(byte[] serialized) {
		this.bytes = serialized;
		this.isCached = false;
	}

	public SerializedOrCached(TypeSerializer<?> serializer, Object cached) {
		this.cached = cached;
		this.serializer = serializer;
		this.isCached = true;
	}

	public int getBytesSize() {
		return bytes != null ? bytes.length : 0;
	}

	@SuppressWarnings("unchecked")
	public byte[] getBytes() throws IOException {
		if (bytes != null) {
			return bytes;
		}

		if (cached == null) {
			return new byte[0];
		} else {
			return InstantiationUtil.serializeToByteArray(serializer, cached);
		}
	}

	@SuppressWarnings("unchecked")
	public <T> T deserialize(TypeSerializer<T> serializer) throws IOException {
		this.serializer = serializer;

		if (isCached) {
			return (T) cached;
		}

		T deserialized = bytes.length > 0 ? InstantiationUtil.deserializeFromByteArray(serializer, bytes) : null;
		if (serializer.isImmutableType()) {
			cached = deserialized;
			isCached = true;
		}
		return deserialized;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(bytes);
		result = prime * result + ((cached == null) ? 0 : cached.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof SerializedOrCached)) {
			return false;
		}
		SerializedOrCached other = (SerializedOrCached) obj;

		if (isCached && other.isCached) {
			if (cached == null) {
				return other.cached == null;
			} else {
				return cached.equals(other.cached);
			}
		} else {
			try {
				return Arrays.equals(getBytes(), other.getBytes());
			} catch (IOException e) {
				Unchecked.throwSilently(e);
				return false;
			}
		}
	}

	@Override
	public String toString() {
		return isCached ? "C(" + cached + ")" : "S";
	}
}
