package com.king.rbea.backend.utils;

import java.io.IOException;
import java.lang.reflect.Constructor;

import org.apache.flink.api.common.typeinfo.PrimitiveArrayTypeInfo;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.typeutils.EitherTypeInfo;
import org.apache.flink.api.java.typeutils.TypeExtractor;
import org.apache.flink.streaming.api.datastream.ConnectedStreams;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.KeyedStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.operators.TwoInputStreamOperator;
import org.apache.flink.streaming.api.transformations.StreamTransformation;
import org.apache.flink.streaming.api.transformations.TwoInputTransformation;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer010;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumerBase;
import org.apache.flink.streaming.util.serialization.KeyedDeserializationSchema;
import org.apache.flink.types.Either;

import com.king.rbea.backend.configuration.KafkaParams;
import com.king.rbea.backend.types.EventWrapper;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.backend.types.bea.BEATypeInfo;
import com.king.rbea.configuration.Configuration;

public class RBEAStreamUtils {

	private static final String DOT = "\\.";
	private static final String DASH = "-";

	public static String removeDots(String name) {
		return name.replaceAll(DOT, DASH);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static SingleOutputStreamOperator<Either<BEA, Configuration>> apply(
			ConnectedStreams<? extends EventWrapper, Configuration> connectedStream,
			TwoInputStreamOperator<? extends EventWrapper, Configuration, Either<BEA, Configuration>> operator) {

		DataStream<? extends EventWrapper> inputStream1 = connectedStream.getFirstInput();
		DataStream<Configuration> inputStream2 = connectedStream.getSecondInput();
		StreamExecutionEnvironment environment = inputStream1.getExecutionEnvironment();

		TypeInformation<Either<BEA, Configuration>> outTypeInfo = new EitherTypeInfo<>(new BEATypeInfo(),
				TypeExtractor.getForClass(Configuration.class));

		TwoInputTransformation<? extends EventWrapper , Configuration, Either<BEA, Configuration>> transform = new TwoInputTransformation(
				inputStream1.getTransformation(),
				inputStream2.getTransformation(),
				"Co-FlatMap",
				operator,
				outTypeInfo,
				environment.getParallelism());

		KeyedStream<? extends EventWrapper, ?> keyedInput1 = (KeyedStream<EventWrapper, ?>) inputStream1;

		TypeInformation<?> keyType1 = keyedInput1.getKeyType();
		KeySelector selector =keyedInput1.getKeySelector();

		transform.setStateKeySelectors(selector, null);
		transform.setStateKeyType(keyType1);

		// You can't stop me...muhahaha
		Constructor<SingleOutputStreamOperator> constructor;
		try {
			constructor = (Constructor<SingleOutputStreamOperator>) SingleOutputStreamOperator.class
					.getDeclaredConstructor(StreamExecutionEnvironment.class, StreamTransformation.class);
			constructor.setAccessible(true);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}

		SingleOutputStreamOperator<Either<BEA, Configuration>> returnStream = null;
		try {
			returnStream = constructor.newInstance(environment, transform);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}

		environment.addOperator(transform);

		return returnStream;
	}

	public static DataStream<byte[]> readRaw(StreamExecutionEnvironment env, String topic, KafkaParams kp,
			String uid, String name, int sourceParallelism) {
		FlinkKafkaConsumerBase<byte[]> c = new FlinkKafkaConsumer010<>(topic, RawSchema.INSTANCE, kp.getKafkaProps());
		c.setStartFromLatest();

		return env.addSource(c)
				.setParallelism(sourceParallelism)
				.uid(uid)
				.name(name);
	}

	public enum RawSchema implements KeyedDeserializationSchema<byte[]> {

		INSTANCE;

		@Override
		public TypeInformation<byte[]> getProducedType() {
			return PrimitiveArrayTypeInfo.BYTE_PRIMITIVE_ARRAY_TYPE_INFO;
		}

		@Override
		public boolean isEndOfStream(byte[] nextElement) {
			return false;
		}

		@Override
		public byte[] deserialize(byte[] key, byte[] message, String topic, int partition, long offset) throws IOException {
			return message;
		}

	}
}
