package com.king.rbea.backend.utils;

import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Supplier;
import com.google.common.base.Suppliers;
import com.king.flink.utils.Unchecked;
import com.king.rbea.exceptions.BackendException;

public class JsonCache<J, T> {

	public static final Logger LOG = LoggerFactory.getLogger(JsonCache.class);
	private static final ObjectMapper MAPPER = new ObjectMapper();

	private final ExecutorService exec = Executors.newSingleThreadExecutor();

	private final String url;
	private final String defaultResourcePath;

	private final Supplier<T> cache;
	private final TypeReference<J> typeRef;

	private T last;
	private final Function<J, T> f;

	public JsonCache(String url, String defaultResourcePath, TypeReference<J> typeRef, long refreshInterval,
			TimeUnit tu, Function<J, T> f) {
		this.url = url;
		this.defaultResourcePath = defaultResourcePath;
		this.typeRef = typeRef;
		this.f = f;

		cache = Suppliers.memoizeWithExpiration(this::download, refreshInterval, tu);
	}

	public T getValue() {
		return cache.get();
	}

	private T download() {
		String json = null;
		try {
			json = exec.submit(() -> IOUtils.toString(new URL(url), StandardCharsets.UTF_8)).get(15, TimeUnit.SECONDS);
		} catch (Exception e) {
			LOG.error("Error while downloading flavour info.", e);
			if (last == null) {
				try {
					LOG.info("Falling back to default info.");
					json = IOUtils.toString(getClass().getClassLoader().getResource(defaultResourcePath),
							StandardCharsets.UTF_8);
				} catch (Exception ex) {}
			} else {
				LOG.error("Falling back to last info.");
				return last;
			}
		}

		if (json == null) {
			Unchecked.throwSilently(new BackendException("Cannot load flavour info file."));
			return null;
		}

		try {
			T parsed = f.apply(MAPPER.readValue(json, typeRef));
			last = parsed;
		} catch (Throwable e) {
			LOG.error("Error while parsing flavour info.", e);
		}

		if (last != null) {
			return last;
		} else {
			Unchecked.throwSilently(new BackendException("Cannot parse flavour info file."));
			return null;
		}
	}
}
