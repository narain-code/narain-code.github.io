package com.king.rbea.backend.output;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.util.Collector;

import com.king.rbea.backend.types.bea.KafkaOutput;
import com.king.rbea.configuration.Configuration;
import com.king.rbea.configuration.processor.OutputInfo;
import com.king.rbea.utils.Constants;

public class KafkaOutputDataMapper implements FlatMapFunction<KafkaOutput, Configuration> {

	private static final long serialVersionUID = 1L;
	private Set<Tuple2<Long, String>> createdTopics = new HashSet<>();

	@Override
	public void flatMap(KafkaOutput bea, Collector<Configuration> out) throws Exception {
		String topic = bea.getTopic();
		if (createdTopics.add(Tuple2.of(bea.getProcessorId(), topic))) {
			out.collect(new OutputInfo(bea.getProcessorId(), topic, Constants.KAFKA,
					Collections.singletonMap(Constants.KAFKA_OUTPUT_TOPIC, topic)));
		}
	}
}
