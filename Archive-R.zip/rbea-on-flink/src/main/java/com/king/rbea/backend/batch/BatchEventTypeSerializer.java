package com.king.rbea.backend.batch;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

import org.apache.flink.api.common.typeutils.CompatibilityResult;
import org.apache.flink.api.common.typeutils.ParameterlessTypeSerializerConfig;
import org.apache.flink.api.common.typeutils.TypeSerializer;
import org.apache.flink.api.common.typeutils.TypeSerializerConfigSnapshot;
import org.apache.flink.api.common.typeutils.base.StringSerializer;
import org.apache.flink.core.memory.DataInputView;
import org.apache.flink.core.memory.DataOutputView;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.king.event.Event;

public class BatchEventTypeSerializer extends TypeSerializer<Event> {

	private static final long serialVersionUID = 1L;
	private static final StringSerializer ss = StringSerializer.INSTANCE;
	public static final BatchEventTypeSerializer INSTANCE = new BatchEventTypeSerializer();

	@Override
	public boolean canEqual(Object o) {
		return o instanceof BatchEventTypeSerializer;
	}

	@Override
	public Event copy(Event e) {
		return e;
	}

	@Override
	public Event copy(Event e, Event reuse) {
		return e;
	}

	@Override
	public void copy(DataInputView source, DataOutputView target) throws IOException {
		ss.copy(source, target);
	}

	@Override
	public Event createInstance() {
		return null;
	}

	@Override
	public Event deserialize(DataInputView in) throws IOException {
		
		//String commaSeperated =ss.deserialize(in);
		int len=in.readInt();
		
		byte[] all = new byte[len];
		in.readFully(all);
		return doSerialize(all);
		//return doSerialize(commaSeperated);
		
	}

	public Event doSerialize(String commaSeperated) throws IOException {
		try {

			ByteBuffer buffer = ByteBuffer.wrap(commaSeperated.getBytes(Charset.forName("UTF-8")));

			long ts = buffer.getLong();

			/*
			 * int flavourId=buffer.getInt();
			 * 
			 * long eventType=buffer.getLong(); long uevId = buffer.getLong();
			 * 
			 * int hsStart=buffer.getInt(); int hsEnd=buffer.getInt();
			 * 
			 * long uacid =buffer.getLong(); int fieldStart = buffer.getInt();
			 * int len =buffer.getInt();
			 * 
			 * byte[] eventB = new byte[len];
			 * 
			 * buffer.get(eventB);
			 * 
			 * String event = new String(eventB); return new BatchEvent(event,
			 * ts, flavourId, eventType, uevId, hsStart, hsEnd, uacid,
			 * fieldStart);
			 */
			return null;
		} catch (Exception e) {
			System.err.println(commaSeperated);
			throw new IOException(e);
		}

	}

	public Event doSerialize(byte[] bytesC) throws IOException {
		try {

			ByteBuffer buffer = ByteBuffer.wrap(bytesC);
			int len = buffer.getInt();

			byte[] eventB = new byte[len];

			buffer.get(eventB);

			String event = new String(eventB);

			long ts = buffer.getLong();

			int flavourId = buffer.getInt();

			long eventType = buffer.getLong();
			long uevId = buffer.getLong();

			int hsStart = buffer.getInt();
			int hsEnd = buffer.getInt();

			long uacid = buffer.getLong();
			int fieldStart = buffer.getInt();
			return new BatchEvent(event, ts, flavourId, eventType, uevId, hsStart, hsEnd, uacid, fieldStart);
		} catch (Exception e) {
			// System.err.println(commaSeperated);
			throw new IOException(e);
		}

	}

	@Override
	public Event deserialize(Event arg0, DataInputView in) throws IOException {
		return deserialize(in);
	}

	@Override
	public TypeSerializer<Event> duplicate() {
		return this;
	}

	@Override
	public boolean equals(Object o) {
		return o instanceof BatchEventTypeSerializer;
	}

	@Override
	public int getLength() {
		return 0;
	}

	@Override
	public int hashCode() {
		return 0;
	}

	@Override
	public boolean isImmutableType() {
		return true;
	}

	@Override
	public void serialize(Event event, DataOutputView out) throws IOException {
		// ss.serialize(event.toString(), out);
		byte[] byteB = ((BatchEvent) event).toBytes();
		out.writeInt(byteB.length);
		out.write(byteB,0,byteB.length);
	}

	@Override
	public TypeSerializerConfigSnapshot snapshotConfiguration() {
		return new ParameterlessTypeSerializerConfig(this.getClass().getSimpleName());
	}

	@Override
	public CompatibilityResult<Event> ensureCompatibility(TypeSerializerConfigSnapshot arg0) {
		return CompatibilityResult.compatible();
	}
}
