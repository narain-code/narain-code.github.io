package com.king.rbea.backend.batch;

import java.util.List;
import java.util.function.Consumer;

public interface FileWrapper {
	
	public  List<FileWrapper> getSplitDirectories(String path);
	public void consume(Consumer<String> consume);
	
	public static  FileWrapper getWrapperForType(FileSourceTypes type){
		switch(type){
		case LOCALFILE:return new LocalFileWrapper();
		case HADOOP: return new HadoopFileWrapper();
		default: throw new RuntimeException(type + " is not supported");
		}
	}
	
	

}
