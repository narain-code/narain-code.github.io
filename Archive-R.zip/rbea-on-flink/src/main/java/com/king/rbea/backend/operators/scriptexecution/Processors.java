package com.king.rbea.backend.operators.scriptexecution;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple3;

import com.king.event.Event;
import com.king.flink.utils.Unchecked;
import com.king.rbea.EventProcessor;
import com.king.rbea.backend.operators.scriptexecution.metrics.ExecutionStats;
import com.king.rbea.backend.operators.scriptexecution.metrics.RBEAMetricsTracker;
import com.king.rbea.backend.utils.ProcessingFunction;
import com.king.rbea.exceptions.BackendException;
import com.king.rbea.exceptions.ProcessorException;

/**
 * {@code Processors} runs the processors of RBEA. It maintains a {@code List}
 * of processors (in practise {@link EventProcessor}-instances) by processor id,
 * in {@link #eventProcessors}.
 */
public class Processors implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * The actual processors with their ids and runtime stats. Stored in a List for
	 * for faster iteration than for a Map.
	 */
	private final List<Tuple3<Long, EventProcessor, ExecutionStats>> eventProcessors;

	// Same data as in eventProcessors for faster lookup
	private final Map<Long, Tuple3<Long, EventProcessor, ExecutionStats>> processorMap;

	public Processors() {
		eventProcessors = new ArrayList<>();
		processorMap = new HashMap<>();
	}

	public List<ProcessorException> runAllProcessEvent(Event event, ContextManager ctxMgr, RBEAMetricsTracker metrics)
			throws BackendException {
		return runForAllProcessors(event, ctxMgr, metrics,
				(id, proc) -> RBEAOperator.run(id, "ProcessEvent", true,
						() -> proc.processEvent(event, ctxMgr.getContext())));
	}

	public List<ProcessorException> runAllOnSessionEnd(Event event, ContextManager ctxMgr, RBEAMetricsTracker metrics)
			throws BackendException {
		return runForAllProcessors(event, ctxMgr, metrics,
				(id, proc) -> RBEAOperator.run(id, "OnSessionEnd", true,
						() -> proc.onSessionEnd(event, ctxMgr.getContext())));
	}

	/**
	 * Sequentially calls the provided function for all processors with the context,
	 * and tracks execution times.
	 * 
	 * @return Returns a (possibly empty) list of errors that occured while
	 *         processing
	 * @throws BackendException
	 */
	public List<ProcessorException> runForAllProcessors(Event event, ContextManager ctx,
			RBEAMetricsTracker metrics, ProcessingFunction fun) throws BackendException {
		List<ProcessorException> errors = null;
		metrics.userStateReadWatch.reset();
		metrics.baseStateReadWatch.reset();
		Tuple2<Boolean, Boolean> stateFetched = Tuple2.of(false, false);
		for (Tuple3<Long, EventProcessor, ExecutionStats> t : eventProcessors) {
			ctx.setProcessorId(t.f0);
			Optional<ProcessorException> err = metrics.callAndMeasure(t.f2, stateFetched, () -> fun.apply(t.f0, t.f1));
			if (err.isPresent()) {
				if (errors == null) {
					errors = new ArrayList<>();
				}
				errors.add(err.get());
			}
		}
		return errors != null ? errors : Collections.emptyList();
	}

	public Tuple3<Long, EventProcessor, ExecutionStats> getForId(long procId) {
		return processorMap.get(procId);
	}

	public List<Tuple3<Long, EventProcessor, ExecutionStats>> getAll() {
		return eventProcessors;
	}

	public boolean has(long procId) {
		return processorMap.containsKey(procId);
	}

	/**
	 * Adds a new processor or updates an existing one with processor id
	 * {@code procId}.
	 * 
	 * @param procId
	 *            the processor id
	 * @param newProc
	 *            the new processor
	 */
	public void addProcessor(long procId, EventProcessor newProc) {
		if (has(procId)) {
			remove(procId);
		}
		Tuple3<Long, EventProcessor, ExecutionStats> t = new Tuple3<>(procId, newProc, new ExecutionStats());
		eventProcessors.add(t);
		processorMap.put(t.f0, t);
	}

	public static boolean isBaseProcessor(long procId) {
		return procId > Integer.MAX_VALUE;
	}

	public Tuple3<Long, EventProcessor, ExecutionStats> remove(long processorId) {
		if (isBaseProcessor(processorId)) {
			Unchecked.throwSilently(new BackendException("Cannot remove base processor"));
		}
		Iterator<Tuple3<Long, EventProcessor, ExecutionStats>> i = eventProcessors.iterator();
		while (i.hasNext()) {
			Tuple3<Long, EventProcessor, ExecutionStats> next = i.next();
			if (next.f0.longValue() == processorId) {
				i.remove();
				break;
			}
		}

		return processorMap.remove(processorId);
	}

	/**
	 * Gets the count of processors.
	 * 
	 * @return the count
	 */
	public int size() {
		return eventProcessors.size();
	}

	@Override
	public String toString() {
		return "Processors [eventProcessors=" + eventProcessors + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((processorMap == null) ? 0 : processorMap.keySet().hashCode());
		return result;
	}

	/**
	 * This method is mostly intended for testing purposes
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Processors other = (Processors) obj;
		if (processorMap == null) {
			if (other.processorMap != null)
				return false;
		} else if (!processorMap.keySet().equals(other.processorMap.keySet()))
			return false;
		return true;
	}

}