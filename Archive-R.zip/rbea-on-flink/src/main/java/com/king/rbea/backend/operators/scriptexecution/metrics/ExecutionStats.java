package com.king.rbea.backend.operators.scriptexecution.metrics;

public class ExecutionStats {

	protected long count = 0;
	protected long totalTimeNanos = 0;
	protected long maxTimeNanos = 0;

	protected void add(long executionTimeNanos) {
		count++;
		totalTimeNanos += executionTimeNanos;
		if (maxTimeNanos < executionTimeNanos) {
			maxTimeNanos = executionTimeNanos;
		}
	}

	protected void reset() {
		count = 0;
		totalTimeNanos = 0;
		maxTimeNanos = 0;
	}

	@Override
	public String toString() {
		return "ExecutionStats [count=" + count + ", totalTimeNanos=" + totalTimeNanos + ", maxTimeNanos="
				+ maxTimeNanos + "]";
	}
}