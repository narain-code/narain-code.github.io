package com.king.rbea.backend.types.bea;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.Map;

import org.apache.flink.api.common.ExecutionConfig;
import org.apache.flink.api.common.typeinfo.TypeInfoFactory;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeutils.CompatibilityResult;
import org.apache.flink.api.common.typeutils.TypeSerializer;
import org.apache.flink.api.common.typeutils.TypeSerializerConfigSnapshot;
import org.apache.flink.api.common.typeutils.base.array.BytePrimitiveArraySerializer;
import org.apache.flink.core.memory.DataInputView;
import org.apache.flink.core.memory.DataOutputView;

public class HLLTypeFactory extends TypeInfoFactory<HLLContainer> {

	@Override
	public TypeInformation<HLLContainer> createTypeInfo(Type t, Map<String, TypeInformation<?>> genericParameters) {
		if (HLLContainer.class.getTypeName().equals(t.getTypeName())) {
			return new HLLTypeInfo();
		} else {
			return null;
		}
	}

	private static class HLLTypeInfo extends TypeInformation<HLLContainer> {

		private static final long serialVersionUID = 1L;

		@Override
		public TypeSerializer<HLLContainer> createSerializer(ExecutionConfig config) {
			return new HLLSerializer();
		}

		@Override
		public boolean isBasicType() {
			return false;
		}

		@Override
		public boolean isTupleType() {
			return false;
		}

		@Override
		public int getArity() {
			return 0;
		}

		@Override
		public int getTotalFields() {
			return 0;
		}

		@Override
		public Class<HLLContainer> getTypeClass() {
			return HLLContainer.class;
		}

		@Override
		public boolean isKeyType() {
			return false;
		}

		@Override
		public String toString() {
			return "HLLTypeInfo";
		}

		@Override
		public boolean equals(Object obj) {
			return obj instanceof HLLTypeInfo;
		}

		@Override
		public int hashCode() {
			return 0;
		}

		@Override
		public boolean canEqual(Object obj) {
			return equals(obj);
		}

	}

	private static class HLLSerializer extends TypeSerializer<HLLContainer> {

		private static final long serialVersionUID = 1L;
		TypeSerializer<byte[]> bs = BytePrimitiveArraySerializer.INSTANCE;

		@Override
		public boolean isImmutableType() {
			return false;
		}

		@Override
		public TypeSerializer<HLLContainer> duplicate() {
			return new HLLSerializer();
		}

		@Override
		public HLLContainer createInstance() {
			return null;
		}

		@Override
		public HLLContainer copy(HLLContainer from) {
			try {
				return new HLLContainer(from.hll.getBytes());
			} catch (IOException e) {
				throw new RuntimeException();
			}
		}

		@Override
		public HLLContainer copy(HLLContainer from, HLLContainer reuse) {
			return copy(from);
		}

		@Override
		public int getLength() {
			return 0;
		}

		@Override
		public void serialize(HLLContainer record, DataOutputView target) throws IOException {
			bs.serialize(record.hll.getBytes(), target);
		}

		@Override
		public HLLContainer deserialize(DataInputView source) throws IOException {
			return new HLLContainer(bs.deserialize(source));
		}

		@Override
		public HLLContainer deserialize(HLLContainer reuse, DataInputView source) throws IOException {
			return deserialize(source);
		}

		@Override
		public void copy(DataInputView source, DataOutputView target) throws IOException {
			bs.copy(source, target);
		}

		@Override
		public boolean equals(Object obj) {
			return obj instanceof HLLSerializer || obj instanceof BytePrimitiveArraySerializer;
		}

		@Override
		public boolean canEqual(Object obj) {
			return equals(obj);
		}

		@Override
		public int hashCode() {
			return 0;
		}

		@Override
		public TypeSerializerConfigSnapshot snapshotConfiguration() {
			return new TypeSerializerConfigSnapshot() {

				@Override
				public int getVersion() {
					return 0;
				}

				@Override
				public int hashCode() {
					return 0;
				}

				@Override
				public boolean equals(Object obj) {
					return true;
				}
			};
		}

		@Override
		public CompatibilityResult<HLLContainer> ensureCompatibility(TypeSerializerConfigSnapshot configSnapshot) {
			return CompatibilityResult.compatible();
		}
	}
}
