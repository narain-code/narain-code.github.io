package com.king.rbea.backend.operators.scriptexecution;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.flink.api.common.typeutils.TypeSerializer;
import org.apache.flink.api.java.tuple.Tuple2;

import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;
import com.king.rbea.backend.utils.BackendConstants;
import com.king.rbea.exceptions.BackendException;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.state.LocalState;

public class Fields implements Serializable {
	private static final long serialVersionUID = 1L;

	// List of fields in order of execution
	private LinkedHashMap<String, LocalState<?>> baseStates = new LinkedHashMap<>();
	private final LinkedHashMap<String, LocalState<?>> userStates = new LinkedHashMap<>();

	private final Map<Long, Set<String>> registeredStateNames = new HashMap<>();
	private final Map<String, Long> stateToProcId = new HashMap<>();

	private final Map<Short, LocalState<?>> idToState = new HashMap<>();
	private final BiMap<Short, String> idToStateName = HashBiMap.create();

	// Should be decremented to keep negative
	private short nextBaseId = -1;

	public void initializeClean() throws Exception {
		initializeFromState((short) -1, new HashMap<>());
	}

	public void initializeFromState(short nbid, Map<Short, String> baseFieldMapping) throws Exception {
		this.nextBaseId = nbid;
		idToStateName.putAll(baseFieldMapping);

		baseStates.forEach((name, field) -> {
			Short fieldId = has(field.getStateName()) ? getIdForName(field.getStateName()) : nextBaseId--;
			idToStateName.put(fieldId, field.getStateName());
			idToState.put(fieldId, field);
		});
	}

	public Tuple2<Short, Map<Short, String>> snapshotState() throws BackendException {
		Map<Short, String> baseFieldIds = new HashMap<>();
		idToStateName.forEach((id, name) -> {
			if (isBaseField(name) || Processors.isBaseProcessor(getProcId(name))) {
				baseFieldIds.put(id, name);
			}
		});
		return Tuple2.of(nextBaseId, baseFieldIds);
	}

	public Map<String, Tuple2<Short, TypeSerializer<?>>> registerFieldInfo(long procId,
			Map<String, Tuple2<Short, TypeSerializer<?>>> mapping) {
		List<String> allForProc = new ArrayList<>(getAllForProcId(procId));
		Map<String, Tuple2<Short, TypeSerializer<?>>> newMapping = new HashMap<>(mapping);

		Map<String, Tuple2<Short, TypeSerializer<?>>> updatedMapping = new HashMap<>();

		allForProc.forEach(name -> {
			Tuple2<Short, TypeSerializer<?>> t = newMapping.remove(name);
			if (t == null) {
				deleteFieldState(name);
			}
		});

		updatedMapping.putAll(newMapping);

		for (Entry<String, Tuple2<Short, TypeSerializer<?>>> e : newMapping.entrySet()) {
			String fieldName = e.getKey();
			Short fieldId = e.getValue().f0;
			idToStateName.put(fieldId, fieldName);
			registeredStateNames.computeIfAbsent(procId, k -> new HashSet<>()).add(fieldName);
			stateToProcId.put(fieldName, procId);
		}

		return updatedMapping;
	}

	public void addUserField(long processorId, LocalState<?> field, String suffixedFieldName)
			throws ProcessorException, BackendException {
		if (!Processors.isBaseProcessor(processorId) && !idToStateName.inverse().containsKey(suffixedFieldName)) {
			throw new ProcessorException(
					"Error while registering the field, this might indicate a non-deterministic initialize method.");
		}

		Short fieldId = idToStateName.inverse().get(suffixedFieldName);
		if (fieldId == null) {
			// This is a base field registered the first time (hopefully)
			fieldId = nextBaseId--;
			idToStateName.put(fieldId, suffixedFieldName);
			registeredStateNames.computeIfAbsent(processorId, k -> new HashSet<>()).add(suffixedFieldName);
			stateToProcId.put(suffixedFieldName, processorId);
		}

		if (Processors.isBaseProcessor(processorId)) {
			registeredStateNames.computeIfAbsent(processorId, k -> new HashSet<>()).add(suffixedFieldName);
			stateToProcId.put(suffixedFieldName, processorId);
		}

		idToState.put(fieldId, field);
		userStates.put(suffixedFieldName, field);

		RBEAOperator.LOG.info("Successfully registered field {} by {} with id {}: {}", suffixedFieldName, processorId,
				fieldId, field);
	}

	public List<String> removeFieldsForProcessor(long processorId, boolean deleteState) throws BackendException {
		Collection<String> fields = deleteState ? registeredStateNames.remove(processorId)
				: registeredStateNames.get(processorId);
		List<String> removed = new ArrayList<>();

		if (fields != null) {
			fields.forEach(name -> {
				if (deleteState) {
					deleteFieldState(name);
				} else {
					disableField(name);
				}
				removed.add(name);
			});
		}
		return removed;
	}

	private void disableField(String name) {
		userStates.remove(name);
	}

	public void deleteFieldState(String name) {
		disableField(name);
		getAllForProcId(stateToProcId.remove(name)).remove(name);
		Short fieldId = getIdForName(name);
		idToStateName.remove(fieldId);
		idToState.remove(fieldId);
	}

	public boolean has(String fieldName) {
		return idToStateName.inverse().containsKey(fieldName);
	}

	public boolean has(Short fieldId) {
		return idToStateName.containsKey(fieldId);
	}

	public Short getIdForName(String name) {
		return idToStateName.inverse().get(name);
	}

	public String getFieldNameForId(short id) {
		return idToStateName.get(id);
	}

	public Map<String, LocalState<?>> getAll() {
		Map<String, LocalState<?>> all = new LinkedHashMap<>(userStates);
		all.putAll(baseStates);
		return all;
	}

	public LocalState<?> getFieldForId(Short id) {
		return idToState.get(id);
	}

	public Set<String> getAllForProcId(long procId) {
		Set<String> l = registeredStateNames.get(procId);
		return l != null ? l : new HashSet<>();
	}

	public Collection<LocalState<?>> getBaseFields() {
		return baseStates.values();
	}

	public Collection<LocalState<?>> getUserFields() {
		return userStates.values();
	}

	public long getProcId(String name) {
		return stateToProcId.getOrDefault(name, BackendConstants.DUMMY_PROC_ID);
	}

	public boolean isBaseField(String field) {
		return baseStates.containsKey(field);
	}

	public Set<Short> getActiveIds() {
		return new HashSet<>(idToState.keySet());
	}

	/**
	 * Mostly for Testing
	 */
	public boolean isEmpty() {
		return baseStates.isEmpty()
				&& userStates.isEmpty()
				&& registeredStateNames.isEmpty()
				&& stateToProcId.isEmpty()
				&& idToState.isEmpty()
				&& idToStateName.isEmpty();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((stateToProcId == null) ? 0 : stateToProcId.hashCode());
		result = prime * result + nextBaseId;
		result = prime * result + ((registeredStateNames == null) ? 0 : registeredStateNames.hashCode());
		return result;
	}

	/**
	 * This method is mostly intended for testing purposes
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Fields other = (Fields) obj;
		if (stateToProcId == null) {
			if (other.stateToProcId != null)
				return false;
		} else if (!stateToProcId.equals(other.stateToProcId))
			return false;
		if (nextBaseId != other.nextBaseId)
			return false;
		if (registeredStateNames == null) {
			if (other.registeredStateNames != null)
				return false;
		} else if (!registeredStateNames.equals(other.registeredStateNames))
			return false;
		return true;
	}

}