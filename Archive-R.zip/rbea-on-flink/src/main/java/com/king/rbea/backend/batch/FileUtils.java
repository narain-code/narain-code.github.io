package com.king.rbea.backend.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.function.Consumer;
import java.util.zip.GZIPInputStream;

public class FileUtils {
	
	
	public static File[] getGzipFiles(String dir){
		return getGzipFiles(new File(dir));
	}
	
	public static File[] getGzipFiles(File dir){
		
		
		return dir.listFiles(f->f.getName().endsWith("gz"));
	}
	
	public static void decompressGzipFile(String gzipFile, Consumer<String> consume) {
		decompressGzipFile(new File(gzipFile),consume);
	}

	public static void decompressGzipFile(File gzipFile, Consumer<String> consume) {
        try {
            FileInputStream fis = new FileInputStream(gzipFile);
            GZIPInputStream gis = new GZIPInputStream(fis);
            Reader decoder = new InputStreamReader(gis, "UTF8");
            BufferedReader buffRead = new BufferedReader(decoder);
           
            String line;
           
            while((line = buffRead.readLine()) != null){
                consume.accept(line);
               
            }
            //close resources
          
            gis.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
    }
}
