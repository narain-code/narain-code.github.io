package com.king.rbea.backend;

import static com.king.rbea.backend.utils.BackendConstants.AGGREGATE_TAG;
import static com.king.rbea.backend.utils.BackendConstants.KAFKA_TAG;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.flink.api.common.functions.ReduceFunction;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.api.java.typeutils.TypeExtractor;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.IterativeStream;
import org.apache.flink.streaming.api.datastream.KeyedStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.datastream.SplitStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.assigners.TumblingProcessingTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.types.Either;

import com.king.flink.utils.Unchecked;
import com.king.flink.utils.types.EitherUtils;
import com.king.rbea.EventProcessor;
import com.king.rbea.backend.operators.BEAOutputSelector;
import com.king.rbea.backend.operators.FieldIdAssigner;
import com.king.rbea.backend.operators.common.PeriodicBooleanSource;
import com.king.rbea.backend.operators.heartbeat.HeartbeatCreator;
import com.king.rbea.backend.operators.jobinfo.JobInfoQueryable;
import com.king.rbea.backend.operators.jobinfo.SleepingSource;
import com.king.rbea.backend.operators.jobinfo.StatsToAggregate;
import com.king.rbea.backend.operators.scriptexecution.RBEAOperator;
import com.king.rbea.backend.operators.windowing.AggregtionWindowAssigner;
import com.king.rbea.backend.operators.windowing.TimestampSetter;
import com.king.rbea.backend.output.MySqlOutputDataMapper;
import com.king.rbea.backend.output.OutputWriter;
import com.king.rbea.backend.output.RBEAOutput;
import com.king.rbea.backend.output.ToAggrigatoEvent;
import com.king.rbea.backend.types.EventWrapper;
import com.king.rbea.backend.types.bea.Aggregate;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.backend.types.bea.BEATypeInfo;
import com.king.rbea.backend.types.bea.KafkaOutput;
import com.king.rbea.backend.utils.BackendConstants;
import com.king.rbea.backend.utils.DummyRegistry;
import com.king.rbea.backend.utils.RBEAStreamUtils;
import com.king.rbea.configuration.Configuration;
import com.king.rbea.configuration.processor.Deployment;
import com.king.rbea.configuration.processor.Failure;
import com.king.rbea.configuration.processor.Heartbeat;
import com.king.rbea.configuration.processor.JobSummariesEnd;
import com.king.rbea.configuration.processor.JobSummariesStart;
import com.king.rbea.configuration.processor.JobSummary;
import com.king.rbea.configuration.processor.Notification;
import com.king.rbea.configuration.processor.Removal;
import com.king.rbea.scripts.proxy.ProxyExecutorFactory;

/**
 * {@code RBEA}
 */
public class RBEA {
	public static RBEAOutput run(DataStream<? extends EventWrapper> eventsDataStream,
			DataStream<Configuration> backendConfigStream,
			ParameterTool params, List<Deployment> baseProcessors,
			OutputWriter outputWriter, boolean finiteSource, String backendId, String envName) {

		// Extract StreamExecutionEnvironment from the event stream, and make
		// sure we run on event time
		StreamExecutionEnvironment env = eventsDataStream.getExecutionEnvironment();
		if (env.getStreamTimeCharacteristic() == TimeCharacteristic.ProcessingTime) {
			throw new RuntimeException("Must use event-time characteristics for environment.");
		}

		// Avoid messing with possibly null values
		params = params != null ? params : ParameterTool.fromMap(new HashMap<>());
		//for batch runner
		boolean isBatch = params.getBoolean("BATCHRUN");
		// Filter non-Deployments and Deployments for the current game
		DataStream<Configuration> configInputStream = backendConfigStream
				.filter(p -> !(p instanceof Deployment) || ((Deployment) p).getBackendId().equals(backendId))
				.setParallelism(1)
				.name("Filter for backend")
				// Transform deployment messages, by enriching them with ids for user defined
				// fields
				.map(new FieldIdAssigner())
				.setParallelism(1)
				.uid(params.get(BackendConstants.DEPLOYMENT_STATE_NAME, "") + "AssignFieldIds")
				.name("Create Fields and Ids");

		// Keep track of errors that happened during script initialization,
		// field creation and create a separate stream as these are not sent to the
		// processing operator
		DataStream<Configuration> initFailureStream  = null;
		IterativeStream<Configuration> deploymentsAndRuntimeFailuresIterativeStream = null;
		DataStream<Either<BEA, Configuration>> beaOrconf  = null;
		DataStream<Configuration> configOutputStream =null;
		if(!isBatch){
		 initFailureStream = configInputStream
				.filter(p -> p instanceof Failure || p instanceof Notification)
				.name("Errors and Notifications")
				.setParallelism(1);
		
		// We need an iterative stream to later feed back removals (for
		// propagating failures). This stream will contain the enriched deployments,
		// other processor info messages and also the propagated runtime failures (as
		// removals) from downstream operators.
		 deploymentsAndRuntimeFailuresIterativeStream = configInputStream
				// We remove failures/notifications that were recieved during id generation
				.filter(p -> !(p instanceof Failure) && !(p instanceof Notification))
				.name("Drop errors and Notifications")
				.setParallelism(1)
				.iterate(params.getInt(BackendConstants.TEST_ITER_TIMEOUT, 0));

		// Apply the main operator that will execute the scripts. We need to use
		// some tricks to actually broadcast the deployment stream to all
		// parallel instances as Flink does not allow that by default.
		beaOrconf = RBEAStreamUtils
				.apply(
						eventsDataStream.keyBy(EventWrapper::getPartitionKey)
								.connect(deploymentsAndRuntimeFailuresIterativeStream.broadcast()),
						new RBEAOperator(baseProcessors, params))
				.uid("EventProcessor")
				.name("Execute processors");
		// Get the stream of info about the running processors
			 configOutputStream = beaOrconf
						.flatMap(new EitherUtils.ProjectRight<>(TypeExtractor.getForClass(Configuration.class)))
						.name("Filter config stream");
		}else{
			
		
			beaOrconf = RBEAStreamUtils
					.apply(
							eventsDataStream.keyBy(EventWrapper::getPartitionKey)
									.connect(configInputStream.broadcast()),
							new RBEAOperator(baseProcessors, params))
					.uid("EventProcessor")
					.name("Execute processors");
		}

		

		// Get the stream of BEA (wrapper type for outputs and aggregates)
		SplitStream<BEA> beaStream = beaOrconf
				.flatMap(new EitherUtils.ProjectLeft<>(new BEATypeInfo<>()))
				.name("Filter BEA")
				.split(new BEAOutputSelector());
		if(!isBatch){
		// Convert the RuntimeMetrics objects to Aggregate events
		DataStream<Aggregate> runtimeMetrics = configOutputStream.flatMap(new StatsToAggregate(envName, backendId))
				.returns(new BEATypeInfo<>());

		DataStream<Configuration> allOutputInfoDataStream = processOutputsAndAggregates(params, outputWriter, beaStream,
				runtimeMetrics);

		DataStream<Configuration> allRuntimeFailures = createRuntimeFailureStream(configOutputStream);
		deploymentsAndRuntimeFailuresIterativeStream.closeWith(convertFailuresToRemovals(allRuntimeFailures));

		DataStream<Boolean> periodicBooleanDataStream = createPeriodicBooleanDataStream(params, finiteSource, env);
		DataStream<Tuple2<String, Heartbeat>> heartbeatStream = createHeartbeatStream(params, finiteSource, backendId,
				periodicBooleanDataStream, env);

		// Union all the different processor infos (deployments, removals,
		// failures, data) into one stream
		DataStream<Configuration> allConfStream = initFailureStream.union(configOutputStream, allRuntimeFailures);

		if (allOutputInfoDataStream != null) {
			allConfStream = allConfStream.union(allOutputInfoDataStream);
		}

		DataStream<Tuple2<String, Either<JobSummary, Either<JobSummariesStart, JobSummariesEnd>>>> jobInfoOutputDataStream = createJobSummaryStream(
				params, finiteSource,
				backendId,
				env, allConfStream, periodicBooleanDataStream, baseProcessors);

		return new RBEAOutput(jobInfoOutputDataStream, configOutputStream.union(initFailureStream),
				beaStream, heartbeatStream);
		}else{
			DataStream<Configuration> allOutputInfoDataStream = processOutputsAndAggregates(params, outputWriter, beaStream,
					null);
			return new RBEAOutput(null, configOutputStream,
					beaStream, null);
		}
	}

	/**
	 * Creates a source that emits every second a Boolean true.
	 * 
	 * @return the created instance
	 */
	private static DataStream<Boolean> createPeriodicBooleanDataStream(ParameterTool params, boolean finiteSource,
			StreamExecutionEnvironment env) {
		if (finiteSource) {
			return env.addSource(new SleepingSource(params.getInt(BackendConstants.TEST_SOURCE_QUERY_SECS, 0)));
		} else {
			return env.addSource(new PeriodicBooleanSource(1000)).name("Periodic Boolean");
		}
	}

	/**
	 * Execute the actual output/aggregation.
	 * 
	 * @return Stream of processor info relating to outputs/aggregates. This
	 *         includes data info for the frontend or runtime failures.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private static DataStream<Configuration> processOutputsAndAggregates(ParameterTool params,
			OutputWriter outputWriter,
			SplitStream<BEA> coreOutput, DataStream<Aggregate> runtimeMetrics) {

		DataStream<Aggregate> aggregateInput = (DataStream) coreOutput.select(AGGREGATE_TAG);

		DataStream<Aggregate> aggregatorOutput = aggregateInput
				// Apply the windowing logic
				.keyBy(new KeySelector<Aggregate, Tuple4<Byte, String, String, Long>>() {
					private static final long serialVersionUID = 1L;

					@Override
					public Tuple4<Byte, String, String, Long> getKey(Aggregate value) throws Exception {
						return value.getWindowKey();
					}

				})
				.window(new AggregtionWindowAssigner())
				.allowedLateness(Time.hours(24))
				.reduce(Aggregate.REDUCER, new TimestampSetter())
				.returns(new BEATypeInfo<>())
				.name("Window aggregator")
				.uid("WindowAggregator-1.3.0")
				// In some casing when the watermarks are off we will get a
				// bunch of values for the same aggregate row, so we keep the
				// last every 5 seconds. This introduces some latency on the
				// aggregates though...
				.keyBy(new KeySelector<Aggregate, Tuple2<Tuple4<Byte, String, String, Long>, Long>>() {
					private static final long serialVersionUID = 1L;

					@Override
					public Tuple2<Tuple4<Byte, String, String, Long>, Long> getKey(Aggregate agg) throws Exception {
						return Tuple2.of(agg.getWindowKey(), agg.getTimestamp());
					}
				})
				.window(TumblingProcessingTimeWindows.of(Time.seconds(5)))
				.reduce(new ReduceFunction<Aggregate>() {
					private static final long serialVersionUID = 1L;

					@Override
					public Aggregate reduce(Aggregate b1, Aggregate b2) throws Exception {
						return b2;
					}
				})
				.name("Keep last")
				.uid("ProcTimeWindow-1.3.0");

		// We select the final output streams
		DataStream<KafkaOutput> kafkaOutput = (DataStream) coreOutput.select(KAFKA_TAG);

		DataStream<Configuration> allOutputInfo = writeOutput(params, outputWriter, kafkaOutput,
				aggregatorOutput, runtimeMetrics);

		return allOutputInfo;
	}

	/**
	 * Writes the different outputs Kafka/Aggregates to the respective systems.
	 * 
	 * @return The stream of data info that should be shown on the frontend for the
	 *         scripts.
	 */
	public static DataStream<Configuration> writeOutput(ParameterTool params, OutputWriter outputWriter,
			DataStream<KafkaOutput> kafkaOutput, DataStream<Aggregate> aggregatorOutput,
			DataStream<Aggregate> runtimeMetrics) {

		DataStream<Configuration> allOutputInfo = null;

		DataStream<KafkaOutput> aggrigatoStream = null;
		if (params.getBoolean(BackendConstants.WRITE_TO_AGGRIGATO, true)) {
			aggrigatoStream = (params.getBoolean(BackendConstants.WRITE_METRICS_TO_KAFKA, true)
					? aggregatorOutput.union(runtimeMetrics)
					: aggregatorOutput)
							.flatMap(new ToAggrigatoEvent(params.getRequired(BackendConstants.AGGRIGATO_TOPIC)))
							.name("Create Aggrigato events");
			allOutputInfo = aggregatorOutput.keyBy(bea -> ((Aggregate) bea).getName())
					.flatMap(new MySqlOutputDataMapper())
					.name("Aggregator output info");
		}

		DataStream<Configuration> kafkaDataInfo = outputWriter.writeKafkaOutput(params, kafkaOutput, aggrigatoStream);
		if (kafkaDataInfo != null) {
			allOutputInfo = allOutputInfo != null ? allOutputInfo.union(kafkaDataInfo) : kafkaDataInfo;
		}
		return allOutputInfo;
	}

	private static DataStream<Configuration> convertFailuresToRemovals(DataStream<Configuration> allFailures) {
		DataStream<Configuration> failureFeedback = allFailures
				.map(f -> {
					Removal removal = new Removal(((Failure) f).getProcessorId(), System.currentTimeMillis())
							.keepStateAfterRemoval();
					removal.propagate();
					return (Configuration) removal;
				})
				.setParallelism(1)
				.returns((new TypeHint<Configuration>() {}).getTypeInfo())
				.name("Failure to Removal");

		return failureFeedback;
	}

	private static DataStream<Configuration> createRuntimeFailureStream(DataStream<Configuration> procInfo) {
		DataStream<Configuration> processorFailures = procInfo
				.filter(i -> i instanceof Failure)
				.name("Filter Failures");
		return processorFailures;
	}

	/**
	 * Creates a {@link DataStream} that is connected to
	 * {@code allProcInfoDataStream} and a source that creates dummy
	 * <code>Boolean</code> objects.
	 * <p>
	 * The created {@link DataStream} outputs info about jobs, see
	 * {@link JobInfoQueryable} for details.
	 * 
	 * @param params
	 * @param finiteSource
	 *            if true, uses a source that eventually terminates. If false, uses
	 *            a source that runs "forever".
	 * @param topic
	 *            the Kafka topic to produce to
	 * @param env
	 *            the Flink env
	 * @param allProcInfoDataStream
	 *            the DataStream to connect to
	 * @return the new DataStream
	 */
	private static DataStream<Tuple2<String, Either<JobSummary, Either<JobSummariesStart, JobSummariesEnd>>>> createJobSummaryStream(
			ParameterTool params,
			boolean finiteSource, String backendId, StreamExecutionEnvironment env,
			DataStream<Configuration> allProcInfoDataStream, DataStream<Boolean> periodicBooleanDataStream,
			List<Deployment> baseProcs) {

		ProxyExecutorFactory pef = ProxyExecutorFactory.builder().build();

		Map<Long, JobSummary> baseSummaries = baseProcs.stream().map(Unchecked.function(dep -> {
			EventProcessor processor = dep.getProcessor(pef);
			processor.initialize(new DummyRegistry(), null);
			dep.updateWithProcInfo(processor.getInfo().get());
			JobSummary summary = new JobSummary(dep.getProcessorId());
			dep.setTopic(backendId);
			dep.mergeToSummary(summary);
			return summary;
		})).collect(Collectors.toMap(JobSummary::getProcessorId, sum -> sum));

		SingleOutputStreamOperator<Tuple2<String, Either<JobSummary, Either<JobSummariesStart, JobSummariesEnd>>>> jobInfoOut = allProcInfoDataStream
				.connect(periodicBooleanDataStream)
				.flatMap(new JobInfoQueryable(backendId, baseSummaries)).name("Create Job information")
				.uid(params.get(BackendConstants.DEPLOYMENT_STATE_NAME, "") + "JobInfoQueryable")
				.setParallelism(1);

		return jobInfoOut;
	}

	/**
	 * Creates a DataStream with a {@link HeartbeatCreator}.
	 *
	 * @param periodicBooleanDataStream
	 *
	 * @return the DataStream
	 */
	private static DataStream<Tuple2<String, Heartbeat>> createHeartbeatStream(ParameterTool params,
			boolean finiteSource, String backendId, DataStream<Boolean> periodicBooleanDataStream,
			StreamExecutionEnvironment env) {
		return periodicBooleanDataStream.flatMap(new HeartbeatCreator(backendId)).uid("Create heartbeat")
				.setParallelism(1);
	}
}
