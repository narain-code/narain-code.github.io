package com.king.rbea.backend.types.bea;

import org.apache.flink.api.common.ExecutionConfig;
import org.apache.flink.api.common.typeutils.TypeSerializer;
import org.apache.flink.api.java.typeutils.TypeExtractor;

import com.king.rbea.backend.utils.BackendConstants;

/**
 * {@code SumAggregate} is a {@link BEA} that sums.
 */
public class SumAggregate extends Aggregate {
	private static final long serialVersionUID = 1L;
	
	public static final TypeSerializer<SumAggregate> serializer = TypeExtractor.getForClass(SumAggregate.class)
			.createSerializer(new ExecutionConfig());

	public long value;

	public SumAggregate(long processorId, long windowSizeMillis, String aggregatorName, String dimensions, Long value) {
		super(BackendConstants.BEA_LONG_AGGREGATE_TYPE, windowSizeMillis, processorId, aggregatorName, dimensions);
		this.value = value;
	}

	public SumAggregate() {
		// Empty constructor for deserialization
	}

	public Long getValue() {
		return value;
	}

	@Override
	public void update(Aggregate sum) {
		value += (Long) sum.getValue();
	}

	@Override
	public long getLongValue() {
		return getValue();
	}
}