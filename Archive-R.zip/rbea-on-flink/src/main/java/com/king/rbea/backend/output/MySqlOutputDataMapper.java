package com.king.rbea.backend.output;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.util.Collector;

import com.king.rbea.backend.types.bea.Aggregate;
import com.king.rbea.backend.utils.BackendConstants;
import com.king.rbea.configuration.Configuration;
import com.king.rbea.configuration.processor.OutputInfo;
import com.king.rbea.utils.Constants;

public class MySqlOutputDataMapper implements FlatMapFunction<Aggregate, Configuration> {

	private static final long serialVersionUID = 1L;
	Map<Long, Set<String>> tables = new HashMap<>();

	@Override
	public void flatMap(Aggregate agg, Collector<Configuration> out) throws Exception {
		long procId = agg.getProcessorId();

		if (procId == BackendConstants.DUMMY_PROC_ID) {
			return;
		}

		String tableName = agg.getName();

		Set<String> currTables = tables.getOrDefault(procId, new HashSet<>());
		if (currTables.add(tableName)) {
			out.collect(new OutputInfo(procId, tableName, Constants.MYSQL,
					Collections.singletonMap(Constants.MYSQL_TABLE_NAME, tableName)));
			tables.put(procId, currTables);
		}
	}
}
