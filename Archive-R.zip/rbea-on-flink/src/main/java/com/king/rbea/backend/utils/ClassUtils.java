package com.king.rbea.backend.utils;

import java.net.URL;
import java.net.URLClassLoader;

import com.king.rbea.EventProcessor;

public class ClassUtils {

	@SuppressWarnings({ "resource", "unchecked" })
	public static EventProcessor getProcessor(URL url, String procClass) throws Exception {
		ClassLoader cl = new URLClassLoader(new URL[] { url }, Thread.currentThread().getContextClassLoader());
		Class<EventProcessor> clazz = (Class<EventProcessor>) cl.loadClass(procClass);
		return clazz.newInstance();
	}
}
