package com.king.rbea.backend.batch;

import org.apache.avro.Schema;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.generic.GenericRecordBuilder;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.king.rbea.backend.RBEAFlinkBackend;
import com.king.rbea.backend.output.OutputWriter;
import com.king.rbea.backend.types.bea.KafkaOutput;
import com.king.rbea.backend.utils.BackendConstants;
import com.king.rbea.configuration.Configuration;
import com.king.rbea.state.export.AvroDateTimeBucketer;
import com.king.rbea.state.export.FlinkAvroWriter;
import com.king.rbea.state.export.HiveTableManager;
import com.king.rbea.state.export.RBEABucketingSink;
import com.king.rbea.state.export.ReadRecordBytes;
import com.king.rbea.state.export.ReadSchema;
import com.king.rbea.state.export.StateExportOperator;

public enum FileWriter implements OutputWriter {

	INSTANCE;

	public static final String EXPORT_BATCH_SIZE = "exportBatchSize";
	public static final String EXPORT_BUCKET_SIZE_MINUTES = "exportBucketSizeMinutes";
	public static final String EXPORT_BASE_PATH = "exportBasePath";
	public static final String HIVE_CONNECTION_STRING = "hiveConnectionString";


	private static final String schemaStr = "{\n" +
			"  \"namespace\": \"com.king.avro\",\n" +
			"  \"name\": \"aggSerializer\",\n" +
			"  \"type\": \"record\",\n" +
			"  \"fields\": [" +
			"{ \"name\":\"value\",\"type\":\"string\"}" +
			"  ] }";
	public static final Schema sch = Schema.parse(schemaStr);

	@Override
	public SingleOutputStreamOperator<Configuration> writeKafkaOutput(ParameterTool params,
			DataStream<KafkaOutput> kafkaOutput, DataStream<KafkaOutput> mysqlOutput) {

		DataStream<KafkaOutput> allKafkaOutput = mysqlOutput != null ? kafkaOutput.union(mysqlOutput)
				: kafkaOutput;

		DataStream<byte[]> rawExportStream = allKafkaOutput.flatMap(new FlatMapFunction<KafkaOutput, byte[]>() {

			@Override
			public void flatMap(KafkaOutput value, Collector<byte[]> out) throws Exception {

				if (value.topic.contains("export")) {
					out.collect(value.bytes);

				}

			}

		});

		DataStream<byte[]> rawSchemaStream = allKafkaOutput.flatMap(new FlatMapFunction<KafkaOutput, byte[]>() {

			@Override
			public void flatMap(KafkaOutput value, Collector<byte[]> out) throws Exception {
				if (value.topic.contains("schema")) {
					out.collect(value.bytes);
				}

			}

		});
		DataStream<Tuple2<Long, Schema>> schemaStream = rawSchemaStream.flatMap(new ReadSchema()).name("Read schema");
		DataStream<Tuple2<String, byte[]>> exportStream = rawExportStream.flatMap(new ReadRecordBytes())
				.name("Read record bytes");

		DataStream<GenericRecord> avroRecords = schemaStream.broadcast().connect(exportStream)
				.transform("Deserialize Avro records", TypeInformation.of(GenericRecord.class),
						new StateExportOperator(params))
				.uid("deserialize");

		String basePath = params.get(EXPORT_BASE_PATH);
		RBEABucketingSink<GenericRecord> sink = new RBEABucketingSink<>(basePath + "/final", basePath + "/uncommitted");
		sink.setCommitWithoutChkpoint();
		sink.setBucketer(new AvroDateTimeBucketer(params.getInt(EXPORT_BUCKET_SIZE_MINUTES, 5)));
		sink.setBatchSize(params.getLong(EXPORT_BATCH_SIZE, RBEABucketingSink.DEFAULT_BATCH_SIZE));
		sink.setWriter(new FlinkAvroWriter());
		// sink.setCommitCallback(new
		// HiveTableManager(params.get(HIVE_CONNECTION_STRING), basePath));

		avroRecords.addSink(sink).uid("bucketsink").name("Bucketing file sink");
		final String aggTopic = params.getRequired(BackendConstants.AGGRIGATO_TOPIC);

		DataStream<GenericRecord> rawAggStream = allKafkaOutput
				.flatMap(new FlatMapFunction<KafkaOutput, GenericRecord>() {

					@Override
					public void flatMap(KafkaOutput value, Collector<GenericRecord> out) throws Exception {
						GenericData.Record r = new GenericData.Record(sch);
						r.put("value", new String(value.bytes));
						out.collect(r);

					}

				});

		RBEABucketingSink<GenericRecord> aggsink = new RBEABucketingSink<>(basePath + "/agg-final",
				basePath + "/agg-uncommitted");
		aggsink.setCommitWithoutChkpoint();
		aggsink.setBucketer(new AvroDateTimeBucketer(params.getInt(EXPORT_BUCKET_SIZE_MINUTES, 5)));
		aggsink.setBatchSize(params.getLong(EXPORT_BATCH_SIZE, RBEABucketingSink.DEFAULT_BATCH_SIZE));
		aggsink.setWriter(new FlinkAvroWriter());
		rawAggStream.addSink(aggsink).uid("aggbucketsink").name("Bucketing Agg file sink");

		return null;

	}

}
