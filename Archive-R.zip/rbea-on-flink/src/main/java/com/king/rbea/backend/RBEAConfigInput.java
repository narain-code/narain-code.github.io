package com.king.rbea.backend;

import static com.king.rbea.utils.Constants.JOB_DEPLOYMENT_TOPIC;

import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.sink.SinkFunction;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer010;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumerBase;
import org.apache.flink.types.Either;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.king.flink.utils.types.EitherUtils;
import com.king.rbea.backend.configuration.KafkaParams;
import com.king.rbea.backend.operators.MaxWatermark;
import com.king.rbea.backend.utils.BackendConstants;
import com.king.rbea.configuration.ConfigSerializationSchema;
import com.king.rbea.configuration.Configuration;

public class RBEAConfigInput {

	private static final Logger LOG = LoggerFactory.getLogger(RBEAConfigInput.class);

	public static DataStream<Configuration> getEventStream(ParameterTool params,
			KafkaParams kp, StreamExecutionEnvironment env) {

		String configInputTopic = params.getRequired(JOB_DEPLOYMENT_TOPIC) + kp.topicSuffix;

		FlinkKafkaConsumerBase<Either<Configuration, Throwable>> c = new FlinkKafkaConsumer010<Either<Configuration, Throwable>>(
				configInputTopic, ConfigSerializationSchema.INSTANCE, kp.getKafkaProps());

		c.setStartFromLatest();
		DataStream<Either<Configuration, Throwable>> source = env.addSource(c)
				.uid(params.get(BackendConstants.DEPLOYMENT_SOURCE_UID, "DeploymentInfoSource3"))
				.name("Kafka[" + configInputTopic + "]")
				.setParallelism(1)
				.assignTimestampsAndWatermarks(new MaxWatermark<>())
				.name("Max watermark").setParallelism(1);

		source.addSink(new SinkFunction<Either<Configuration,Throwable>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void invoke(Either<Configuration, Throwable> e) throws Exception {
				if (e.isRight()) {
					LOG.error("Received invalid deployment message", e.right());
				}				
			}
		}).setParallelism(1).name("Log errors");

		return source.flatMap(new EitherUtils.ProjectLeft<>(new TypeHint<Configuration>() {}.getTypeInfo()))
				.name("Drop errors")
				.setParallelism(1);
	}
}
