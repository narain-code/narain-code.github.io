package com.king.rbea.backend.batch;

import java.io.File;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Collectors;

import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.mapreduce.Job;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HadoopFileWrapper implements FileWrapper{
	
	
	protected static final Logger LOG = LoggerFactory.getLogger(HadoopFileWrapper.class);
	
	
	public HadoopFileWrapper(){
		
	}
	
	private FileStatus fs;
	
	public HadoopFileWrapper(FileStatus fs){
		this.fs = fs;
	}
	

	@Override
	public List<FileWrapper> getSplitDirectories(String path) {
		try{
		  Job job = Job.getInstance();
		  int index = path.indexOf("*");
		  FileSystem fs;
		  Path inp = new Path(path);
		  FileStatus[] all;
		  if(index>-1){
			  String beforeGlob = path.substring(0,index);
			  LOG.info(beforeGlob);
			  Path beforeGlobPath = new Path(beforeGlob);
			  LOG.info(beforeGlobPath.getName());
			  fs=beforeGlobPath.getFileSystem(job.getConfiguration());
			  LOG.info("got filesystem");
			  //File status are implementing comparable
			  all=fs.globStatus(inp);
			  Arrays.sort(all);
		  }else{
			  fs = inp.getFileSystem(job.getConfiguration());
			  all = fs.listStatus(inp);
		  }
		 
		 
	   
	      LOG.info("got list");
	      List<FileWrapper> fws =Arrays.asList(all).stream().filter(f->f.getPath().toString().endsWith(".gz")).map(f->new HadoopFileWrapper(f)).collect(Collectors.toList());
	      return fws;
		}catch(Exception ex){
			LOG.error(ex.getMessage());
			
			throw new RuntimeException("Unable to create hadoop wrappers" + ex.getMessage());
		}
		  
	}

	@Override
	public void consume(Consumer<String> consume) {
		try{
		Job job = Job.getInstance();
		Path inp = fs.getPath();
		FileSystem fs = inp.getFileSystem(job.getConfiguration());
		Path tgt =new Path("file:///"+System.getProperty("java.io.tmpdir"));
		LOG.info(tgt + " " + inp);
		fs.copyToLocalFile( inp, tgt);
		LOG.info("copied file to " + tgt.toUri().getPath() );
		/*for(String fName: new File(tgt.toUri().getPath()).list()){
			LOG.info("list file to " + fName );
		}*/
		File[] all =FileUtils.getGzipFiles(tgt.toUri().getPath());
		//LOG.info("gzip " + all.length );
		Arrays.asList(all).stream().forEach(f->{
		FileUtils.decompressGzipFile(f, consume);
		LOG.info("finished with "+f.getName());
		try {
			Files.delete(f.toPath());
		} catch (Exception e) {
			LOG.error(e.getCause().getMessage());
			e.printStackTrace();
		}
		});
		;
		}catch(Exception ex){
			ex.printStackTrace();
			
		}
		
	}

	

}
