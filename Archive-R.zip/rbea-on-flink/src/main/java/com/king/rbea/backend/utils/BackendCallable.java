package com.king.rbea.backend.utils;

import com.king.rbea.exceptions.BackendException;

public interface BackendCallable<T> {
	T call() throws BackendException;
}