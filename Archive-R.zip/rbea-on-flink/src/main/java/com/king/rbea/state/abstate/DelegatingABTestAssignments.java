package com.king.rbea.state.abstate;

import com.king.rbea.state.basefields.ABTestAssignments;

public class DelegatingABTestAssignments implements ABTestAssignments {

	private final ABTestAssignments assignments;

	public DelegatingABTestAssignments(ABTestAssignments assignments) {
		this.assignments = assignments;
	}

	@Override
	public Integer getCaseNum(String abTestName, Integer version) {
		return assignments.getCaseNum(abTestName, version);
	}

	@Override
	public Integer getLastCaseNum(String abTestName) {
		return assignments.getLastCaseNum(abTestName);
	}

	@Override
	public Integer getLastVersion(String abTestName) {
		return assignments.getLastVersion(abTestName);
	}

}
