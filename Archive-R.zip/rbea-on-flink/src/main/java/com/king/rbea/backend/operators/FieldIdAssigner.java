package com.king.rbea.backend.operators;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.api.common.typeutils.TypeSerializer;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.checkpoint.ListCheckpointed;
import org.apache.flink.util.InstantiationUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.king.rbea.EventProcessor;
import com.king.rbea.Registry;
import com.king.rbea.configuration.Configuration;
import com.king.rbea.configuration.processor.Deployment;
import com.king.rbea.configuration.processor.DeploymentWithFields;
import com.king.rbea.configuration.processor.Failure;
import com.king.rbea.configuration.processor.Notification;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.scripts.ProcessorFactory;
import com.king.rbea.scripts.proxy.ProxyExecutorFactory;
import com.king.rbea.state.LocalState;
import com.king.rbea.state.StateDescriptor;

/**
 * {@code FieldIdAssigner} is a part of the RBEA Flink job responsible for
 * mapping {@link Deployment}-objects to {@link DeploymentWithFields}-objects
 * and handling errors if the creation of the object fails.
 */
public class FieldIdAssigner extends RichMapFunction<Configuration, Configuration>
		implements ListCheckpointed<Short> {

	private static final long serialVersionUID = 1L;
	private static final Logger LOG = LoggerFactory.getLogger(FieldIdAssigner.class);

	private transient ProcessorFactory processorFactory;

	private Short nextId = 0;

	@Override
	public Configuration map(Configuration info) throws Exception {
		if (info instanceof Deployment) {
			Deployment dep = (Deployment) info;
			short oldNextId = nextId;
			try {
				return new DeploymentWithFields(dep, createFieldMapping(dep));
			} catch (ProcessorException e) {
				LOG.error("Error during field id assignments", e);
				nextId = oldNextId;
				Failure failure = new Failure(dep.getProcessorId(), e,
						dep.getString(Deployment.SCRIPT_TEXT_KEY).orElse(null),
						System.currentTimeMillis());
				return dep.isUpdate()
						? new Notification(dep.getProcessorId(), "Update error: " + failure.getCause())
						: failure.withDeployment(dep);
			}
		} else {
			return info;
		}
	}

	private Map<String, Tuple2<Short, TypeSerializer<?>>> createFieldMapping(Deployment dep) throws ProcessorException {
		Map<String, Tuple2<Short, TypeSerializer<?>>> mapping = new HashMap<>();
		FieldAssigner reg = new FieldAssigner(mapping, dep.getProcessorId());

		EventProcessor executor = null;
		try {
			executor = dep.getProcessor(processorFactory);
			executor.initialize(reg, null);
			executor.getInfo().ifPresent(dep::updateWithProcInfo);
		} catch (ProcessorException pe) {
			throw pe;
		} catch (Throwable e) {
			throw new ProcessorException(e);
		} finally {
			if (executor != null) {
				try {
					executor.close();
				} catch (Exception e) {
					throw new ProcessorException(dep.getProcessorId(), e, "Failed to close");
				}
			}
		}

		for (Entry<String, Tuple2<Short, TypeSerializer<?>>> entry : mapping.entrySet()) {
			TypeSerializer<?> serializer = entry.getValue().f1;
			try {
				// Ensure type is serializable with user code classloader
				InstantiationUtil.deserializeObject(
						InstantiationUtil.serializeObject(serializer),
						getRuntimeContext().getUserCodeClassLoader());
			} catch (Throwable e) {
				entry.getValue().f1 = null;
			}
		}

		if (mapping.size() >= 50) {
			throw new ProcessorException(
					"Maximum number of states per scripts is currently set to 50. If this is a problem please to talk to us about it.");
		}

		return mapping;
	}

	public void setProcessorFactory(ProcessorFactory factory) {
		this.processorFactory = factory;
	}

	@Override
	public void open(org.apache.flink.configuration.Configuration conf) {
		if (getRuntimeContext().getNumberOfParallelSubtasks() != 1) {
			throw new RuntimeException("This operator must run with dop = 1");
		}
		// The FieldIdAssigner is serializable, so dependencies get initialized here
		setProcessorFactory(ProxyExecutorFactory.builder().build());
	}

	@Override
	public void restoreState(List<Short> nextIdState) throws Exception {
		if (nextIdState.size() > 1) {
			throw new RuntimeException("Received more than one state, weird...");
		}
		if (nextIdState.size() == 1) {
			nextId = nextIdState.get(0);
			LOG.info("Restoring next user field id: {}", nextId);
		} else {
			LOG.info("Cannot find any field state, resetting");
		}
	}

	@Override
	public List<Short> snapshotState(long arg0, long arg1) throws Exception {
		LOG.info("Next field id: {} Number of remaining field ids: {}", nextId, (Short.MAX_VALUE - nextId));
		return Collections.singletonList(nextId);
	}

	private class FieldAssigner implements Registry {

		private Map<String, Tuple2<Short, TypeSerializer<?>>> mapping;
		private long procId;

		public FieldAssigner(Map<String, Tuple2<Short, TypeSerializer<?>>> mapping, long procId) {
			this.mapping = mapping;
			this.procId = procId;
		}

		@Override
		public <T> StateDescriptor<T> registerState(LocalState<T> field) throws ProcessorException {
			String fieldName = field.getStateName() + procId;
			if (mapping.containsKey(fieldName)) {
				throw new ProcessorException("Cannot register 2 states with the same name: " + fieldName);
			}
			TypeSerializer<?> serializer = field.getSerializer();
			if (serializer == null) {
				throw new ProcessorException(procId,
						"Missing field type. withType(class) or initial value must be used.");
			}
			mapping.put(fieldName, Tuple2.of(++nextId, serializer));
			return field;
		}

		@Override
		public void registerStateDependency(long rbeaJobId, String fieldName) {}
	}

}
