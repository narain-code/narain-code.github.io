package com.king.rbea.state.abstate;

import java.io.Serializable;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.king.constants.external.EventType;
import com.king.constants.external.event.typed.events.RbeaStateUpdate;
import com.king.kgk.SCAbTestCaseAssignedServer;
import com.king.rbea.Registry;
import com.king.rbea.State;
import com.king.rbea.annotations.Initialize;
import com.king.rbea.annotations.ProcessEvent;
import com.king.rbea.configuration.processor.Deployment;
import com.king.rbea.exceptions.ProcessorException;
import com.king.rbea.state.LocalState;
import com.king.rbea.state.StateDescriptor;

public class ABTestBaseProcessor implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final Logger LOG = LoggerFactory.getLogger(ABTestBaseProcessor.class);

	public static final String AB_ASSIGNMENTS_FIELD_NAME = "AB_TEST_ASSIGNMENTS_3";
	public static final String AB_ASSIGNMENT_BACKFILL_KEY = "AB_TEST_ASSIGNMENTS_BACKFILL_3";

	private static final ObjectMapper mapper = new ObjectMapper();

	public static final Deployment DEPLOYMENT = Deployment.newJavaProcessor("ABTestBaseProcessor",
			Long.MAX_VALUE - 6666, new ABTestBaseProcessor(), "", 0l, false);

	private StateDescriptor<ABTestAssignmentsNew> abState;

	@ProcessEvent(semanticClass = SCAbTestCaseAssignedServer.class)
	public void process(State state, SCAbTestCaseAssignedServer assignment) throws ProcessorException {
		ABTestAssignmentsNew assignments = state.get(abState);
		assignments.update(assignment.getAbTestName(), assignment.getAbTestVersion(), assignment.getCaseNum());
		state.update(abState, assignments);
	}

	@ProcessEvent(eventType = EventType.RbeaStateUpdate)
	public void backFill(RbeaStateUpdate stateUpdate, State state) throws ProcessorException {
		String key = stateUpdate.getKey();
		String value = stateUpdate.getValue();

		if (key.equals(AB_ASSIGNMENT_BACKFILL_KEY)) {
			ABTestAssignmentsNew assignments = state.get(abState);

			Assignment[] abBackFill;
			try {
				abBackFill = mapper.readValue(value, Assignment[].class);
			} catch (Throwable e) {
				LOG.warn("Unable to process AB test backfill value: {}", value);
				return;
			}

			for (Assignment abTest : abBackFill) {
				if (abTest.name == null || abTest.casenum == null || abTest.version == null) {
					LOG.warn("Empty AB test field in {}", value);
				} else if (assignments.getLastVersion(abTest.name) == null ||
						abTest.version > assignments.getLastVersion(abTest.name)) {
					assignments.update(abTest.name, abTest.version, abTest.casenum);
				}
			}
			state.update(abState, assignments);
		}
	}

	@Initialize
	public void init(Registry reg) throws ProcessorException {
		abState = reg.registerState(ABState());
	}

	public static LocalState<ABTestAssignmentsNew> ABState() {
		return LocalState.create(AB_ASSIGNMENTS_FIELD_NAME, ABTestAssignmentsNew.class)
				.withInitializer(c -> new ABTestAssignmentsNew(new HashMap<>()))
				.withType(new ABTestAssingmentsTypeInfo());
	}

	public static class Assignment {
		public String name;
		public Integer version;
		public Integer casenum;
	}
}
