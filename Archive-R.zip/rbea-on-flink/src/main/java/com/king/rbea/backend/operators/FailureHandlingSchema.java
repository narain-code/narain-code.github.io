package com.king.rbea.backend.operators;

import java.nio.charset.StandardCharsets;

import org.apache.flink.api.common.serialization.DeserializationSchema;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.king.event.Event;
import com.king.event.format.EventFormat;
import com.king.flink.utils.CustomEvent;
import com.king.flink.utils.events.LazyEventFormat;
import com.king.flink.utils.types.EventTypeInfo;

public enum FailureHandlingSchema implements DeserializationSchema<Event> {

	INSTANCE;

	public static final EventFormat eventFormat = new LazyEventFormat();
	public static final Logger LOG = LoggerFactory.getLogger(FailureHandlingSchema.class);

	public static final long PARSE_ERROR_TYPE = -666;

	@Override
	public TypeInformation<Event> getProducedType() {
		return new EventTypeInfo();
	}

	@Override
	public Event deserialize(byte[] bytes) {
		String s = new String(bytes, StandardCharsets.UTF_8);
		try {
			Event e = eventFormat.parse(s);
			// Trigger full event parse to catch errors early
			e.getFlavourId();
			return e;
		} catch (Exception e) {
			LOG.error("Could not parse event: " + s, e);
			return CustomEvent.create(PARSE_ERROR_TYPE).withTimeStamp(0);
		}
	}

	@Override
	public boolean isEndOfStream(Event event) {
		return false;
	}
}
