package com.king.rbea.backend.types.bea;

import java.io.Serializable;

import org.apache.flink.api.common.typeutils.TypeSerializer;

import com.king.rbea.backend.utils.BackendConstants;

/**
 * {@code BEA} is base/container class for easily passing objects of related but
 * different classes around. The class of contained instance is identified by
 * {@link #type}. Type is needed e.g. when deserializing
 * ({@link BEASerializer#deserialize(org.apache.flink.core.memory.DataInputView)}).
 */
public abstract class BEA implements Serializable {
	private static final long serialVersionUID = 1L;

	public byte type;
	public long procId;

	/**
	 * Constructs a BEA.
	 * 
	 * @param type
	 *            uniquely identifies the type of BEA,
	 * @param procId
	 */
	protected BEA(byte type, long procId) {
		this.type = type;
		this.procId = procId;
	}

	public BEA() {
		// Empty constructor for deserialization
	}

	public byte getType() {
		return type;
	}

	public long getProcessorId() {
		return procId;
	}

	@SuppressWarnings("unchecked")
	public static <B extends BEA> TypeSerializer<B> getSerializerForType(byte type) {
		switch (type) {
		case BackendConstants.BEA_LONG_AGGREGATE_TYPE:
			return (TypeSerializer<B>) SumAggregate.serializer;
		case BackendConstants.BEA_KAFKA_OUTPUT_TYPE:
			return (TypeSerializer<B>) KafkaOutput.serializer;
		case BackendConstants.BEA_RATIO_AGGREGATE_TYPE:
			return (TypeSerializer<B>) RatioAggregate.serializer;
		case BackendConstants.BEA_HLL_AGGREGATE_TYPE:
			return (TypeSerializer<B>) HLLAggregate.serializer;
		default:
			throw new RuntimeException("Unknown type: " + type);
		}
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (procId ^ (procId >>> 32));
		result = prime * result + type;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof BEA)) {
			return false;
		}
		BEA other = (BEA) obj;
		if (procId != other.procId) {
			return false;
		}
		if (type != other.type) {
			return false;
		}
		return true;
	}
}
