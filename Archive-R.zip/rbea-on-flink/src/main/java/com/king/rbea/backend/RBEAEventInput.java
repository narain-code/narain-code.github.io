package com.king.rbea.backend;

import static com.king.rbea.backend.utils.BackendConstants.BACKEND_TOPIC;
import static com.king.rbea.backend.utils.BackendConstants.SOURCE_PARALLELISM;
import static com.king.rbea.backend.utils.BackendConstants.WATERMARKS_PER_PARTITION;
import static com.king.rbea.backend.utils.BackendConstants.WATERMARK_BUCKET_SIZE;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.AssignerWithPeriodicWatermarks;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.king.constants.external.EventType;
import com.king.event.Event;
import com.king.flink.utils.source.BucketMinWatermark;
import com.king.flink.utils.source.Kafka;
import com.king.rbea.backend.configuration.KafkaParams;
import com.king.rbea.backend.operators.FailureHandlingSchema;
import com.king.rbea.backend.operators.InputThrottler;
import com.king.rbea.backend.operators.MaxWatermark;
import com.king.rbea.backend.operators.PartitionKey;
import com.king.rbea.backend.types.EventWrapper;
import com.king.rbea.backend.utils.BackendConstants;

public class RBEAEventInput {

	private static final Logger LOG = LoggerFactory.getLogger(RBEAEventInput.class);

	public static DataStream<EventWrapper> getEventStream(ParameterTool params, KafkaParams kp,
			StreamExecutionEnvironment env) {

		List<String> inputTopics = Arrays.asList(params.getRequired(BACKEND_TOPIC).split(","));
		if (inputTopics.isEmpty()) {
			throw new RuntimeException("Cannot parse input topics");
		}
		int sourceParallelism = params.getInt(SOURCE_PARALLELISM, env.getParallelism());

		PartitionKey partitionKey = PartitionKey
				.valueOf(params.get(BackendConstants.PARTITION_KEY, PartitionKey.CUID.name()));

		LOG.info("Using partition key: " + partitionKey);

		MapFunction<Event, EventWrapper> eventWrapper = partitionKey.getEventWrapper();

		// Creates the events streams
		// 1. the stream for the events
		AssignerWithPeriodicWatermarks<Event> assigner = new BucketMinWatermark(params.getInt(WATERMARK_BUCKET_SIZE));
		boolean watermarksPerPartition = params.getBoolean(WATERMARKS_PER_PARTITION, true);
		LOG.info("Input topics: {}", inputTopics);
		DataStream<EventWrapper> eventsDataStream = Kafka.readEvents(kp.kafkaBroker, kp.zkHost,
				kp.groupId, inputTopics, env, assigner, watermarksPerPartition,
				sourceParallelism, "EventSourceIncognito", FailureHandlingSchema.INSTANCE, "KafkaEventInput")
				.filter(e -> e.getEventType() != FailureHandlingSchema.PARSE_ERROR_TYPE)
				.setParallelism(sourceParallelism)
				.name("Drop parse errors")
				.map(eventWrapper)
				.name("Wrap events")
				.setParallelism(sourceParallelism);

		boolean stateFeedInEnabled = params.getBoolean(BackendConstants.STATE_FEED_IN_ENABLED, true);
		String feedinTopic = stateFeedInEnabled && inputTopics.size() > 1
				? params.getRequired(BackendConstants.STATE_FEED_TOPIC)
				: params.get(BackendConstants.STATE_FEED_TOPIC, "rbea.state." + inputTopics.get(0));

		if (stateFeedInEnabled) {
			LOG.info("Feed in topic: {}", feedinTopic);
			// 2. the stream for the states, {@link EventType.RbeaStateUpdate}
			DataStream<EventWrapper> stateEventsDataStream = Kafka.readEvents(kp.kafkaBroker, kp.zkHost,
					kp.groupId, Collections.singletonList(feedinTopic), env, new MaxWatermark<>(), false,
					sourceParallelism,
					"FeedInStateIncognito", FailureHandlingSchema.INSTANCE, "KafkaStateInput")
					.filter(e -> e.getEventType() == EventType.RbeaStateUpdate)
					.setParallelism(sourceParallelism)
					.name("Filter state updates")
					.map(eventWrapper)
					.name("Wrap events")
					.setParallelism(sourceParallelism);

			if (params.getBoolean(BackendConstants.THROTTLE_FEEDBACK, true)) {
				stateEventsDataStream = stateEventsDataStream
						.filter(new InputThrottler<>(params.getInt(BackendConstants.MAX_FEEDBACK_PER_SEC, 17_000)))
						.setParallelism(sourceParallelism)
						.name("Throttle input");
			}

			return eventsDataStream.union(stateEventsDataStream);
		} else {
			return eventsDataStream;
		}
	}
}
