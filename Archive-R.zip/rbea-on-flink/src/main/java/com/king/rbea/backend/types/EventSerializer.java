package com.king.rbea.backend.types;

import java.io.IOException;
import java.io.Serializable;

import org.apache.commons.lang3.SerializationUtils;

public enum EventSerializer implements Serializable {

	INSTANCE;

	public byte[] serialize(EventWrapper event) throws IOException {
		return SerializationUtils.serialize(event);
	}

	public EventWrapper deserialize(byte[] bytes) throws IOException {
		return SerializationUtils.deserialize(bytes);
	}
}
