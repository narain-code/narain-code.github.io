package com.king.rbea.backend.utils;

import java.util.Optional;

import com.king.rbea.EventProcessor;
import com.king.rbea.exceptions.BackendException;
import com.king.rbea.exceptions.ProcessorException;

public interface ProcessingFunction {
	Optional<ProcessorException> apply(long procId, EventProcessor proc) throws BackendException;
}