package com.king.rbea.backend.output;

import static com.king.rbea.backend.utils.BackendConstants.FORCE_JOB_SUMMARY_WRITE_TO_KAFKA;
import static com.king.rbea.backend.utils.BackendConstants.PRINT_JOB_SUMMARY_TO_STDOUT;
import static com.king.rbea.backend.utils.BackendConstants.WRITE_TO_KAFKA;
import static com.king.rbea.utils.Constants.DEFAULT_HEARTBEAT_OUTPUT_TOPIC;
import static com.king.rbea.utils.Constants.HEARTBEAT_OUTPUT_TOPIC;
import static com.king.rbea.utils.Constants.JOB_INFO_OUTPUT_TOPIC;

import java.util.Properties;

import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaProducer010;
import org.apache.flink.types.Either;

import com.king.rbea.backend.configuration.KafkaParams;
import com.king.rbea.backend.types.bea.BEA;
import com.king.rbea.configuration.Configuration;
import com.king.rbea.configuration.processor.Heartbeat;
import com.king.rbea.configuration.processor.HeartbeatSerializer;
import com.king.rbea.configuration.processor.JobSummariesEnd;
import com.king.rbea.configuration.processor.JobSummariesStart;
import com.king.rbea.configuration.processor.JobSummary;
import com.king.rbea.configuration.processor.JobSummarySerializer;
import com.king.rbea.configuration.processor.ProcessorInfo;

/**
 * {@code RBEAOutput} is container class for various results (currently
 * DataStream-objects) RBEA#run creates and returns.
 */
public class RBEAOutput {
	private final DataStream<Tuple2<String, Either<JobSummary, Either<JobSummariesStart, JobSummariesEnd>>>> jobInfoOutput;
	private final DataStream<Configuration> processorInfoOutput;
	private final DataStream<BEA> beaOutput;
	private final DataStream<Tuple2<String, Heartbeat>> heartbeatOutput;

	public RBEAOutput(DataStream<Tuple2<String, Either<JobSummary, Either<JobSummariesStart, JobSummariesEnd>>>> jobInfoOutput,
			DataStream<Configuration> processorInfoOutput,
			DataStream<BEA> beaOutput,
			DataStream<Tuple2<String, Heartbeat>> heartbeatOutput) {
		this.jobInfoOutput = jobInfoOutput;
		this.processorInfoOutput = processorInfoOutput;
		this.beaOutput = beaOutput;
		this.heartbeatOutput = heartbeatOutput;
	}

	/**
	 * Gets the {@link DataStream} having {@link JobSummary}-objects.
	 */
	public DataStream<Tuple2<String, Either<JobSummary, Either<JobSummariesStart, JobSummariesEnd>>>> getJobInfoOutput() {
		return jobInfoOutput;
	}

	/**
	 * Gets the {@link DataStream} having {@link Heartbeat}-objects.
	 */
	public DataStream<Tuple2<String, Heartbeat>> getHeartbeatOutput() {
		return heartbeatOutput;
	}

	/**
	 * Gets the {@link DataStream} having {@link ProcessorInfo}-objects.
	 */
	public DataStream<Configuration> getConfigurationOutput() {
		return processorInfoOutput;
	}

	/**
	 * Gets the {@link DataStream} having {@link BEA}-objects.
	 */
	public DataStream<BEA> getBeaOutput() {
		return beaOutput;
	}

	public void writeOutputStreams(ParameterTool params, KafkaParams kp) {
		boolean forceJobSummaryWriteToKafka = params.getBoolean(FORCE_JOB_SUMMARY_WRITE_TO_KAFKA, false);
		boolean printSummaries = params.getBoolean(PRINT_JOB_SUMMARY_TO_STDOUT, false);
		boolean writeToKafka = params.getBoolean(WRITE_TO_KAFKA, true);

		String jobInfoOutputTopic = params.getRequired(JOB_INFO_OUTPUT_TOPIC) + kp.topicSuffix;
		String heartbeatOutputTopic = params.get(HEARTBEAT_OUTPUT_TOPIC, DEFAULT_HEARTBEAT_OUTPUT_TOPIC) + kp.topicSuffix;
		
		// Optionally write to Kafka job summaries
		if (writeToKafka || forceJobSummaryWriteToKafka) {
			writeJobSummaryStreamToKafka(jobInfoOutputTopic, kp.getKafkaProps(), getJobInfoOutput());
		}
		
		if (writeToKafka) {
			writeHeartbeatStreamToKafka(heartbeatOutputTopic, kp.getKafkaProps(), getHeartbeatOutput());
		}

		// Optionally print job summaries to TM stdout
		if (printSummaries) {
			getJobInfoOutput().print().setParallelism(1).name("Print JobSummaries");
		}
	}

	/**
	 * Adds to {@code jobInfoOutput} {@link DataStream} a sink that writes to Kafka
	 * topic {@code jobInfoOutputTopic}.
	 * 
	 * @param jobInfoOutputTopic
	 *            the Kafka topic
	 * @param kafkaBroker
	 *            Kafka broker to connect to
	 * @param jobInfoOutput
	 *            the {@DataStream}
	 */
	private void writeJobSummaryStreamToKafka(String jobInfoOutputTopic, Properties properties,
			DataStream<Tuple2<String, Either<JobSummary, Either<JobSummariesStart, JobSummariesEnd>>>> jobInfoOutput) {
		properties.setProperty("flink.disable-metrics", "true");

		jobInfoOutput.addSink(new FlinkKafkaProducer010<>(jobInfoOutputTopic, JobSummarySerializer.INSTANCE, properties))
				.setParallelism(1).disableChaining()
				.uid("JobInfoSink")
				.name("Push to frontend");
	}
	
	/**
	 * Adds a Kafka sink that produces the heartbeat messages.
	 */
	private void writeHeartbeatStreamToKafka(String jobInfoOutputTopic, Properties properties, DataStream<Tuple2<String, Heartbeat>> heartbeatOutput) {
		heartbeatOutput.addSink(new FlinkKafkaProducer010<>(jobInfoOutputTopic, HeartbeatSerializer.INSTANCE, properties))
				.setParallelism(1).disableChaining()
				.uid("HeartbeatSink")
				.name("Push heartbeat to frontend");
	}

}