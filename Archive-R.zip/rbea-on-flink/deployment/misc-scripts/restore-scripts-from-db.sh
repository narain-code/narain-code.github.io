#!/bin/bash
set -o errexit

if [ "$#" -ne 1 ]; then
   echo "Must specify topic"
   exit 1
fi

java -cp rbea-on-flink-1.0-SNAPSHOT.jar com.king.rbea.manager.RedeployPreviouslyRunning backend/conf/rbea_general.properties $1
