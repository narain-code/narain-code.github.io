# RBEA on Flink

The programming guide can be found [here](https://github.int.midasplayer.com/SPLAT/rbea-api).

For diagnosing RBEA backend problems please refer to [this chart](https://github.int.midasplayer.com/SPLAT/rbea-on-flink/blob/master/deployment/yarn-prod/rbea_diagnostics.pdf).

## General info

All deploy scripts are found under `rbea-on-flink/deployment/` and should be executed from splat@deploy.sto.midasplayer.com.

Make sure you forward your ssh credentials with `-A` as some scripts might need to ssh to other servers as well.

## RBea Flink Backend

There are a bunch of convenience scripts for managing the different rbea backends for each environment (prod/dev/qa) and game.

Most of these scripts act based on some configuration properties set for the given environment that can be found under `rbea-on-flink/deployment/environments/(prod/dev/qa)`.

So for instance to change the properties for the candycrush backend on prod we would have to edit:
`rbea-on-flink/deployment/environemnts/prod/rbea-conf/backend/games/candycrush.props`

Many scripts require a `game` parameter. Games are defined under `rbea-on-flink/deployment/environemnts/(prod/qa/dev)/rbea-conf/backend/games/*.props`. So if there is a `candycrush.props` file there, `candycrush` is a valid game name.

### Managing RBEA Backends

The bea backends are running on one of our three hadoop environments:
 - [Production](http://splat3.sto.midasplayer.com:7180/cmf/home)
 - [QA](http://splat.qa.midasplayer.com:7180/cmf/home)
 - [DEV](http://splat.vm.dev.midasplayer.com:7180/cmf/home)

## RBea Manager

The manager has been moved to its own [git project](https://github.int.midasplayer.com/SPLAT/rbea-manager).
