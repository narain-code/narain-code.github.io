package com.calcite.query.file;

import java.util.HashMap;
import java.util.Map;

import org.apache.calcite.schema.Table;
import org.apache.calcite.schema.impl.AbstractSchema;

public class FileSchema extends AbstractSchema {
	
	 public FileSchema() {
		super();
	}
	
	@Override protected Map<String, Table> getTableMap() {
		Map<String,Table> allTables = new HashMap<String, Table>();
		
		allTables.put("TESTTABLE", new FileTable());
		
		return allTables;
	}

}
