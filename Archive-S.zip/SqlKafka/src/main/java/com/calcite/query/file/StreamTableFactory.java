package com.calcite.query.file;

import java.util.Map;

import org.apache.calcite.rel.type.RelDataType;
import org.apache.calcite.schema.SchemaPlus;
import org.apache.calcite.schema.TableFactory;

public class StreamTableFactory implements TableFactory<FileTable> {

	public FileTable create(SchemaPlus arg0, String arg1, Map<String, Object> arg2, RelDataType arg3) {
		// TODO Auto-generated method stub
		return null;
	}

}
