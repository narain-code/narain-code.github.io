package com.calcite.query.file;

import java.io.PrintStream;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import org.apache.calcite.linq4j.function.Function1;


public class FileAdapterTest {
	
	 private String resourcePath(String path) {
		    final URL url = FileAdapterTest.class.getResource("/" + path);
		    String s = url.toString();
		    if (s.startsWith("file:")) {
		      s = s.substring("file:".length());
		    }
		    return s;
		  }
	
	public static void main(String[] args){
		FileAdapterTest t = new FileAdapterTest();
		 Connection connection = null;
		    Statement statement = null;
		    try {
		      Properties info = new Properties();
		      info.put("model", t.resourcePath("smart.json"));
		      connection = DriverManager.getConnection("jdbc:calcite:", info);
		      statement = connection.createStatement();
		      final ResultSet resultSet =
		          statement.executeQuery(
		              "select testcolumn from TestTable");
		      t.output().apply(resultSet);
		    
		      
		      
		     statement.close();
		     connection.close();
		    }catch(Exception ex){
		    	ex.printStackTrace();
		    }
		    
		 
	}
	
	private void output(ResultSet resultSet, PrintStream out)
		      throws SQLException {
		    final ResultSetMetaData metaData = resultSet.getMetaData();
		    final int columnCount = metaData.getColumnCount();
		    while (resultSet.next()) {
		      for (int i = 1;; i++) {
		        out.print(resultSet.getString(i));
		        if (i < columnCount) {
		          out.print(", ");
		        } else {
		          out.println();
		          break;
		        }
		      }
		    }
		  }
	
	
	private Function1<ResultSet, Void> output() {
	    return new Function1<ResultSet, Void>() {
	      public Void apply(ResultSet resultSet) {
	        try {
	          output(resultSet, System.out);
	        } catch (SQLException e) {
	          throw new RuntimeException(e);
	        }
	        return null;
	      }
	    };
	  }

}
