package com.calcite.query.file;

import java.util.Arrays;
import java.util.Scanner;

public class Test {
	public static void main(String args[]){
	       Scanner in = new Scanner(System.in);
	        int n = in.nextInt();
	        int arr[] = new int[n];
	        for(int arr_i=0; arr_i < n; arr_i++){
	            arr[arr_i] = in.nextInt();
	        }
	        
	        Arrays.sort(arr, 0, arr.length);
	        int max = arr[arr.length-1] + 999;
	        int lengthOfCut = arr[0];
	        int sum = -1;
	        int cuts = 0;
	        while(sum != 0) {
	            cuts = 0;
	            sum = 0;
	            
	            for(int i=0; i < n; i++){
	                if(arr[i] == max) continue;
	                arr[i] = arr[i] - lengthOfCut;
	                if(arr[i] == 0) arr[i] = max;
	                ++cuts;
	                if(arr[i] != max) sum += arr[i];
	            }
	            Arrays.sort(arr, 0, arr.length);
	            lengthOfCut = arr[0];
	            System.out.println(cuts);
	        }
	}
}
