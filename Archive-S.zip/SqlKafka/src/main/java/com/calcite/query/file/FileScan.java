package com.calcite.query.file;




import org.apache.calcite.adapter.enumerable.EnumerableConvention;
import org.apache.calcite.adapter.enumerable.EnumerableRel;
import org.apache.calcite.adapter.enumerable.EnumerableRelImplementor;
import org.apache.calcite.adapter.enumerable.PhysType;
import org.apache.calcite.adapter.enumerable.PhysTypeImpl;
import org.apache.calcite.linq4j.tree.Blocks;
import org.apache.calcite.linq4j.tree.Expressions;
import org.apache.calcite.plan.RelOptCluster;
import org.apache.calcite.plan.RelOptTable;
import org.apache.calcite.rel.RelInput;
import org.apache.calcite.rel.core.TableScan;

public class FileScan extends TableScan implements EnumerableRel{

	final FileTable fileTable;
	final int[] fields;
	  
	protected FileScan(RelOptCluster cluster, RelOptTable table,
		      FileTable fileTable, int[] fields) {
		super(cluster, cluster.traitSetOf(EnumerableConvention.INSTANCE), table);
		this.fileTable =fileTable;
		this.fields=fields;
		
	}

	public Result implement(EnumerableRelImplementor implementor, Prefer pref) {
		PhysType physType =
		        PhysTypeImpl.of(
		            implementor.getTypeFactory(),
		            getRowType(),
		            pref.preferArray());

		    return implementor.result(
		        physType,
		        Blocks.toBlock(
		            Expressions.call(table.getExpression(FileTable.class),
		                "project", implementor.getRootExpression(),
		                Expressions.constant(fields))));
	}

}
