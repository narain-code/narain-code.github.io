package com.calcite.query.file;

import java.util.Map;


import org.apache.calcite.schema.Schema;
import org.apache.calcite.schema.SchemaFactory;
import org.apache.calcite.schema.SchemaPlus;

public class FileSchemaFactory implements SchemaFactory {

	  public static final FileSchemaFactory INSTANCE = new FileSchemaFactory();
	
	public Schema create(SchemaPlus arg0, String arg1, Map<String, Object> arg2) {
		//use the operand in the model in the future
		return new FileSchema();
	}

}
