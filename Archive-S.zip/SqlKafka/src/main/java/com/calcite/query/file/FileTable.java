package com.calcite.query.file;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.atomic.AtomicBoolean;

import org.apache.calcite.DataContext;

import org.apache.calcite.linq4j.AbstractEnumerable;
import org.apache.calcite.linq4j.Enumerable;
import org.apache.calcite.linq4j.Enumerator;
import org.apache.calcite.linq4j.QueryProvider;
import org.apache.calcite.linq4j.Queryable;
import org.apache.calcite.linq4j.tree.Expression;
import org.apache.calcite.plan.RelOptTable;
import org.apache.calcite.plan.RelOptTable.ToRelContext;
import org.apache.calcite.rel.RelNode;
import org.apache.calcite.rel.type.RelDataType;
import org.apache.calcite.rel.type.RelDataTypeFactory;
import org.apache.calcite.schema.QueryableTable;
import org.apache.calcite.schema.SchemaPlus;
import org.apache.calcite.schema.Schemas;
import org.apache.calcite.schema.TranslatableTable;
import org.apache.calcite.schema.impl.AbstractTable;

public class FileTable extends AbstractTable implements QueryableTable, TranslatableTable{
	
	public FileTable(){
		
	}

	public RelDataType getRowType(RelDataTypeFactory typeFactory) {
		final RelDataTypeFactory typesFactory = typeFactory;
		List<Map.Entry<String,RelDataType>> types  = new ArrayList<Map.Entry<String,RelDataType>>();
		types.add(new Entry<String, RelDataType>() {

			public String getKey() {
				return "TESTCOLUMN";
			}

			public RelDataType getValue() {
				return typesFactory.createJavaType(String.class);
			}

			public RelDataType setValue(RelDataType value) {
				// TODO Auto-generated method stub
				return null;
			}
		});
		return typeFactory.createStructType(types);
	}

	  /** Returns an enumerable over a given projection of the fields.
	   *
	   * <p>Called from generated code. */
	 public Enumerable<Object> project(final DataContext root,
		      final int[] fields) {
		    
		    return new AbstractEnumerable<Object>() {
		      public Enumerator<Object> enumerator() {
		       return new Enumerator<Object>() {
		    	   public boolean moveNext = true;
				
				public void reset() {
					// TODO Auto-generated method stub
					System.out.println("reset called");
					
				}
				
				public boolean moveNext() {
					
					return moveNext;
				}
				
				public Object current() {
					moveNext = false;
					return "TestRow1";
				}
				
				public void close() {
					// TODO Auto-generated method stub
					
				}
			};
		      }
		    };
		  }

	public RelNode toRel(ToRelContext context, RelOptTable relOptTable) {
		 final int fieldCount = relOptTable.getRowType().getFieldCount();
		 final int[] fields = new int[fieldCount];
		 for(int i=0;i<fieldCount;i++){
			 fields[i]=i;
		 }
		 return new FileScan(context.getCluster(), relOptTable, this, fields);
	}

	public <T> Queryable<T> asQueryable(QueryProvider arg0, SchemaPlus arg1, String arg2) {
		
		return null;
	}

	public Type getElementType() {
		
		 return Object[].class;
	}

	public Expression getExpression(SchemaPlus schema, String tableName, Class clazz) {
		 return Schemas.tableExpression(schema, getElementType(), tableName, clazz);
	}

}
