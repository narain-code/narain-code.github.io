package com.king.quantcast.spreadsheet.expressions;

import org.junit.Assert;
import org.junit.Test;

import com.quantcast.spreadsheet.InMemoryState;

public class TestInMemoryState {

	@Test
	public void testAddGet(){
		InMemoryState st = new InMemoryState(1, 1);
		st.addRow(0, "1");
		Assert.assertEquals(1.0d, st.get("A1"),0.0);
		Assert.assertEquals(Double.MIN_VALUE, st.get("A3"),0.0); // invalid column
		
	}
}
