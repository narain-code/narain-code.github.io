package com.king.quantcast.spreadsheet.expressions;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.quantcast.spreadsheet.State;
import com.quantcast.spreadsheet.input.ConsoleUtil;

public class TestConsoleInput {
	
	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	PrintStream stream;

	@Before
	public void initOut() {
		stream = System.out;
		System.setOut(new PrintStream(outContent));
	}
	
	@Test
	public void testConsoleUtil_happy1() {
		ConsoleUtil util = new ConsoleUtil();
		util.forTesting("Test_input_scenario_happy1");
		State st =util.loop();

		
		System.setOut(stream);
		try {
			Assert.assertEquals(20.00000d, st.get("A1"),0.0);
			Assert.assertEquals(20.000000d, st.get("A2"),0.0);
			Assert.assertEquals(20.000000d, st.get("A3"),0.0);
			Assert.assertEquals(8.66667d, st.get("B1"),0.00001);// not formating the out hence the delta
			Assert.assertEquals(3.00000d, st.get("B2"),0.0);
			Assert.assertEquals(1.50000d, st.get("B3"),0.00001);// not formating the out hence the delta
		}catch (Exception ex) {
			Assert.fail();
		}
	}
	
	@Test
	public void testConsoleUtil_loop1() {
		ConsoleUtil util = new ConsoleUtil();
		util.forTesting("Test_input_scenario_loop1");
		State st =util.loop();

		
		System.setOut(stream);
		try {
			Assert.assertEquals(Double.MIN_VALUE, st.get("A1"),0.0);// since all the A columns have a loop
			Assert.assertEquals(Double.MIN_VALUE, st.get("A2"),0.0);// since all the A columns have a loop
			Assert.assertEquals(Double.MIN_VALUE, st.get("A3"),0.0);// since all the A columns have a loop
			Assert.assertEquals(Double.MIN_VALUE, st.get("B1"),0.00001);// // since all the A columns have a loop
			Assert.assertEquals(3.00000d, st.get("B2"),0.0);
			Assert.assertEquals(Double.MIN_VALUE, st.get("B3"),0.00001);//// since all the A columns have a loop
		}catch (Exception ex) {
			Assert.fail();
		}
		
	}

	@Test
	public void testConsoleUtil_loop2() {
		ConsoleUtil util = new ConsoleUtil();
		util.forTesting("Test_input_scenario_loop2");
		State st =util.loop();

		
		System.setOut(stream);
		try {
			Assert.assertEquals(20.00000d, st.get("A1"),0.0);
			Assert.assertEquals(20.000000d, st.get("A2"),0.0);
			Assert.assertEquals(Double.MIN_VALUE, st.get("A3"),0.0);// since all the A3 column has a  self loop
			Assert.assertEquals(8.66667d, st.get("B1"),0.00001);// not formating the out hence the delta
			Assert.assertEquals(3.00000d, st.get("B2"),0.0);
			Assert.assertEquals(1.50000d, st.get("B3"),0.00001);// not formating the out hence the delta
		}catch (Exception ex) {
			Assert.fail();
		}
		
	}
	
	
	@Test
	public void testConsoleUtil_happy_large1() {
		ConsoleUtil util = new ConsoleUtil();
		util.forTesting("Test_input_scenario_happy_large1");
		State st =util.loop();

		
		System.setOut(stream);
		try {
			Assert.assertEquals(20.00000d, st.get("A1"),0.0);
			Assert.assertEquals(20.000000d, st.get("A2"),0.0);
			Assert.assertEquals(20.000000d, st.get("A3"),0.0);
			Assert.assertEquals(10.0d, st.get("A10"),0.0);
			Assert.assertEquals(8.66667d, st.get("B1"),0.00001);// not formating the out hence the delta
			Assert.assertEquals(3.00000d, st.get("B2"),0.0);
			Assert.assertEquals(1.50000d, st.get("B3"),0.00001);// not formating the out hence the delta
			Assert.assertEquals(9.0d, st.get("B9"),0.0);
		}catch (Exception ex) {
			Assert.fail();
		}
	}
}
