package com.king.quantcast.spreadsheet.expressions;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.quantcast.spreadsheet.RPN;
import com.quantcast.spreadsheet.State;
import com.quantcast.spreadsheet.InMemoryState;
import com.quantcast.spreadsheet.graph.GraphNode;

public class TestRpn {
	
	RPN rpn;
	@Before
	public void setUp(){
		
		State st = new InMemoryState(1,3);
		st.addRow(0, "20");
		st.addRow(1, "40");
		st.addRow(2, "60");
		rpn = new RPN(new ArrayDeque<Double>(),st);
	}
	
	@Test
	public void testRpn(){
		
		Assert.assertEquals(20.0d,rpn.parse("4 5 *"),0.0);
		Assert.assertEquals(20.0d,rpn.parse("A1"),0.0);
		Assert.assertEquals(40.0d,rpn.parse("A1 A1 +"),0.0);
		Assert.assertEquals(80.0d,rpn.parse("A3 A1 +"),0.0);
		Assert.assertEquals(30.76923076923077d,	rpn.parse("A3 A1 * 39 /"),0.0);
	}

}
