package com.quantcast.spreadsheet;

import java.util.ArrayDeque;

import com.quantcast.spreadsheet.graph.GraphNode;

public interface State {

	Double get(String address);

	void doAll();
	
	public void addRow(int lineNumber,String line);
	
	/*
	 * A1 is resolved by getting the ascii code of A-65 == row number
	 * + 1 == position in the state
	 * so in case of inmemory the value can be found 0 pos
	 * in case of file the value can be found in the file A .. line 0 in the file
	 */
	
	default int getRowAddress(String address,int rows){
		char first = address.charAt(0);
		if (!Character.isAlphabetic(first)) {
			return -1;
		}
		int addr = first - 65;
		if (addr > rows)
			return -1;
		return addr;
		
		
	}
	
	default int getColumnAddress(String address,int cols){
		
		try{
		int col = Integer.parseInt(address.substring(1));
		
		if (col > cols)
			return -1;
		return col;
		}catch(NumberFormatException ex){
			//wrong address
			;
		}
		return -1;
	}

	default Double getFromGraphNode(GraphNode graph){
		if(graph == null)
			throw new RuntimeException("graph node is null");
		return graph.get(new RPN(new ArrayDeque<>(), this));
	}
	
	public default Double get(Double d) {
		return d;
	}
}