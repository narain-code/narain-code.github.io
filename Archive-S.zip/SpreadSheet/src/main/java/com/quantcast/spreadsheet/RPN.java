package com.quantcast.spreadsheet;

import java.util.Deque;
import java.util.Optional;
import java.util.function.BiFunction;

import com.quantcast.spreadsheet.utils.Utils;

/*
 * Parsers a string into a stack and performs an operation on them
 */
public class RPN {

	private final Deque<Double> stack;
	private final State resolver;


	public RPN(Deque<Double> stack, State resolve) {
		this.stack = stack;
		this.resolver = resolve;

	}

	public Double parse(String expr) {
		String[] parts = expr.split(" ");
		for (String part : parts) {
			if (Utils.isRef(part)) {
				Double dPart =resolver.get(part);
				if(dPart == Double.MIN_VALUE)
					return dPart;
				stack.push(dPart);
			} else {
				if(Utils.isNumber(part)){
					Double dPart =Double.valueOf(part);
					stack.push(dPart);
					continue;
				}
				Optional<OPTypes> type = parseOptypes(part);
				if (type.isPresent()) {
					BiFunction<Double, Double, Double> func = type.get().execute();
					
					stack.push(func.apply(resolver.get(stack.pop()),resolver.get(stack.pop())));
						
					

				} else {
					throw new RuntimeException(" the string " + expr + " cannot be parsed");
				}
			}
			
			
		}
		if(stack.size()==1)
			return stack.pop();
		return Double.MIN_VALUE;
	}

	private Optional<OPTypes> parseOptypes(String token) {
		return OPTypes.getTypeFor(token);
	}
}
