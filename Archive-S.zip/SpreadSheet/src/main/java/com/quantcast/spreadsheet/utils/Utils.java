package com.quantcast.spreadsheet.utils;

public class Utils {
	
	public static boolean isRef(String token) {
		char c = token.charAt(0);
		if (Character.isAlphabetic(c)) {
			return true;
		}
		return false;
	}

	public static boolean isNumber(String token) {
		char[] chars = token.toCharArray();
		for (char c : chars) {
			if (!Character.isDigit(c)) {
				return false;
			}
		}
		return true;
	}

}
