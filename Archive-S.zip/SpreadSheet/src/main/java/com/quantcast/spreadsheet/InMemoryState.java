package com.quantcast.spreadsheet;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

import com.quantcast.spreadsheet.graph.GraphNode;

public class InMemoryState implements State {

	int rows;
	int cols;
	List<GraphNode> allData;

	public InMemoryState( int rows, int cols) {
		this.allData = new ArrayList<>(rows*cols);
		this.rows = rows;
		this.cols = cols;

	}

	/* (non-Javadoc)
	 * @see com.quantcast.spreadsheet.State#get(java.lang.String)
	 */
	@Override
	public Double get(String address) {
		
		int addr =getRowAddress(address, rows);
		int col = getColumnAddress(address, cols);
		if(addr == -1 || col == -1)//-1 indicates a wrong address
			return Double.MIN_VALUE;
		int jump = addr * cols;
		int slotId = jump + col - 1;
		if(slotId == -1)//-1 indicates a wrong address
			return Double.MIN_VALUE;
		return getFromGraphNode(allData.get(slotId));
	}

	
	

	/* (non-Javadoc)
	 * @see com.quantcast.spreadsheet.State#doAll()
	 */
	@Override
	public void doAll(){
		allData.stream()
				.map(node->node.get(new RPN(new ArrayDeque<Double>(),this)))
				.map(v->String.format("%.5f",v))
				.forEach(System.out::println);
				
	}

	@Override
	public void addRow(int lineNumber, String line) {
		allData.add(lineNumber, new GraphNode(line));
		
	}

	

}
