package com.quantcast.spreadsheet;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.stream.Stream;

import com.quantcast.spreadsheet.graph.GraphNode;

public class FileState implements State {
	int rows;
	int cols;
	List<File> allData;
	LinkedHashMap<String, GraphNode> cache = new LinkedHashMap<>(1000);
	private int fileNumber = -1;
	private BufferedWriter fw = null;

	public FileState(int rows, int cols) {

		this.rows = rows;
		this.cols = cols;
		this.allData = new ArrayList<>(rows * cols);
		for (int i = 65; i < 65 + rows; i++) {
			allData.add(new File(Character.toString((char)i) + ".txt"));
		}

	}

	@Override
	public Double get(String address) {
		if(cache.containsKey(address)){
			return getFromGraphNode(cache.get(address));
		}
		int slotId = getRowAddress(address, rows);
		if (slotId == -1)// -1 indicates a wrong address
			return Double.MIN_VALUE;
		File f = allData.get(slotId);
		try {
			BufferedReader current = new BufferedReader(new InputStreamReader(new FileInputStream(f)));
			Stream<String> lines = current.lines();

			slotId = getColumnAddress(address, cols);
			if (slotId == -1)// -1 indicates a wrong address
				return Double.MIN_VALUE;
			
				cache.put(address, new GraphNode(lines.skip(slotId - 1).findFirst().get()));
			Double d = getFromGraphNode(cache.get(address));
			lines.close();
			current.close();
			return d;
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	@Override
	public void doAll() {

		allData.stream().flatMap(f -> {
			try {
				return Files.lines(Paths.get(URI.create("file://"+f.getAbsolutePath())));
			} catch (Exception ex) {
				throw new RuntimeException(ex.getMessage());
			}
		})
				.map(l -> new GraphNode(l))
				.map(node -> node.get(new RPN(new ArrayDeque<Double>(), this)))
				.map(v -> String.format("%.5f", v))
				.forEach(System.out::println);
	}

	@Override
	public void addRow(int lineNumber, String line) {
		
		int current =0;
		if(lineNumber>0)
			current = lineNumber / cols;

		try {
			if (fileNumber == current) {
				;

			} else {

				if (fileNumber > -1) {
					fw.close();
				}
				fileNumber = current;
				fw = new BufferedWriter(new FileWriter(allData.get(fileNumber)));
				
			}

			fw.write(line);
			fw.newLine();
			fw.flush();

		} catch (IOException e) {
			throw new RuntimeException(e.getMessage());
		}

	}

}
