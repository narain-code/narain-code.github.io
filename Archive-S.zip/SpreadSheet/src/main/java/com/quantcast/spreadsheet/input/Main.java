package com.quantcast.spreadsheet.input;

public class Main {
	
	/*
	 * This takes input from the console and
	 * prints the output..
	 * 
	 * if the formula has loop or incorrect addressing like AA1 ..
	 * the program will calculate value for valid paths and for paths with invalid Path
	 * the program will return Double.MIN_VALUE which when printed with "%.5f" format becomes
	 * 0.00000
	 * if the number of inputs is large the program moves from storing values from list into Files
	 * there would be one file per row so if we inputs like 2 row 100 columns the data will be written
	 * in 2 files named A and B .A will contain all columns of row A and B will contain all columns of row
	 *  B.
	 * 
	 */
	
	public static void main(String[] args){
		ConsoleUtil util =new ConsoleUtil();
		util.loop().doAll();
		
		
	}

}
