package com.quantcast.spreadsheet.graph;

import com.quantcast.spreadsheet.RPN;


/*
 *  represents a node in the spreadsheet..
 *   this contains entire the value or the formula in RPN..
 */
public class GraphNode {

	private String payload;
	private Double  cached=null;
	private boolean inQueryPath = false;

	
	
	public GraphNode(String payload){
		this.payload = payload;
		
	}
	
	public Double get(RPN parser){
		
		
		if (cached != null){
			return cached;
		}
		cached = doDfs(parser);
		return cached;
	}
	
	/**
	 * in query path is used to check if there are cycles in the current path
	 * @param parser
	 * @return
	 */
	private Double doDfs(RPN parser){
		if(inQueryPath){
			inQueryPath= false;
			return Double.MIN_VALUE;
		}
		inQueryPath=true;
		Double ret = parser.parse(payload);
		inQueryPath = false;
		return ret;
	}
}
