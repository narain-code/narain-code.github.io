package com.quantcast.spreadsheet.input;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import com.quantcast.spreadsheet.FileState;
import com.quantcast.spreadsheet.InMemoryState;
import com.quantcast.spreadsheet.State;
import com.quantcast.spreadsheet.graph.GraphNode;

/*
* 
* a simple state machine for managaing the input from console..
*  the state transistion are from initial -> row input --> end
*  
*  if the number of columns is less than x hold things in memory .. greater than that 
*  switch to file .. we can tune x according the memory we supply to the java program..
*  for now setting this a low value to be able to do tests ...
*/
public class ConsoleUtil {
	
	private static final int SWITCHTOFILE = 10;

	private static InputStream input = System.in;
	private static BufferedReader br = null;

	public void forTesting(String fileName) {
		try {
			input = new FileInputStream(new File(fileName));
			br = new BufferedReader(new InputStreamReader(input));
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
			throw new RuntimeException("Cannot read file " + fileName);
		}
	}

	private interface StateMachineState {

		public StateMachineState process(StateMachineContext contxt);

		default String getChoice() {
			int choice = -100;
			try {
				if (br == null) {
					br = new BufferedReader(new InputStreamReader(input));
				}
			
				String s = br.readLine();
				return s;
			} catch (Exception ex) {
				
				System.out.println("Please enter valid input");
			}
			return null;
		}

		default String getStrChoice() {
			String choice = null;
			try {

				choice = br.readLine();

			} catch (Exception ex) {
				ex.printStackTrace();
			}
			return choice;
		}
	}

	private class StateMachineContext {

		private int rows;
		private int cols;
		private int currentRow;
		//List<GraphNode> allColRows = new ArrayList<>();
		
		State state;
		

		public void setCols(int cols) {
			this.cols = cols;
			
		}

		public int getCols() {
			return cols;
		}

		public void setRows(int rows) {
			this.rows = rows;
			if(cols >SWITCHTOFILE){
				state = new FileState( rows, cols);
			}else{
				state = new InMemoryState(rows, cols);
			}
		}

		public int getRows() {
			return rows;
		}

		public void incrementRow() {
			this.currentRow++;
		}

		public boolean finished() {
			return currentRow == (rows * cols);
		}

		public void addRow(String line) {
			state.addRow(currentRow, line);
		}

	}

	public enum States implements StateMachineState {
		INITIAL {

			@Override
			public StateMachineState process(StateMachineContext contxt) {
				String line = getChoice();
				String[] parts = line.split(" ");
				if (parts.length != 2){
					System.out.println("Enter number of columns follwed by the number of rows");
					return INITIAL;
				}
				int choice1 = parse(parts[0]);
			
				if (choice1 <= 0){
					System.out.println("Enter number of columns greater 0");
					return INITIAL;
				}
				contxt.setCols(choice1);
				choice1 = parse(parts[1]);
				if (choice1 <=0 || choice1 > 25){
					System.out.println("Enter number of rows within 1 -25");
					return INITIAL;
				}
				contxt.setRows(choice1);
				
				return ROWINPUT;
			}

			public int parse(String s) {
				try {
					return Integer.parseInt(s);
				} catch (Exception ex) {
					System.out.println("Only valid numbers allowed");
				}
				return -1;
			}

		},
		ROWINPUT {
			@Override
			public StateMachineState process(StateMachineContext contxt) {
				try {
					
					String line = getChoice();
					contxt.addRow(line.toUpperCase());
					contxt.incrementRow();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
				if (contxt.finished())
					return null;
				return ROWINPUT;
			}
		};

	}

	public State loop() {
		System.out.println("Enter number of cols follwed by the number of rows. Rows has to be between 1-26");
		StateMachineContext contxt = new StateMachineContext();
		StateMachineState state = States.INITIAL.process(contxt);
		while (state != null) {
			state = state.process(contxt);
		}
		System.out.println(contxt.cols + " "+contxt.rows);
	return contxt.state;
		
	}
	
	
	

}
