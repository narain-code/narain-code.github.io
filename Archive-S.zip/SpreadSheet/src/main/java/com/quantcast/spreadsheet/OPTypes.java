package com.quantcast.spreadsheet;

import java.util.Optional;
import java.util.function.BiFunction;

public enum OPTypes implements Operator {

	PLUS("+") {

		public BiFunction<Double, Double, Double> execute() {
			return (input1, input2) -> input1 + input2;
		}
	},
	STAR("*") {
		public BiFunction<Double, Double, Double> execute() {
			return (input1, input2) -> input1 * input2;
		}
	},
	MINUS("-") {
		public BiFunction<Double, Double, Double> execute() {
			return (input1, input2) -> input2 - input1;
		}
	},
	DIVIDE("/") {
		public BiFunction<Double, Double, Double> execute() {
			return (input1, input2) -> input2 / input1;
		}
	};

	OPTypes(String op) {
		this.op = op;
	}

	public static Optional<OPTypes> getTypeFor(String op) {
		for (OPTypes operator : OPTypes.values()) {
			if (operator.op.equalsIgnoreCase(op)) {
				return Optional.of(operator);
			}
		}
		return Optional.empty();
	}

	private String op;

}
