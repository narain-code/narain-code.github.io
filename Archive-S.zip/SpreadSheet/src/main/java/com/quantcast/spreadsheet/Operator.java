package com.quantcast.spreadsheet;

import java.util.function.BiFunction;

public interface Operator {

	public BiFunction<Double, Double, Double> execute();

}
