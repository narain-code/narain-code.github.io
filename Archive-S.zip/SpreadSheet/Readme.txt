to build the project .. please use maven clean build package
to run .. you can do java -jar ./target/SpreadSheet-0.2-SNAPSHOT-jar-with-dependencies.jar
Since the coding excercise specifies not to use any external libs .. i have avoided using any logging libraries.in the normal scheme of things
a lot of log statements would have been sprinkled in the code.

The program constructs a Directed Graph .. looks for cycle in them. If there is a cycle then the paths containing cycle return Double.MIN_Value which
when formated using %.5f will give 0.0000. All the other paths in the spreadsheet which do not have a problem will be calculated normally.
The program based on the number of cols switches from in memory mode to a file mode. Right now this is set a low number
to enable easy testing but this can be tuned. The way the file mode works is each row is mapped to a file and all the columns in the row are written the file.
So if we have 11 columns and 2 rows we will have 2 files named A and B each containing 11 rows.

Since i was fighting a production bug at work ... i was constrainted by time ..else there would have been more documentation in each of the classes and more tests.
  
