package com.king.sql;

import java.util.LinkedHashMap;
import java.util.List;

public class Analysis {
	
	private LinkedHashMap<String, List<Column>> table2Cols = new LinkedHashMap<>();
	
	private LogicalNode root;
	
	
	public Analysis(){
		
	}
	
	public void setRoot(LogicalNode node){
		this.root=node;
	}
	
	public LogicalNode getRoot(){
		return root;
	}
	
	public void addColToTable(String tableName, Column col){
		
	}
	
	public static class Column{
		
		private String name;
		private String type;
		
		public Column(String name, String type){
			this.name =name;
			this.type = type;
		}
	}
	
	
}
