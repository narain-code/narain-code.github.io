package com.king.sql;

import static java.util.Objects.requireNonNull;

import java.util.ArrayList;
import java.util.List;

public class Table {
	
	
	List<Field> allFields;
	String name;
	
	private static final String COMMON="cannot be null";
	private static final String NAME= "name "+COMMON;
	private static final String FIELDS= "fields "+COMMON;
	
	public Table(List<Field> allFields, String name) {
		requireNonNull(name, NAME);
		requireNonNull(allFields, FIELDS);
		this.allFields = allFields;
		this.name = name;
	}
	
	public void merge(Table other){
		List<Field> newArray = new ArrayList<Field>(this.allFields.size()+other.allFields.size());
		newArray.addAll(allFields);
		newArray.addAll(other.allFields);
	}

}
