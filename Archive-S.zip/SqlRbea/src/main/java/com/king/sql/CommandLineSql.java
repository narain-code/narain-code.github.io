package com.king.sql;

import com.facebook.presto.sql.parser.ParsingOptions;
import com.facebook.presto.sql.parser.SqlParser;
import com.facebook.presto.sql.tree.Insert;
import com.facebook.presto.sql.tree.Query;
import com.facebook.presto.sql.tree.QuerySpecification;
import com.facebook.presto.sql.tree.Select;
import com.facebook.presto.sql.tree.Statement;
import com.facebook.presto.sql.tree.TableSubquery;

public class CommandLineSql {
	private final static SqlParser parser = new SqlParser();
	private final static ParsingOptions options = new ParsingOptions();
	

	public static Analysis parseSql(String sql) {
		
		Analysis anly = new Analysis();
		 StatementAnalyzer analyzer = new StatementAnalyzer(parser, options);
		
		 analyzer.analyze(sql,anly);
		 return anly;
	}
	
	
}
