package com.king.sql;

public class TableLogicalNode extends LogicalNode {

	
	private String tableName;
	
	public TableLogicalNode(LogicalNodeType op) {
		super(op);
	}

	public void setTableName(String table){
		this.tableName=table;
	}
	
	public String getTableName(){
		return tableName;
	}
	
	
	
}
