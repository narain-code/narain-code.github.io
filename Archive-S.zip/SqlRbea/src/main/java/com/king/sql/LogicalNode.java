package com.king.sql;

import java.util.HashSet;
import java.util.Set;
import static java.util.Objects.requireNonNull;
public class LogicalNode {
	Set<LogicalNode> sources;
	
	public static enum LogicalNodeType{
		INSERT(0),
		QUERY(1),
		PROJECTION(2),
		TABLE(3);
		
		int type;
		private LogicalNodeType(int i){
			type=i;
		}
	}
	LogicalNodeType op;
	
	public LogicalNode(LogicalNodeType op){
	
		this.op=op;
	}
	
	public void addSource(LogicalNode scope){
		requireNonNull(scope, "trying to insert null node");
		if(sources == null){
			sources = new HashSet<>();
		}
		if(!sources.contains(scope)){
			sources.add(scope);
		}
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((op == null) ? 0 : op.hashCode());
		result = prime * result + ((sources == null) ? 0 : sources.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LogicalNode other = (LogicalNode) obj;
		if (op != other.op)
			return false;
		if (sources == null) {
			if (other.sources != null)
				return false;
		} else if (!sources.equals(other.sources))
			return false;
		return true;
	}
	
}
