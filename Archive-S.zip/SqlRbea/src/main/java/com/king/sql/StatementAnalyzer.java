package com.king.sql;

import static java.util.Objects.requireNonNull;

import java.util.Optional;

import com.facebook.presto.sql.parser.ParsingOptions;
import com.facebook.presto.sql.parser.SqlParser;
import com.facebook.presto.sql.tree.AstVisitor;
import com.facebook.presto.sql.tree.GroupBy;
import com.facebook.presto.sql.tree.Insert;
import com.facebook.presto.sql.tree.Node;
import com.facebook.presto.sql.tree.Query;
import com.facebook.presto.sql.tree.QueryBody;
import com.facebook.presto.sql.tree.QuerySpecification;
import com.facebook.presto.sql.tree.Relation;
import com.facebook.presto.sql.tree.Select;
import com.facebook.presto.sql.tree.SelectItem;
import com.facebook.presto.sql.tree.Statement;
import com.facebook.presto.sql.tree.Table;
import com.google.common.annotations.VisibleForTesting;
import com.king.sql.LogicalNode.LogicalNodeType;

public class StatementAnalyzer {

	// plugin metadata
	SqlParser pq;
	ParsingOptions op;

	public StatementAnalyzer(SqlParser pq, ParsingOptions op) {
		requireNonNull(pq);
		requireNonNull(op);
		this.pq = pq;
		this.op = op;
	}

	public void analyze(String stmt,Analysis anly) {
		requireNonNull(stmt);
		Statement stm = pq.createStatement(stmt, op);
		LogicalNode sc = new SqlVisitor(Optional.empty()).process(stm, Optional.empty());
		anly.setRoot(sc);
	}

	private class SqlVisitor extends AstVisitor<LogicalNode, Optional<LogicalNode>> {

		private final Optional<LogicalNode> parentNode;

		private SqlVisitor(Optional<LogicalNode> outerQueryScope) {
			this.parentNode = requireNonNull(outerQueryScope, "parentNode is null");
		}

		public LogicalNode process(Node node, Optional<LogicalNode> scope) {
			LogicalNode returnScope = super.process(node, scope);
			return returnScope;
		}

		private LogicalNode process(Node node, LogicalNode scope) {
			return process(node, Optional.of(scope));
		}

		@Override
		protected LogicalNode visitInsert(Insert node, Optional<LogicalNode> context) {
			// System.out.println("inside insert");
			LogicalNode insertScope;
			insertScope = new LogicalNode(LogicalNodeType.INSERT);

			insertScope.addSource(process(node.getQuery(), insertScope));

			return insertScope;
		}

		@Override
		protected LogicalNode visitQuery(Query node, Optional<LogicalNode> context) {
			// System.out.println("in Query "+node.toString());
			LogicalNode query= new LogicalNode(LogicalNodeType.QUERY);
			Optional<LogicalNode> ctx = Optional.of(query);
			if (node.getWith().isPresent()) {
				process(node.getWith().get(),ctx );
			}
			// System.out.println("processing query body");
			query.addSource(process(node.getQueryBody(), context));
			if (node.getOrderBy().isPresent()) {
				process(node.getOrderBy().get(), ctx);
			}

			
			
			return query;
		}

		@Override
		protected LogicalNode visitQueryBody(QueryBody node, Optional<LogicalNode> context) {
			//System.out.println("in Querybody " + node.toString());
			return null;
		}

		@Override
		protected LogicalNode visitQuerySpecification(QuerySpecification node, Optional<LogicalNode> context) {
			//System.out.println("in QuerySpec " + node.toString());
			LogicalNode tt = null;
			if (node.getFrom().isPresent()) {
				tt=process(node.getFrom().get());
			}
			if (node.getGroupBy().isPresent()) {
				process(node.getGroupBy().get());
			}
			LogicalNode selectI =process(node.getSelect());
			selectI.addSource(tt);
				
			return selectI;
		}
		
		@Override
		protected LogicalNode visitSelect(Select node,Optional<LogicalNode> context){
			//System.out.println(node.toString());
			SelectLogicalNode sN= new SelectLogicalNode(LogicalNodeType.PROJECTION);
			sN.isDistinct(node.isDistinct());
			for(SelectItem item:node.getSelectItems())
				sN.setItems(item.toString());
			return sN;
		}

		@Override
		protected LogicalNode visitTable(Table node, Optional<LogicalNode> context) {
			//System.out.println(node.toString());
			TableLogicalNode tableNode = new TableLogicalNode(LogicalNodeType.TABLE);
			tableNode.setTableName(node.getName().toString());
			return tableNode;

		}

		@Override
		protected LogicalNode visitGroupBy(GroupBy node, Optional<LogicalNode> context) {
			System.out.println(node.toString());
			return null;

		}
	}

}
