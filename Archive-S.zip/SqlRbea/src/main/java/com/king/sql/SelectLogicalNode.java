package com.king.sql;

public class SelectLogicalNode extends LogicalNode {

	public SelectLogicalNode(LogicalNodeType op) {
		super(op);
		
	}
	
	public void setItems(String name){
		System.out.println(name);
	}
	
	public void isDistinct(boolean isDistinct){
		
	}

}
