package com.king.sql;

public class Field {
	
	
	
	public static enum Types{
		INT(1),
		LONG(2),
		FLOAT(3);
		
		private int type;
		
		private Types(int i){
			this.type = i;
		}
		
	}
	
	String name;
	Types type;
	
	
public Field(String name, Types type) {
		
		this.name = name;
		this.type = type;
	}
	
	
	public String getName() {
		return name;
	}
	public void setType(Types type) {
		this.type = type;
	}

}
