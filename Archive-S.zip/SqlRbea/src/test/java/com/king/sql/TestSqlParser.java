package com.king.sql;

import java.util.ArrayDeque;

import com.king.sql.LogicalNode.LogicalNodeType;

public class TestSqlParser {

	public static void main(String[] args){
		Analysis anly =CommandLineSql.parseSql("insert into test_table select * from A");
		LogicalNode n =anly.getRoot();
		ArrayDeque<LogicalNode> dq = new ArrayDeque<>();
		dq.add(n);
		
		while(!dq.isEmpty()){
			LogicalNode curr=	dq.pop();
			System.out.println(curr.op);
			
			if(curr.sources!=null)
			curr.sources.forEach(ln->dq.add(ln));
			if(curr.op == LogicalNodeType.TABLE){
				TableLogicalNode t = (TableLogicalNode)curr;
				System.out.println(t.getTableName());
				
			
			}
		}
		
		
	}
}
