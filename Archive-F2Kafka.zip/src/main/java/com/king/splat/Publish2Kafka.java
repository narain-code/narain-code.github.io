package com.king.splat;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.serde2.lazy.LazySimpleSerDe;
import org.apache.hadoop.hive.serde2.objectinspector.StructField;
import org.apache.hadoop.hive.serde2.objectinspector.StructObjectInspector;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapred.TextInputFormat;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;


public class Publish2Kafka {
	private static LazySimpleSerDe serde;
	static
	  {
	    try
	    {
	      Configuration conf = new Configuration();
	      Properties tbl = new Properties();

	      tbl.setProperty("serialization.format", "\t");

	      tbl.setProperty("columns", "coreuserid,installid,msts");
	      tbl.setProperty("columns.types", "bigint:string:bigint");

	      tbl.setProperty("serialization.null.format", "NULL");

	      //serde = new ColumnarSerDe();
	      serde = new LazySimpleSerDe();
	      serde.initialize(conf, tbl);

	      StructObjectInspector oi = (StructObjectInspector)serde.getObjectInspector();
	      List<? extends StructField> fieldRefs = oi.getAllStructFieldRefs();

	      for (StructField structField : fieldRefs) {
	        System.out.println("FIELD: " + structField.getFieldName());
	      }

	    }
	    catch (Exception e)
	    {
	      e.printStackTrace();
	      System.out.println("Failed to setup SERDE.");
	    }
	  }
	
	
	public static void main(String[] args) throws Exception
	{
	if (args.length != 2) {
	System.err.println("usage: <input path> <kafka output url>");
	return;
	}
	JobConf job = new JobConf(Publish2Kafka.class);
    job.setJobName("PublishInstall2Kafka");
	job.setJarByClass(Publish2Kafka.class);
	//job.setInputFormat(RCFileInputFormat.class);
	job.setInputFormat(TextInputFormat.class);
	
	job.setOutputFormat(KafkaOutputFormat.class);

	job.setMapperClass(TheMapper.class);
	job.setNumReduceTasks(0);
	FileInputFormat.addInputPath(job, new Path(args[0]));
	 //FileOutputFormat.setOutputPath(job, new Path(args[1]));
	//KafkaOutputFormat.setOutputPath(job, new Path(args[1]));
	 job.set(KafkaOutputFormat.KAFKA_URL,  new Path(args[1]).toString());
	 job.setBoolean("mapred.map.tasks.speculative.execution", false);
	 job.setBoolean("mapred.reduce.tasks.speculative.execution", false);
	 try
	    {
	      JobClient.runJob(job);
	    }
	    catch (IOException e) {
	      e.printStackTrace();
	    }
	}
	
	public static class TheMapper extends MapReduceBase implements Mapper<LongWritable, Text, Object, Object>
	{
		
		
		
	
	public void map(LongWritable key, Text value, OutputCollector<Object,Object> oc,Reporter rprtr) throws IOException
	{
		
	  	
	 try{	
		StructObjectInspector oi = (StructObjectInspector)serde.getObjectInspector();
        List fieldRefs = oi.getAllStructFieldRefs();

        Object raw = serde.deserialize(value);

        List dataStruct = oi.getStructFieldsDataAsList(raw);
      
        long userId  =0;
        String installId = null;
		if(dataStruct.get(0) != null){
			//buff.append(dataStruct.get(0).toString());
			userId = Long.parseLong(dataStruct.get(0).toString());
			//System.out.println(userId + " :: " + dataStruct.get(0).toString());
		}
		if(dataStruct.get(1) != null){
			//buff.append(dataStruct.get(1).toString());
			 installId=dataStruct.get(1).toString();
			
		}
		
		
		 byte[] vbytes =getSerializer().writeValueAsBytes(installId);
		 byte[] kbytes =getSerializer().writeValueAsBytes(userId);
		 oc.collect(kbytes,vbytes );
		 
	  }catch(Exception e){
		  e.printStackTrace();
		  throw new RuntimeException(e.getMessage());
	  }
		
	}
	
	
	 static ObjectMapper getSerializer() {
	        final ObjectMapper mapper = new ObjectMapper();
	       
	        // only allow fields
	        mapper.setVisibility(PropertyAccessor.ALL, JsonAutoDetect.Visibility.NONE);
	        mapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY); // allow private fields

	        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
	        mapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
	        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
	        mapper.configure(JsonParser.Feature.ALLOW_UNQUOTED_CONTROL_CHARS, true);
	        mapper.configure(JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES, true);

	       
	        
	

	               
	        
	        return mapper;
	    }
	
	}



}


