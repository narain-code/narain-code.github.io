package com.king.splat;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.Charset;
import java.util.LinkedList;
import java.util.List;
import java.util.zip.GZIPInputStream;

import kafka.javaapi.producer.Producer;
import kafka.producer.KeyedMessage;

public class ThreadPublish2Kafka  extends Thread{
	
	String fileName ;
	public static final String REGEX = "\t";
	public static final int KAFKA_QUEUE_BYTES = 1000000;
	
	Producer<byte[], byte[]> producer ;
	String topic;
	
	public ThreadPublish2Kafka(String fileName, Producer producer, String topic ){
		this.fileName = fileName;
		this.producer = producer;
		this.topic = topic;
		setName(fileName);
		
	}
	
	 
	
	public void run(){
		try{
			long count = 0L;	
		InputStream fileStream = new FileInputStream(fileName);
		InputStream gzipStream = new GZIPInputStream(fileStream);
		Reader decoder = new InputStreamReader(gzipStream, Charset.defaultCharset());
		BufferedReader buffered = new BufferedReader(decoder);
		List<KeyedMessage<byte[], byte[]>> msgList = new LinkedList<KeyedMessage<byte[], byte[]>>();
		
		int totalBytes = 0;
		String line =buffered.readLine();
		while(line != null){
		  String[] parsed =	line.split(REGEX);
/*		  String coreUserId = parsed[0];
		  String installId = parsed[1];
		  String timestamp = parsed[2];
	*/
		  String coreUserId = parsed[1];
		  String installId = parsed[3]; //< --- installKey
		  String timestamp = parsed[2];
		  String mergeId = "0";
		  if(parsed.length > 4){
			  if(parsed[4] != null)
				  mergeId=parsed[4];
		  }
		  
		  
		  StringBuilder b = new StringBuilder();
			b.append(timestamp);
			b.append("\t");
		/*	b.append(0);
			b.append("\t"); */
		    b.append(coreUserId);
		    b.append("\t");
		    b.append(mergeId);
		    b.append("\t");
		    b.append(installId);
		    
		   
		  byte[] valBytes =b.toString().getBytes();
		  byte[] keyBytes = coreUserId.concat("\t").concat(installId).getBytes();
		  if ((totalBytes + valBytes.length +keyBytes.length) > KAFKA_QUEUE_BYTES || msgList.size() >= Short.MAX_VALUE){
			  producer.send(msgList);
		      totalBytes = 0;
		     // System.out.println( Thread.currentThread().getName() +" sent  " + count);
		      msgList.clear();
		  }
		  
		 
		    
		   msgList.add(new KeyedMessage<byte[], byte[]>(topic, keyBytes, valBytes));
		    totalBytes += valBytes.length+keyBytes.length;
		//  producer.send(new KeyedMessage<byte[], byte[]>(topic, keyBytes, valBytes));

		  line = buffered.readLine();
		  count ++;
		  if (count%1000000 == 0)
		   System.out.println( Thread.currentThread().getName() +" processed " + count);
		 
		}
		
		
		if(msgList.size() > 0){
			producer.send(msgList);
		}
		    producer.close();
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
}
