package com.king.rbea.hashlookup;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.fs.permission.FsPermission;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapreduce.RecordWriter;
import org.apache.hadoop.mapreduce.TaskAttemptContext;

import com.king.splat.RKeyValueWritable;



public class HashLookUpWriter<K,V> extends RecordWriter<K,V> {
	
	
	String baseOutput;
	int writeBatchSize;
	String tempDir;
	CdbMake make;
	int currIndex =0;
	int index = -1;
	String newVersion;
	
	public HashLookUpWriter( Configuration jobConf) throws IOException {
		
		
		baseOutput = jobConf.get("mapred.output.dir");
		writeBatchSize = jobConf.getInt("hashlookup.write.batch.size", 10000);	
		tempDir = Files.createTempDirectory("CDBShards").toAbsolutePath().toString();
		make = new CdbMake();
		
	}
	
	@Override
	public void write(K key, V value) throws IOException {
		
		byte[] rkey =((RKeyValueWritable)value).getKey().copyBytes();
		byte[] rvalue = ((RKeyValueWritable)value).getValue().copyBytes();
		
		if(index == -1){
			index = ((IntWritable)key).get();
			maxVersionPath =Paths.get("maxVersion").toAbsolutePath().toString() +"/"+index+"-cdb";
			File f = new File(maxVersionPath);
			if (!f.exists())
				maxVersionPath = null;
			//System.out.println(" file " + tempDir+"/"+index+"-cdb");
			make.start(tempDir+"/"+index+"-cdb");
		}
		//System.out.println(" inside writer "+ new String(rkey) + " " + new String(rvalue) );
		make.add(rkey, rvalue);
		currIndex ++;
		
	}

	
	 public List<Long> getAllVersions(Configuration conf) throws FileNotFoundException, IOException{
		 List<Long> ret = new ArrayList<Long>();
		 Path rootPath = new Path(baseOutput+"/"+index);
		  FileSystem fs =rootPath.getFileSystem(conf);
		 if (fs.exists(rootPath)) {
	            for(FileStatus stat: fs.listStatus(rootPath)) {
	            	Path p =stat.getPath()	;
	            	ret.add(Long.parseLong(p.getName()));
	            }
		 }
		 return ret;
	 }
	 
	 String maxVersionPath = null;//= Files.createTempDirectory("maxVersion").toAbsolutePath().toString() +"/"+index+"-cdb";
	 public void copyToLocal(long maxVersion , Configuration conf) throws IOException{
		 Path out =  new Path(baseOutput+"/"+index + "/" +maxVersion + "/" + index + "-cdb");
		 FileSystem fs =out.getFileSystem(conf);
		 maxVersionPath =Files.createTempDirectory("maxVersion").toAbsolutePath().toString() +"/"+index+"-cdb";
		 Path dst = new Path(maxVersionPath);
		 fs.copyToLocalFile(out, dst);
		 
	 }
	 
	 public String merge(String newPath) throws IOException{
		 System.out.println("maxVersionPath " +maxVersionPath);
		 Enumeration e1 = Cdb.elements(maxVersionPath);
		 Enumeration e2 = Cdb.elements(newPath);
		  newVersion = Files.createTempDirectory("CDBMerged").toAbsolutePath().toString()+"/"+index + "-cdb";
		 CdbMake merged = new CdbMake();
			merged.start(newVersion);
			CdbElement el2= null;
			while(e1.hasMoreElements()){
				CdbElement el1 =(CdbElement) e1.nextElement();
				if(el2 == null && e2.hasMoreElements()){
					el2 =(CdbElement) e2.nextElement();
				}
				if(el2 == null){
					merged.add(el1.getKey(), el1.getData());
				}else{
				int res =ByteBuffer.wrap(el1.getKey()).compareTo((ByteBuffer.wrap(el2.getKey())));
				if( res == 0){
					merged.add(el1.getKey(), el2.getData());
					if(e2.hasMoreElements())
						el2 =(CdbElement) e2.nextElement();
					else
						el2 = null;
					
				}else{
					
					if(res > 0){
						do
						{
						merged.add(el2.getKey(), el2.getData());
						if(e2.hasMoreElements())
							el2 =(CdbElement) e2.nextElement();
						else
							el2 = null;	
						if(el2!=null)
							res =ByteBuffer.wrap(el1.getKey()).compareTo((ByteBuffer.wrap(el2.getKey())));
						else
							res = -1;
						}while( el2!= null && res > 0);
					}
						if(res == 0){
							merged.add(el1.getKey(), el2.getData());
							if(e2.hasMoreElements())
								el2 =(CdbElement) e2.nextElement();
							else
								el2 = null;	
						}
						else	
						merged.add(el1.getKey(), el1.getData());
				}
			}
			}
			if(el2 != null)
			merged.add(el2.getKey(),el2.getData());
			while(e2.hasMoreElements()){
				el2 = (CdbElement)e2.nextElement();
				System.out.println("inside merge " + el2.getKey());
				merged.add(el2.getKey(), el2.getData());
			}
			merged.finish();
			
			return newVersion;
	 }

	@Override
	public void close(TaskAttemptContext context) throws IOException,
			InterruptedException {
		if(index == -1)
			return;
		if(currIndex == 0)
			return;
		make.finish();
		
		//FileSystem fs =FileSystem.get(jobConf);
		
		File shardDir = new File(tempDir);
		
		// get earlier version
		//Path base =  new Path(baseOutput+"/"+index );
		/*List<Long> all = getAllVersions(context.getConfiguration());
		long maxVersion = 0;
		if(all.size() >0){
		int size	=all.size();
		Collections.sort(all);
		maxVersion =all.get((size - 1));
		
		}
		System.out.println("Max version is " + maxVersion);
		if( maxVersion > 0)
			copyToLocal(maxVersion, context.getConfiguration());*/
		Path out =  new Path(baseOutput+"/"+index + "/"+ System.currentTimeMillis());
		FileSystem fs =out.getFileSystem(context.getConfiguration());
		FsPermission filePerm = new FsPermission((short)0777);
		fs.mkdirs(out, filePerm);
	   
		File[] files =shardDir.listFiles();
		System.out.println("Copying files now " + files.length );
		for(File f:files){
			System.out.println("Copying file " +f.getPath() + " to " + out );
			if(maxVersionPath == null )
			fs.copyFromLocalFile(new Path(f.getPath()),new Path( out.toString() + "/" + f.getName()));
			else
			fs.copyFromLocalFile( new Path(merge(f.getPath())),new Path( out.toString() + "/" + f.getName()) );
		}
		System.out.println("Finished");
		
	}

}
