

package com.king.rbea.hashlookup;


public final class CdbElement {
	/** The key value for this element. */
	private byte[] key_ = null;

	/** The data value for this element. */
	private byte[] data_ = null;


	/**
	 * Creates an instance of the CdbElement class and initializes it
	 * with the given key and data values.
	 *
	 * @param key The key value for this element.
	 * @param data The data value for this element.
	 */
	public CdbElement(byte[] key, byte[] data) {
		key_ = key;
		data_ = data;
	}


	/**
	 * Returns this element's key.
	 *
	 * @return This element's key.
	 */
	public final byte[] getKey() {
		return key_;
	}

	/**
	 * Returns this element's data.
	 *
	 * @return This element's data.
	 */
	public final byte[] getData() {
		return data_;
	}
}
