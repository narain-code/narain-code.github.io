package com.king.rbea.hashlookup;

import java.io.IOException;

import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.mapreduce.JobContext;
import org.apache.hadoop.mapreduce.OutputCommitter;
import org.apache.hadoop.mapreduce.OutputFormat;
import org.apache.hadoop.mapreduce.RecordWriter;
import org.apache.hadoop.mapreduce.TaskAttemptContext;
import org.apache.hadoop.util.Progressable;

import com.twitter.elephantbird.mapreduce.output.WorkFileOverride.FileOutputFormat;

public class HashLookUpOutputFormat<K,V> extends OutputFormat<K, V> {


	



@Override
public RecordWriter<K, V> getRecordWriter(TaskAttemptContext context)
		throws IOException, InterruptedException {
	
	return new HashLookUpWriter<K, V>(context.getConfiguration());
}

@Override
public void checkOutputSpecs(JobContext context) throws IOException,
		InterruptedException {
	// TODO Auto-generated method stub
	
}

@Override
public OutputCommitter getOutputCommitter(TaskAttemptContext context)
		throws IOException, InterruptedException {
	// TODO Auto-generated method stub
	return new HashLoopCommitter();
}
}
