package com.king.splat;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.InputSplit;


import com.king.splat.kafka.Partition;

public class KafkaInputSplit extends InputSplit implements Writable {

	private Partition partition;
    private long startOffset;
    private long endOffset;
    private boolean partitionCommitter;
	
    public KafkaInputSplit() {
    }
    
   

    public KafkaInputSplit(final Partition partition, final long startOffset, final long endOffset,
            final boolean partitionCommitter) {
        this.partition = partition;
        this.startOffset = startOffset;
        this.endOffset = endOffset;
        this.partitionCommitter = partitionCommitter;
    }
    
	
	public void write(DataOutput out) throws IOException {
		this.partition.write(out);
        out.writeLong(startOffset);
        out.writeLong(endOffset);
        out.writeBoolean(partitionCommitter);
		
	}

	public void readFields(DataInput in) throws IOException {
		this.partition = new Partition();
        this.partition.readFields(in);
        this.startOffset = in.readLong();
        this.endOffset = in.readLong();
        this.partitionCommitter = in.readBoolean();
		
	}

	@Override
	public long getLength() throws IOException, InterruptedException {
		return endOffset - startOffset;
	}

	@Override
	public String[] getLocations() throws IOException, InterruptedException {
		return new String[] { toString() };
	}
	
	public Partition getPartition() {
        return partition;
    }

    public void setPartition(final Partition partition) {
        this.partition = partition;
    }

    public long getStartOffset() {
        return startOffset;
    }

    public void setStartOffset(final long startOffset) {
        this.startOffset = startOffset;
    }

    public long getEndOffset() {
        return endOffset;
    }

    public void setEndOffset(final long endOffset) {
        this.endOffset = endOffset;
    }

    public boolean isPartitionCommitter() {
        return partitionCommitter;
    }

    public void setPartitionCommitter(final boolean partitionCommitter) {
        this.partitionCommitter = partitionCommitter;
    }

    @Override
    public String toString() {
        return String.format("%s:%d:%s_%d[%d, %d]", partition.getBroker().getHost(), partition.getBroker().getPort(),
                partition.getTopic(), partition.getPartId(), startOffset, endOffset);
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o)
            return true;
        if (!(o instanceof KafkaInputSplit))
            return false;

        final KafkaInputSplit that = (KafkaInputSplit) o;

        if (endOffset != that.endOffset)
            return false;
        if (partitionCommitter != that.partitionCommitter)
            return false;
        if (startOffset != that.startOffset)
            return false;
        if (partition != null ? !partition.equals(that.partition) : that.partition != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = partition != null ? partition.hashCode() : 0;
        result = 31 * result + (int) (startOffset ^ (startOffset >>> 32));
        result = 31 * result + (int) (endOffset ^ (endOffset >>> 32));
        result = 31 * result + (partitionCommitter ? 1 : 0);
        return result;
    }

}
