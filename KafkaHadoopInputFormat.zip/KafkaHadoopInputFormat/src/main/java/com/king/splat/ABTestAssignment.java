package com.king.splat;

import java.io.IOException;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.serde2.columnar.BytesRefArrayWritable;
import org.apache.hadoop.hive.serde2.columnar.BytesRefWritable;
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import com.king.constants.EventField;
import com.king.event.Event;
import com.king.event.format.DelegatingEventFormat;
import com.king.event.format.EventFormat;
import com.king.event.format.util.HTMLEntityEncoder;
import com.king.event.format.util.IdentityDecoder;
import com.king.splat.util.ZkUtils;

public class ABTestAssignment {
	
	
	
	public static class ABTestMapper extends Mapper<LongWritable, BytesWritable, NullWritable, BytesRefArrayWritable> {
		EventFormat eventFormat = new DelegatingEventFormat(new HTMLEntityEncoder(),
				new IdentityDecoder());
		
	
		 NullWritable nullW = NullWritable.get();
		
		
	    public void map(LongWritable key, BytesWritable value, Context context) throws IOException, InterruptedException {
	    	
	    	Event event;
			try {
				event = eventFormat.parse(new String(value.getBytes()));
				if(event.getEventType() == 9020L){
					long coreUserId =event.get(EventField.AbTestCaseAssigned.coreUserId);
					String abTestName = event.get(EventField.AbTestCaseAssigned.abTestName);
					int abTestVersion = event.get(EventField.AbTestCaseAssigned.abTestVersion);
					int caseNum = event.get(EventField.AbTestCaseAssigned.caseNum);
					
				    BytesRefArrayWritable bytes = new BytesRefArrayWritable(3);
			            bytes.set(0, new BytesRefWritable( (""+coreUserId).getBytes("UTF-8")));
			            bytes.set(1, new BytesRefWritable( abTestName.getBytes("UTF-8")));
			            bytes.set(2, new BytesRefWritable( (""+abTestVersion).getBytes("UTF-8")));
			            bytes.set(3, new BytesRefWritable( (""+caseNum).getBytes("UTF-8")));
			           
				context.write(nullW, bytes);
			 }
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
	 
	}
	
	
	
	/**
	 *  building the job
	 */
	
	public static void main(String[] args){
	 try{	
		Configuration conf = new Configuration();
		
	    
	    if ( args.length < 4) {
	      System.err.println("Usage: Kafka2Hdfs <topic> <hdfsoutputpath> <zookeeper> <consumerGroup> <number of splits>");
	      System.exit(2);
	    }
	    
	    /**
	     * read up all the args
	     */
	    String topic = args[0];
	    String hdfsOutput = args[1];
	    String zookeeperURL = args[2];
	    String consumerGroup = args[3];
	    int mapper = 1;
	    int numberOfSplits = Integer.MAX_VALUE;
	   
	    numberOfSplits = Integer.parseInt(args[4]);
	    	
	    
	    
	    System.out.println( "###### Printing args  ##### ");
	    
	    System.out.println( "topic is " + topic);
	    System.out.println( "hdfsOutput is " + hdfsOutput);
	    System.out.println( "zookeeperURL is " + zookeeperURL);
	    System.out.println( "consumerGroup is " + consumerGroup);
	    System.out.println( "numberOfSplits is " + numberOfSplits);
	    System.out.println( "mapper is " + mapper);
	    System.out.println( "###### Printing args  ##### ");
	    
	    Job job = Job.getInstance(conf, "Slogo2AbTest-"+topic);
	    job.setJarByClass(ABTestAssignment.class);
	   
	    job.setMapperClass(ABTestMapper.class);
	    
	    
	    System.out.println( "mapperclass  is " + job.getMapperClass());
	    job.getConfiguration().setInt("hive.io.rcfile.column.number.conf", 9);
	    job.setOutputKeyClass(NullWritable.class);
	    job.setOutputValueClass(BytesRefArrayWritable.class);
	    job.setOutputFormatClass(com.twitter.elephantbird.mapreduce.output.RCFileOutputFormat.class);
	   // job.setOutputFormatClass(TextOutputFormat.class);
	    FileOutputFormat.setOutputPath(job, new Path(hdfsOutput));
	    job.setNumReduceTasks(0);
	   
	    /**
	     * 
	     * 
	     */
	    job.setInputFormatClass(KafkaInputFormat.class);
	    KafkaInputFormat.setConsumerGroup(job, consumerGroup);
	    // Set your Zookeeper connection string
	    KafkaInputFormat.setZkConnect(job, zookeeperURL);
	    // Set the topic you want to consume
	    KafkaInputFormat.setTopic(job, topic);
	    KafkaInputFormat.setMaxSplitsPerPartition(job,numberOfSplits );
	    
	   
	    List<InputSplit> allSplits =KafkaInputFormat.getAllSplits(job.getConfiguration(), topic,consumerGroup);
	    System.out.println(" The size is " + allSplits.size());
	    for(InputSplit s:allSplits){
	    	System.out.println(((KafkaInputSplit)s).getPartition() + " " + ((KafkaInputSplit)s).getStartOffset());
	    }
	    if (job.waitForCompletion(true)) {
	    	  final ZkUtils zk = new ZkUtils(job.getConfiguration());
	    	  zk.commit(consumerGroup,topic);
	    	  zk.close();
	    	} 

	    
	 }catch(Exception ex){
		 ex.printStackTrace();
	 }
	}
	
}
