package com.king.splat;

import java.io.IOException;

import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.util.ReflectionUtils;

public class DelegatingMapper<K1, V1, K2, V2> extends Mapper<K1, V1, K2, V2> {

    private Mapper<K1, V1, K2, V2> mapper;

    @SuppressWarnings("unchecked")
    protected void setup(Context context) throws IOException, InterruptedException {
        // Find the Mapper from the TaggedInputSplit.
        TaggedInputSplit inputSplit = (TaggedInputSplit) context.getInputSplit();
        mapper = (Mapper<K1, V1, K2, V2>) ReflectionUtils.newInstance(inputSplit.getMapperClass(),
                context.getConfiguration());

    }

    @SuppressWarnings("unchecked")
    public void run(Context context) throws IOException, InterruptedException {
        setup(context);
        System.out.println(" mapper is "+ mapper.getClass());
        mapper.run(context);
        cleanup(context);
    }
}
