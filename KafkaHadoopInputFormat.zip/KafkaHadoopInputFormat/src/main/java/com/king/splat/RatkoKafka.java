package com.king.splat;

import static java.lang.String.format;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.attribute.FileAttribute;
import java.nio.file.attribute.PosixFilePermission;
import java.nio.file.attribute.PosixFilePermissions;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.Partitioner;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.jobcontrol.ControlledJob;
import org.apache.hadoop.mapreduce.lib.jobcontrol.JobControl;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import com.king.event.format.DelegatingEventFormat;
import com.king.event.format.EventFormat;
import com.king.event.format.EventFormatException;
import com.king.event.format.util.HTMLEntityEncoder;
import com.king.event.format.util.IdentityDecoder;
import com.king.kafka.util.TopicUtil;

import com.king.rbea.hashlookup.Cdb;
import com.king.rbea.hashlookup.HashLookUpOutputFormat;
import com.king.splat.util.ZkUtils;


public class RatkoKafka {
	
	
	
	public static class ThePartitioner implements Partitioner<IntWritable, Text>{

		@Override
		public void configure(JobConf job) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public int getPartition(IntWritable key, Text value,
				int numPartitions) {
			
			return key.get()%numPartitions;
		}
		
	}
	
	
	public static class RatkoInstallReducer extends Reducer<IntWritable, Text, IntWritable, RKeyValueWritable>{
		
		
		private Cdb sideData = null;
		private boolean loaded = false;
		
		public List<Long> getAllVersions(Configuration conf,String baseOutput,int index) throws FileNotFoundException, IOException{
			 List<Long> ret = new ArrayList<Long>();
			
			 Path rootPath = new Path(baseOutput+"/"+index);
			  FileSystem fs =rootPath.getFileSystem(conf);
			 if (fs.exists(rootPath)) {
		            for(FileStatus stat: fs.listStatus(rootPath)) {
		            	Path p =stat.getPath()	;
		            	ret.add(Long.parseLong(p.getName()));
		            }
			 }
			 return ret;
		 }
		 
		 String maxVersionPath;
		 public void copyToLocal(long maxVersion , Configuration conf,String baseOutput,int index) throws IOException{
			 Path out =  new Path(baseOutput+"/"+index + "/" +maxVersion + "/" + index + "-cdb");
			 FileSystem fs =out.getFileSystem(conf);
			
			 maxVersionPath =Files.createDirectory(Paths.get("maxVersion")).toAbsolutePath().toString() +"/"+index+"-cdb";
			 Path dst = new Path(maxVersionPath);
			 fs.copyToLocalFile(out, dst);
			 
		 }
		boolean noVersions = false;
		public  void reduce (IntWritable key, Iterable<Text> values, Context context
					) throws IOException, InterruptedException {
			
			if( !loaded && !noVersions) {
				String baseOutput = context.getConfiguration().get("mapred.output.dir");
				List<Long> all = getAllVersions(context.getConfiguration(),baseOutput, key.get());
				long maxVersion = 0;
				if(all.size() >0){
				int size	=all.size();
				Collections.sort(all);
				maxVersion =all.get((size - 1));
				
				
				copyToLocal(maxVersion, context.getConfiguration(), baseOutput, key.get());
				sideData = new Cdb(maxVersionPath);
				loaded = true;
				}else{
					noVersions = true;
				}
				
			}
			
			String prev = null;
			String funnel = null;
			String entire = null;
			int counter =0;
			for(Text value:values) {
				 entire = value.toString();
				int index = entire.indexOf("|");
			//	System.out.println("entire " + entire  + " " +entire.substring(0,index) + " " + entire.substring(index + 1) );
				 // String[] parts =entire.split("|");
				 	funnel =entire.substring(0,index);
				 	String msgId = entire.substring((index + 1));
				  if(prev == null){
					  prev =msgId ;
				  }
				  if(!prev.equalsIgnoreCase(msgId)){
					  int prevCounter = 0;
					  if(loaded ){
						byte[] v= sideData.find(entire.getBytes());
						if(v != null && !"".equalsIgnoreCase(new String(v))){
							prevCounter = Integer.parseInt(new String(v));
						}
					  }	  
					  RKeyValueWritable val = new RKeyValueWritable(new BytesWritable(entire.getBytes()) , new BytesWritable((""+(counter+prevCounter)).getBytes()));
					  context.write(key, val);
					 System.out.println(funnel+ " " + msgId);
					  counter = 1;
					  prev = msgId;
					
				  }else{
					  counter ++;
				  }
			}
			
			if (counter > 0){
				
				  RKeyValueWritable val = new RKeyValueWritable(new BytesWritable(entire.getBytes()) , new BytesWritable((""+counter).getBytes()));
				  context.write(key, val);
				 
			}
		}
	
		
	
	}
	
	public static class RatkoInstallMapper extends Mapper<LongWritable, BytesWritable,IntWritable,Text>{
		
		EventFormat eventFormat = new DelegatingEventFormat(new HTMLEntityEncoder(),
				new IdentityDecoder());
		
		 MessageDigest instance = null;
		
		private static final String XPROMO="crosspromotion";
		private static final BigInteger numberofReducers = new BigInteger("32");
		
		public RatkoInstallMapper(){
			try {
				instance = MessageDigest.getInstance("MD5");
			} catch (NoSuchAlgorithmException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		
		 public void map(LongWritable key, BytesWritable value, Context context) throws IOException, InterruptedException {
			 
			 
			/* try {
				
				 
				 SCInstallAttributed attr = SCInstallAttributed.process(eventFormat.parse(new String(value.copyBytes())));
				 
				if(attr != null && XPROMO.equalsIgnoreCase( attr.getType()) && (attr.getSubType8() != null)){
					try{
					int messageId =Integer.parseInt(attr.getSubType8());
					String funnelStr =attr.getTransactionId();
					
					String outV = funnelStr+"|"+messageId;
					
					 instance.reset();
				        
				        instance.update(funnelStr.getBytes());
				        byte[] digest = instance.digest();

				       int partitionKey= new BigInteger(digest).mod(numberofReducers).intValue();
					context.write(new IntWritable(partitionKey), new Text(outV));
					}catch (NumberFormatException ex){
						ex.printStackTrace();
					} 
				}
				 
				 
			} catch (EventFormatException e) {
				
				e.printStackTrace();
			}*/
		 }
		
	}
	
	
	static class JobRunner implements Runnable {
		  private JobControl control;

		  public JobRunner(JobControl _control) {
		    this.control = _control;
		  }

		  public void run() {
		    this.control.run();
		  }
		}
	
	
	public static void main(String[] args){
		 try{	
			Configuration conf = new Configuration();
			
		    
		    if ( args.length < 4) {
		      System.err.println("Usage: Ratkokafka <topic> <hdfsoutputpath> <zookeeper> <consumerGroup> <number of splits> <mapper>");
		      System.exit(2);
		    }
		    
		    /**
		     * read up all the args
		     */
		    String topic = args[0];
		    String hdfsOutput = args[1];
		    String zookeeperURL = args[2];
		    String consumerGroup = args[3];
		    int mapper = 1;
		    int numberOfSplits = Integer.MAX_VALUE;
		    if(args.length > 4 && args[4] != null){
		    	numberOfSplits = Integer.parseInt(args[4]);
		    	mapper = Integer.parseInt(args[5]);
		    }
		    
		    System.out.println( "###### Printing args  ##### ");
		    
		    System.out.println( "topic is " + topic);
		    System.out.println( "hdfsOutput is " + hdfsOutput);
		    System.out.println( "zookeeperURL is " + zookeeperURL);
		    System.out.println( "consumerGroup is " + consumerGroup);
		    System.out.println( "numberOfSplits is " + numberOfSplits);
		    System.out.println( "mapper is " + mapper);
		    System.out.println( "###### Printing args  ##### ");
		    
		    Job job = Job.getInstance(conf, "RatkoKafka-"+topic);
		    job.setJarByClass(RatkoKafka.class);
		    job.setMapperClass(RatkoInstallMapper.class);
		    job.setReducerClass(RatkoInstallReducer.class);
		   
		    job.getConfiguration().setInt("hive.io.rcfile.column.number.conf", 9);
		    job.setMapOutputKeyClass(IntWritable.class);
		    job.setMapOutputValueClass(Text.class);
		    job.setOutputKeyClass(IntWritable.class);
		    job.setOutputValueClass(RKeyValueWritable.class);
		    job.setOutputFormatClass(HashLookUpOutputFormat.class);
		   // job.setOutputFormatClass(TextOutputFormat.class);
		    FileOutputFormat.setOutputPath(job, new Path(hdfsOutput));
		    job.setNumReduceTasks(32);
		   
		    /**
		     * 
		     * 
		     */
		    job.setInputFormatClass(KafkaInputFormat.class);
		    KafkaInputFormat.setConsumerGroup(job, consumerGroup);
		    // Set your Zookeeper connection string
		    KafkaInputFormat.setZkConnect(job, zookeeperURL);
		    // Set the topic you want to consume
		    KafkaInputFormat.setTopic(job, topic);
		    KafkaInputFormat.setMaxSplitsPerPartition(job,numberOfSplits );
		    
		   
		  /*  List<InputSplit> allSplits =KafkaInputFormat.getAllSplits(job.getConfiguration(), topic,consumerGroup);
		    System.out.println(" The size is " + allSplits.size());
		    for(InputSplit s:allSplits){
		    	System.out.println(((KafkaInputSplit)s).getPartition() + " " + ((KafkaInputSplit)s).getStartOffset());
		    }*/
		   /* if (job.waitForCompletion(true)) {
		    	  final ZkUtils zk = new ZkUtils(job.getConfiguration());
		    	  zk.commit(consumerGroup,topic);
		    	  zk.close();
		    	} */
		    JobControl ratkoInstallImpressions = new JobControl("Workflow-Ratko");
		    
		    ControlledJob ratkoInstallJob = new ControlledJob(job, null);
		   
		    
		   // ratkoInstallImpressions.addJob(ratkoInstallJob);
		    Job guiShown =Kafka2GuiShown.createJob(args);
		  
		    ControlledJob kafkaGuiShown = new ControlledJob(guiShown, null);
		    kafkaGuiShown.addDependingJob(ratkoInstallJob);
		   
		    ratkoInstallImpressions.addJob(kafkaGuiShown);
		    
		    JobRunner runner = new JobRunner(ratkoInstallImpressions);
		    Thread t = new Thread(runner);
		    t.start();

		 //  while (! ratkoInstallImpressions.allFinished()) {
		    	if(job.waitForCompletion(true)){
		    		final ZkUtils zk = new ZkUtils(job.getConfiguration());
			    	  zk.commit(consumerGroup,topic);
			    	  zk.close();
		    	}
		    	if(guiShown.waitForCompletion(true)){
		    		final ZkUtils zk = new ZkUtils(guiShown.getConfiguration());
		    		consumerGroup = "GuiShown-"+consumerGroup;
		    		System.out.println("committing " + consumerGroup + " " + format("%s/consumers/%s/offsets-temp", "Kafka", consumerGroup) + " "+ zk);
			    	  zk.commit(consumerGroup);
		    	//	TopicUtil tpUtil =  TopicUtil.connect("zk04.sto.midasplayer.com:2181,zk05.sto.midasplayer.com:2181,zk06.sto.midasplayer.com:2181/kafka");
		    	//	List<String> topics =tpUtil.getTopicNames( Pattern.compile("^event\\..*\\.log$"));
		    	//	String group=  "GuiShown-"+consumerGroup;
		    	//	for(String tp:topics){
		    			
		    			//zk.commit(group, topic);
		    	//	}
			    	  zk.close();
		    	}
		    	
		    	
		 //   }
		   System.exit(0);
		 }catch(Exception ex){
			 ex.printStackTrace();
		 }
		}
	
	

}
