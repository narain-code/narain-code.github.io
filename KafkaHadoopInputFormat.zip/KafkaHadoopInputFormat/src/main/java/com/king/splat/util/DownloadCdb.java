
package com.king.splat.util;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

public class DownloadCdb {
	
	public static List<Long> getAllVersions(FileSystem fs,String baseOutput,int index) throws FileNotFoundException, IOException{
		 List<Long> ret = new ArrayList<Long>();
		
		 Path rootPath = new Path(baseOutput+"/"+index);
		System.out.println(rootPath.toUri().getRawPath());
		System.out.println("baseOutput " +baseOutput + " "+fs.exists(rootPath));
		 if (fs.exists(rootPath)) {
	            for(FileStatus stat: fs.listStatus(rootPath)) {
	            	Path p =stat.getPath()	;
	            	System.out.println(p.getName());
	            	ret.add(Long.parseLong(p.getName()));
	            }
		 }
		 return ret;
	 }
	
	 public static void copyToLocal(long maxVersion , FileSystem fs,String baseOutput,int index, String maxVersionPath) throws IOException{
		 Path out =  new Path(baseOutput+"/"+index + "/" +maxVersion + "/" + index + "-cdb");
		
		 maxVersionPath =maxVersionPath +"/"+index+"-cdb";
		 Path dst = new Path(maxVersionPath);
		 System.out.println(maxVersionPath + " :: "+ out.getName());
		 fs.copyToLocalFile(out, dst);
		 
	 }
	
	public static void main(String[] args) throws IOException{
		Configuration conf =new Configuration();
		conf.addResource(new Path("/etc/hadoop/conf/core-site.xml"));
	    conf.addResource(new Path("/etc/hadoop/conf/hdfs-site.xml"));
	    conf.addResource(new Path("/etc/hadoop/conf/yarn-site.xml"));
	    
	    FileSystem fs = FileSystem.get(conf);
		for(int i=0;i<=31;i++){
			List<Long> all =	getAllVersions(fs, args[0], i);
			
			long maxVersion = 0;
			if(all.size() >0){
			int size	=all.size();
			Collections.sort(all);
			maxVersion =all.get((size - 1));
			copyToLocal(maxVersion, fs, args[0], i, args[1]);
		}
		
		}
	}
}
