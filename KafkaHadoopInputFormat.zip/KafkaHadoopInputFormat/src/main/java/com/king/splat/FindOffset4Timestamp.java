package com.king.splat;

import java.nio.ByteBuffer;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import kafka.api.FetchRequestBuilder;
import kafka.api.OffsetRequest;
import kafka.api.PartitionOffsetRequestInfo;
import kafka.common.TopicAndPartition;
import kafka.javaapi.FetchResponse;
import kafka.javaapi.OffsetResponse;
import kafka.javaapi.consumer.SimpleConsumer;
import kafka.message.MessageAndOffset;
import scala.actors.threadpool.Arrays;

import com.king.event.Event;
import com.king.event.format.DelegatingEventFormat;
import com.king.event.format.EventFormat;
import com.king.event.format.EventFormatException;
import com.king.event.format.util.HTMLEntityEncoder;
import com.king.event.format.util.IdentityDecoder;
import com.king.kafka.util.TopicUtil;
import com.king.splat.kafka.Broker;
import com.king.splat.kafka.Partition;
import com.king.splat.util.ZkUtils;
import java.io.Serializable;

public class FindOffset4Timestamp {
	
	private static final String zkConnectionString = "zk05.sto.midasplayer.com:2181";
	private static final String zkRoot = KafkaInputFormat.DEFAULT_ZK_ROOT;
	private static final int sessionTimeout = KafkaInputFormat.DEFAULT_ZK_SESSION_TIMEOUT_MS;
	private static final int connectionTimeout = KafkaInputFormat.DEFAULT_ZK_CONNECTION_TIMEOUT_MS;
	
	static EventFormat eventFormat = new DelegatingEventFormat(new HTMLEntityEncoder(),
			new IdentityDecoder());
	
	public static void main(String[] args){
		try{
		//String topic = args[0];
		//int jump = Integer.parseInt(args[1]);
		//String topic = "event.diamonddigger.log";
		
		
			TopicUtil tpUtil =  TopicUtil.connect("zk04.sto.midasplayer.com:2181,zk05.sto.midasplayer.com:2181,zk06.sto.midasplayer.com:2181/kafka");
		//	List<String> topics =tpUtil.getTopicNames( Pattern.compile("^event\\..*\\.log$"));
			String[] t ={"event.candycrush.log"};
			List<String> topics = Arrays.asList(t );
		
		int jump = 10000000;
		ZkUtils zk = new ZkUtils(zkConnectionString, zkRoot, sessionTimeout, connectionTimeout);
		for(String topic: topics){
			
		
		for (final Partition partition : zk.getPartitions(topic)) {
			//System.out.println(partition.getPartId() + " " + partition.getBroker().getId());
			  final Broker broker = partition.getBroker();
			  String clientName = "FindOffset422"+topic+"-"+broker.getId();
			  SimpleConsumer consumer = new SimpleConsumer(broker.getHost(), broker.getPort(), KafkaInputFormat.DEFAULT_SOCKET_TIMEOUT_MS,
					  KafkaInputFormat.DEFAULT_BUFFER_SIZE_BYTES, KafkaInputFormat.clientName+"-"+broker.getId());
			  TopicAndPartition topicAndPartition = new TopicAndPartition(topic, partition.getPartId());
		        Map<TopicAndPartition, PartitionOffsetRequestInfo> requestInfo = new HashMap<TopicAndPartition, PartitionOffsetRequestInfo>();
		        requestInfo.put(topicAndPartition, new PartitionOffsetRequestInfo(
		        		System.currentTimeMillis(), 1));
		        short version =0; // current version
		        kafka.javaapi.OffsetRequest request = new kafka.javaapi.OffsetRequest(requestInfo,version ,clientName);
		        OffsetResponse response = consumer.getOffsetsBefore(request);
		        
		        
		        final long[] allOffsets =response.offsets(topic, partition.getPartId());
		        
		        
		        requestInfo = new HashMap<TopicAndPartition, PartitionOffsetRequestInfo>();
		        long latestTime = -1L;
		        requestInfo.put(topicAndPartition, new PartitionOffsetRequestInfo(latestTime, 1));
		        request = new kafka.javaapi.OffsetRequest(requestInfo, version,clientName);
		        
		        response = consumer.getOffsetsBefore(request);
		        long[] maxOffset =response.offsets(topic, partition.getPartId());
		        if(allOffsets == null || allOffsets.length == 0)
		        	continue;
		       // System.out.println("Max " + maxOffset[0]  + " allOffsets " + allOffsets[0]);
		        if( maxOffset[0] <= allOffsets[0] )
		        	continue;
		        boolean continueLooking = true;
		        if(allOffsets == null || allOffsets.length == 0 )
		        	continue;
		        long reduce =3*((maxOffset[0] - allOffsets[0])/4); 
		        if(reduce<10)
		        	continue;
		     //  System.out.println("reduce is " + reduce);
		       // long beginOffset = maxOffset[0] -2_000_000_000l ;
		       // long beginOffset = maxOffset[0] -reduce ;
		        long beginOffset = allOffsets[0];
		      while(continueLooking){
		    	  FetchRequestBuilder builder = new FetchRequestBuilder();
		       kafka.api.FetchRequest req = builder.addFetch(topic, partition.getPartId(),beginOffset, jump).build();
		       FetchResponse resp = consumer.fetch(req);
		       
		       kafka.javaapi.message.ByteBufferMessageSet set =resp.messageSet(topic, partition.getPartId());
		       java.util.Iterator<MessageAndOffset>  it =set.iterator();
		       boolean start = true;
		       Event event;
		       MessageAndOffset msg = null;
		       long offset = 0 ;
		       Date dt  = null;
		       while(it.hasNext() && continueLooking){
		    	   msg= it.next();
		    	
		    	   if(start){
		    		    offset =msg.offset();
		    		    String dateStr = getDatefromMessage(msg);
		    		 // System.out.println( "Parition number " + partition.getPartId() +" offset :: " + offset +  " date " + getDatefromMessage(msg)) ;
		    		  start = false;
		    		  if(dateStr.indexOf("Wed") != -1){
				    	   continueLooking = false;
				       }
		    	   }
		       }
		       String dateStr = getDatefromMessage(msg);
		      
		     //  System.out.println( "dateStr " + dateStr);
		       if(dateStr.indexOf("Wed") != -1){
		    	   continueLooking = false;
		    	//   System.out.println(topic + " Parition number " +    +partition.getPartId() +" offset :: " + msg.offset()  +  " date " + dateStr) ;
		    	   System.out.println(topic + "\t" +    partition.getPartId() +"\t" + msg.offset());
		       }
		       if(msg == null){
		    	   continueLooking = false;
		       }
		       if(msg != null){
		       beginOffset =  msg.offset() ;
		       }
		       
		       if(dateStr.indexOf("Wed") != -1){
		    	   beginOffset = beginOffset - (reduce/3);
		    	   reduce = reduce /3;
		       }else{
		       beginOffset = beginOffset + (reduce/2);
		       }
		       //System.out.println("beginOffset is now " +beginOffset + " is it " + (beginOffset > maxOffset[0]));
		      }
		}
		}
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}

	
	    public static  String getDatefromMessage(MessageAndOffset msg) throws EventFormatException {
	    	if(msg==null || msg.message() ==null || msg.message().payload() == null){
	    		//System.out.println( " Message is null ");
	    		return "";
	    	}	
	    	 ByteBuffer buf = msg.message().payload();
   		  int size =msg.message().payloadSize();
   		  byte[] byt= buf.array();
   		  byte[] valBytes = new byte[size];
   		   System.arraycopy(byt, buf.arrayOffset(), valBytes, 0, size);
   		   //evenator time stamp
   		   Event event = eventFormat.parse(new String(valBytes));
   		   return new Date( event.getTimeStamp()).toString();
	    }
	
}
