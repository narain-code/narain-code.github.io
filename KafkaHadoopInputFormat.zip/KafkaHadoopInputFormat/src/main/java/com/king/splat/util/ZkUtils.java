package com.king.splat.util;

import static java.lang.String.format;

import java.io.Closeable;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import kafka.api.OffsetRequest;

import org.I0Itec.zkclient.ZkClient;
import org.I0Itec.zkclient.exception.ZkMarshallingError;
import org.I0Itec.zkclient.exception.ZkNoNodeException;
import org.I0Itec.zkclient.serialize.ZkSerializer;
import org.apache.hadoop.conf.Configuration;
import org.codehaus.jackson.map.ObjectMapper;

import com.google.common.base.Function;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.common.collect.Ranges;
import com.king.splat.KafkaInputFormat;
import com.king.splat.kafka.Broker;
import com.king.splat.kafka.Partition;

public class ZkUtils implements Closeable {

   
    private final ZkClient client;
    private final String zkRoot;
    private final ObjectMapper mapper = new org.codehaus.jackson.map.ObjectMapper();
    
    
    ZkUtils(final ZkClient client, final String zkRoot) {
        this.client = client;
        this.zkRoot = zkRoot.endsWith("/") ? zkRoot.substring(0, zkRoot.length() - 1) : zkRoot;
    }

    /**
     * Creates a Zookeeper client.
     * 
     * @param zkConnectionString
     *            the connection string for Zookeeper, e.g. {@code zk-1.com:2181,zk-2.com:2181}.
     * @param zkRoot
     *            the Zookeeper root of your Kafka configuration.
     * @param sessionTimeout
     *            Zookeeper session timeout for this client.
     * @param connectionTimeout
     *            Zookeeper connection timeout for this client.
     */
    public ZkUtils(final String zkConnectionString, final String zkRoot, final int sessionTimeout,
            final int connectionTimeout) {
        this(new ZkClient(zkConnectionString, sessionTimeout, connectionTimeout, new StringSerializer()), zkRoot);
    }

    /**
     * Creates a Zookeeper client based on the settings in {@link Configuration}.
     * 
     * @param config
     *            config with the Zookeeper settings in it.
     * @see KafkaInputFormat#getZkConnect(org.apache.hadoop.conf.Configuration)
     * @see KafkaInputFormat#getZkRoot(org.apache.hadoop.conf.Configuration)
     * @see KafkaInputFormat#getZkSessionTimeoutMs(org.apache.hadoop.conf.Configuration)
     * @see KafkaInputFormat#getZkConnectionTimeoutMs(org.apache.hadoop.conf.Configuration)
     */
    public ZkUtils(final Configuration config) {
    	
       this(KafkaInputFormat.getZkConnect(config), // zookeeper connection string
                KafkaInputFormat.getZkRoot(config), // zookeeper root
                KafkaInputFormat.getZkSessionTimeoutMs(config), // session timeout
                KafkaInputFormat.getZkConnectionTimeoutMs(config)); // connection timeout
        
       
    }

    /**
     * Closes the Zookeeper client
     * 
     * @throws IOException
     */
    @Override
    public void close() throws IOException {
        client.close();
    }

    /**
     * Gets the {@link Broker} by ID if it exists, {@code null} otherwise.
     * 
     * @param id
     *            the broker id.
     * @return a {@link Broker} if it exists, {@code null} otherwise.
     */
    public Broker getBroker(final Integer id) {
        String data = client.readData(getBrokerIdPath(id), true);
        if (!Strings.isNullOrEmpty(data)) {
           try {
			HashMap brokerInfo =mapper.readValue(data, HashMap.class);
			return new Broker((String)brokerInfo.get("host"), (Integer)brokerInfo.get("port"), id);
		} catch (Exception ex){
			throw new RuntimeException(ex.getMessage());
		}
        }
        return null;
    }

    /**
     * Gets all of the {@link Broker}s in this Kafka cluster.
     * 
     * @return all of the {@link Broker}s in this Kafka cluster.
     */
    public List<Broker> getBrokers() {
        final List<Broker> brokers = Lists.newArrayList();
        final List<String> ids = getChildrenParentMayNotExist(getBrokerIdSubPath());
        for (final String id : ids) {
            brokers.add(getBroker(Integer.parseInt(id)));
        }
        return brokers;
    }

    /**
     * A {@link List} of all the {@link Partition} for a given {@code topic}.
     * 
     * @param topic
     *            the topic.
     * @return all the {@link Partition} for a given {@code topic}.
     */
    public List<Partition> getPartitions(final String topic) {
        final List<Partition> partitions = Lists.newArrayList();
        //final List<String> brokersHostingTopic = getChildrenParentMayNotExist(getTopicBrokerIdSubPath(topic));
        	String partitionPath =getTopicBrokerIdSubPath(topic)+ "/partitions";
        	final List<String> brokersHostingTopic = getChildrenParentMayNotExist(partitionPath);
        for (final String partitionId : brokersHostingTopic) {
        	
            final int paritionId = Integer.parseInt(partitionId);
            final String parts = client.readData(partitionPath+"/"+partitionId + "/state");
            Map<?, ?> partitionInfo;
			try {
				partitionInfo = mapper.readValue(parts, HashMap.class);
			
            // Get leader broker for this partition
			Integer leader = (Integer) partitionInfo.get("leader");
			
            final Broker brokerInfo = getBroker(leader);
          //  for (int i = 0; i < Integer.valueOf(parts); i++) {
                partitions.add(new Partition(topic, paritionId, brokerInfo));
            //}
			} catch (IOException e) {
				throw new RuntimeException(e.getMessage());
			}
        }
       // System.out.println("partitions size " + partitions.size());
        return partitions;
    }

    /**
     * Checks whether the provided partition exists on the {@link Broker}.
     * 
     * @param broker
     *            the broker.
     * @param topic
     *            the topic.
     * @param partId
     *            the partition id.
     * @return true if this partition exists on the {@link Broker}, false otherwise.
     */
    public boolean partitionExists(final Broker broker, final String topic, final int partId) {
        final String parts = client.readData(getTopicBrokerIdPath(topic, broker.getId()), true);
        return !Strings.isNullOrEmpty(parts) && Ranges.closedOpen(0, Integer.parseInt(parts)).contains(partId);
    }

    /**
     * Gets the last commit made by the {@code group} on the {@code topic-partition}.
     * 
     * @param group
     *            the consumer group.
     * @param partition
     *            the partition.
     * @return the last offset, {@code -1} if the {@code group} has never committed an offset.
     */
    public long getLastCommit(String group, Partition partition) {
        final String offsetPath = getOffsetsPath(group, partition);
        final String offset = client.readData(offsetPath, true);
        System.out.println(" reading from " + group + " " +partition.getTopic() + " " + offset);
        if (offset == null) {
            return OffsetRequest.EarliestTime();

        }
        return Long.valueOf(offset);
    }

    /**
     * ` Sets the last offset to {@code commit} of the {@code group} for the given {@code topic-partition}.
     * <p/>
     * If {@code temp == true}, this will "temporarily" set the offset, in which case the user must call
     * {@link #commit(String, String)}. This is useful if a user wants to temporarily commit an offset for a topic
     * partition, and then commit it once <em>all</em> topic partitions have completed.
     * 
     * @param group
     *            the consumer group.
     * @param partition
     *            the partition.
     * @param commit
     *            the commit offset.
     * @param temp
     *            If {@code temp == true}, this will "temporarily" set the offset, in which case the user must call
     *            {@link #commit(String, String)}. This is useful if a user wants to temporarily commit an offset for a
     *            topic partition, and then commit it once the user has finished consuming <em>all</em> topic
     *            partitions.
     */
    public void setLastCommit(final String group, final Partition partition, final long commit, final boolean temp) {
    	if(!temp)
    	System.out.println("last commit "+commit + " "+ group + " " + partition.getTopic() + " " + partition.getPartId());
        final String path = temp ? getTempOffsetsPath(group, partition) : getOffsetsPath(group, partition);
        if (!client.exists(path)) {
            client.createPersistent(path, true);
        }
        client.writeData(path, commit);
    }

    /**
     * Commits any temporary offsets of the {@code group} for a given {@code topic}.
     * 
     * @param group
     *            the consumer group.
     * @param topic
     *            the topic.
     * @return true if the commit was successful, false otherwise.
     */
    public boolean commit(final String group, final String topic) {
        for (final Partition partition : getPartitionsWithTempOffsets(topic, group)) {
            final String path = getTempOffsetsPath(group, partition);
            System.out.println("offsets path "+path);
            final String offset = client.readData(path);
            setLastCommit(group, partition, Long.valueOf(offset), false);
            client.delete(path);
        }
        return true;
    }

    public boolean commit(String group) {
    	System.out.println("group is "+ group);
    	System.out.println(format("%s/consumers/%s/offsets-temp", zkRoot, group));
    	List<String> zkTopics =getChildrenParentMayNotExist(format("%s/consumers/%s/offsets-temp", zkRoot, group));
    	for(String topic:zkTopics){
        for (final Partition partition : getPartitionsWithTempOffsets(topic, group)) {
            final String path = getTempOffsetsPath(group, partition);
           
            final String offset = client.readData(path);
           
            System.out.println("offsets path "+path + " " + offset);
           setLastCommit(group, partition, Long.valueOf(offset), false);
            
            client.delete(path);
        }
    	}
        return true;
    }
    
    public List<Partition> getPartitionsWithTempOffsets(final String topic, final String group) {
        final List<String> brokerPartIds = getChildrenParentMayNotExist(getTempOffsetsSubPath(group, topic));
        return Lists.transform(brokerPartIds, new Function<String, Partition>() {
            @Override
            public Partition apply(final String brokerPartId) {
                // brokerPartId = brokerId-partId
                final String[] brokerIdPartId = brokerPartId.split("-");
                final Broker broker = getBroker(Integer.parseInt(brokerIdPartId[0]));
                return new Partition(topic, Integer.parseInt(brokerIdPartId[1]), broker);
            }
        });
    }

   
  public  List<String> getChildrenParentMayNotExist(String path) {
        try {
            return client.getChildren(path);
        } catch (final ZkNoNodeException e) {
            return Lists.newArrayList();
        }
    }

   
    String getOffsetsPath(String group, Partition partition) {
        return format("%s/consumers/%s/offsets/%s/%s", zkRoot, group, partition.getTopic(),
                partition.getPartId());
    }

    
   public String getTempOffsetsPath(String group, Partition partition) {
        return format("%s/%s", getTempOffsetsSubPath(group, partition.getTopic()), partition.getBrokerPartition());
    }

   
    String getTempOffsetsSubPath(String group, String topic) {
        return format("%s/consumers/%s/offsets-temp/%s", zkRoot, group, topic);
    }

   
    String getBrokerIdSubPath() {
        return format("%s/brokers/ids", zkRoot);
    }

    
    String getBrokerIdPath(final Integer id) {
        return format("%s/%d", getBrokerIdSubPath(), id);
    }

    
    private final static String topicString = "%s/brokers/topics/%s";
    
    String getTopicBrokerIdSubPath(final String topic) {
        return format(topicString, zkRoot, topic);
    }

    
    String getTopicBrokerIdPath(final String topic, final int brokerId) {
        return format("%s/%d", getTopicBrokerIdSubPath(topic), brokerId);
    }

  
    static class StringSerializer implements ZkSerializer {

        public StringSerializer() {
        }

        @Override
        public Object deserialize(byte[] data) throws ZkMarshallingError {
            if (data == null)
                return null;
            return new String(data);
        }

        @Override
        public byte[] serialize(Object data) throws ZkMarshallingError {
            return data.toString().getBytes();
        }

    }

    
    String getZkRoot() {
        return zkRoot;
    }
}