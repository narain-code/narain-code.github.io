
package com.king.splat;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.serde2.columnar.BytesRefArrayWritable;
import org.apache.hadoop.hive.serde2.columnar.BytesRefWritable;
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import com.king.event.Event;
import com.king.event.format.DelegatingEventFormat;
import com.king.event.format.EventFormat;
import com.king.event.format.EventFormatException;
import com.king.event.format.util.HTMLEntityEncoder;
import com.king.event.format.util.IdentityDecoder;
import com.king.splat.util.ZkUtils;

public class KafkaPerEventTable {
	
	public static class PerEventMapper extends Mapper<LongWritable, BytesWritable, NullWritable, BytesRefArrayWritable> {
	
	org.apache.hadoop.mapreduce.lib.output.MultipleOutputs<NullWritable, BytesRefArrayWritable> mos;
	
	 NullWritable nullW = NullWritable.get();
	 String encoding = "UTF-8";
	  EventFormat eventFormat = new DelegatingEventFormat(new HTMLEntityEncoder(),
				new IdentityDecoder());
	  HashSet<Long> eventTypes = new HashSet();
	 @Override
		protected void setup(Context context
             ) throws IOException, InterruptedException {
				mos = new org.apache.hadoop.mapreduce.lib.output.MultipleOutputs<NullWritable, BytesRefArrayWritable>(context);
				String filter =context.getConfiguration().get("kafka.eventfilter");
				System.out.println(filter);
				String[] filters =filter.split(",");
				
				
				for(String ev:filters){
					eventTypes.add(Long.parseLong(ev));
					
				}
		}
	
	 @Override
     public void cleanup(Context context) throws IOException, InterruptedException {
               mos.close();
     }
	 
	 public final static long MINUTES_15= 1000*60*15;
	 
	 public void map(LongWritable key, BytesWritable value, Context context) throws IOException, InterruptedException {
		
		 try{
     		Event ev =eventFormat.parse(new String(value.copyBytes(),encoding));
     		long type =ev.getEventType();
     		System.out.println(type);
     		if(eventTypes.contains(type)){
     			System.out.println("inside");
     			List<String> fields = new ArrayList<String>();
     			for(String f:ev.fields()){
     				fields.add(f);
     				
     			}
     			
     			BytesRefArrayWritable v = new BytesRefArrayWritable(fields.size() );
     			for(int i=0;i<fields.size();i++){
     				if(fields.get(i) == null){
     					v.set(i, BytesRefWritable.ZeroBytesRefWritable);
     				}else{
     					v.set(i, new BytesRefWritable(fields.get(i).getBytes(encoding)));
     				}
     			}
     			/*long timestamp = System.currentTimeMillis();
     			timestamp = timestamp -(timestamp%MINUTES_15);
     			v.set(fields.size(), new BytesRefWritable((""+timestamp).getBytes(encoding)));*/
     			mos.write(""+type, nullW, v);
     		}
     		
     		}catch(EventFormatException ex){
     			System.out.println(" bad event " + new String(value.copyBytes(),encoding));
     			
     		}
	 }
	 
	}
	/**
	 *  building the job
	 */
	
	public static void main(String[] args){
	 try{	
		Configuration conf = new Configuration();
		
	    
	    if ( args.length < 4) {
	      System.err.println("Usage: KafkaPerEventTable <topic> <hdfsoutputpath> <zookeeper> <consumerGroup> <number of splits> <filter>");
	      System.exit(2);
	    }
	    
	    /**
	     * read up all the args
	     */
	    String topic = args[0];
	    String hdfsOutput = args[1];
	    String zookeeperURL = args[2];
	    String consumerGroup = args[3];
	    String filter ="sagaappgamestart2";
	    int numberOfSplits = Integer.MAX_VALUE;
	    if(args.length > 4 && args[4] != null){
	    	numberOfSplits = Integer.parseInt(args[4]);
	    	filter = args[5];
	    }
	    
	    System.out.println( "###### Printing args  ##### ");
	    
	    System.out.println( "topic is " + topic);
	    System.out.println( "hdfsOutput is " + hdfsOutput);
	    System.out.println( "zookeeperURL is " + zookeeperURL);
	    System.out.println( "consumerGroup is " + consumerGroup);
	    System.out.println( "numberOfSplits is " + numberOfSplits);
	  
	    System.out.println( "###### Printing args  ##### ");
	    
	    Job job = Job.getInstance(conf, "Kafka2Hdfs-"+topic);
	   
	    job.setJarByClass(KafkaPerEventTable.class);
	    job.setMapperClass(PerEventMapper.class);
	    System.out.println( "mapperclass  is " + job.getMapperClass());
	    job.getConfiguration().setInt("hive.io.rcfile.column.number.conf", 9);
	    job.setOutputKeyClass(NullWritable.class);
	    job.setOutputValueClass(BytesRefArrayWritable.class);
	   // job.setOutputFormatClass(com.twitter.elephantbird.mapreduce.output.RCFileOutputFormat.class);
	   // job.setOutputFormatClass(TextOutputFormat.class);
	    FileOutputFormat.setOutputPath(job, new Path(hdfsOutput));
	    job.setNumReduceTasks(0);
	   
	  
	    job.setInputFormatClass(KafkaInputFormat.class);
	    KafkaInputFormat.setConsumerGroup(job, consumerGroup);
	    // Set your Zookeeper connection string
	    KafkaInputFormat.setZkConnect(job, zookeeperURL);
	    // Set the topic you want to consume
	    KafkaInputFormat.setTopic(job, topic);
	    KafkaInputFormat.setMaxSplitsPerPartition(job,numberOfSplits );
	    job.getConfiguration().set("kafka.eventfilter", filter);
	    String[] filters = filter.split(",");
	    for(String f:filters){
	    	 org.apache.hadoop.mapreduce.lib.output.MultipleOutputs.addNamedOutput(job,f,  com.twitter.elephantbird.mapreduce.output.RCFileOutputFormat.class, NullWritable.class, BytesRefArrayWritable.class);
	    }
	   
	    List<InputSplit> allSplits =KafkaInputFormat.getAllSplits(job.getConfiguration(), topic,consumerGroup);
	    System.out.println(" The size is " + allSplits.size());
	    for(InputSplit s:allSplits){
	    	System.out.println(((KafkaInputSplit)s).getPartition()  + " " + ((KafkaInputSplit)s).getStartOffset());
	    }
	    if (job.waitForCompletion(true)) {
	    	  final ZkUtils zk = new ZkUtils(job.getConfiguration());
	    	  zk.commit(consumerGroup,topic);
	    	  zk.close();
	    	} 

	    
	 }catch(Exception ex){
		 ex.printStackTrace();
	 }
	}

}
