package com.king.splat;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.mapreduce.InputFormat;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.JobContext;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.RecordReader;
import org.apache.hadoop.mapreduce.TaskAttemptContext;
import org.apache.hadoop.mapreduce.task.TaskAttemptContextImpl;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;

public class MultipleKafkaInputFormat extends InputFormat<LongWritable, BytesWritable> {

	private static final String TOPICS_CONF = "kafka.topics";

	@Override
	public List<InputSplit> getSplits(JobContext context) throws IOException,
			InterruptedException {
		final Configuration conf = context.getConfiguration();
        final List<InputSplit> splits = Lists.newArrayList();
        final List<TopicConf> topicConfs = getTopics(conf);
        warnOnDuplicateTopicConsumers(topicConfs);
        for (final TopicConf topicConf : topicConfs) {
            final String topic = topicConf.getTopic();
            final String group = topicConf.getConsumerGroup();
            final Class<? extends Mapper> delegateMapper = topicConf.getMapper();
            for (final InputSplit inputSplit : getInputSplits(conf, group, topic)) {
                splits.add(new TaggedInputSplit(inputSplit, conf, KafkaInputFormat.class, delegateMapper));
            }
        }
        return splits;
	}

	List<InputSplit> getInputSplits(final Configuration conf, final String group, final String topic)
            throws IOException {
        return new KafkaInputFormat().getInputSplits(conf, topic, group);
    }
	
	 public static List<TopicConf> getTopics(final Configuration conf) {
	        final List<TopicConf> result = Lists.newArrayList();
	        for (final String topicConf : conf.get(TOPICS_CONF).split(";")) {
	            final String[] topicConfTokens = topicConf.split(",");
	            final String topic = topicConfTokens[0];
	            final String group = topicConfTokens[1];
	            final Class<? extends Mapper> mapper;
	            try {
	                mapper = (Class<? extends Mapper>) conf.getClassByName(topicConfTokens[2]);
	            } catch (final ClassNotFoundException e) {
	                throw new RuntimeException(e);
	            }
	            result.add(new TopicConf(topic, group, mapper));
	        }
	        return result;
	    }

	 
	 private void warnOnDuplicateTopicConsumers(final List<TopicConf> topicConfs) {
	        final Set<String> topicConsumers = Sets.newHashSet();
	        for (final TopicConf topicConf : topicConfs) {
	            final String topicConsumer = topicConf.getTopic() + topicConf.getConsumerGroup();
	            if (topicConsumers.contains(topicConsumer)) {
	               System.out.println(String.format(
	                        "Found duplicate consumer group '%s' consuming the same topic '%s'! "
	                                + "This may cause non-deterministic behavior if you commit your offsets for this consumer group!",
	                        topicConf.getConsumerGroup(), topicConf.getTopic()));
	            }
	            topicConsumers.add(topicConsumer);
	        }
	    }

	
	@Override
	public RecordReader<LongWritable, BytesWritable> createRecordReader(
			InputSplit split, TaskAttemptContext context) throws IOException,
			InterruptedException {
		 final TaggedInputSplit taggedInputSplit = (TaggedInputSplit) split;
	        final TaskAttemptContext taskAttemptContextClone = new TaskAttemptContextImpl(taggedInputSplit.getConf(),
	                context.getTaskAttemptID());
	        taskAttemptContextClone.setStatus(context.getStatus());
	        return new DelegatingRecordReader<LongWritable, BytesWritable>(split, taskAttemptContextClone);
	}
	
	
	public static void addTopic(final Job job, final String topic, final String consumerGroup,
            final Class<? extends Mapper> mapperClass) {
       // job.setMapperClass(DelegatingMapper.class);
        final String existingTopicConf = job.getConfiguration().get(TOPICS_CONF);
        final String topicConfig = String.format("%s,%s,%s", topic, consumerGroup, mapperClass.getName());
        if (Strings.isNullOrEmpty(existingTopicConf)) {
            job.getConfiguration().set(TOPICS_CONF, topicConfig);
        } else {
            job.getConfiguration().set(TOPICS_CONF, String.format("%s;%s", existingTopicConf, topicConfig));
        }
    }

	
	
	 public static class TopicConf {
	        private final String topic;
	        private final String consumerGroup;
	        private final Class<? extends Mapper> mapper;

	        public TopicConf(final String topic, final String consumerGroup, final Class<? extends Mapper> mapper) {
	            this.topic = topic;
	            this.consumerGroup = consumerGroup;
	            this.mapper = mapper;
	        }

	        public String getTopic() {
	            return topic;
	        }

	        public String getConsumerGroup() {
	            return consumerGroup;
	        }

	        public Class<? extends Mapper> getMapper() {
	            return mapper;
	        }

	        @Override
	        public String toString() {
	            return String.format("group %s consuming %s mapped by %s", consumerGroup, topic, mapper);
	        }

	        @Override
	        public boolean equals(final Object o) {
	            if (this == o)
	                return true;
	            if (!(o instanceof TopicConf))
	                return false;

	            final TopicConf topicConf = (TopicConf) o;

	            if (consumerGroup != null ? !consumerGroup.equals(topicConf.consumerGroup)
	                    : topicConf.consumerGroup != null)
	                return false;
	            if (mapper != null ? !mapper.equals(topicConf.mapper) : topicConf.mapper != null)
	                return false;
	            if (topic != null ? !topic.equals(topicConf.topic) : topicConf.topic != null)
	                return false;

	            return true;
	        }

	        @Override
	        public int hashCode() {
	            int result = topic != null ? topic.hashCode() : 0;
	            result = 31 * result + (consumerGroup != null ? consumerGroup.hashCode() : 0);
	            result = 31 * result + (mapper != null ? mapper.hashCode() : 0);
	            return result;
	        }
	    }
}
