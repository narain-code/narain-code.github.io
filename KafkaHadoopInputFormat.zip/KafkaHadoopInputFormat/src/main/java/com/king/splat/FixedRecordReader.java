
package com.king.splat;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import kafka.api.FetchRequest;
import kafka.api.FetchRequestBuilder;
import kafka.api.OffsetRequest;
import kafka.api.PartitionOffsetRequestInfo;
import kafka.common.ErrorMapping;
import kafka.common.TopicAndPartition;
import kafka.javaapi.OffsetResponse;
import kafka.javaapi.consumer.SimpleConsumer;
import kafka.message.Message;
import kafka.message.MessageAndOffset;

import org.apache.commons.io.IOUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.RecordReader;
import org.apache.hadoop.mapreduce.TaskAttemptContext;

import com.google.common.collect.Lists;
import com.king.splat.kafka.Broker;
import com.king.splat.kafka.Partition;
import com.king.splat.util.ZkUtils;

public class FixedRecordReader extends RecordReader<LongWritable, BytesWritable> {

	FixedKafkaInputSplit split;
	Partition currentPartition = null;
	Configuration conf;
	private long startOffset;
	private long endOffset;
	private long currOffset;
	private int fetchSize;
	private List<String> topics;
	private ZkUtils zkUtils = null;
	private SimpleConsumer consumer = null;
	private int currTopic = 0;
	private String clientName;
	 private Iterator<MessageAndOffset> currentMessageItr;
	 
	 public static final int DEFAULT_FETCH_SIZE_BYTES = 1024 * 1024; // 1MB
	    /**
	     * Default Kafka socket timeout, 10 seconds.
	     */
	    public static final int DEFAULT_SOCKET_TIMEOUT_MS = (int) TimeUnit.SECONDS.toMillis(10);
	    /**
	     * Default Kafka buffer size, 64KB.
	     */
	    public static final int DEFAULT_BUFFER_SIZE_BYTES = 64 * 1024; // 64 KB
	    /**
	     * Default Zookeeper session timeout, 10 seconds.
	     */
	    public static final int DEFAULT_ZK_SESSION_TIMEOUT_MS = (int) TimeUnit.SECONDS.toMillis(10);
	    /**
	     * Default Zookeeper connection timeout, 10 seconds.
	     */
	    public static final int DEFAULT_ZK_CONNECTION_TIMEOUT_MS = (int) TimeUnit.SECONDS.toMillis(10);
	    
	    private LongWritable key;
	    private BytesWritable value;
	@Override
	public void initialize(InputSplit split, TaskAttemptContext context)
			throws IOException, InterruptedException {
		 if (!(split instanceof FixedKafkaInputSplit)) {
	            throw new IllegalArgumentException("Expected an InputSplit of type FixedKafkaInputSplit but got "
	                    + split.getClass());
	        }

	        final FixedKafkaInputSplit inputSplit = (FixedKafkaInputSplit) split;
	        this.conf = context.getConfiguration();
	        this.split = inputSplit;
	        this.fetchSize = FixedKafkaInputFormat.getKafkaFetchSizeBytes(conf);
	        this.clientName =conf.get("kafka.groupid");
	        System.out.println("clientName");
	        initTopics();
	        initConsumer(topics.get(currTopic));
	        
	}

	public void initTopics(){
	 ZkUtils zkUtils=	getZk();
	 final List<String> result = Lists.newArrayList();
     for (final String topicConf : conf.get("kafka.topic").split(";")) {
    	 	result.add(topicConf);
     }
     this.topics = result;
     
	}
	
	public void initConsumer(String topic){
		if(consumer != null){
			consumer.close();
			consumer = null;
			zkUtils.setLastCommit(this.clientName,this.currentPartition,this.endOffset,true);
		}
		 for (final Partition partition : zkUtils.getPartitions(topic)) {
			 if(partition.getPartId() == this.split.getPartId()){
				this.currentPartition = partition;
				this.currOffset= zkUtils.getLastCommit(clientName, partition);
				 consumer = getConsumer(partition.getBroker());
				 getOffsets(consumer,topic,this.split.getPartId(),currOffset);
			 }
		 }
	}
	
	SimpleConsumer getConsumer(final Broker broker) {
        return new SimpleConsumer(broker.getHost(), broker.getPort(), DEFAULT_SOCKET_TIMEOUT_MS,
                DEFAULT_BUFFER_SIZE_BYTES, conf.get("kafka.groupid") +"-"+broker.getId());
    }
	
	@Override
	public boolean nextKeyValue() throws IOException, InterruptedException {
		 if (key == null) {
	            key = new LongWritable();
	        }
	        if (value == null) {
	            value = new BytesWritable();
	        }
	        if (continueItr()) {
	            final MessageAndOffset msg = getCurrentMessageItr().next();
	            final long msgOffset = msg.offset();
	            final Message message = msg.message();
	            final ByteBuffer buffer = message.payload();
	           
	            value.set(buffer.array(), buffer.arrayOffset(), buffer.remaining());
	            key.set(msgOffset);
	           
	            currOffset =msg.nextOffset();
	            return true;
	        }else{
	        	if(currTopic < (topics.size() -1)){
	        		currTopic ++;
	        		System.out.println("topic is " +topics.get(currTopic));
	        		initConsumer(topics.get(currTopic));
	        		 if (continueItr()) {
	     	            final MessageAndOffset msg = getCurrentMessageItr().next();
	     	            final long msgOffset = msg.offset();
	     	            final Message message = msg.message();
	     	            final ByteBuffer buffer = message.payload();
	     	           
	     	            value.set(buffer.array(), buffer.arrayOffset(), buffer.remaining());
	     	            key.set(msgOffset);
	     	           
	     	            currOffset =msg.nextOffset();
	     	            return true;
	     	        }
	        	}
	        }
	        return false;
	}

	@Override
	public LongWritable getCurrentKey() throws IOException,
			InterruptedException {
		
		return key;
	}

	@Override
	public BytesWritable getCurrentValue() throws IOException,
			InterruptedException {
		
		return value;
	}

	@Override
	public float getProgress() throws IOException, InterruptedException {
		 if (currOffset >= endOffset || currOffset == endOffset) {
	            return 1.0f;
	        }
	        return Math.min(1.0f, (currOffset ) / (float) (endOffset ));
	}

	@Override
	public void close() throws IOException {
		consumer.close();
		zkUtils.setLastCommit(this.clientName,this.currentPartition,this.endOffset,true);
		zkUtils.close();
	}
	
	
	public void getOffsets(SimpleConsumer consumer,String topic,  int partitionNum , final long lastCommit){
		TopicAndPartition topicAndPartition = new TopicAndPartition(topic, partitionNum);
        Map<TopicAndPartition, PartitionOffsetRequestInfo> requestInfo = new HashMap<TopicAndPartition, PartitionOffsetRequestInfo>();
        requestInfo.put(topicAndPartition, new PartitionOffsetRequestInfo(OffsetRequest.LatestTime(),
        		//epoch, 
        		Integer.MAX_VALUE));
        kafka.javaapi.OffsetRequest request = new kafka.javaapi.OffsetRequest(requestInfo, kafka.api.OffsetRequest.CurrentVersion(),clientName);
        OffsetResponse response = consumer.getOffsetsBefore(request);
        final long[] allOffsets =response.offsets(topic, partitionNum);
        long max = -1;
       
        for (final long offset : allOffsets) {
        	 if (offset > lastCommit){
        		  if( offset > max){
        			  max = offset;
        		  }
        	 }
        }
        this.endOffset = max;
        this.currOffset = lastCommit;
	}
	
	 boolean continueItr() {
	       
	        if (!canCallNext() && (endOffset-currOffset) > 0) {
	            final int theFetchSize = (fetchSize > (endOffset-currOffset)) ? (int) (endOffset-currOffset) : fetchSize;
	        /*    System.out.println(String.format("%s fetching %d bytes starting at offset %d", split.toString(), theFetchSize,
	                    currentOffset));*/
	        /*    final FetchRequest request = new FetchRequest(split.getPartition().getTopic(), split.getPartition()
	                    .getPartId(), currentOffset, theFetchSize);*/
	            FetchRequestBuilder  builder =new kafka.api.FetchRequestBuilder().
		  					clientId(this.clientName + this.split.getPartId());
	            builder.addFetch(this.topics.get(currTopic), this.split.getPartId(),currOffset, theFetchSize);
	            FetchRequest req =builder.build();
	            kafka.javaapi.FetchResponse response = consumer.fetch(req);
	            kafka.javaapi.message.ByteBufferMessageSet msg =response.messageSet(this.topics.get(currTopic), this.split.getPartId());
	            
	            final short errorCode = response.errorCode(this.topics.get(currTopic), this.split.getPartId());		
	            if (errorCode == ErrorMapping.OffsetOutOfRangeCode()) {
	                return false;
	            }
	            if (errorCode != ErrorMapping.NoError()) {
	                ErrorMapping.maybeThrowException(errorCode);
	            } // --> else we try to grab the next iterator
	            currentMessageItr = msg.iterator();
	            //currentOffset += msg.validBytes();
	           
	        }
	        
	        return canCallNext();
	    }

	   
	    boolean canCallNext() {
	        return getCurrentMessageItr() != null && getCurrentMessageItr().hasNext();
	    }

	    
	    void commitOffset() throws IOException {
	        ZkUtils zk = null;
	        try {
	            zk = getZk();
	           
	            /**
	             * Note: last parameter (temp) MUST be true. It is up to the ToolRunner to commit offsets upon successful
	             * job execution. Reason: since there are multiple input splits per partition, the consumer group could get
	             * into a bad state if this split finished successfully and committed the offset while another input split
	             * from the same partition didn't finish successfully.
	             */
	            zk.setLastCommit(this.clientName, this.currentPartition, currOffset, true);
	        } finally {
	            IOUtils.closeQuietly(zk);
	        }
	    }

	   

	   
	    ZkUtils getZk() {
	    	if(this.zkUtils == null)
	          this.zkUtils= new ZkUtils(conf);
	    	return zkUtils;
	    }

	    public Configuration getConf() {
	        return conf;
	    }

	    public FixedKafkaInputSplit getSplit() {
	        return split;
	    }

	    public Iterator<MessageAndOffset> getCurrentMessageItr() {
	        return currentMessageItr;
	    }

	   

	    public int getFetchSize() {
	        return fetchSize;
	    }

	    public long getCurrentOffset() {
	        return currOffset;
	    }
	    
	    

}
