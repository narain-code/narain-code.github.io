package com.king.splat;

import java.util.List;
import java.util.concurrent.TimeUnit;

import com.king.splat.kafka.Partition;
import com.king.splat.util.ZkUtils;

public class SetTimeStamp {
	
	private static final String zkConnectionString = "zk05.sto.midasplayer.com:2181";
	private static final String zkRoot = "/kafka";
	private static final int sessionTimeout = (int) TimeUnit.SECONDS.toMillis(10);
	private static final int connectionTimeout = (int) TimeUnit.SECONDS.toMillis(10);

	
	public static void main(String[] args){
		
		ZkUtils zk = new ZkUtils(zkConnectionString, zkRoot, sessionTimeout, connectionTimeout);
		List<Partition> parts =zk.getPartitions("event.candycrush.log");
		zk.setLastCommit("candyevent-15min-batch", parts.get(0), 883121298052L, false);
		zk.setLastCommit("candyevent-15min-batch", parts.get(1), 608821279295L, false);
		zk.setLastCommit("candyevent-15min-batch", parts.get(2), 679476573709L, false);
		zk.setLastCommit("candyevent-15min-batch", parts.get(3), 684973512352L, false);
		zk.setLastCommit("candyevent-15min-batch", parts.get(4), 682996222618L, false);
		zk.setLastCommit("candyevent-15min-batch", parts.get(5), 608677353217L, false);
		zk.setLastCommit("candyevent-15min-batch", parts.get(6), 688187661460L, false);
		zk.setLastCommit("candyevent-15min-batch", parts.get(7), 682388401382L, false);
		zk.setLastCommit("candyevent-15min-batch", parts.get(8), 684180915872L, false);
		zk.setLastCommit("candyevent-15min-batch", parts.get(9), 681561214328L, false);
		zk.setLastCommit("candyevent-15min-batch", parts.get(10), 685617243481L, false);
		zk.setLastCommit("candyevent-15min-batch", parts.get(11), 127011272780L, false);
		zk.setLastCommit("candyevent-15min-batch", parts.get(12), 679916489153L, false);
		zk.setLastCommit("candyevent-15min-batch", parts.get(13), 681533360157L, false);
		zk.setLastCommit("candyevent-15min-batch", parts.get(14), 680152701465L, false);
		zk.setLastCommit("candyevent-15min-batch", parts.get(15), 680660317770L, false);
		
		
	}
}
