package com.king.splat;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Writable;

public class CreativesValue implements Writable{
	
	String creatives;
	String funnelId;
	int messageId = 0;
	long windowId;
	
	
	public void writeString(String data,DataOutput out) throws IOException{
		out.writeInt(data.length());
		out.write(data.getBytes());
	}

	public void writeInt(int data,DataOutput out) throws IOException{
		
		out.writeInt(data);
	}
	
	public void writeLong(long data,DataOutput out) throws IOException{
		out.writeLong(data);
	}
	
	public String readString(DataInput in) throws IOException{
		int len =in.readInt();
		byte[] b = new byte[len];
		in.readFully(b);
		return new String(b);
	}

	public int readInt(DataInput in) throws IOException{
		return in.readInt();
	}
	
	public long readLong(DataInput in) throws IOException{
		return in.readLong();
	}
	
	@Override
	public void write(DataOutput out) throws IOException {
		writeString(creatives,out);
		writeString(funnelId,out);
		writeInt(messageId, out);
		writeLong(windowId, out);
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		creatives = readString(in);
		funnelId = readString(in);
		messageId =readInt(in);
		windowId = readLong(in);
		
	}

	public String getCreatives() {
		return creatives;
	}

	public void setCreatives(String creatives) {
		this.creatives = creatives;
	}

	public String getFunnelId() {
		return funnelId;
	}

	public void setFunnelId(String funnelId) {
		this.funnelId = funnelId;
	}

	public int getMessageId() {
		return messageId;
	}

	public void setMessageId(int messageId) {
		this.messageId = messageId;
	}

	public long getWindowId() {
		return windowId;
	}

	public void setWindowId(long windowId) {
		this.windowId = windowId;
	}

}
