package com.king.splat;

import java.io.IOException;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.ql.io.RCFile;
import org.apache.hadoop.hive.ql.io.RCFileOutputFormat;
import org.apache.hadoop.hive.serde2.columnar.BytesRefArrayWritable;
import org.apache.hadoop.hive.serde2.columnar.BytesRefWritable;
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

import com.king.event.Event;
import com.king.event.format.DelegatingEventFormat;
import com.king.event.format.EventFormat;
import com.king.event.format.EventFormatException;
import com.king.event.format.util.HTMLEntityEncoder;
import com.king.event.format.util.IdentityDecoder;
import com.king.splat.util.ZkUtils;

public class Kafka2HdfsJob {

	
	public static class KafkaMapper extends Mapper<LongWritable, BytesWritable, NullWritable, BytesRefArrayWritable> {
		EventFormat eventFormat = new DelegatingEventFormat(new HTMLEntityEncoder(),
				new IdentityDecoder());
		
		private static final long EMPTY_MERGE = 0;
		private static final String EMPTY_INSTALL = "-1";
		 NullWritable nullW = NullWritable.get();
		
		
	    public void map(LongWritable key, BytesWritable value, Context context) throws IOException, InterruptedException {
	    	Event event;
			try {
				/*event = eventFormat.parse(value.toString());
				Long eventId = Long.valueOf(event.getEventType());
				long timestamp =event.getTimeStamp();
				Text oKey  = new Text(eventId.toString()); 
				Text oValue  = new Text(""+timestamp); */
				
				String[] split = new String(value.getBytes()).split("\t");
				Long mergeId = Long.valueOf(split[2]);
				mergeId = mergeId.equals(EMPTY_MERGE) ? null : mergeId;

				Long installKey= null;
				split[3] = split[3].trim();
				installKey = (split[3].equalsIgnoreCase(EMPTY_INSTALL) ) ? null : Long.valueOf(split[3]);
				long timeStamp =Long.valueOf(split[0]);
				long userId = Long.valueOf(split[1]);
				
			  BytesRefArrayWritable bytes = new BytesRefArrayWritable(4);
		            bytes.set(0, new BytesRefWritable(("" + timeStamp).getBytes("UTF-8")));
		            bytes.set(1, new BytesRefWritable(("" + userId).getBytes("UTF-8")));
		            bytes.set(2, new BytesRefWritable(("" + mergeId).getBytes("UTF-8")));
		            bytes.set(3, new BytesRefWritable(("" + installKey).getBytes("UTF-8")));
		           
			//	Text oValue = new Text(timeStamp +"/t"+userId+"/t"+mergeId+"/t"+installKey);
				context.write(nullW, bytes);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
	 
	}
	
	
	public static class CoreEventMapper extends Mapper<LongWritable, BytesWritable, NullWritable, BytesRefArrayWritable> {
		EventFormat eventFormat = new DelegatingEventFormat(new HTMLEntityEncoder(),
				new IdentityDecoder());
		
	//	private static final long EMPTY_MERGE = 0;
		private static final String EMPTY_MERGE = "0";
		private static final String EMPTY_INSTALL = "-1";
		 NullWritable nullW = NullWritable.get();
		
		
	    public void map(LongWritable key, BytesWritable value, Context context) throws IOException, InterruptedException {
	    	Event event;
			try {
				/*event = eventFormat.parse(value.toString());
				Long eventId = Long.valueOf(event.getEventType());
				long timestamp =event.getTimeStamp();
				Text oKey  = new Text(eventId.toString()); 
				Text oValue  = new Text(""+timestamp); */
				
				String[] split = new String(value.copyBytes()).split("\t");
			/*	Long playerId = Long.valueOf(split[2].trim());
				playerId = playerId.equals(EMPTY_MERGE) ? null : playerId;

				
				long timeStamp =Long.valueOf(split[0].trim());
				long userId = Long.valueOf(split[1].trim()); */
				String playerId = split[2].trim();
				playerId = playerId.equalsIgnoreCase(EMPTY_MERGE) ? null : playerId;
				
				String timeStamp = split[0].trim();
				String userId = split[1].trim();
				
				
				
			  BytesRefArrayWritable bytes = new BytesRefArrayWritable(3);
		            bytes.set(0, new BytesRefWritable( timeStamp.getBytes("UTF-8")));
		            bytes.set(1, new BytesRefWritable( userId.getBytes("UTF-8")));
		            bytes.set(2, new BytesRefWritable( playerId.getBytes("UTF-8")));
		           
		           
			//	Text oValue = new Text(timeStamp +"/t"+userId+"/t"+mergeId+"/t"+installKey);
				context.write(nullW, bytes);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
	 
	}
	
	
	public static class InstallEventMapper extends Mapper<LongWritable, BytesWritable, NullWritable, BytesRefArrayWritable> {
		EventFormat eventFormat = new DelegatingEventFormat(new HTMLEntityEncoder(),
				new IdentityDecoder());
		
	//	private static final long EMPTY_MERGE = 0;
		private static final String EMPTY_MERGE = "0";
		private static final String EMPTY_INSTALL = "-1";
		 NullWritable nullW = NullWritable.get();
		
		
	    public void map(LongWritable key, BytesWritable value, Context context) throws IOException, InterruptedException {
	    	Event event;
			try {
				/*event = eventFormat.parse(value.toString());
				Long eventId = Long.valueOf(event.getEventType());
				long timestamp =event.getTimeStamp();
				Text oKey  = new Text(eventId.toString()); 
				Text oValue  = new Text(""+timestamp); */
				
				String[] split = new String(value.copyBytes()).split("\t");
			/*	Long playerId = Long.valueOf(split[2].trim());
				playerId = playerId.equals(EMPTY_MERGE) ? null : playerId;

				
				long timeStamp =Long.valueOf(split[0].trim());
				long installId = Long.valueOf(split[1].trim());*/
				
				String playerId = split[2].trim();
				playerId = playerId.equals(EMPTY_MERGE) ? null : playerId;
				String timeStamp = split[0].trim();
				String installId = split[1].trim();
				 System.out.println(new String(value.getBytes()) + " "+installId);
			  BytesRefArrayWritable bytes = new BytesRefArrayWritable(3);
		            bytes.set(0, new BytesRefWritable( timeStamp.getBytes("UTF-8")));
		            bytes.set(1, new BytesRefWritable( installId.getBytes("UTF-8")));
		            bytes.set(2, new BytesRefWritable(playerId.getBytes("UTF-8")));
		           
		           
			//	Text oValue = new Text(timeStamp +"/t"+userId+"/t"+mergeId+"/t"+installKey);
				context.write(nullW, bytes);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
	 
	}
	/**
	 *  building the job
	 */
	
	public static void main(String[] args){
	 try{	
		Configuration conf = new Configuration();
		
	    
	    if ( args.length < 4) {
	      System.err.println("Usage: Kafka2Hdfs <topic> <hdfsoutputpath> <zookeeper> <consumerGroup> <number of splits> <mapper>");
	      System.exit(2);
	    }
	    
	    /**
	     * read up all the args
	     */
	    String topic = args[0];
	    String hdfsOutput = args[1];
	    String zookeeperURL = args[2];
	    String consumerGroup = args[3];
	    int mapper = 1;
	    int numberOfSplits = Integer.MAX_VALUE;
	    if(args.length > 4 && args[4] != null){
	    	numberOfSplits = Integer.parseInt(args[4]);
	    	mapper = Integer.parseInt(args[5]);
	    }
	    
	    System.out.println( "###### Printing args  ##### ");
	    
	    System.out.println( "topic is " + topic);
	    System.out.println( "hdfsOutput is " + hdfsOutput);
	    System.out.println( "zookeeperURL is " + zookeeperURL);
	    System.out.println( "consumerGroup is " + consumerGroup);
	    System.out.println( "numberOfSplits is " + numberOfSplits);
	    System.out.println( "mapper is " + mapper);
	    System.out.println( "###### Printing args  ##### ");
	    
	    Job job = Job.getInstance(conf, "Kafka2Hdfs-"+topic);
	    job.setJarByClass(Kafka2HdfsJob.class);
	    if(mapper == 1)
	    job.setMapperClass(KafkaMapper.class);
	    else{
	      if(mapper == 2)	
	    	job.setMapperClass(CoreEventMapper.class);
	      else
	    	  job.setMapperClass(InstallEventMapper.class);
	    }
	    
	    System.out.println( "mapperclass  is " + job.getMapperClass());
	    job.getConfiguration().setInt("hive.io.rcfile.column.number.conf", 9);
	    job.setOutputKeyClass(NullWritable.class);
	    job.setOutputValueClass(BytesRefArrayWritable.class);
	    job.setOutputFormatClass(com.twitter.elephantbird.mapreduce.output.RCFileOutputFormat.class);
	   // job.setOutputFormatClass(TextOutputFormat.class);
	    FileOutputFormat.setOutputPath(job, new Path(hdfsOutput));
	    job.setNumReduceTasks(0);
	   
	    /**
	     * 
	     * 
	     */
	    job.setInputFormatClass(KafkaInputFormat.class);
	    KafkaInputFormat.setConsumerGroup(job, consumerGroup);
	    // Set your Zookeeper connection string
	    KafkaInputFormat.setZkConnect(job, zookeeperURL);
	    // Set the topic you want to consume
	    KafkaInputFormat.setTopic(job, topic);
	    KafkaInputFormat.setMaxSplitsPerPartition(job,numberOfSplits );
	    
	   
	    List<InputSplit> allSplits =KafkaInputFormat.getAllSplits(job.getConfiguration(), topic,consumerGroup);
	    System.out.println(" The size is " + allSplits.size());
	    for(InputSplit s:allSplits){
	    	System.out.println(((KafkaInputSplit)s).getPartition() + " " + ((KafkaInputSplit)s).getStartOffset());
	    }
	    if (job.waitForCompletion(true)) {
	    	  final ZkUtils zk = new ZkUtils(job.getConfiguration());
	    	  zk.commit(consumerGroup,topic);
	    	  zk.close();
	    	} 

	    
	 }catch(Exception ex){
		 ex.printStackTrace();
	 }
	}
	
	
	
	
}
