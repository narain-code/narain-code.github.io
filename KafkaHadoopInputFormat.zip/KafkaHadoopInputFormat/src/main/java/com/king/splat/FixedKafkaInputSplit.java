
package com.king.splat;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.InputSplit;

public class FixedKafkaInputSplit extends InputSplit implements Writable {

	private int partId;
	
	 public FixedKafkaInputSplit() {
		
	}
	
	 public FixedKafkaInputSplit(int partId){
		 this.partId = partId;
	 }
	 
	 public int getPartId(){
		 return partId;
	 }
	 
	@Override
	public void write(DataOutput out) throws IOException {
		out.writeInt(partId);
		
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		this.partId=in.readInt();
		
	}

	@Override
	public long getLength() throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		return 100;
	}

	@Override
	public String[] getLocations() throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		return new String[] { ""+this.partId};
	}

	
	 @Override
	    public boolean equals(final Object o) {
	        if (this == o)
	            return true;
	        if (!(o instanceof FixedKafkaInputSplit))
	            return false;

	        final FixedKafkaInputSplit that = (FixedKafkaInputSplit) o;

	       if(that.partId == partId)
	    	   	return true;
	        return true;
	    }

	    @Override
	    public int hashCode() {
	        int result =  0;
	        result = 31 * result + (int) (partId ^ (partId >>> 32));
	       
	        return result;
	    }
}
