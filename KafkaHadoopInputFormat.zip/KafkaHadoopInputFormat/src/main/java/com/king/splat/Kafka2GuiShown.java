package com.king.splat;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.serde2.columnar.BytesRefArrayWritable;
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.Partitioner;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import com.king.constants.EventField.SLGUIShown4;
import com.king.event.Event;
import com.king.event.format.DelegatingEventFormat;
import com.king.event.format.EventFormat;
import com.king.event.format.EventFormatException;
import com.king.event.format.util.HTMLEntityEncoder;
import com.king.event.format.util.IdentityDecoder;
import com.king.kafka.util.TopicUtil;
import com.king.rbea.hashlookup.Cdb;
import com.king.rbea.hashlookup.HashLookUpOutputFormat;
import com.king.splat.RatkoKafka.RatkoInstallMapper;
import com.king.splat.RatkoKafka.RatkoInstallReducer;
import com.king.splat.util.ZkUtils;

public class Kafka2GuiShown {
	
	public static final BigInteger numberofReducers = new BigInteger("32");
	
	
	
	public static class GuiShownReducer extends Reducer<IntWritable,CreativesValue,IntWritable,RKeyValueWritable>{
		
		private static String SEP ="|";
		
		private Cdb sideData = null;
		
		 public List<Long> getAllVersions(Configuration conf,String baseOutput,int index) throws FileNotFoundException, IOException{
			 List<Long> ret = new ArrayList<Long>();
			
			 Path rootPath = new Path(baseOutput+"/"+index);
			  FileSystem fs =rootPath.getFileSystem(conf);
			 if (fs.exists(rootPath)) {
		            for(FileStatus stat: fs.listStatus(rootPath)) {
		            	Path p =stat.getPath()	;
		            	ret.add(Long.parseLong(p.getName()));
		            }
			 }
			 return ret;
		 }
		 
		 String maxVersionPath;
		 public void copyToLocal(long maxVersion , Configuration conf,String baseOutput,int index) throws IOException{
			 Path out =  new Path(baseOutput+"/"+index + "/" +maxVersion + "/" + index + "-cdb");
			 FileSystem fs =out.getFileSystem(conf);
			 maxVersionPath =Files.createTempDirectory("maxVersion").toAbsolutePath().toString() +"/"+index+"-cdb";
			 Path dst = new Path(maxVersionPath);
			 fs.copyToLocalFile(out, dst);
			 
		 }
		
		 boolean loaded = false;
		 static final byte[] ZERO = "0".getBytes(); 
		 static final  String BLANK ="";
		public  void reduce (IntWritable key, Iterable<CreativesValue> values, Context context
				) throws IOException, InterruptedException {
			
			if(!loaded){
				String baseOutput = context.getConfiguration().get("mapred.output.dir");
				List<Long> all = getAllVersions(context.getConfiguration(),baseOutput, key.get());
				long maxVersion = 0;
				if(all.size() >0){
				int size	=all.size();
				Collections.sort(all);
				maxVersion =all.get((size - 1));
				
				
				copyToLocal(maxVersion, context.getConfiguration(), baseOutput, key.get());
				sideData = new Cdb(maxVersionPath);
				loaded = true;
				}
			}
			
			String prev = null;
			String funnelId = null;
			int msgId = 0;
			String entire = null;
			String creatives = null;
			int counter =0;
			long window =0;
			for(CreativesValue value:values) {
				creatives= value.getCreatives();
				funnelId= value.getFunnelId();
				msgId= value.getMessageId();
				
				if(prev == null)
					prev = creatives;
				 if(!creatives.equalsIgnoreCase(prev)){
					
					 int prevCount = 0;
					 byte[] installCount = ZERO;
					 int previousInstallCount = 0;
					 if(loaded){
						 installCount =sideData.find((funnelId+SEP+msgId).getBytes());
						 if(installCount == null)
							 installCount = ZERO;
						 byte[] entireRow =sideData.find(prev.getBytes());
						 if(entireRow != null && !BLANK.equalsIgnoreCase(new String(entireRow).trim())){
							 String sRow =new String(entireRow).trim();
							 int counterIndex =sRow.lastIndexOf(SEP);
							 if(counterIndex != -1){
								 String countStr =sRow.substring((counterIndex + 1));
								 if(countStr!=null && !BLANK.equalsIgnoreCase(countStr.trim()))
									 prevCount = Integer.parseInt(countStr.trim());
								 String prevInstallStr = sRow.substring(0,counterIndex);
								 if(prevInstallStr !=null && !prev.equalsIgnoreCase(BLANK)){
									 previousInstallCount += Integer.parseInt(prevInstallStr);
								 }
							 }else{
								 previousInstallCount +=Integer.parseInt(sRow);
							 }
							 
							 }
					 }
					 
					int newInstallCount = 0;
					String strInstallCount =new String(installCount);
					if(!strInstallCount.equalsIgnoreCase(BLANK)){
						 newInstallCount=  Integer.parseInt(strInstallCount) + previousInstallCount;
					}else{
						newInstallCount = previousInstallCount;
					}
					 String rValue = newInstallCount +SEP+(counter + prevCount);
					 RKeyValueWritable val = new RKeyValueWritable(new BytesWritable(prev.getBytes()) , new BytesWritable(rValue.getBytes()));
					 context.write(key, val);
					// System.out.println(prev + " " + rValue);
					 prev = creatives;
					 counter = 1;
				 }else{
					 counter ++;
				 }
			}
			
			if(counter > 0){
				int prevCount = 0;
				 int previousInstallCount = 0;
				 byte[] installCount = ZERO;
				if(loaded){
					
				 installCount =sideData.find((funnelId+SEP+msgId).getBytes());
				 if(installCount == null)
					 installCount = ZERO;
				 byte[] entireRow =sideData.find(prev.getBytes());
				
				 if(entireRow != null ){
				 String sRow =new String(entireRow);
				 if(!sRow.trim().equalsIgnoreCase(BLANK)){
					 int counterIndex =sRow.lastIndexOf(SEP);
					 if(counterIndex > -1){
					  String strPrevCount =sRow.substring((counterIndex + 1));
					  if(!strPrevCount.trim().equalsIgnoreCase(BLANK))
						  prevCount = Integer.parseInt(strPrevCount);
					
						 String prevInstallStr = sRow.substring(0,counterIndex);
						 if(prevInstallStr !=null && !prev.equalsIgnoreCase(BLANK)){
							 previousInstallCount = Integer.parseInt(prevInstallStr);
						 }
					 }else{
						 previousInstallCount =Integer.parseInt(sRow);
					 }
				 	} 
				 }
				}
				int newInstallCount = 0;
				String strInstallCount =new String(installCount);
				if(!strInstallCount.equalsIgnoreCase(BLANK)){
					 newInstallCount=  Integer.parseInt(strInstallCount) + previousInstallCount;
				}else{
					newInstallCount = previousInstallCount;
				}
				 String rValue = newInstallCount+SEP+(counter + prevCount);
				 RKeyValueWritable val = new RKeyValueWritable(new BytesWritable(prev.getBytes()) , new BytesWritable(rValue.getBytes()));
				 context.write(key, val);
			}
		}
		
	}
	
	
	public static class ThePartitioner implements Partitioner<IntWritable, Text>{

		@Override
		public void configure(JobConf job) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public int getPartition(IntWritable key, Text value,
				int numPartitions) {
			
			return key.get()%numPartitions;
		}
		
	}
	
	
	public static class GuiShownMapper extends Mapper<LongWritable, BytesWritable, IntWritable, CreativesValue>{
		EventFormat eventFormat = new DelegatingEventFormat(new HTMLEntityEncoder(),
				new IdentityDecoder());
		public static final long SLGUISHOWN4= 28013l;
		
		public static final int WINDOWSIZE=(3600 * 6);
		
		MessageDigest instance = null;
		
		public GuiShownMapper() {
			try {
				instance = MessageDigest.getInstance("MD5");
			} catch (NoSuchAlgorithmException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		@Override
		public void map(LongWritable key, BytesWritable value,Context context) throws IOException, InterruptedException{
			
			//filter
			try {
				Event e =eventFormat.parse(new String(value.copyBytes()));
			
				if (e.getEventType() == SLGUISHOWN4  
						&& e.get(SLGUIShown4.msgType) == 5 && e.get(SLGUIShown4.provId) == 2 
						){
					
					String extId =e.get(SLGUIShown4.extId);
					
					if(extId!= null &&  !extId.trim().isEmpty() && !extId.equalsIgnoreCase("null")){
						if(extId.trim().equals("3801"))	{
					
							String creatives =e.get(SLGUIShown4.creatives);
							String funnelId = e.get(SLGUIShown4.funnelId);
							int msgId = e.get(SLGUIShown4.msgId);
							long time = e.get(SLGUIShown4.clientTimestamp);
							long windowId = time -(time%WINDOWSIZE);
							CreativesValue v = new CreativesValue();
							v.setCreatives(creatives+"|"+windowId);
							v.setFunnelId(funnelId);
							v.setMessageId(msgId);
							v.setWindowId(windowId);
							
							instance.reset();  
						    instance.update(funnelId.getBytes());
						    byte[] digest = instance.digest();
						    int partitionKey= new BigInteger(digest).mod(numberofReducers).intValue();
							context.write(new IntWritable(partitionKey), v);
						}
					}
				}
				
				
			} catch (EventFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
				throw new IOException(e);
			}
		}
	}

	
	private static final String zkConnectionString = "zk05.sto.midasplayer.com:2181";
	private static final String zkRoot = KafkaInputFormat.DEFAULT_ZK_ROOT;
	private static final int sessionTimeout = KafkaInputFormat.DEFAULT_ZK_SESSION_TIMEOUT_MS;
	private static final int connectionTimeout = KafkaInputFormat.DEFAULT_ZK_CONNECTION_TIMEOUT_MS;
	
	
	public static void setUp(Job job,String consumerGroup,Class mapperClass){
		TopicUtil tpUtil =  TopicUtil.connect("zk04.sto.midasplayer.com:2181,zk05.sto.midasplayer.com:2181,zk06.sto.midasplayer.com:2181/kafka");
		List<String> topics =tpUtil.getTopicNames( Pattern.compile("^event\\..*\\.log$"));
		ZkUtils zk = new ZkUtils(zkConnectionString, zkRoot, sessionTimeout, connectionTimeout);
		//for(String topic: topics){
		String topic = "event.bubblewitch2.log;event.stritz.log;event.farmking.log;event.blossomblastsaga.log";
			//MultipleKafkaInputFormat.addTopic(job, topic, consumerGroup, mapperClass);
			FixedKafkaInputFormat.setTopic(job, topic);
			System.out.println(topic);
		//}
	}
	
	public static Job createJob(String[] args){
		 try{	
			
			Configuration conf = new Configuration();
			
		    
		    if ( args.length < 4) {
		      System.err.println("Usage: Kafka2GuiShown <topic> <hdfsoutputpath> <zookeeper> <consumerGroup> <number of splits> <mapper>");
		      System.exit(2);
		    }
		    
		    /**
		     * read up all the args
		     */
		    String topic = args[0];
		    String hdfsOutput = args[1];
		    String zookeeperURL = args[2];
		    String consumerGroup = args[3];
		    consumerGroup ="GuiShown-"+consumerGroup;
		    int mapper = 1;
		    int numberOfSplits = Integer.MAX_VALUE;
		    if(args.length > 4 && args[4] != null){
		    	numberOfSplits = Integer.parseInt(args[4]);
		    	mapper = Integer.parseInt(args[5]);
		    }
		    
		    System.out.println( "###### Printing args  ##### ");
		    
		    System.out.println( "topic is " + topic);
		    System.out.println( "hdfsOutput is " + hdfsOutput);
		    System.out.println( "zookeeperURL is " + zookeeperURL);
		    System.out.println( "consumerGroup is " +consumerGroup);
		    System.out.println( "numberOfSplits is " + numberOfSplits);
		    System.out.println( "mapper is " + mapper);
		    System.out.println( "###### Printing args  ##### ");
		    
		    Job job = Job.getInstance(conf, "RatkoKafka-"+topic);
		    job.setJarByClass(Kafka2GuiShown.class);
		   // job.setMapperClass(DelegatingMapper.class);
		    job.setMapperClass(GuiShownMapper.class);
		    job.setReducerClass(GuiShownReducer.class);
		   
		  
		    job.setMapOutputKeyClass(IntWritable.class);
		    job.setMapOutputValueClass(CreativesValue.class);
		    job.setOutputKeyClass(IntWritable.class);
		    job.setOutputValueClass(RKeyValueWritable.class);
		    job.setOutputFormatClass(HashLookUpOutputFormat.class);
		   
		    FileOutputFormat.setOutputPath(job, new Path(hdfsOutput));
		    job.setNumReduceTasks(32);
		   
		    /**
		     * 
		     * 
		     */
		    job.setInputFormatClass(FixedKafkaInputFormat.class);
		    KafkaInputFormat.setConsumerGroup(job, consumerGroup);
		    // Set your Zookeeper connection string
		    KafkaInputFormat.setZkConnect(job, zookeeperURL);
		    // Set the topic you want to consume
		    //KafkaInputFormat.setTopic(job, topic);
		    KafkaInputFormat.setMaxSplitsPerPartition(job,numberOfSplits );
		   // System.out.println(job.getMapperClass());	
		   setUp(job, consumerGroup,GuiShownMapper.class);
		   
		   /* if (job.waitForCompletion(true)) {
		    	  final ZkUtils zk = new ZkUtils(job.getConfiguration());
		    	 // zk.commit(consumerGroup,topic);
		    	  zk.close();
		    	} */
		   return job;
		    
		 }catch(Exception ex){
			 ex.printStackTrace();
		 }
		 return null;
		}
	
	
	public static void main(String[] args) throws ClassNotFoundException, IOException, InterruptedException{
		if(createJob(args).waitForCompletion(true))
			;
			
	}
}
