
package com.king.splat;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import kafka.javaapi.consumer.SimpleConsumer;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.mapreduce.InputFormat;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.JobContext;
import org.apache.hadoop.mapreduce.RecordReader;
import org.apache.hadoop.mapreduce.TaskAttemptContext;
import org.joda.time.DateTime;

import com.google.common.collect.Lists;

public class FixedKafkaInputFormat extends InputFormat<LongWritable, BytesWritable> {

	 /**
     * Default Kafka fetch size, 1MB.
     */
    public static final int DEFAULT_FETCH_SIZE_BYTES = 1024 * 1024; // 1MB
    /**
     * Default Kafka socket timeout, 10 seconds.
     */
    public static final int DEFAULT_SOCKET_TIMEOUT_MS = (int) TimeUnit.SECONDS.toMillis(10);
    /**
     * Default Kafka buffer size, 64KB.
     */
    public static final int DEFAULT_BUFFER_SIZE_BYTES = 64 * 1024; // 64 KB
    /**
     * Default Zookeeper session timeout, 10 seconds.
     */
    public static final int DEFAULT_ZK_SESSION_TIMEOUT_MS = (int) TimeUnit.SECONDS.toMillis(10);
    /**
     * Default Zookeeper connection timeout, 10 seconds.
     */
    public static final int DEFAULT_ZK_CONNECTION_TIMEOUT_MS = (int) TimeUnit.SECONDS.toMillis(10);
    /**
     * Default Zookeeper root, '/kafka'.
     */
    public static final String DEFAULT_ZK_ROOT = "/kafka";
    /**
     * Default maximum number of partitions per split.
     */
    public static final int DEFAULT_MAX_SPLITS_PER_PARTITION = Integer.MAX_VALUE;
    /**
     * Default timestamp to include
     */
    public static final long DEFAULT_INCLUDE_OFFSETS_AFTER_TIMESTAMP = 0;
    
    

@Override
public List<InputSplit> getSplits(JobContext context) throws IOException,
		InterruptedException {
	final Configuration  conf =context.getConfiguration();
	int nsplits= conf.getInt("kafka.max.splits.per.partition", DEFAULT_MAX_SPLITS_PER_PARTITION);
	List<InputSplit> kSplits = new ArrayList<InputSplit>(nsplits);
	for(int i =0;i<nsplits;i++){
		kSplits.add(new FixedKafkaInputSplit(i));
	}
	return kSplits;
}

@Override
public RecordReader<LongWritable, BytesWritable> createRecordReader(
		InputSplit split, TaskAttemptContext context) throws IOException,
		InterruptedException {
	// TODO Auto-generated method stub
	return new FixedRecordReader();
 }



/**
 * Sets the Zookeeper connection string (required).
 * 
 * @param job
 *            the job being configured
 * @param zkConnect
 *            zookeeper connection string.
 */
public static void setZkConnect(final Job job, final String zkConnect) {
    job.getConfiguration().set("kafka.zk.connect", zkConnect);
}

/**
 * Gets the Zookeeper connection string set by {@link #setZkConnect(Job, String)}.
 * 
 * @param conf
 *            the job conf.
 * @return the Zookeeper connection string.
 */
public static String getZkConnect(final Configuration conf) {
     System.out.println(" in get zkconnect " +conf.get("kafka.zk.connect"));
	
	return conf.get("kafka.zk.connect");
}

/**
 * Set the Zookeeper session timeout for Kafka.
 * 
 * @param job
 *            the job being configured.
 * @param sessionTimeout
 *            the session timeout in milliseconds.
 */
public static void setZkSessionTimeoutMs(final Job job, final int sessionTimeout) {
    job.getConfiguration().setInt("kafka.zk.session.timeout.ms", sessionTimeout);
}

/**
 * Gets the Zookeeper session timeout set by {@link #setZkSessionTimeoutMs(Job, int)}, defaulting to
 * {@link #DEFAULT_ZK_SESSION_TIMEOUT_MS} if it has not been set.
 * 
 * @param conf
 *            the job conf.
 * @return the Zookeeper session timeout.
 */
public static int getZkSessionTimeoutMs(final Configuration conf) {
    return conf.getInt("kafka.zk.session.timeout.ms", DEFAULT_ZK_SESSION_TIMEOUT_MS);
}

/**
 * Set the Zookeeper connection timeout for Zookeeper.
 * 
 * @param job
 *            the job being configured.
 * @param connectionTimeout
 *            the connection timeout in milliseconds.
 */
public static void setZkConnectionTimeoutMs(final Job job, final int connectionTimeout) {
    job.getConfiguration().setInt("kafka.zk.connection.timeout.ms", connectionTimeout);
}

/**
 * Gets the Zookeeper connection timeout set by {@link #setZkConnectionTimeoutMs(Job, int)}, defaulting to
 * {@link #DEFAULT_ZK_CONNECTION_TIMEOUT_MS} if it has not been set.
 * 
 * @param conf
 *            the job conf.
 * @return the Zookeeper connection timeout.
 */
public static int getZkConnectionTimeoutMs(final Configuration conf) {
    return conf.getInt("kafka.zk.connection.timeout.ms", DEFAULT_ZK_CONNECTION_TIMEOUT_MS);
}

/**
 * Sets the Zookeeper root for Kafka.
 * 
 * @param job
 *            the job being configured.
 * @param root
 *            the zookeeper root path.
 */
public static void setZkRoot(final Job job, final String root) {
    job.getConfiguration().set("kafka.zk.root", root);
}

/**
 * Gets the Zookeeper root of Kafka set by {@link #setZkRoot(Job, String)}, defaulting to {@link #DEFAULT_ZK_ROOT}
 * if it has not been set.
 * 
 * @param conf
 *            the job conf.
 * @return the Zookeeper root of Kafka.
 */
public static String getZkRoot(final Configuration conf) {
    return conf.get("kafka.zk.root", DEFAULT_ZK_ROOT);
}

/**
 * Sets the input topic (required).
 * 
 * @param job
 *            the job being configured
 * @param topic
 *            the topic name
 */
public static void setTopic(final Job job, final String topic) {
    job.getConfiguration().set("kafka.topic", topic);
}

/**
 * Gets the input topic.
 * 
 * @param conf
 *            the job conf.
 * @return the input topic.
 */
public static String getTopic(final Configuration conf) {
    return conf.get("kafka.topic");
}

/**
 * Sets the consumer group of the input reader (required).
 * 
 * @param job
 *            the job being configured.
 * @param consumerGroup
 *            consumer group name.
 */
public static void setConsumerGroup(final Job job, final String consumerGroup) {
    job.getConfiguration().set("kafka.groupid", consumerGroup);
}

/**
 * Gets the consumer group.
 * 
 * @param conf
 *            the job conf.
 * @return the consumer group.
 */
public static String getConsumerGroup(final Configuration conf) {
    return conf.get("kafka.groupid");
}

/**
 * Only consider partitions created <em>approximately</em> on or after {@code timestamp}.
 * <p/>
 * Note that you are only guaranteed to get all data on or after {@code timestamp}, but you may get <i>some</i> data
 * before the specified timestamp.
 * 
 * @param job
 *            the job being configured.
 * @param timestamp
 *            the timestamp.
 * @see SimpleConsumer#getOffsetsBefore(String, int, long, int)
 */
public static void setIncludeOffsetsAfterTimestamp(final Job job, final long timestamp) {
    job.getConfiguration().setLong("kafka.timestamp.offset", timestamp);
}

/**
 * Gets the offset timestamp set by {@link #setIncludeOffsetsAfterTimestamp(Job, long)}, returning {@code 0} by
 * default.
 * 
 * @param conf
 *            the job conf.
 * @return the offset timestamp, {@code 0} by default.
 */
public static long getIncludeOffsetsAfterTimestamp(final Configuration conf) {
    //return conf.getLong("kafka.timestamp.offset", DEFAULT_INCLUDE_OFFSETS_AFTER_TIMESTAMP);
	
	DateTime today = new DateTime().withTimeAtStartOfDay();
    long epoch = today.getMillis();
	return epoch;
}

/**
 * Limits the number of splits to create per partition.
 * <p/>
 * Note that it if there more partitions to consume than {@code maxSplits}, the input format will take the
 * <em>earliest</em> Kafka partitions.
 * 
 * @param job
 *            the job to configure.
 * @param maxSplits
 *            the maximum number of splits to create from each Kafka partition.
 */
public static void setMaxSplitsPerPartition(final Job job, final int maxSplits) {
    job.getConfiguration().setInt("kafka.max.splits.per.partition", maxSplits);
}

/**
 * Gets the maximum number of splits per partition set by {@link #setMaxSplitsPerPartition(Job, int)}, returning
 * {@link Integer#MAX_VALUE} by default.
 * 
 * @param conf
 *            the job conf
 * @return the maximum number of splits, {@link Integer#MAX_VALUE} by default.
 */
public static int getMaxSplitsPerPartition(final Configuration conf) {
    return conf.getInt("kafka.max.splits.per.partition", DEFAULT_MAX_SPLITS_PER_PARTITION);
}

/**
 * Sets the fetch size of the {@link RecordReader}. Note that your mapper should have enough memory allocation to
 * handle the specified size, or else you will likely throw {@link OutOfMemoryError}s.
 * 
 * @param job
 *            the job being configured.
 * @param fetchSize
 *            the fetch size (bytes).
 */
public static void setKafkaFetchSizeBytes(final Job job, final int fetchSize) {
    job.getConfiguration().setInt("kafka.fetch.size", fetchSize);
}

/**
 * Gets the Kafka fetch size set by {@link #setKafkaFetchSizeBytes(Job, int)}, defaulting to
 * {@link #DEFAULT_FETCH_SIZE_BYTES} if it has not been set.
 * 
 * @param conf
 *            the job conf.
 * @return the Kafka fetch size.
 */
public static int getKafkaFetchSizeBytes(final Configuration conf) {
    return conf.getInt("kafka.fetch.size", DEFAULT_FETCH_SIZE_BYTES);
}

/**
 * Sets the buffer size of the {@link SimpleConsumer} inside of the {@link KafkaRecordReader}.
 * 
 * @param job
 *            the job being configured.
 * @param bufferSize
 *            the buffer size (bytes).
 */
public static void setKafkaBufferSizeBytes(final Job job, final int bufferSize) {
    job.getConfiguration().setInt("kafka.socket.buffersize", bufferSize);
}

/**
 * Gets the Kafka buffer size set by {@link #setKafkaBufferSizeBytes(Job, int)}, defaulting to
 * {@link #DEFAULT_BUFFER_SIZE_BYTES} if it has not been set.
 * 
 * @param conf
 *            the job conf.
 * @return the Kafka buffer size.
 */
public static int getKafkaBufferSizeBytes(final Configuration conf) {
    return conf.getInt("kafka.socket.buffersize", DEFAULT_BUFFER_SIZE_BYTES);
}

/**
 * Sets the socket timeout of the {@link SimpleConsumer} inside of the {@link KafkaRecordReader}.
 * 
 * @param job
 *            the job being configured.
 * @param timeout
 *            the socket timeout (milliseconds).
 */
public static void setKafkaSocketTimeoutMs(final Job job, final int timeout) {
    job.getConfiguration().setInt("kafka.socket.timeout.ms", timeout);
}

/**
 * Gets the Kafka socket timeout set by {@link #setKafkaSocketTimeoutMs(Job, int)}, defaulting to
 * {@link #DEFAULT_SOCKET_TIMEOUT_MS} if it has not been set.
 * 
 * @param conf
 *            the job conf.
 * @return the Kafka socket timeout.
 */
public static int getKafkaSocketTimeoutMs(final Configuration conf) {
    return conf.getInt("kafka.socket.timeout.ms", DEFAULT_SOCKET_TIMEOUT_MS);
}
}