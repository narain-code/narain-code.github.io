package com.king.splat;

import java.io.IOException;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.serde2.columnar.BytesRefArrayWritable;
import org.apache.hadoop.hive.serde2.columnar.BytesRefWritable;
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import com.king.splat.util.ZkUtils;

public class Kafka2MultipleOutputFile {
	
	public static class DedupoloMapper extends Mapper<LongWritable, BytesWritable, NullWritable, BytesRefArrayWritable> {
		
		org.apache.hadoop.mapreduce.lib.output.MultipleOutputs<NullWritable, BytesRefArrayWritable> mos;
		
	//	private static final long EMPTY_MERGE = 0;
		private static final String EMPTY_MERGE = "0";
		private static final String EMPTY_INSTALL = "-1";
		private static final String EMPTY_INSTALL_ID = "";
		 NullWritable nullW = NullWritable.get();
		 Pattern installPt = Pattern.compile("^(MOID[0-9a-f]{32}|IDFV[0-9a-f]{32}|NOMO[0-9a-f]{32}|[0-9]{1,20}|WIPH[0-9a-f]{32}|WIPL[0-9a-f]{32})$");
		 
		
		@Override
		protected void setup(Context context
                ) throws IOException, InterruptedException {
				mos = new org.apache.hadoop.mapreduce.lib.output.MultipleOutputs<NullWritable, BytesRefArrayWritable>(context);
		}
		
		 public void map(LongWritable key, BytesWritable value, Context context) throws IOException, InterruptedException {
		    	
				try {
					
					String[] split = new String(value.copyBytes()).split("\t");
					//Long mergeId = Long.valueOf(split[2]);
					String mergeId = split[2];
					mergeId = mergeId.equalsIgnoreCase(EMPTY_MERGE) ? null : mergeId;

					
					  String installKeyString = split[3].trim();
					  installKeyString = (installKeyString.equalsIgnoreCase(EMPTY_INSTALL) ) ? null : installKeyString;
					  String installIDString = null;
					  if(split.length == 5 ){
						  if(split[4] != null){
						  installIDString= split[4].trim();
						  installIDString= (installIDString.equalsIgnoreCase(EMPTY_INSTALL_ID) ) ? null : installIDString;
						  if(!installPt.matcher(installIDString).find())
							  System.out.println( " Debug :: "+new String(value.copyBytes()) + installIDString );
						  
						  }
					  }
					/*long timeStamp =Long.valueOf(split[0]);
					long userId = Long.valueOf(split[1]);*/
					String timeStamp = split[0];
					String userId = split[1];
					
					BytesRefArrayWritable bytes = new BytesRefArrayWritable(5);
		            bytes.set(0, new BytesRefWritable( timeStamp.getBytes("UTF-8")));
		            bytes.set(1, new BytesRefWritable(userId.getBytes("UTF-8")));
		            if(installKeyString != null)
		            	bytes.set(2, new BytesRefWritable((installKeyString).getBytes("UTF-8")));
		            else
		            	bytes.set(2,BytesRefWritable.ZeroBytesRefWritable);
		            if(mergeId != null)
		            	bytes.set(3, new BytesRefWritable( mergeId.getBytes("UTF-8")));
		            else
		            	bytes.set(3,BytesRefWritable.ZeroBytesRefWritable);
		            
		            if(installIDString != null)
		            	bytes.set(4, new BytesRefWritable((installIDString).getBytes("UTF-8")));
		            else
		            	bytes.set(4, BytesRefWritable.ZeroBytesRefWritable);
					
					if(installKeyString == null ){
						mos.write("CoreUser", nullW, bytes);
					}else{
						mos.write("Install", nullW, bytes);
					}
					
				}catch(Exception ex){
					ex.printStackTrace();
				}
		 }
				
		 
		 @Override
         public void cleanup(Context context) throws IOException, InterruptedException {
                   mos.close();
         }
		
	}
	
	/**
	 *  building the job
	 */
	
	public static void main(String[] args){
	 try{	
		Configuration conf = new Configuration();
		
	    
	    if ( args.length < 4) {
	      System.err.println("Usage: Kafka2MultipleOutputFile <topic> <hdfsoutputpath> <zookeeper> <consumerGroup> <number of splits> <mapper>");
	      System.exit(2);
	    }
	    
	    /**
	     * read up all the args
	     */
	    String topic = args[0];
	    String hdfsOutput = args[1];
	    String zookeeperURL = args[2];
	    String consumerGroup = args[3];
	    int mapper = 1;
	    int numberOfSplits = Integer.MAX_VALUE;
	    if(args.length > 4 && args[4] != null){
	    	numberOfSplits = Integer.parseInt(args[4]);
	    	mapper = Integer.parseInt(args[5]);
	    }
	    
	    System.out.println( "###### Printing args  ##### ");
	    
	    System.out.println( "topic is " + topic);
	    System.out.println( "hdfsOutput is " + hdfsOutput);
	    System.out.println( "zookeeperURL is " + zookeeperURL);
	    System.out.println( "consumerGroup is " + consumerGroup);
	    System.out.println( "numberOfSplits is " + numberOfSplits);
	    System.out.println( "mapper is " + mapper);
	    System.out.println( "###### Printing args  ##### ");
	    
	    Job job = Job.getInstance(conf, "Kafka2Hdfs-"+topic);
	   
	    job.setJarByClass(Kafka2HdfsJob.class);
	    if(mapper == 1)
	    job.setMapperClass(DedupoloMapper.class);
	    else
	   // 	job.setMapperClass(CoreEventMapper.class);
	    	;
	    System.out.println( "mapperclass  is " + job.getMapperClass());
	    job.getConfiguration().setInt("hive.io.rcfile.column.number.conf", 9);
	    job.setOutputKeyClass(NullWritable.class);
	    job.setOutputValueClass(BytesRefArrayWritable.class);
	   // job.setOutputFormatClass(com.twitter.elephantbird.mapreduce.output.RCFileOutputFormat.class);
	   // job.setOutputFormatClass(TextOutputFormat.class);
	    FileOutputFormat.setOutputPath(job, new Path(hdfsOutput));
	    job.setNumReduceTasks(0);
	   
	    org.apache.hadoop.mapreduce.lib.output.MultipleOutputs.addNamedOutput(job,"Install",  com.twitter.elephantbird.mapreduce.output.RCFileOutputFormat.class, NullWritable.class, BytesRefArrayWritable.class);
	    org.apache.hadoop.mapreduce.lib.output.MultipleOutputs.addNamedOutput(job,"CoreUser",  com.twitter.elephantbird.mapreduce.output.RCFileOutputFormat.class, NullWritable.class, BytesRefArrayWritable.class);
	    /**
	     * 
	     * 
	     */
	    job.setInputFormatClass(KafkaInputFormat.class);
	    KafkaInputFormat.setConsumerGroup(job, consumerGroup);
	    // Set your Zookeeper connection string
	    KafkaInputFormat.setZkConnect(job, zookeeperURL);
	    // Set the topic you want to consume
	    KafkaInputFormat.setTopic(job, topic);
	    KafkaInputFormat.setMaxSplitsPerPartition(job,numberOfSplits );
	    
	   
	    List<InputSplit> allSplits =KafkaInputFormat.getAllSplits(job.getConfiguration(), topic,consumerGroup);
	    System.out.println(" The size is " + allSplits.size());
	    for(InputSplit s:allSplits){
	    	System.out.println(((KafkaInputSplit)s).getPartition()  + " " + ((KafkaInputSplit)s).getStartOffset());
	    }
	    if (job.waitForCompletion(true)) {
	    	  final ZkUtils zk = new ZkUtils(job.getConfiguration());
	    	  zk.commit(consumerGroup,topic);
	    	  zk.close();
	    	} 

	    
	 }catch(Exception ex){
		 ex.printStackTrace();
	 }
	}

}
