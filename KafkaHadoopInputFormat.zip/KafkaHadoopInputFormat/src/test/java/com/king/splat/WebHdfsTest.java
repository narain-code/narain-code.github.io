
package com.king.splat;

import java.io.IOException;
import java.net.URI;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.LocatedFileStatus;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.fs.RemoteIterator;

public class WebHdfsTest {
	
	public static void main(String[] args) throws IOException{
		String webHdfsUrl = "webhdfs://bihdnn01.skd.midasplayer.com:50070/webhdfs/v1/";
		String dir = "/tmp";
		Configuration hdfsConfig = new Configuration();
		FileSystem fs = FileSystem.get(URI.create(webHdfsUrl), hdfsConfig);
		RemoteIterator<LocatedFileStatus> files = fs.listFiles(new Path(dir), false);
		while (files.hasNext()) {
			LocatedFileStatus srcFile = files.next();
			String path = Path.getPathWithoutSchemeAndAuthority(srcFile.getPath()).toString();
			System.out.println(path);
		}
	}

}
