package com.king.splat;

import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import kafka.api.FetchRequestBuilder;
import kafka.api.OffsetRequest;
import kafka.api.PartitionOffsetRequestInfo;
import kafka.common.TopicAndPartition;
import kafka.javaapi.FetchResponse;
import kafka.javaapi.OffsetResponse;
import kafka.javaapi.consumer.SimpleConsumer;
import kafka.message.MessageAndOffset;

public class FilterNegative {
	private static final String zkConnectionString = "zk05.sto.midasplayer.com:2181";
	private static final String zkRoot = KafkaInputFormat.DEFAULT_ZK_ROOT;
	private static final int sessionTimeout = KafkaInputFormat.DEFAULT_ZK_SESSION_TIMEOUT_MS;
	private static final int connectionTimeout = KafkaInputFormat.DEFAULT_ZK_CONNECTION_TIMEOUT_MS;
	private static final String topic ="splat.installplayer-livetest_20160223_1.log";
	private static final String clientName ="negative123";
	private static final int partitionNumber = 6;
	
	
	 public static kafka.api.FetchRequest getNextFetch(long nextOffset){
		 FetchRequestBuilder fetchBuilder = new FetchRequestBuilder();
			
			fetchBuilder.addFetch(topic, partitionNumber, nextOffset, KafkaInputFormat.DEFAULT_FETCH_SIZE_BYTES);
			return fetchBuilder.build();
	 }
	
	
	public static void main(String[] args){
		SimpleConsumer consumer = new SimpleConsumer("kafka16.sto.midasplayer.com", 9092, KafkaInputFormat.DEFAULT_SOCKET_TIMEOUT_MS,  KafkaInputFormat.DEFAULT_BUFFER_SIZE_BYTES,clientName );
		long nextOffset;
		/**
		 * init
		 */
		  TopicAndPartition topicAndPartition = new TopicAndPartition(topic, partitionNumber);
	      Map<TopicAndPartition, PartitionOffsetRequestInfo> requestInfo = new HashMap<TopicAndPartition, PartitionOffsetRequestInfo>();
	      requestInfo.put(topicAndPartition, new PartitionOffsetRequestInfo(OffsetRequest.EarliestTime(), 1));
	      kafka.javaapi.OffsetRequest request = new kafka.javaapi.OffsetRequest(requestInfo, kafka.api.OffsetRequest.CurrentVersion(),clientName);
	      OffsetResponse response = consumer.getOffsetsBefore(request);
	      final long[] allOffsets =response.offsets(topic, partitionNumber);
		  nextOffset = allOffsets[0];
		  boolean found = false;
		  while(!found){
		  FetchResponse resp = consumer.fetch( getNextFetch(nextOffset));
		  
		  Iterator<MessageAndOffset> it =resp.messageSet(topic, partitionNumber).iterator();
		  
		   while(it.hasNext()){
			   MessageAndOffset m= it.next();
			   
			   final ByteBuffer buffer = m.message().payload();
			   
			  String v = new String( buffer.array());
			   nextOffset = m.offset() + 1;
		   }
		  
		  }
		
		
		
	}

}
