package com.king.splat;

import java.math.BigInteger;
import java.nio.charset.Charset;

public class TestLongParsing {
	
	
	public static void main(String[] args){
	//	BigInteger l = new BigInteger("9956671200638986747");
	//System.out.println(	Double.parseDouble("1274928329509957363290016846"));
		//long l = Long.valueOf("9956671200638986747");
	/*	BigInteger b= new BigInteger("9956671200638986747");
		System.out.println(b);
		System.out.println(Charset.defaultCharset());
		Long l = 1439628486L;
		System.out.println(l.hashCode()%15);*/
		String t = " 1583 ".trim();
		System.out.println(t.equals("1583"));
		System.out.println(Integer.parseInt(t.trim()) == 1583);
		
	}

}
