package com.king.splat;

import java.util.Collections;
import java.util.List;

import kafka.javaapi.PartitionMetadata;
import kafka.javaapi.TopicMetadata;
import kafka.javaapi.TopicMetadataRequest;
import kafka.javaapi.TopicMetadataResponse;
import kafka.javaapi.consumer.SimpleConsumer;


public class TestSimpleConsumer {

	
	public static void main(String[] args){
		SimpleConsumer c= new SimpleConsumer("kafka10.sto.midasplayer.com", 9092,1000, 64 * 1024,
				//"TestConsumer-"+15);
				"flink-kafka-consumer-partition-lookup");
		
	/*	 FetchRequestBuilder  builder =new kafka.api.FetchRequestBuilder().
					clientId("KafkaHadoopConsumer-"+15 +""+11);
     builder.addFetch("targettedusers",11, 0, 64*1024);
     FetchRequest req =builder.build();
     kafka.api.FetchResponse response = c.fetch(req);
     ByteBufferMessageSet mgs= response.messageSet("targettedusers", 11);
     System.out.println(mgs.size());
     Iterator<MessageAndOffset> it =mgs.iterator();
    // it.size(); 
     System.out.println(it.hasNext());
     System.out.println(it.next());*/
		
	List<String> topics = Collections.singletonList(args[0]);
	TopicMetadataRequest req = new TopicMetadataRequest(topics);
    TopicMetadataResponse resp = c.send(req);

    List<TopicMetadata> metaData = resp.topicsMetadata();

     for (TopicMetadata item : metaData) {
    	 for(PartitionMetadata m:	item.partitionsMetadata()){
    		 System.out.println(m.partitionId() + " :: " + m.leader() );
    	 }
     }
     
	}
}
