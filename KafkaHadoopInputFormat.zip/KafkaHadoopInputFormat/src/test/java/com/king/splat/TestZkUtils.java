
package com.king.splat;

import static java.lang.String.format;

import java.util.List;

import com.king.splat.kafka.Partition;
import com.king.splat.util.ZkUtils;

public class TestZkUtils {

	private static final String zkConnectionString = "zk05.sto.midasplayer.com:2181";
	private static final String zkRoot = KafkaInputFormat.DEFAULT_ZK_ROOT;
	private static final int sessionTimeout = KafkaInputFormat.DEFAULT_ZK_SESSION_TIMEOUT_MS;
	private static final int connectionTimeout = KafkaInputFormat.DEFAULT_ZK_CONNECTION_TIMEOUT_MS;
	
	public static void main(String[] args){
		ZkUtils zkCLient = new ZkUtils(zkConnectionString,zkRoot,sessionTimeout,connectionTimeout);
		String group = "GuiShown-kafkaconsumer-ratko";
		/*List<String> zkTopics =zkCLient.getChildrenParentMayNotExist(format("%s/consumers/%s/offsets-temp", zkRoot, group));
		
		for(String topic:zkTopics){
	        for (final Partition partition : zkCLient.getPartitionsWithTempOffsets(topic, group)) {
	            final String path = zkCLient.getTempOffsetsPath(group, partition);
	            System.out.println("offsets path "+path);
	        }
		} */
		zkCLient.commit(group);
	}
}
