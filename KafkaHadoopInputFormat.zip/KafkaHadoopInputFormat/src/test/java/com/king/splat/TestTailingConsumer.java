package com.king.splat;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import kafka.consumer.ConsumerConfig;
import kafka.consumer.ConsumerIterator;
import kafka.consumer.ConsumerTimeoutException;
import kafka.consumer.KafkaStream;
import kafka.javaapi.consumer.ConsumerConnector;

public class TestTailingConsumer {

	private  ConsumerConfig createConsumerConfig(String a_zookeeper, String a_groupId) {
        Properties props = new Properties();
        props.put("zookeeper.connect", a_zookeeper);
        props.put("group.id", a_groupId);
        props.put("zookeeper.session.timeout.ms", "400");
        props.put("zookeeper.sync.time.ms", "200");
        props.put("auto.commit.interval.ms", "1000");
       
 
        return new ConsumerConfig(props);
    }
	
	
	public void run(String topic) {
		final StringBuilder sb = new StringBuilder();
        Map<String, Integer> topicCountMap = new HashMap<String, Integer>();
        topicCountMap.put(topic, new Integer(1));
        final ConsumerConnector consumer = kafka.consumer.Consumer.createJavaConsumerConnector(
                createConsumerConfig("zk04.sto.midasplayer.com:2181/kafka", "tailing_consumer"));
        Map<String, List<KafkaStream<byte[], byte[]>>> consumerMap = consumer.createMessageStreams(topicCountMap);
        KafkaStream<byte[], byte[]> streams = consumerMap.get(topic).get(0);
       
        ConsumerIterator<byte[], byte[]> it = streams.iterator() ;
       
     
      long start = System.currentTimeMillis();
        while (System.currentTimeMillis()-start < 5000  && it.hasNext()){
        	
        	String message = new String(	it.next().message());
        	sb.append(message);
        		
        }
       
        //System.out.println(sb.toString());
        consumer.commitOffsets();
        consumer.shutdown();
    }
	
	public static void main(String[] args){
		TestTailingConsumer c = new TestTailingConsumer();
		c.run("PRINT_69288336");
	}
}
