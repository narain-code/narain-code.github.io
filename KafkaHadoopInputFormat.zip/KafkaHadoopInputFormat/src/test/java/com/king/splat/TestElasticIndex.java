package com.king.splat;

import static org.elasticsearch.common.xcontent.XContentFactory.jsonBuilder;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.concurrent.ThreadPoolExecutor;

import org.elasticsearch.action.admin.indices.create.CreateIndexRequestBuilder;
import org.elasticsearch.action.admin.indices.delete.DeleteIndexRequestBuilder;
import org.elasticsearch.action.admin.indices.exists.indices.IndicesExistsResponse;
import org.elasticsearch.action.bulk.BulkRequestBuilder;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.index.IndexRequestBuilder;
import org.elasticsearch.client.ElasticsearchClient;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.elasticsearch.common.xcontent.XContentBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TestElasticIndex {
	
//private final Logger logger = LoggerFactory.getLogger(ElasticsearchClient.class);
	
	
	private  ThreadPoolExecutor asyncRestPool;
	
	private TransportClient client;
	
	
	private static final String HOST = "fbweb619.sto.midasplayer.com";
	private static final int PORT=9300;
	private static final String clusterName ="elasticsearch";
	
	
	public TestElasticIndex() throws UnknownHostException{
		
		final Settings settings = Settings.settingsBuilder()
				.put("client.transport.sniff", true)
				.put("cluster.name", clusterName)
				.build();
		client =new TransportClient.Builder()
				.settings(settings)
				.build()
				.addTransportAddress(new InetSocketTransportAddress(InetAddress.getByName(HOST), PORT));
		
		
	}
	
	public TransportClient getClient(){
		return client;
	}
	
	/**
	 * 
	 * bulk processing of GameEnd
	 * 
	 * id == coreuserid
	 * 
	 */
	
	
	public void doBulk(){
		client.prepareBulk();
		
		
	}
	
	
	
	
    
	
	public XContentBuilder addMappingToIndex() throws IOException{
		final XContentBuilder mappingBuilder = jsonBuilder().startObject().startObject("SCGameEnd")
                .startObject("_ttl").field("enabled", "true").field("default", "1000s").endObject() //endobject for ttl
                .startObject("_all").field("enabled","true").endObject() //endfor all
                .startObject("_source").field("enabled","true").endObject() //endfor source
                .startObject("properties")
              
                .startObject("msts").field("type","date").field("doc_values","true").endObject()
                .startObject("episode").field("type","integer").field("doc_values","true")//.field("index","no")
                .endObject()
                .startObject("flavourid").field("type","integer").field("doc_values","true")//.field("index","no")
                .endObject()
                 .startObject("kingappid").field("type","integer").field("doc_values","true")//.field("index","no")
                 .endObject()
                 .startObject("level").field("type","integer").field("doc_values","true")//.field("index","no")
                 .endObject()
                 .startObject("gameends").field("type","integer").field("doc_values","true")//.field("index","no")
                 .endObject()
                .endObject() //end properties
                .endObject()// end ScGameEnd
                .endObject(); // end blank
       // System.out.println(mappingBuilder.string());
		return mappingBuilder;
       
	}
	
	
	public  interface Document{
		
		public XContentBuilder doIndex() throws IOException;
		
	}
	
	public static class GameEndDocument implements Document{
		
		public String documentId;
		public long msts;
		public int episode;
		public int flavourid;
		public int kingappid;
		public int level;
		public int gameend;
		
		public XContentBuilder doIndex() throws IOException{
			final XContentBuilder contentBuilder = jsonBuilder().startObject().prettyPrint();
	      
	        contentBuilder.field("msts", msts);
	        contentBuilder.field("episode", episode);
	        contentBuilder.field("flavourid", flavourid);
	        contentBuilder.field("kingappid", kingappid);
	        contentBuilder.field("level", level);
	        contentBuilder.field("gameend", gameend);
	        contentBuilder.endObject();
	        return contentBuilder;
	       
		}
		
	}
	
	
	public void send2Elastic(ArrayList<GameEndDocument> docs) throws IOException{
		BulkRequestBuilder bulkRequest =client.prepareBulk();
		
		for(GameEndDocument ge:docs){
		String documentId = ge.documentId;
        // Add documents
        final IndexRequestBuilder indexRequestBuilder = getClient().prepareIndex(indexName, documentType, documentId);
       
        // build json object
        
        
       
        
        indexRequestBuilder.setSource(ge.doIndex());
        //indexRequestBuilder.execute().actionGet();
        bulkRequest.add(indexRequestBuilder);
		}
		
		BulkResponse bulkResponse = bulkRequest.get();
		if (bulkResponse.hasFailures()) {
			System.out.println(bulkResponse.buildFailureMessage());
		}
	}
	
	private static String indexName ="rbea";
	private static String documentType = "SCGameEnd";
	
	public static void main(String[] args) {
		try{
			TestElasticIndex cl = new TestElasticIndex();
		//cl.doBulk();
		
		final IndicesExistsResponse res = cl.getClient().admin().indices().prepareExists(indexName).execute().actionGet();
		if (res.isExists()) {
            DeleteIndexRequestBuilder delIdx = cl.getClient().admin().indices().prepareDelete(indexName );
            delIdx.execute().actionGet();
        }
		  final CreateIndexRequestBuilder createIndexRequestBuilder = cl.getClient().admin().indices().prepareCreate(indexName);
		  createIndexRequestBuilder.addMapping(documentType, cl.addMappingToIndex());
		  
		
	        createIndexRequestBuilder.execute().actionGet();
	        ArrayList<GameEndDocument> docs = new ArrayList<TestElasticIndex.GameEndDocument>();
	        GameEndDocument doc = null;
	       for(int i =0; i< 10;i ++){
	    	   doc=new GameEndDocument();
	    	   doc.documentId = ""+i;
	    	   doc.episode = i;
	    	   doc.flavourid = i;
	    	   doc.gameend=i;
	    	   doc.kingappid = i;
	    	   doc.level=i;
	    	   doc.msts = System.currentTimeMillis();
	    	   docs.add(doc);
	       }
	        

		System.out.println(res.isExists());
		
		cl.send2Elastic(docs);
		
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}


}
