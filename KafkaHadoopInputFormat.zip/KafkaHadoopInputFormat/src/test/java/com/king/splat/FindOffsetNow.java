package com.king.splat;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import kafka.api.PartitionOffsetRequestInfo;
import kafka.common.TopicAndPartition;
import kafka.javaapi.OffsetRequest;
import kafka.javaapi.OffsetResponse;
import kafka.javaapi.consumer.SimpleConsumer;

import com.king.splat.kafka.Broker;
import com.king.splat.kafka.Partition;
import com.king.splat.util.ZkUtils;

public class FindOffsetNow {
	private static final String zkConnectionString = "zk05.sto.midasplayer.com:2181";
	private static final String zkRoot = KafkaInputFormat.DEFAULT_ZK_ROOT;
	private static final int sessionTimeout = KafkaInputFormat.DEFAULT_ZK_SESSION_TIMEOUT_MS;
	private static final int connectionTimeout = KafkaInputFormat.DEFAULT_ZK_CONNECTION_TIMEOUT_MS;
	private static final String topic = "splat.kpidevent_20160223.log";
	
	public static void main(String[] args){
		ZkUtils zk = new ZkUtils(zkConnectionString, zkRoot, sessionTimeout, connectionTimeout);
		for (final Partition partition : zk.getPartitions("splat.kpidevent_20160223.log")){
			final Broker broker = partition.getBroker();
			  String clientName = "FindOffset422"+topic+"-"+broker.getId();
			  SimpleConsumer consumer = new SimpleConsumer(broker.getHost(), broker.getPort(), KafkaInputFormat.DEFAULT_SOCKET_TIMEOUT_MS,
					  KafkaInputFormat.DEFAULT_BUFFER_SIZE_BYTES, KafkaInputFormat.clientName+"-"+broker.getId());
			  TopicAndPartition topicAndPartition = new TopicAndPartition(topic, partition.getPartId());
		        Map<TopicAndPartition, PartitionOffsetRequestInfo> requestInfo = new HashMap<TopicAndPartition, PartitionOffsetRequestInfo>();
		        requestInfo.put(topicAndPartition, new PartitionOffsetRequestInfo(
		        		kafka.api.OffsetRequest.LatestTime(), 1));
		        short version =0; // current version
		        kafka.javaapi.OffsetRequest request = new kafka.javaapi.OffsetRequest(requestInfo,version ,clientName);
		        OffsetResponse response = consumer.getOffsetsBefore(request);
		        
		        
		        final long[] allOffsets =response.offsets(topic, partition.getPartId());
		        
		        System.out.println( " " + partition.getPartId() + " "+allOffsets[0]);
		}
		
	}

}
