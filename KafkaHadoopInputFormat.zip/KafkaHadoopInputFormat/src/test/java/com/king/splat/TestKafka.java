package com.king.splat;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

import kafka.api.OffsetRequest;
import kafka.api.PartitionOffsetRequestInfo;
import kafka.common.TopicAndPartition;
import kafka.javaapi.OffsetResponse;
import kafka.javaapi.consumer.SimpleConsumer;

import com.google.common.collect.Lists;
import com.king.splat.Kafka2HdfsJob.KafkaMapper;
import com.king.splat.kafka.Broker;
import com.king.splat.kafka.Partition;
import com.king.splat.util.ZkUtils;

public class TestKafka {
	
	private static final String zkConnectionString = "zk05.sto.midasplayer.com:2181";
	private static final String zkRoot = KafkaInputFormat.DEFAULT_ZK_ROOT;
	private static final int sessionTimeout = KafkaInputFormat.DEFAULT_ZK_SESSION_TIMEOUT_MS;
	private static final int connectionTimeout = KafkaInputFormat.DEFAULT_ZK_CONNECTION_TIMEOUT_MS;
	//private static final String topic ="splat.installplayer-livetest_20160223_3.log";
	private static final String topic ="targettedusers";
	private static  String clientName ;
	
	public static void main(String[] args){
	/*	ZkUtils zk = new ZkUtils(zkConnectionString, zkRoot, sessionTimeout, connectionTimeout);
		for (final Partition partition : zk.getPartitions(topic)) {
			//System.out.println(partition.getPartId() + " " + partition.getBroker().getId());
			  final Broker broker = partition.getBroker();
			  clientName = KafkaInputFormat.clientName+"-"+broker.getId();
			  SimpleConsumer consumer = new SimpleConsumer(broker.getHost(), broker.getPort(), KafkaInputFormat.DEFAULT_SOCKET_TIMEOUT_MS,
					  KafkaInputFormat.DEFAULT_BUFFER_SIZE_BYTES, KafkaInputFormat.clientName+"-"+broker.getId());
			  
			  TopicAndPartition topicAndPartition = new TopicAndPartition(topic, partition.getPartId());
		      Map<TopicAndPartition, PartitionOffsetRequestInfo> requestInfo = new HashMap<TopicAndPartition, PartitionOffsetRequestInfo>();
		      requestInfo.put(topicAndPartition, new PartitionOffsetRequestInfo(OffsetRequest.LatestTime(), Integer.MAX_VALUE));
		      kafka.javaapi.OffsetRequest request = new kafka.javaapi.OffsetRequest(requestInfo, kafka.api.OffsetRequest.CurrentVersion(),clientName);
		      OffsetResponse response = consumer.getOffsetsBefore(request);
		      final long[] allOffsets =response.offsets(topic, partition.getPartId());
			 System.out.println(allOffsets.length + " " + allOffsets.length%3 + " each is " + (allOffsets.length - (allOffsets.length%3)) /3);
			 for(Long l : allOffsets){
				 System.out.println( partition.getPartId() + " :: " +l);
			 }
			
		} */
		
	try{	
		Configuration conf = new Configuration();
		
	    
	    if ( args.length < 4) {
	      System.err.println("Usage: Kafka2Hdfs <topic> <hdfsoutputpath> <zookeeper> <consumerGroup> <number of splits>");
	      System.exit(2);
	    }
	    
	    /**
	     * read up all the args
	     */
	    String topic = args[0];
	    String hdfsOutput = args[1];
	    String zookeeperURL = args[2];
	    String consumerGroup = args[3];
	    
	    int numberOfSplits = Integer.MAX_VALUE;
	    if(args.length > 4 && args[4] != null){
	    	numberOfSplits = Integer.parseInt(args[4]);
	    }
	    
	    System.out.println( "###### Printing args  ##### ");
	    
	    System.out.println( "topic is " + topic);
	    System.out.println( "hdfsOutput is " + hdfsOutput);
	    System.out.println( "zookeeperURL is " + zookeeperURL);
	    System.out.println( "consumerGroup is " + consumerGroup);
	    System.out.println( "numberOfSplits is " + numberOfSplits);
	    System.out.println( "###### Printing args  ##### ");
	    
	    Job job = Job.getInstance(conf, "Kafka2Hdfs-"+topic);
	    job.setJarByClass(Kafka2HdfsJob.class);
	    job.setMapperClass(KafkaMapper.class);
	    
	    job.setOutputKeyClass(Text.class);
	    job.setOutputValueClass(Text.class);
	    job.setOutputFormatClass(TextOutputFormat.class);
	    FileOutputFormat.setOutputPath(job, new Path(hdfsOutput));
	    job.setNumReduceTasks(0);

	    /**
	     * 
	     * 
	     */
	    job.setInputFormatClass(KafkaInputFormat.class);
	    KafkaInputFormat.setConsumerGroup(job, consumerGroup);
	    // Set your Zookeeper connection string
	    KafkaInputFormat.setZkConnect(job, zookeeperURL);
	    // Set the topic you want to consume
	    KafkaInputFormat.setTopic(job, topic);
	    KafkaInputFormat.setMaxSplitsPerPartition(job,numberOfSplits );
	    
	    System.out.println(job.getConfiguration().get("kafka.zk.connect"));
	    List<InputSplit> allSplits =KafkaInputFormat.getAllSplits(job.getConfiguration(), topic,consumerGroup);
	    System.out.println(" The size is " + allSplits.size());
	    for(InputSplit s:allSplits){
	    	System.out.println(((KafkaInputSplit)s).getPartition() + " " + ((KafkaInputSplit)s).getStartOffset() + " " +((KafkaInputSplit)s).getEndOffset());
	    	;
	    }
	    
	    
	    
	   
	    
	    
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	private static List<Long> getOffsets(final SimpleConsumer consumer, final String topic, final int partitionNum,
	            final long lastCommit, final long asOfTime, final int maxSplitsPerPartition) {
	        // all offsets that exist for this partition (in descending order)
	    	TopicAndPartition topicAndPartition = new TopicAndPartition(topic, partitionNum);
	        Map<TopicAndPartition, PartitionOffsetRequestInfo> requestInfo = new HashMap<TopicAndPartition, PartitionOffsetRequestInfo>();
	        requestInfo.put(topicAndPartition, new PartitionOffsetRequestInfo(asOfTime, Integer.MAX_VALUE));
	        kafka.javaapi.OffsetRequest request = new kafka.javaapi.OffsetRequest(requestInfo, kafka.api.OffsetRequest.CurrentVersion(),clientName);
	        OffsetResponse response = consumer.getOffsetsBefore(request);
	        final long[] allOffsets =response.offsets(topic, partitionNum);

	     /*   final long[] allOffsets = consumer.getOffsetsBefore(topic, partitionNum, OffsetRequest.LatestTime(),
	                Integer.MAX_VALUE);*/

	       
	        requestInfo = new HashMap<TopicAndPartition, PartitionOffsetRequestInfo>();
	        requestInfo.put(topicAndPartition, new PartitionOffsetRequestInfo(lastCommit, 1));
	         request = new kafka.javaapi.OffsetRequest(requestInfo,kafka.api.OffsetRequest.CurrentVersion(),clientName);
	        final long[] offsetsBeforeAsOf = consumer.getOffsetsBefore(request).offsets(topic, partitionNum);
	        final long includeAfter = offsetsBeforeAsOf.length == 1 ? offsetsBeforeAsOf[0] : 0;

	        // note that the offsets are in descending order
	        List<Long> result = Lists.newArrayList();
	        for (final long offset : allOffsets) {
	            if (offset > lastCommit && offset > includeAfter) {
	                result.add(offset);
	            } else {
	                // we add "lastCommit" iff it is after "includeAfter"
	                if (lastCommit > includeAfter) {
	                    result.add(lastCommit);
	                }
	                // we can break out of loop here bc offsets are in desc order, and we've hit the latest one to include
	                break;
	            }
	        }
	        // to get maxSplitsPerPartition number of splits, you need (maxSplitsPerPartition + 1) number of offsets.
	        if (result.size() - 1 > maxSplitsPerPartition) {
	            result = result.subList(result.size() - maxSplitsPerPartition - 1, result.size());
	        }
	        
	        return result;
	    }

}
