package com.king.rbea.hashlookup;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.fs.permission.FsPermission;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.RecordWriter;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.util.Progressable;

import com.king.rbea.RKeyValueWritable;

public class HashLookUpWriter<K,V> implements RecordWriter<K,V> {
	JobConf jobConf;
	Progressable progress;
	String baseOutput;
	int writeBatchSize;
	String tempDir;
	CdbMake make;
	int currIndex =0;
	int index = -1;
	public HashLookUpWriter(Progressable progress, JobConf jobConf) throws IOException {
		this.progress = progress;
		this.jobConf = jobConf;
		baseOutput = jobConf.get("mapred.output.dir");
		writeBatchSize = jobConf.getInt("hashlookup.write.batch.size", 10000);	
		tempDir = Files.createTempDirectory("CDBShards").toAbsolutePath().toString();
		make = new CdbMake();
		
	}
	
	@Override
	public void write(K key, V value) throws IOException {
		
		byte[] rkey =((RKeyValueWritable)value).getKey().copyBytes();
		byte[] rvalue = ((RKeyValueWritable)value).getValue().copyBytes();
		
		if(index == -1){
			index = ((IntWritable)key).get();
			
			make.start(tempDir+"/"+index+"-cdb");
		}
		make.add(rkey, rvalue);
		currIndex ++;
		if(currIndex > 0 && currIndex%writeBatchSize == 0 ){
			 progress.progress();
			 currIndex =0;
		}
	}

	@Override
	public void close(Reporter reporter) throws IOException {
		make.finish();
		FileSystem fs =FileSystem.get(jobConf);
		
		File shardDir = new File(tempDir);
		Path out =  new Path(baseOutput+"/"+index);
		FsPermission filePerm = new FsPermission((short)0777);
		fs.mkdirs(out, filePerm);
		
		File[] files =shardDir.listFiles();
		System.out.println("Copying files now " + files.length );
		for(File f:files){
			System.out.println("Copying file " +f.getPath() + " to " + out );
			
			fs.copyFromLocalFile(new Path(f.getPath()),new Path( out.toString() + "/" + f.getName()));
		}
		System.out.println("Finished");
	
		
	}

}
