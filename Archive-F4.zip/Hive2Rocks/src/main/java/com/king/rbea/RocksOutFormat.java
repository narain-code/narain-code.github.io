package com.king.rbea;

import java.io.IOException;

import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.OutputFormat;
import org.apache.hadoop.mapred.RecordWriter;
import org.apache.hadoop.util.Progressable;

public class RocksOutFormat<K,V> implements OutputFormat<K, V>{

	public RecordWriter<K, V> getRecordWriter(FileSystem ignored, JobConf job,
			String name, Progressable progress) throws IOException {

		try {
			return new RocksDbWriter( job);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new IOException(e.getMessage());
		}
	}

	public void checkOutputSpecs(FileSystem ignored, JobConf job)
			throws IOException {
		/*
		 * 
		 * Right now nothing to do
		 */
		
	}

}
