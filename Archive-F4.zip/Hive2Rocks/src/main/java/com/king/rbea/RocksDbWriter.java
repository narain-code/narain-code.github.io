package com.king.rbea;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

import net.openhft.hashing.LongHashFunction;

import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.fs.permission.FsPermission;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.RecordWriter;
import org.apache.hadoop.mapred.Reporter;
import org.rocksdb.BlockBasedTableConfig;
import org.rocksdb.ColumnFamilyDescriptor;
import org.rocksdb.ColumnFamilyHandle;
import org.rocksdb.ColumnFamilyOptions;
import org.rocksdb.CompactionStyle;
import org.rocksdb.CompressionType;
import org.rocksdb.DBOptions;
import org.rocksdb.Options;
import org.rocksdb.RocksDB;
import org.rocksdb.VectorMemTableConfig;
import org.rocksdb.WriteBatch;
import org.rocksdb.WriteOptions;

public class RocksDbWriter<K,V> implements RecordWriter<K,V> {
	
	public static int NUMBEROFPARTITIONS=16;

	int numberOfFlush;
	LongHashFunction partitioner =LongHashFunction.xx_r39();
	
	static {
	    RocksDB.loadLibrary();   
	  }

	
	
	JobConf conf;
	String baseOutput;
	int writeBatchSize;
	String tempDir;
	RocksDB db;
	int previousShard = -1;
	//List<RKeyValueWritable> recordsToBeFlushed = new ArrayList<RKeyValueWritable>();
	//RKeyValueWritable[] recordsToBeFlushed ;
	WriteBatch recordsToBeFlushed = new WriteBatch();
	
	/**
	 * Rocks things
	 */
	
	Options opt ;
	List<ColumnFamilyDescriptor> listCfs =new ArrayList<ColumnFamilyDescriptor>();
    List<ColumnFamilyHandle> listCFhs = new ArrayList<ColumnFamilyHandle>();
	int index;
	int currPosition;
	public RocksDbWriter( JobConf jobConf) throws Exception{
		
		this.conf =jobConf;
		
	    baseOutput = conf.get("mapred.output.dir");
		writeBatchSize = conf.getInt("rocksdb.write.batch.size", 100);	
		tempDir = Files.createTempDirectory("DBshards").toAbsolutePath().toString();
		opt = new Options().setCreateIfMissing(true).setCreateMissingColumnFamilies(true).setCompressionType(CompressionType.NO_COMPRESSION);
		//recordsToBeFlushed = new RKeyValueWritable[writeBatchSize];
	}

	public void write(K key, V value) throws IOException {
		/**
		 * not doing something with previous shard..
		 * but if we write more shards in the same recordwriter
		 */
		
		if(previousShard == -1){
			try {
				openDb((IntWritable)key);
			} catch (Exception e) {
				e.printStackTrace();
				throw new IOException(e.getMessage());
			}
			previousShard = ((IntWritable)key).get();
		}
		if ( recordsToBeFlushed !=null &&currPosition >0 && currPosition% writeBatchSize == 0){
			try {
			 flush();
			} catch (Exception e) {
				e.printStackTrace();
				throw new IOException(e.getMessage());
			}
	
			
		}
		//System.out.println(new String(((RKeyValueWritable)value).getKey().getBytes()));
		byte[] rkey =((RKeyValueWritable)value).getKey().copyBytes();
		byte[] rvalue = ((RKeyValueWritable)value).getValue().copyBytes();
		recordsToBeFlushed.put(rkey, rvalue);
		currPosition +=1;
	}
	
	
	private void flush() throws Exception{
		//System.out.println(" flushing records " + currPosition);
		
		//for(RKeyValueWritable w:recordsToBeFlushed){
		/*for(int i =0; i< recordsToBeFlushed.length; i++){
			RKeyValueWritable w = recordsToBeFlushed[i];
			byte[] key =w.getKey().copyBytes();
			byte[] value = w.getValue().copyBytes();
			/*int part =Math.abs((int)(partitioner.hashBytes(key) % NUMBEROFPARTITIONS));
			System.out.println(" " + new String(key) + " " + numberOfFlush);
			writeBatch.put(listCFhs.get((part +1)),  key, value);*/
			
			//writeBatch.put(key, value);
		//}
		db.write(new WriteOptions().setDisableWAL(true), recordsToBeFlushed);
		recordsToBeFlushed = null;
		recordsToBeFlushed = new WriteBatch();
		currPosition =0;
		numberOfFlush ++;
	    //System.out.println(" Completed flushing  records ");
	}
	
	private void openDb(IntWritable shard ) throws Exception{

		BlockBasedTableConfig blockConfig =new BlockBasedTableConfig();
		 /*
		  * 256 MB
		  */
		 blockConfig.setBlockSize(256*1024);
		 blockConfig.setCacheIndexAndFilterBlocks(true);
		// opt.setMemTableConfig(new VectorMemTableConfig().setReservedSize(writeBatchSize));
		 ColumnFamilyOptions cfOptions = new ColumnFamilyOptions();
	     cfOptions.setCompactionStyle(CompactionStyle.LEVEL);
	     cfOptions.setTableFormatConfig(blockConfig);
	     index = shard.get();
	 /*    int windowLength = NUMBEROFPARTITIONS;
	     index = shard.get();
	     int start = (index - 1) * windowLength;
		 int endWindowLength = index*windowLength;
	     for(int i=start; i< endWindowLength ; i ++ ){
	    	if(i==start)  
	    		listCfs.add(new ColumnFamilyDescriptor(RocksDB.DEFAULT_COLUMN_FAMILY, cfOptions));
		    listCfs.add( new ColumnFamilyDescriptor(("schema_"+i).getBytes(),cfOptions));
	     }
	     
	     	
			db = RocksDB.open(opt, tempDir+"-"+index,listCfs,listCFhs);
			
			
			listCFhs.get(0).dispose();
			
			*/
	    db = RocksDB.open(opt, tempDir+"-"+index);
	}
	
	private void closeDB() throws Exception{
		
		if ( recordsToBeFlushed !=null ){
			
			 flush();
			
		}
		
	/*	int i =0;
		for(ColumnFamilyHandle h : listCFhs){
			
			if(i == 0){
				i ++;
				continue;
			}	
			h.dispose();
			i++;
		}
		*/
		db.close();
	}

	public void close(Reporter reporter) throws IOException {
		try{
		closeDB();
		}catch(Exception ex){
			throw new IOException(ex.getMessage());
		}
		FileSystem fs =FileSystem.get(conf);
		
		File shardDir = new File(tempDir+"-"+index);
		Path out =  new Path(baseOutput+"/"+index);
		FsPermission filePerm = new FsPermission((short)0777);
		fs.mkdirs(out, filePerm);
		
		File[] files =shardDir.listFiles();
		System.out.println("Copying files now " + files.length );
		for(File f:files){
			System.out.println("Copying file " +f.getPath() + " to " + out );
			
			fs.copyFromLocalFile(new Path(f.getPath()),new Path( out.toString() + "/" + f.getName()));
		}
		System.out.println("Finished");
	}

}
