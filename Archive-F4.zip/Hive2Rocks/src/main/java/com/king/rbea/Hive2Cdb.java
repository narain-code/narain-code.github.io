package com.king.rbea;

import java.io.DataOutput;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.serde2.lazy.LazySimpleSerDe;
import org.apache.hadoop.hive.serde2.objectinspector.StructField;
import org.apache.hadoop.hive.serde2.objectinspector.StructObjectInspector;
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Partitioner;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapred.TextInputFormat;

import com.google.common.base.Charsets;
import com.king.rbea.hashlookup.HashLookUpOutputFormat;

public class Hive2Cdb {
	private static LazySimpleSerDe serde;
	static
	  {
	    try
	    {
	      Configuration conf = new Configuration();
	      Properties tbl = new Properties();

	      tbl.setProperty("serialization.format", "1");

	      tbl.setProperty("columns", "coreuserid,kingappid,activitystate,paystate,payvolume,churnrisk,loyaltystate,payprediction,countrycode");
	      tbl.setProperty("columns.types", "bigint:string:string:string:string:string:string:string:string");

	      tbl.setProperty("serialization.null.format", "NULL");

	      //serde = new ColumnarSerDe();
	      serde = new LazySimpleSerDe();
	      serde.initialize(conf, tbl);

	      StructObjectInspector oi = (StructObjectInspector)serde.getObjectInspector();
	      List<? extends StructField> fieldRefs = oi.getAllStructFieldRefs();

	      for (StructField structField : fieldRefs) {
	        System.out.println("FIELD: " + structField.getFieldName());
	      }

	    }
	    catch (Exception e)
	    {
	      e.printStackTrace();
	      System.out.println("Failed to setup SERDE.");
	    }
	  }
	
	
	public static class ThePartitioner implements Partitioner<IntWritable, RKeyValueWritable>{

		@Override
		public void configure(JobConf job) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public int getPartition(IntWritable key, RKeyValueWritable value,
				int numPartitions) {
			
			return key.get()%numPartitions;
		}
		
	}
	
	public static class TheMapper extends MapReduceBase implements Mapper<LongWritable,Text,IntWritable,RKeyValueWritable>{

		
		
		public static final int NUMBEROFPARTS = 256;
		Ring ring;
		
		public TheMapper(){
			ArrayList<Integer> nodes = new ArrayList<Integer>();
			for(int i =0; i < NUMBEROFPARTS; i ++){
				nodes.add(i);
			}	
			ring = new Ring(0, nodes);
			
		}
		
		 private byte[] compress(long value) throws IOException {
			ByteBuffer buff = ByteBuffer.allocate(Long.BYTES * 8);
			 int i = 1;
			    while ((value & ~0x7FL) != 0) {
			      buff.putInt((((int) value & 0x7F) | 0x80));
			      value >>>= 7;
			      i++;
			    }
			    buff.put((byte) value);
			    buff.flip();
			    byte[] lArray = new byte[i];
			     buff.get(lArray, 0, i);
			     return lArray;
		    }
		 
		
		 
		 private byte[] compressInt(int value) {
		
			 ByteBuffer buff = ByteBuffer.allocate(Integer.BYTES * 8);
			 int i = 1;
			    while ((value & ~0x7F) != 0) {
			     buff.put((byte)((value & 0x7F) | 0x80));
			      value >>>= 7;
			      i++;
			    }

			    buff.put((byte) value);
			    buff.flip();
			    System.out.println("length " +i);
			    byte[] lArray = new byte[i];
			     buff.get(lArray, 0, i);
			     return lArray;

		 }
		
		
		@Override
		public void map(LongWritable key, Text value,
				OutputCollector<IntWritable, RKeyValueWritable> output,
				Reporter reporter) throws IOException {
			 try{	
					StructObjectInspector oi = (StructObjectInspector)serde.getObjectInspector();
			        List fieldRefs = oi.getAllStructFieldRefs();

			        Object raw = serde.deserialize(value);

			        List dataStruct = oi.getStructFieldsDataAsList(raw);
			       if(dataStruct.get(0) != null){
			        String coreUserId =dataStruct.get(0).toString();
			        List<byte[]> values = new ArrayList<byte[]>();
			        int totalLength = 0;
			        for(int i=1;i<=8;i++){
			        	if(dataStruct.get(i) != null){
			        	 byte[] vlBytes;
			        	if(i == 8){	
			        	 vlBytes =writeStringWithLength(i, dataStruct.get(i).toString());
			        	}else
			        	{
			        		
			        		int val =Integer.parseInt(dataStruct.get(i).toString());
			        		System.out.println("value is " +val);
			        		vlBytes = compressInt(val);
			        	}
			        	totalLength += vlBytes.length;
			        	values.add(vlBytes);
			        	}
			        	else{
			        		byte[] vlBytes =writeNullColumn(i);
			        		totalLength += vlBytes.length;
				        	values.add(vlBytes);
			        	}
			        }
			      // System.out.println("totallength " +totalLength);
			        ByteBuffer buf = ByteBuffer.allocate(totalLength);
			        for(byte[] b: values){
			         buf.put(b);
			         
			        } 
			        
			        System.out.println("compressed " + totalLength);
			        buf.flip();
			        byte[] copy = new byte[totalLength];
			        buf.get(copy, 0, totalLength);
			        Long l = Long.valueOf(coreUserId);
			        RKeyValueWritable val = new RKeyValueWritable(new BytesWritable(compress(l)), new BytesWritable(copy));
			        int shardId = ring.getNodeByObjectId(coreUserId);
			        IntWritable keyWritable = new IntWritable(shardId);
			        
			        //	 System.out.println(new String(val.getKey().copyBytes()));
			    //    reporter.getCounter(SHARDS.valueOf(""+shardId)).increment(1L);
			        	 output.collect(keyWritable,val);
			       
			       } 
			 }catch(Exception ex){
				 ex.printStackTrace();
			 }
			
		}
		
		
		public byte[] writeNullColumn(int column){
			//ByteBuffer buf = ByteBuffer.allocate(1*(Integer.SIZE/Byte.SIZE));
			//buf.putInt(column);
			//buf.putInt(0);
			//buf.flip();
			//return buf.array();
			return compressInt(0);
		}
		
		
		public byte[] writeStringWithLength(int column,String value){
		//	System.out.println("column " + column + " value " + value);
			int totalSize = 0;
			byte[] vlBytes =value.getBytes(Charsets.UTF_8);
			int l =value.length();
			ByteBuffer buf = ByteBuffer.allocate(vlBytes.length+(Integer.SIZE/Byte.SIZE));
			//buf.putInt(column);
			//buf.putInt(l);
			byte[] cInt =compressInt(l);
			buf.put(cInt);
			totalSize+=cInt.length;
			for (int i = 0; i < l; i++) {
		        int c = (int) value.charAt(i);
		        byte[] pInt =compressInt(c);
		        totalSize+=pInt.length;
		        buf.put(pInt);
			}
			buf.flip();
			 byte[] lArray = new byte[totalSize];
		     buf.get(lArray, 0, totalSize);
		     return lArray;
		}
		
	}

	public static class TheReducer extends MapReduceBase implements Reducer<IntWritable,RKeyValueWritable,IntWritable,RKeyValueWritable>{
		int count =0;
		@Override
		public void reduce(IntWritable key, Iterator<RKeyValueWritable> values,
				OutputCollector<IntWritable, RKeyValueWritable> output,
				Reporter reporter) throws IOException {
			while(values.hasNext()){
			RKeyValueWritable val = values.next();	
			//System.out.println(new String(val.getKey().getBytes()));
			output.collect(key, val);
			count ++;
			if(count%10000 == 0)
			System.out.println("count "+count);
			}
			
		}
		
	}
	
	public static void main(String[] args){
		
		if (args.length != 2) {
			System.err.println("usage: <input path> <cdb output path>");
			return;
			}
		JobConf job = new JobConf(Hive2Cdb.class);
		job.setJobName("Hive2HashLookup");
		job.setJarByClass(Hive2Rocks.class);
		job.setInputFormat(TextInputFormat.class);
		job.setOutputFormat(HashLookUpOutputFormat.class);
		job.setMapOutputKeyClass(IntWritable.class);
		job.setMapOutputValueClass(RKeyValueWritable.class);
		job.setMapperClass(TheMapper.class);
		job.setReducerClass(TheReducer.class);
		job.setNumReduceTasks(TheMapper.NUMBEROFPARTS);
		job.setOutputKeyClass(IntWritable.class);
		job.setOutputValueClass(RKeyValueWritable.class);
		job.setPartitionerClass(ThePartitioner.class);
		
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		try
	    {
	      JobClient.runJob(job);
	    }
	    catch (IOException e) {
	      e.printStackTrace();
	    }
	}
}

