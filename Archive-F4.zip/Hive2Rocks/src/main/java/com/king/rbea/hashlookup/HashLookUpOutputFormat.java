package com.king.rbea.hashlookup;

import java.io.IOException;

import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.OutputFormat;
import org.apache.hadoop.mapred.RecordWriter;
import org.apache.hadoop.util.Progressable;

public class HashLookUpOutputFormat<K,V> implements OutputFormat<K, V> {


	

@Override
public RecordWriter<K, V> getRecordWriter(FileSystem ignored, JobConf job,
		String name, Progressable progress) throws IOException {
	// TODO Auto-generated method stub
	return new HashLookUpWriter<K, V>(progress, job);
}

@Override
public void checkOutputSpecs(FileSystem ignored, JobConf job)
		throws IOException {
	// TODO Auto-generated method stub
	
}
}
