package com.king.rbea.metrics;

public interface PauseDetectorListener {

	 /**
     * handle a pause event notification.
     * @param pauseLength Length of reported pause (in nanoseconds)
     * @param pauseEndTime Time sampled at end of reported pause (in nanoTime units).
     */
    public void handlePauseEvent(long pauseLength, long pauseEndTime);
}
