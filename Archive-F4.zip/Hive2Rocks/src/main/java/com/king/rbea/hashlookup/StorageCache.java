package com.king.rbea.hashlookup;

import java.nio.ByteBuffer;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class StorageCache {
// Static null object to recognizes null from missing values
protected static final byte[] NULL_VALUE = new byte[0];


ReadWriteLock lock =new ReentrantReadWriteLock();





/*
 * Memory usage
 *  632 bytes for the LinkedHashMap
 *  24 bytes theoretical overhead per entry but more like 45 in practice
 */
final static int OVERHEAD = 50;
private final Map<ByteBuffer,byte[]> cache;

private long maxWeight;
private long currentWeight;
private static int CACHE_INITIAL_CAPACITY = 100000;
private static float CACHE_LOAD_FACTOR = 0.75f;
private static long CACHE_BYTES = Math.max(0, Runtime.getRuntime().maxMemory() - (100 * 1024 * 1024));
/**
 * Cache constructor.
 *
 * @param config configuration
 */
public StorageCache() {
	
	
  cache =  new LinkedHashMap(CACHE_INITIAL_CAPACITY,
		  				CACHE_LOAD_FACTOR, true) {
    @Override
    protected boolean removeEldestEntry(Map.Entry eldest) {
      boolean res = currentWeight > maxWeight;
      if (res) {
        Object key = eldest.getKey();
        Object value = eldest.getValue();
        currentWeight -= getWeight(key) + getWeight(value) + OVERHEAD;
      }
      return res;
    }
  };
  maxWeight = CACHE_BYTES;
 
}



/**
 * Gets the value in the cache for <code>key</code> or null if not found.
 * <p>
 * If the value associated with <code>key</code> exists but is null, returns
 * <code>StorageCache.NULL_VALUE</code>.
 *
 * @param key key to get value for
 * @param <K> return type
 * @return value, null or <code>StorageCache.NULL_VALUE</code>
 */
public byte[] get(byte[] key) {
	try{
		lock.readLock().lock();
		return  cache.get(ByteBuffer.wrap(key));
	} finally{
		lock.readLock().unlock();
  }
}

/**
 * Returns true if the cache contains <code>key</code>.
 *
 * @param key key to test presence for
 * @return true if found, false otherwise
 */
public boolean contains(byte[] key) {
  return cache.containsKey(ByteBuffer.wrap(key));
}

/**
 * Puts the <code>key/value</code> pair into the cache.
 *
 * @param key key
 * @param value value
 */
public void put(byte[] key, byte[] value) {
try{	
	lock.writeLock().lock();
  int weight = getWeight(key) + getWeight(value) + OVERHEAD;
  currentWeight += weight;
  if (cache.put(ByteBuffer.wrap(key), value == null ? NULL_VALUE : value) != null) {
    currentWeight -= weight;
  }
 }finally{
	 lock.writeLock().unlock();
 }
}

/**
 * Gets the weight for <code>value</code>.
 *
 * @param value value to get weight for
 * @return weight
 */
private int getWeight(Object value) {
  if (value == null) {
    return 0;
  }
  if (value.getClass().isArray()) {
    Class cc = value.getClass().getComponentType();
    if (cc.isPrimitive()) {
      if (cc.equals(int.class)) {
        return ((int[]) value).length * 4;
      } else if (cc.equals(long.class)) {
        return ((long[]) value).length * 8;
      } else if (cc.equals(double.class)) {
        return ((double[]) value).length * 8;
      } else if (cc.equals(float.class)) {
        return ((float[]) value).length * 4;
      } else if (cc.equals(boolean.class)) {
        return ((boolean[]) value).length * 1;
      } else if (cc.equals(byte.class)) {
        return ((byte[]) value).length * 1;
      } else if (cc.equals(short.class)) {
        return ((short[]) value).length * 2;
      } else if (cc.equals(char.class)) {
        return ((char[]) value).length * 2;
      }
    } else if (cc.equals(String.class)) {
      String[] v = (String[]) value;
      int res = 0;
      for (int i = 0; i < v.length; i++) {
        res += v[i].length() * 2 + 40;
      }
      return res;
    } else if (cc.equals(int[].class)) {
      int[][] v = (int[][]) value;
      int res = 0;
      for (int i = 0; i < v.length; i++) {
        res += v[i].length * 4;
      }
      return res;
    } else if (cc.equals(long[].class)) {
      long[][] v = (long[][]) value;
      int res = 0;
      for (int i = 0; i < v.length; i++) {
        res += v[i].length * 8;
      }
      return res;
    } else {
      Object[] v = (Object[]) value;
      int res = 0;
      for (int i = 0; i < v.length; i++) {
        res += getWeight(v[i]);
      }
      return res;
    }
  } else if (value instanceof String) {
    return ((String) value).length() * 2 + 40;
  } else {
    
  }
  return 16;
}

/**
 * Sets the max weight in the cache.
 *
 * @param maxWeight max weight
 */
public void setMaxWeight(long maxWeight) {
  this.maxWeight = maxWeight;
}

/**
 * Gets the cache size.
 *
 * @return cache size
 */
public int size() {
  return cache.size();
}

/**
 * Gets the cache current weight.
 *
 * @return weight
 */
public long getWeight() {
  return currentWeight;
}

/**
 * Special inner class that overrides all cache's features when the cache is disabled.
 */
private static class DisabledCache extends StorageCache {

  DisabledCache() {
    
  }

  @Override
  public byte[] get(byte[] key) {
    return null;
  }

  @Override
  public boolean contains(byte[] key) {
    return false;
  }

  @Override
  public void put(byte[] key, byte[] value) {
  }

  @Override
  public int size() {
    return 0;
  }
}
}


