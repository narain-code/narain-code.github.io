package com.king.rbea;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.SortedMap;
import java.util.TreeMap;

import net.openhft.hashing.LongHashFunction;

public class Ring {

	
	
	private SortedMap<Long, Integer> ring = new TreeMap<Long, Integer>();
	
	
	//private FarmHash hash = new FarmHash();
	
	private MD5Hash hash = new MD5Hash();
	
	private int vNodeCount;
	private BigInteger count;

	public Ring(int vnodeCount, Collection<Integer> pNodes) {

	    this.vNodeCount = vnodeCount;

	    for (Integer pNode : pNodes) {
	        addNode( pNode, vnodeCount);
	    }
	    count = new BigInteger(""+pNodes.size());
	}

	private void addNode(Integer pNode, int vnodeCount) {
	    if(vNodeCount == 0){
	    	 ring.put(hash.hash(pNode.toString() ), pNode );
	    }
		/**
		 *  the below will work only for a string.. need to change ring to accept types
		 */
		for (int i = 0; i < vnodeCount; i++) {
	        ring.put(hash.hash(pNode.toString() + i), pNode + i);
	    }
	}

	    public void removeNode(Integer pNode, int vnodeCount) {
	    	 if(vNodeCount == 0){
		    	 ring.put(hash.hash(pNode.toString() ), pNode );
		    }
	      for (int i = 0; i < vnodeCount; i++) {
	        ring.remove(hash.hash(pNode.toString() + i));
	      }
	    }

	public synchronized Integer getNodeByObjectId(Object objectId) {

	    return hash.hash(objectId.toString(),count);

	   /* if (!ring.containsKey(hashValue)) {
	        SortedMap<Long, Integer> tailMap = ring.tailMap(hashValue);
	        hashValue = tailMap.isEmpty() ? ring.firstKey() : tailMap.firstKey();
	    }

	    return ring.get(hashValue);*/
	    
	  
	}

	
	private static class FarmHash{
		LongHashFunction func;
		
		public FarmHash(){
			func =LongHashFunction.xx_r39();
		}
		
		long hash(String key){
			return func.hashChars(key);
		}
	}
	
	
	
	private static class MD5Hash {
	    MessageDigest instance;

	    public MD5Hash() {
	        try {
	            instance = MessageDigest.getInstance("MD5");
	        } catch (NoSuchAlgorithmException e) {
	        }
	    }

	     long hash(String key){
	    	 instance.reset();
		        
		        instance.update(key.getBytes());
		        byte[] digest = instance.digest();

		        return new BigInteger(digest).longValue();
	    	 
	     }
	    int hash(String key,BigInteger c) {
	        instance.reset();
	        
	        instance.update(key.getBytes());
	        byte[] digest = instance.digest();

	        return new BigInteger(digest).mod(c).intValue();
	        
	    }
	}
	
	
	public static void main(String[] args){
		//ArrayList<String> testNodes = new ArrayList<String>();
		//testNodes.add("A");
		//testNodes.add("B");
		//testNodes.add("C");
		
		/*Ring ring = new Ring(2, testNodes);
		System.out.println("Node for MOID581a92d0ca4e2587419d7ab99798555e " + ring.getNodeByObjectId("MOID581a92d0ca4e2587419d7ab99798555e"));
		System.out.println( " Node for 1 "+ ring.getNodeByObjectId(1));
		System.out.println( " Node for 105 "+ ring.getNodeByObjectId(105));
		System.out.println( " Node for 5 "+ ring.getNodeByObjectId(5));
		System.out.println( " Node for 6 "+ ring.getNodeByObjectId(6));
		System.out.println( " Node for 110 "+ ring.getNodeByObjectId(10));
		System.out.println( " Node for 1234566666 "+ ring.getNodeByObjectId("1234566666"));
		System.out.println( " Node for 44343434343 "+ ring.getNodeByObjectId("44343434343"));*/
		
		ArrayList<Integer> testNodes = new ArrayList<Integer>();
		for(int i =0; i < 256; i ++){
			testNodes.add(i);
		}
		Ring ring = new Ring(0, testNodes);
		System.out.println(" size of MOID581a92d0ca4e2587419d7ab99798555e " + "MOID581a92d0ca4e2587419d7ab99798555e".getBytes().length);
		System.out.println("Node for MOID581a92d0ca4e2587419d7ab99798555e " + ring.getNodeByObjectId("MOID581a92d0ca4e2587419d7ab99798555e"));
		System.out.println( " Node for 1 "+ ring.getNodeByObjectId(1));
		System.out.println( " Node for 105 "+ ring.getNodeByObjectId(105));
		System.out.println( " Node for 5 "+ ring.getNodeByObjectId(5));
		System.out.println( " Node for 6 "+ ring.getNodeByObjectId(6));
		System.out.println( " Node for 110 "+ ring.getNodeByObjectId(10));
		System.out.println( " Node for 1234566666 "+ ring.getNodeByObjectId("1234566666"));
		System.out.println( " Node for 44343434343 "+ ring.getNodeByObjectId("44343434343"));
		System.out.println( " Node for 1000069927 "+ring.getNodeByObjectId("1000069927"));
	}
}

