package com.king.rbea;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Enumeration;

import com.king.rbea.hashlookup.Cdb;
import com.king.rbea.hashlookup.CdbElement;
import com.king.rbea.hashlookup.CdbMake;

public class TestCdbMerge {

	
	private static final String tempFilePath = "/tmp/cdbmerge";
	
	public static void main(String[] args) throws IOException{
		
		for(int i=0 ; i<2; i ++ ){
			CdbMake cdb = new CdbMake();
			cdb.start(tempFilePath+"-"+i);
			
			if(i==1){
				cdb.add("B".getBytes(), (""+i*5).getBytes());
				cdb.add("C".getBytes(), (""+i*5).getBytes());
				cdb.add("D".getBytes(), (""+i*5).getBytes());
			}
			if(i==0){
				cdb.add("A".getBytes(), (""+i*5).getBytes());
				cdb.add("C".getBytes(), (""+i*5).getBytes());
				cdb.add("E".getBytes(), (""+i*5).getBytes());
			}
			cdb.finish();
		}
	
		
		Enumeration e1 =Cdb.elements(tempFilePath + "-"+0);
		Enumeration e2 = Cdb.elements(tempFilePath + "-"+1);
		
		CdbMake merged = new CdbMake();
		merged.start(tempFilePath+"-"+3);
		CdbElement el2= null;
		while(e1.hasMoreElements()){
			CdbElement el1 =(CdbElement) e1.nextElement();
			if(el2 == null && e2.hasMoreElements()){
				el2 =(CdbElement) e2.nextElement();
			}
			if(el2 == null){
				merged.add(el1.getKey(), el1.getData());
			}else{
			int res =ByteBuffer.wrap(el1.getKey()).compareTo((ByteBuffer.wrap(el2.getKey())));
			if( res == 0){
				merged.add(el1.getKey(), el2.getData());
				if(e2.hasMoreElements())
					el2 =(CdbElement) e2.nextElement();
				else
					el2 = null;
				
			}else{
				
				if(res > 0){
					do
					{
					merged.add(el2.getKey(), el2.getData());
					if(e2.hasMoreElements())
						el2 =(CdbElement) e2.nextElement();
					else
						el2 = null;	
					if(el2!=null)
						res =ByteBuffer.wrap(el1.getKey()).compareTo((ByteBuffer.wrap(el2.getKey())));
					else
						res = -1;
					}while( el2!= null && res > 0);
				}
					if(res == 0){
						merged.add(el1.getKey(), el2.getData());
						if(e2.hasMoreElements())
							el2 =(CdbElement) e2.nextElement();
						else
							el2 = null;	
					}
					else	
					merged.add(el1.getKey(), el1.getData());
			}
		}
		}
		if(el2 != null)
		merged.add(el2.getKey(),el2.getData());
		while(e2.hasMoreElements()){
			el2 = (CdbElement)e2.nextElement();
			merged.add(el2.getKey(), el2.getData());
		}
		merged.finish();
		
		Cdb constant1 = new Cdb(tempFilePath + "-"+3);
		System.out.println(new String(constant1.find("A".getBytes())));
		
		Enumeration e3 =constant1.elements(tempFilePath + "-"+3);
		
		while(e3.hasMoreElements()){
			CdbElement el= (CdbElement)e3.nextElement();
			System.out.println(new String(el.getKey())  + " :: " + new String(el.getData()));
		}
	}
	
}
