package com.king.rbea;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import com.king.rbea.hashlookup.CdbMake;
import com.king.rbea.hashlookup.ThreadSafeCdb;
import com.king.rbea.utils.NanoBench;

public class TestCdb {

	private static final String tempFilePath = "/tmp/cdb";
	 private final static int READS = 100;
	
	 
	 
	 public static Long[] generateRandomIntKeys(int count, int range, long seed) {
		    Random random = new Random(seed);
		    Set<Long> set = new HashSet<Long>(count);
		    while (set.size() < count) {
		      set.add(random.nextLong());
		    }
		    return set.toArray(new Long[0]);
		  }
	 
	 private static byte[] compress(long value) throws IOException {
			ByteBuffer buff = ByteBuffer.allocate(Long.BYTES * 8);
			 int i = 1;
			    while ((value & ~0x7FL) != 0) {
			      buff.putInt((((int) value & 0x7F) | 0x80));
			      value >>>= 7;
			      i++;
			    }
			    buff.put((byte) value);
			    buff.flip();
			    byte[] lArray = new byte[i];
			     buff.get(lArray, 0, i);
			     return lArray;
		    }
	 
	 
	public static void main(String[] args){
		try {
			CdbMake cdbMake = new CdbMake();

			/* Create the CDB file. */
			cdbMake.start(tempFilePath);
			for(int i = 0; i< READS ; i ++){
				//cdbMake.add( (""+1000+i).getBytes(), (""+10000000000l+i).getBytes());
				cdbMake.add(compress(1000l),(""+10000000000l+i).getBytes());
			}
			cdbMake.finish();
			
			
			
			final Long[] keys =generateRandomIntKeys(READS, READS, 1000);
			final boolean frequentReads = true;
			/* Create the CDB object. */
			final  ThreadSafeCdb cdb = new ThreadSafeCdb(tempFilePath);
			System.out.println(" start " + System.nanoTime());
			 NanoBench nanoBench = NanoBench.create();
			nanoBench.cpuOnly().warmUps(1).measurements(2)
	          .measure("Measure %d reads for %d keys with cache", new Runnable() {
	            @Override
	            public void run() {
	            	int  corePoolSize  =    5;
	            	int  maxPoolSize   =   10;
	            	long keepAliveTime = 5000;
	            	ExecutorService threadPoolExecutor =
	            	        new ThreadPoolExecutor(
	            	                corePoolSize,
	            	                maxPoolSize,
	            	                keepAliveTime,
	            	                TimeUnit.MILLISECONDS,
	            	                new LinkedBlockingQueue<Runnable>()
	            	                );
	             Runnable tget = new Runnable(){
	            	 @Override
	            	    public void run() 
	            	    {
	            	        try
	            	        {
	            	        	Random r = new Random();
	          	              int length = keys.length;
	          	              for (int i = 0; i < READS/5; i++) {
	          	                int index;
	          	                if (i % 2 == 0 && frequentReads) {
	          	                  index = r.nextInt(length / 10);
	          	                } else {
	          	                  index = r.nextInt(length);
	          	                }
	          	                Long key = keys[index];
	          	                try {
	          	                	//byte[] bKey = key.toString().getBytes();
	          	                	byte[] bKey =compress(key);
	          	                	byte[] v =cdb.find(bKey);
	          	                	
	          	                	System.out.println( key + " " + v);
	          	                } catch (Exception e) {

	          	                }
	          	              }
	            	        } 
	            	        catch (Exception e) 
	            	        {
	            	            e.printStackTrace();
	            	        }
	            	    }
	             };
	             for(int i =0;i<5;i ++)
	              threadPoolExecutor.execute(tget);
	            }
	          });
			System.out.println(" end: " + System.nanoTime());
			System.out.println("Tps:: " + READS* nanoBench.getTps());
			
			
			
		/*	Enumeration<CdbElement> e =Cdb.elements(tempFilePath);
			int count =0;
			while(e.hasMoreElements()){
				//System.out.println(new String(e.nextElement().getKey()));
				e.nextElement();
				count ++;
			}
			System.out.println(count);*/
		} catch (IOException ioException) {
			System.out.println("Couldn't create CDB file: "
				+ ioException);
		}
	}
}
