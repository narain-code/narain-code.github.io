
package com.king.rbea;

import java.io.IOException;
import java.util.Enumeration;

import com.king.rbea.hashlookup.Cdb;
import com.king.rbea.hashlookup.CdbElement;

public class TestRatkoCdb {
	
	private static final String filepath = "/tmp/2-cdb";
	
	public static void main(String[] args){
		
		try {
		 Enumeration<CdbElement> e=	Cdb.elements(filepath);
		 int counter = 0;
		 while(e.hasMoreElements()){
			CdbElement elem = e.nextElement();
			
			//if(!new String(elem.getData()).contains("0|")){
			if(new String(elem.getKey()).contains("{\"texts\": [\"12059\"], \"images\": [\"91051\"]}")){
			//	System.out.println( "" + counter + " " +new String(elem.getKey()) + " " + new String(elem.getData()));
				String strData =new String(elem.getData());
				if(! "".equalsIgnoreCase(strData))
				System.out.println( "" + strData);
				counter ++;
			}
			
		 }
		System.out.println(counter);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
