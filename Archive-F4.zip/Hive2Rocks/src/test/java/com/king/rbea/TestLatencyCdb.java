package com.king.rbea;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

import org.HdrHistogram.Histogram;

import com.king.rbea.hashlookup.Cdb;
import com.king.rbea.metrics.LatencyStats;

public class TestLatencyCdb {
	private static final String tempFilePath = "/tmp/cdb";
	 private final static int READS = 5000;
	
	 
	 public static Long[] generateRandomIntKeys(int count, int range, long seed) {
		    Random random = new Random(seed);
		    Set<Long> set = new HashSet<Long>(count);
		    while (set.size() < count) {
		     // set.add(random.nextLong());
		    	set.add(Long.parseLong(""+1000+set.size()));
		    }
		    return set.toArray(new Long[0]);
		  }
	 
	public static void main(String[] args) throws IOException{
		boolean frequentReads = true;
		final  Cdb cdb = new Cdb(tempFilePath);
		final Long[] keys =generateRandomIntKeys(READS, READS, 0);
		
		 
		for(int i = 0 ; i < 5 ; i ++ ){ 
			LatencyStats myOpStats = new LatencyStats();
		 // Perform operation:
		 Random r = new Random();
         int length = keys.length;
         for (int j = 0; j < READS; j++) {
           int index;
           if (i % 2 == 0 && frequentReads) {
             index = r.nextInt(length / 10);
           } else {
             index = r.nextInt(length);
           }
           Long key = keys[index];
           try {
        	   long startTime = System.nanoTime();   
           	byte[] bKey = key.toString().getBytes();
           	cdb.find(bKey);
            // Record operation latency:
   		 myOpStats.recordLatency(System.nanoTime() - startTime);
             
           } catch (Exception e) {

           }
         }
		
		 

		 // Later, report on stats collected:
		 Histogram intervalHistogram = myOpStats.getIntervalHistogram();
		//myOpStats.getLatestUncorrectedIntervalHistogram().outputPercentileDistribution(System.out, 1000000.0);
		 DecimalFormat d = new DecimalFormat("#.##");
		 System.out.println(" totalTime: Count=" + intervalHistogram.getTotalCount() + 
                ", Max=" + intervalHistogram.getMaxValue() + 
                ", Min=" + intervalHistogram.getMinValue() +
                ", Avg=" + d.format(intervalHistogram.getMean()) );
		 
		/* intervalHistogram = cdb.hashCdb.getIntervalHistogram();
			System.out.println(" hashTime: Count=" + intervalHistogram.getTotalCount() + 
	                ", Max=" + intervalHistogram.getMaxValue() + 
	                ", Min=" + intervalHistogram.getMinValue() +
	                ", Avg=" + d.format(intervalHistogram.getMean()) );
			
			 intervalHistogram = cdb.findSlot.getIntervalHistogram();
				System.out.println(" findslot: Count=" + intervalHistogram.getTotalCount() + 
		                ", Max=" + intervalHistogram.getMaxValue() + 
		                ", Min=" + intervalHistogram.getMinValue() +
		                ", Avg=" + d.format(intervalHistogram.getMean()) );
				
				 intervalHistogram = cdb.seek1.getIntervalHistogram();
					System.out.println(" seek1: Count=" + intervalHistogram.getTotalCount() + 
			                ", Max=" + intervalHistogram.getMaxValue() + 
			                ", Min=" + intervalHistogram.getMinValue() +
			                ", Avg=" + d.format(intervalHistogram.getMean()) );
					 intervalHistogram = cdb.seek2.getIntervalHistogram();
						System.out.println(" seek2: Count=" + intervalHistogram.getTotalCount() + 
				                ", Max=" + intervalHistogram.getMaxValue() + 
				                ", Min=" + intervalHistogram.getMinValue() +
				                ", Avg=" + d.format(intervalHistogram.getMean()) );
						
			intervalHistogram = cdb.findNext.getIntervalHistogram();
				System.out.println(" findNext: Count=" + intervalHistogram.getTotalCount() + 
		                ", Max=" + intervalHistogram.getMaxValue() + 
		                ", Min=" + intervalHistogram.getMinValue() +
		                ", Avg=" + d.format(intervalHistogram.getMean()) ); */
				
			}
		
		
		
		}
		
	}


