package com.king.rbea;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

import com.google.common.base.Charsets;

public class TestRkeyValue {
	
	public static byte[] writeStringWithLength(int column,String value){
		//System.out.println("column " + column + " value " + value);
		byte[] vlBytes =value.getBytes(Charsets.UTF_8);
		int l =value.length();
		ByteBuffer buf = ByteBuffer.allocate(vlBytes.length+2*(Integer.SIZE/Byte.SIZE));
		buf.putInt(column);
		buf.putInt(l);
		buf.put(vlBytes);
		buf.flip();
		return buf.array();
	}
	
	public static byte[] writeNullColumn(int column){
		ByteBuffer buf = ByteBuffer.allocate(2*(Integer.SIZE/Byte.SIZE));
		buf.putInt(column);
		buf.putInt(0);
		buf.flip();
		return buf.array();
	}
	
	public static void main(String[] args){
		System.out.println("EN".getBytes().length  + " :: " + Integer.BYTES);
		
		List dataStruct = new ArrayList<String>();
		
			dataStruct.add("0");
			dataStruct.add("31");
			dataStruct.add("1");
			dataStruct.add("1");
			dataStruct.add("1");
			dataStruct.add("0");
			dataStruct.add("1");
			dataStruct.add("0");
			dataStruct.add("FR");
		 List<byte[]> values = new ArrayList<byte[]>();
	        int totalLength = 0;
	        for(int i=1;i<=8;i++){
	        	if(dataStruct.get(i) != null){
	        	byte[] vlBytes =writeStringWithLength(i, dataStruct.get(i).toString());
	        	totalLength += vlBytes.length;
	        	values.add(vlBytes);
	        	}
	        	else{
	        		byte[] vlBytes =writeNullColumn(i);
	        		totalLength += vlBytes.length;
		        	values.add(vlBytes);
	        	}
	        }
	        System.out.println("totallength " +totalLength);
	        
	        ByteBuffer buf = ByteBuffer.allocate(totalLength);
	        for(byte[] b: values){
	         buf.put(b);
	         
	        } 
	        
	        byte[] ar = buf.array();
	        
	     //   System.out.println(ar.length);
	        
	         ByteBuffer newBuf = ByteBuffer.wrap(ar);
	         int column =newBuf.getInt();
	         int length;
	         while(column != -1){
	        	 System.out.println("column " +column);
	        	 length =newBuf.getInt();
	        	 byte[] dst = new byte[length];
	        	 newBuf.get(dst);
	        	 System.out.println(new String(dst));
	        	 if(newBuf.hasRemaining())
	        		 column = newBuf.getInt();
	        	 else
	        		 column = -1;
	         }
		
	}

}
