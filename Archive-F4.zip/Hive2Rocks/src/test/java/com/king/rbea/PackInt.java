package com.king.rbea;

import java.io.IOException;
import java.nio.ByteBuffer;

import com.king.rbea.hashlookup.Cdb;
import com.king.rbea.hashlookup.CdbMake;

public class PackInt {
	
	
	private static final String tempFilePath = "/tmp/cdb-packInt";
	
	
	 private static byte[] compressInt(int value) {
			
		 ByteBuffer buff = ByteBuffer.allocate(Integer.BYTES * 8);
		 int i = 1;
		    while ((value & ~0x7F) != 0) {
		     buff.put((byte)((value & 0x7F) | 0x80));
		      value >>>= 7;
		      i++;
		    }

		    buff.put((byte) value);
		    buff.flip();
		    System.out.println(i);
		    
		    
		    byte[] lArray = new byte[i];
		     buff.get(lArray, 0, i);
		     return lArray;

	 }
	 
	 
	 private static int unCompressInt(ByteBuffer buf ){
		 for (int offset = 0, result = 0; offset < 32; offset += 7) {
		      int b = buf.get() ;
		      result |= (b & 0x7F) << offset;
		      if ((b & 0x80) == 0) {
		    	  System.out.println(offset);
		        return result;
		      }
		    }
		 return 0;
	 }
	 
	 
	 public static void main(String[] args) throws IOException{
		byte[] compressInt =compressInt(31);
		//System.out.println(compressInt.length);
		//System.out.println();
		//System.out.println(new String(compressInt));
		
			CdbMake cdbMake = new CdbMake();

			/* Create the CDB file. */
			cdbMake.start(tempFilePath);
			cdbMake.add(compressInt, compressInt);
			cdbMake.add(compressInt,compressInt(28));
			cdbMake.add(compressInt,compressInt(51));
			cdbMake.add(compressInt,compressInt(82));
			cdbMake.add(compressInt,compressInt(1));
			cdbMake.add(compressInt,compressInt(82));
			cdbMake.finish();
			Cdb cdb = new Cdb(tempFilePath);
			byte[] v =cdb.find(compressInt);
		ByteBuffer buf = ByteBuffer.wrap(v);
		 System.out.println(unCompressInt(buf));
		 
		 
	 }

}
