package com.king.rbea;

import java.io.IOException;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

import org.rocksdb.BlockBasedTableConfig;
import org.rocksdb.ColumnFamilyOptions;
import org.rocksdb.CompactionStyle;
import org.rocksdb.CompressionType;
import org.rocksdb.Options;
import org.rocksdb.RocksDB;
import org.rocksdb.VectorMemTableConfig;

import com.king.rbea.hashlookup.Cdb;
import com.king.rbea.hashlookup.CdbElement;
import com.king.rbea.hashlookup.CdbMake;
import com.king.rbea.utils.NanoBench;

public class TestLatencyRocks {
	private static final String tempFilePath = "/tmp/rocks";
	 private final static int READS = 1000000;
	 
	 
	 public static Long[] generateRandomIntKeys(int count, int range, long seed) {
		    Random random = new Random(seed);
		    Set<Long> set = new HashSet<Long>(count);
		    while (set.size() < count) {
		      set.add(random.nextLong());
		    }
		    return set.toArray(new Long[0]);
		  }
	 
	 
	public static void main(String[] args){
		try {
			RocksDB db ;
			Options opt = new Options().setCreateIfMissing(true).setCreateMissingColumnFamilies(true)
					.setCompressionType(CompressionType.NO_COMPRESSION)
					.optimizeForPointLookup(256)
					;
			BlockBasedTableConfig blockConfig =new BlockBasedTableConfig();
			 /*
			  * 256 MB
			  */
			 blockConfig.setBlockSize(256*1024);
			 blockConfig.setCacheIndexAndFilterBlocks(true);
			// opt.setMemTableConfig(new VectorMemTableConfig().setReservedSize(writeBatchSize));
			 ColumnFamilyOptions cfOptions = new ColumnFamilyOptions();
		     cfOptions.setCompactionStyle(CompactionStyle.LEVEL);
		     cfOptions.setTableFormatConfig(blockConfig);
		     db = RocksDB.open(opt,tempFilePath);
			/* Create the CDB file. */
			
			for(int i = 0; i< READS ; i ++){
				db.put( (""+1000+i).getBytes(), (""+10000000000l+i).getBytes());
			}
			db.close();
			
			final Long[] keys =generateRandomIntKeys(READS, READS, 1000);
			final boolean frequentReads = true;
			final RocksDB rdb = RocksDB.open(opt,tempFilePath);
			System.out.println(" start " + System.nanoTime());
			 NanoBench nanoBench = NanoBench.create();
			nanoBench.cpuOnly().warmUps(1).measurements(2)
	          .measure("Measure %d reads for %d keys with cache", new Runnable() {
	            @Override
	            public void run() {
	              Random r = new Random();
	              int length = keys.length;
	              for (int i = 0; i < READS; i++) {
	                int index;
	                if (i % 2 == 0 && frequentReads) {
	                  index = r.nextInt(length / 10);
	                } else {
	                  index = r.nextInt(length);
	                }
	                Long key = keys[index];
	                try {
	                	byte[] bKey = key.toString().getBytes();
	                	rdb.get(bKey);
	                	
	                  
	                } catch (Exception e) {

	                }
	              }
	            }
	          });
			System.out.println(" end: " + System.nanoTime());
			System.out.println("Tps:: " +READS * nanoBench.getTps());
			
			
			
			
			
		} catch (Exception ioException) {
			System.out.println("Couldn't create CDB file: "
				+ ioException);
		}
	}
}



