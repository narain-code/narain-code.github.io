package com.king.rbea;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;

import com.king.rbea.hashlookup.Cdb;
import com.king.rbea.hashlookup.CdbMake;
import com.king.rbea.hashlookup.ThreadSafeCdb;

public class TestCdbMake {
	
	 private static byte[] compress(long value) throws IOException {
			ByteBuffer buff = ByteBuffer.allocate(Long.BYTES * 8);
			 int i = 1;
			    while ((value & ~0x7FL) != 0) {
			      buff.putInt((((int) value & 0x7F) | 0x80));
			      value >>>= 7;
			      i++;
			    }
			    buff.put((byte) value);
			    buff.flip();
			    byte[] lArray = new byte[i];
			     buff.get(lArray, 0, i);
			     return lArray;
		    }
	
	private static final String tempFilePath = "/tmp/cdbdebug";
	public static void main(String[] args){
		CdbMake cdbMake = new CdbMake();

		/* Create the CDB file. */
		try {
			cdbMake.start(tempFilePath);
			for(Integer i =0;i<100;i++)
			//cdbMake.add(i.toString().getBytes(),i.toString().getBytes());
			cdbMake.add(compress(1000069927 + i), ("data" + i).getBytes());
			cdbMake.finish();
			ThreadSafeCdb cbd = new ThreadSafeCdb(tempFilePath);
			Integer f = 1;
			for(Integer i =0;i<100;i++)
			System.out.println(new String(cbd.find(compress(1000069927 + i))));
			/* FileChannel ch = new RandomAccessFile(tempFilePath,"r").getChannel();
			 MappedByteBuffer buffer = ch.map(FileChannel.MapMode.READ_ONLY, 4260, 100).load();
			// buffer.position(0);
			 System.out.println(buffer.isLoaded());
			byte[] bulk = new byte[8];
			buffer.get(bulk);
			 int h = (bulk[0] & 0xff)
						| ((bulk[1] & 0xff) <<  8)
						| ((bulk[2] & 0xff) << 16)
						| ((bulk[3] & 0xff)<< 24);
			 
			 int pos = (bulk[4] & 0xff)
						| ((bulk[5] & 0xff) <<  8)
						| ((bulk[6] & 0xff) << 16)
						| ((bulk[7] & 0xff)<< 24);
			 System.out.println(h + " " + pos); */
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
