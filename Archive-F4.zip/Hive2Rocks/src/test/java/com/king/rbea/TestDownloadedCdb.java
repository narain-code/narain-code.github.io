package com.king.rbea;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Enumeration;

import com.king.rbea.hashlookup.Cdb;
import com.king.rbea.hashlookup.CdbElement;
import com.king.rbea.hashlookup.ThreadSafeCdb;

public class TestDownloadedCdb {
	
	private static byte[] compress(long value) throws IOException {
		ByteBuffer buff = ByteBuffer.allocate(Long.BYTES * 8);
		 int i = 1;
		    while ((value & ~0x7FL) != 0) {
		      buff.putInt((((int) value & 0x7F) | 0x80));
		      value >>>= 7;
		      i++;
		    }
		   
		    buff.put((byte) value);
		    buff.flip();
		    
		    byte[] lArray = new byte[i];
		     buff.get(lArray, 0, i);
		     return lArray;
	    }
	
	
	 private static int unCompressInt(ByteBuffer buf ){
		 for (int offset = 0, result = 0; offset < 32; offset += 7) {
		      int b = (buf.get() & 0xffff);
		      result |= (b & 0x7F) << offset;
		    //  System.out.println("offset "+offset);
		      if ((b & 0x80) == 0) {
		    	  
		    	//  System.out.println("result "+result);
		        return result;
		      }
		    }
		 return 0;
	 }
	 
	 private static String unCompressString(ByteBuffer newBuf){
		// System.out.println("before p "+newBuf.position());
		int length = unCompressInt(newBuf);
		 //System.out.println("after p "+newBuf.position());
		char[] ar = new char[length];
		for(int i=0;i<length;i++){
			// System.out.println("before q "+newBuf.position());
			//System.out.println(unCompressInt(newBuf));
			ar[i]=(char)unCompressInt(newBuf);
		}	
		System.out.println(new String(ar));
		return new String(ar);
	 }
	
	public static void main(String[] args) throws IOException, InterruptedException{
	//	Cdb table = new Cdb("/tmp/96-cdb");
		ThreadSafeCdb table = new ThreadSafeCdb("/tmp/96-cdb");
		
		
		byte[] val =table.find("1000069927".getBytes());
		if(val == null){
			System.out.println("nll");
		/*	Enumeration en =table.elements("/tmp/96-cdb");
			while(en.hasMoreElements()){
				System.out.println(new String(((CdbElement)en.nextElement()).getKey()));
			}*/
			return;
		}
		ByteBuffer newBuf = ByteBuffer.wrap(val);
		
		//int b = newBuf.get() & 0xffff;
		//int r  = 0| (b & 0x7F) << 0;
		//System.out.println( r);
		
       for(int i =0 ; i < 8 ; i ++ ){
        	if( i < 7)
		
        	System.out.println( unCompressInt(newBuf));
        }
       
       unCompressString(newBuf);
       Thread.sleep(10000);
	}

}
