package com.king.rbea;

public class TestLatencyStatsRocks {

}
