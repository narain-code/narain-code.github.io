for i in {0..255}
do
 mkdir /fjord/sites/cdb/$i
done
