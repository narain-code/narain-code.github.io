package com.king.splat.flink.metrics.serializer;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.StringJoiner;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MetricKey {

	private static final String SEP = "\\.";
	private static final String DASH = "-";
	private static final String ONLYCHARS = "[^a-zA-Z0-9_-]";

	public String host = "unknown";
	public String metricName = "blank";
	public String operator = null;
	public String jobName = null;
	public String subtaskIndex = null;
	public String tmId = null;

	/**
	 * Key from flink which follows the below convention
	 * 
	 * we will parse the hostname out of these and set it as a tag in opentsdb..
	 * 
	 * <host>.jobmanager <host>.jobmanager.<job_name>
	 * 
	 * <host>.taskmanager.<tm_id> <host>.taskmanager.<tm_id>.<job_name>
	 * <host>.taskmanager.<tm_id>.<job_name>.<task_name>.<subtask_index>
	 * <host>.taskmanager.<tm_id>.<job_name>.<operator_name>.<subtask_index>
	 * 
	 */
	private MetricKey(String[] parts) {
		StringJoiner joiner = new StringJoiner(DASH);
		int size = parts.length;

		host = parts[0];
		boolean JVMMetric = false;
		if (size > 2) {
			metricName = parts[1] + DASH + parts[(size - 1)];
			Set<String> set = new HashSet<String>(Arrays.asList(parts));
			if (set.contains("JVM")) {
				JVMMetric = true;
				if (set.contains("PS_MarkSweep")) {
					metricName = parts[1] + DASH + "JVM" + DASH + "GC" + DASH + "MarkSweep" + DASH + parts[(size - 1)];
				} else if (set.contains("PS_Scavenge")) {
					metricName = parts[1] + DASH + "JVM" + DASH + "GC" + DASH + "Scavenge" + DASH + parts[(size - 1)];
				} else {
					metricName = parts[1] + DASH + "JVM" + DASH + parts[(size - 1)];
				}

				tmId = parts[2];
			}

		}

		boolean taskMetric = parts[1].equals("taskmanager") && size > 4 && !JVMMetric;
		boolean jobMetric = parts[1].equals("jobmanager") && size > 3;
		boolean opMetric = taskMetric && size > 6;

		if (jobMetric) {
			jobName = parts[2];
		}

		if (taskMetric) {
			tmId = parts[2];
			jobName = parts[3];
			if (opMetric) {
				subtaskIndex = parts[size - 2];

				// Integer.parseInt(subtaskIndex);
				for (int i = 4; i < (size - 2); i++) {
					joiner.add(parts[i].replaceAll(ONLYCHARS, ""));
				}
				operator = joiner.toString();
			}
		}

	}

	private static final Logger LOG = LoggerFactory.getLogger(MetricKey.class);

	public static MetricKey parse(String key) {
		LOG.trace("Received metric key: {}", key);

		if (key.contains("Source:")) {
			String[] split = key.split("Source:");
			if (split.length != 2) {
				return null;
			}
			key = split[0] +
					split[1]
							.replaceFirst(SEP, "#")
							.replaceFirst(SEP, "#")
							.replaceAll(SEP, DASH)
							.replaceAll("#", ".");
		}

		String[] parts = key.replaceAll("\\s", "_").replace("-offsets.", "-offsets-").split(SEP);

		if (parts.length == 0) {
			return null;
		}

		try {
			return new MetricKey(parts);
		} catch (Throwable e) {
			return null;
		}
	}

	@Override
	public String toString() {
		return "MetricKey [host=" + host + ", mkey=" + metricName + ", operator=" + operator + ", jobName=" + jobName
				+ ", subtaskIndex=" + subtaskIndex + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((host == null) ? 0 : host.hashCode());
		result = prime * result + ((jobName == null) ? 0 : jobName.hashCode());
		result = prime * result + ((metricName == null) ? 0 : metricName.hashCode());
		result = prime * result + ((operator == null) ? 0 : operator.hashCode());
		result = prime * result + ((subtaskIndex == null) ? 0 : subtaskIndex.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MetricKey other = (MetricKey) obj;
		if (host == null) {
			if (other.host != null)
				return false;
		} else if (!host.equals(other.host))
			return false;
		if (jobName == null) {
			if (other.jobName != null)
				return false;
		} else if (!jobName.equals(other.jobName))
			return false;
		if (metricName == null) {
			if (other.metricName != null)
				return false;
		} else if (!metricName.equals(other.metricName))
			return false;
		if (operator == null) {
			if (other.operator != null)
				return false;
		} else if (!operator.equals(other.operator))
			return false;
		if (subtaskIndex == null) {
			if (other.subtaskIndex != null)
				return false;
		} else if (!subtaskIndex.equals(other.subtaskIndex))
			return false;
		return true;
	}
}