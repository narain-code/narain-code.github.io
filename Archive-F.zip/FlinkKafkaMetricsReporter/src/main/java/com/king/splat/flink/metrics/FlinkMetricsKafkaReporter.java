package com.king.splat.flink.metrics;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.flink.dropwizard.ScheduledDropwizardReporter;
import org.apache.flink.metrics.MetricConfig;
import org.apache.kafka.clients.producer.KafkaProducer;

import com.codahale.metrics.ScheduledReporter;
import com.king.splat.flink.metrics.serializer.MeterLoggerSerializer;

public class FlinkMetricsKafkaReporter extends ScheduledDropwizardReporter {

	private static final String brokerList = "kafka10.sto.midasplayer.com:9092";
	public final static String DEFAULT_TOPIC = "testflinkmetrics";
	private static final String BROKER = "broker";
	private static final String TOPIC = "topic";
	private static final String ENV = "env";

	@Override
	public ScheduledReporter getReporter(MetricConfig config) {

		Map<String, String> cMap = new HashMap<String, String>();

		cMap.put("producer.type", "sync");
		cMap.put("compression.codec", Integer.toString(1));
		cMap.put("request.required.acks", Integer.toString(1));

		Map<String, String> kafkaConfigMap = Collections.unmodifiableMap(cMap);

		String brokers = config.getString(BROKER, brokerList);
		String topic = config.getString(TOPIC, DEFAULT_TOPIC);
		Properties props = new Properties();
		props.putAll(kafkaConfigMap);
		//this is now changed in kafka 10
		//props.setProperty("metadata.broker.list", brokers);
		props.setProperty("bootstrap.servers", brokers);
		 props.put("key.serializer", "org.apache.kafka.common.serialization.ByteArraySerializer");
		 props.put("value.serializer", "org.apache.kafka.common.serialization.ByteArraySerializer");
		
		String conversionRate = config.getString(ARG_CONVERSION_RATE, null);
		String conversionDuration = config.getString(ARG_CONVERSION_DURATION, null);
		com.king.splat.flink.metrics.KafkaReporter.Builder builder = KafkaReporter.forRegistry(registry);

		if (conversionRate != null) {
			builder.convertRatesTo(TimeUnit.valueOf(conversionRate));
		}

		if (conversionDuration != null) {
			builder.convertDurationsTo(TimeUnit.valueOf(conversionDuration));
		}

		String environment = config.getProperty(ENV);
		if (environment == null) {
			throw new RuntimeException("Cannot find " + ENV + " metric config parameter.");
		}

		builder.topic(topic).serializer(new MeterLoggerSerializer(environment));
		return builder.build(new KafkaProducer<>(props));
	}

}
