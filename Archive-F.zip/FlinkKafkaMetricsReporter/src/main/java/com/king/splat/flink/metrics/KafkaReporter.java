package com.king.splat.flink.metrics;

import java.util.Date;
import java.util.List;
import java.util.SortedMap;
import java.util.concurrent.TimeUnit;

import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;

import com.codahale.metrics.Counter;
import com.codahale.metrics.Gauge;
import com.codahale.metrics.Histogram;
import com.codahale.metrics.Meter;
import com.codahale.metrics.MetricFilter;
import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.ScheduledReporter;
import com.codahale.metrics.Timer;
import com.king.splat.flink.metrics.serializer.KafkaMetricsSerializer;

public final class KafkaReporter extends ScheduledReporter {

	public static Builder forRegistry(MetricRegistry registry) {
		return new Builder(registry);
	}

	public static class Builder {
		private final MetricRegistry registry;

		private TimeUnit rateUnit;
		private TimeUnit durationUnit;
		private MetricFilter filter;

		private String topic;
		private KafkaMetricsSerializer serializer;

		private Builder(MetricRegistry registry) {
			this.registry = registry;
			this.rateUnit = TimeUnit.SECONDS;
			this.durationUnit = TimeUnit.MILLISECONDS;
			this.filter = MetricFilter.ALL;
		}

		public Builder convertRatesTo(TimeUnit rateUnit) {
			this.rateUnit = rateUnit;
			return this;
		}

		public Builder convertDurationsTo(TimeUnit durationUnit) {
			this.durationUnit = durationUnit;
			return this;
		}

		public Builder filter(MetricFilter filter) {
			this.filter = filter;
			return this;
		}

		public Builder topic(String topic) {
			this.topic = topic;
			return this;
		}

		public Builder serializer(KafkaMetricsSerializer serializer) {
			this.serializer = serializer;
			return this;
		}

		public KafkaReporter build(Producer<?, ?> producer) {
			return new KafkaReporter(registry,
					producer,
					topic,
					serializer,
					rateUnit,
					durationUnit,
					filter);
		}
	}

	private final String topic;
	private final Producer<?, ?> producer;
	private final KafkaMetricsSerializer serializer;

	public final TimeUnit metricRateUnit;
	public final TimeUnit metricDurationUnit;

	private KafkaReporter(MetricRegistry registry,
			Producer<?, ?> producer,
			String topic,
			KafkaMetricsSerializer serializer,
			TimeUnit rateUnit,
			TimeUnit durationUnit,
			MetricFilter filter) {
		super(registry, "kafka-reporter", filter, rateUnit, durationUnit);
		this.producer = producer;
		this.topic = topic;
		if(serializer == null) {
			throw new RuntimeException("KafkaMetricsSerializer must be defined");
		}
		this.serializer = serializer;
		this.metricRateUnit = rateUnit;
		this.metricDurationUnit = durationUnit;
	}

	@Override
	@SuppressWarnings("unchecked")
	public void report(SortedMap<String, Gauge> gauges,
			SortedMap<String, Counter> counters,
			SortedMap<String, Histogram> histograms,
			SortedMap<String, Meter> meters,
			SortedMap<String, Timer> timers) {
		final Date timestamp = java.util.Calendar.getInstance().getTime();
		final List<Tuple2> messages = serializer.serialize(gauges,
				counters,
				histograms,
				meters,
				timers,
				topic,
				timestamp,
				metricRateUnit,
				metricDurationUnit);

		for (Tuple2 message : messages) {
			producer.send(new ProducerRecord(topic, message.f0, message.f1));
		}
	}
}
