package com.king.splat.flink.metrics.serializer;

import java.util.Date;
import java.util.List;
import java.util.SortedMap;
import java.util.concurrent.TimeUnit;

import org.apache.flink.api.java.tuple.Tuple2;

import com.codahale.metrics.Counter;
import com.codahale.metrics.Gauge;
import com.codahale.metrics.Histogram;
import com.codahale.metrics.Meter;
import com.codahale.metrics.Timer;

public interface KafkaMetricsSerializer {

	public List<Tuple2> serialize(SortedMap<String, Gauge> gauges,
			SortedMap<String, Counter> counters,
			SortedMap<String, Histogram> histograms,
			SortedMap<String, Meter> meters,
			SortedMap<String, Timer> timers,
			String topic,
			Date timestamp,
			TimeUnit rateUnit,
			TimeUnit durationUnit)
			throws RuntimeException;
}
