package com.king.splat;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.zip.GZIPInputStream;

import kafka.javaapi.producer.Producer;
import kafka.producer.KeyedMessage;
import kafka.producer.ProducerConfig;

public class FilePublish2Kafka {
	public static final String REGEX = "\t";
	public static final int KAFKA_QUEUE_BYTES = 1000000;
	public static int parallel = 40;
	private static  Map<String, String> kafkaConfigMap;
	static {
	 kafkaConfigMap = new HashMap<String, String>();
	// producer configs
	 kafkaConfigMap.put("producer.type", "sync");
	 kafkaConfigMap.put("compression.codec", Integer.toString(1));
	 kafkaConfigMap.put("request.required.acks", Integer.toString(1));
	
	}
	
	
	
	
	
	public static Producer createProducer(Map config){
		Properties prop = new Properties();
		prop.putAll(config);
		return  new Producer<byte[], byte[]>(new ProducerConfig(prop));
	}
	
	public static void main(String[] args){
	 try{
		
		String fileName = args[0];
		String brokerList = args[1];
		String topic = args[2];
		
		kafkaConfigMap.put("metadata.broker.list", brokerList);
		
		File parentDir = new File(fileName);
		String parent ="";
		String[] allFiles = null;
		if( parentDir.isDirectory()){
			allFiles =parentDir.list();
			parent =parentDir.getAbsolutePath();
		}else{
			allFiles = new String[1];
			allFiles[0] = fileName;
		}
		ExecutorService service =null;
		if(allFiles.length > parallel){
			service =Executors.newFixedThreadPool(parallel);
		}else{
			service =Executors.newSingleThreadExecutor();
		}
		for(String file :allFiles){
			Producer producer = createProducer(kafkaConfigMap);
			 ThreadPublish2Kafka t = new ThreadPublish2Kafka(parent + "/" +file, producer, topic);
			
			 service.execute(t);
			 
		
		}
		
		service.shutdown();
	  if(service.awaitTermination(24, TimeUnit.HOURS)){
		  
	  }
	  
	 }catch(Exception ex){
		 ex.printStackTrace();
	 }
		
	}

	
	
	
}
