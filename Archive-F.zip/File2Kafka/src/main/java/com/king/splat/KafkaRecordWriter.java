package com.king.splat;

import java.io.IOException;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import kafka.javaapi.producer.Producer;
import kafka.producer.KeyedMessage;

import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.mapred.RecordWriter;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapred.TaskAttemptContext;






public class KafkaRecordWriter<K,V> implements RecordWriter<K,V>
{
  protected Producer<Object, byte[]> producer;
  protected String topic;

  protected List<KeyedMessage<Object, byte[]>> msgList = new LinkedList<KeyedMessage<Object, byte[]>>();
  protected int totalBytes = 0;
  protected int queueBytes;

  public KafkaRecordWriter(Producer<Object, byte[]> producer, String topic, int queueBytes)
  {
    this.producer = producer;
    this.topic = topic;
    this.queueBytes = queueBytes;
  }

  protected void sendMsgList() 
  {
    if (msgList.size() > 0) {
      try {
        producer.send(msgList);
      }
      catch (Exception e) {
        throw new RuntimeException(e);           // all Kafka exceptions become IOExceptions
      }
      msgList.clear();
      totalBytes = 0;
    }
  }


  public void write(K key, V value) 
  {
    byte[] valBytes;
    if (value instanceof byte[])
      valBytes = (byte[]) value;
    else if (value instanceof BytesWritable)
      // BytesWritable.getBytes returns its internal buffer, so .length would refer to its capacity, not the
      // intended size of the byte array contained.  We need to use BytesWritable.getLength for the true size.
      valBytes = Arrays.copyOf(((BytesWritable) value).getBytes(), ((BytesWritable) value).getLength());
    else
      throw new IllegalArgumentException("KafkaRecordWriter expects byte array value to publish");

    // MultiProducerRequest only supports sending up to Short.MAX_VALUE messages in one batch
    // If the new message is going to make the message list tip over 1 million bytes, send the
    // message list now.
    if ((totalBytes + valBytes.length) > queueBytes || msgList.size() >= Short.MAX_VALUE)
      sendMsgList();

    msgList.add(new KeyedMessage<Object, byte[]>(this.topic, key, valBytes));
    totalBytes += valBytes.length;
  }

  public void close(Reporter arg0) throws IOException
  {
    sendMsgList();
    producer.close();
  }


}
