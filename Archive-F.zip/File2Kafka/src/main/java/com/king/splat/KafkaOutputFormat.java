package com.king.splat;

import java.io.IOException;
import java.net.URI;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import kafka.common.KafkaException;
import kafka.javaapi.producer.Producer;
import kafka.producer.ProducerConfig;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.mapred.FileOutputCommitter;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.OutputCommitter;
import org.apache.hadoop.mapred.OutputFormat;
import org.apache.hadoop.mapred.RecordWriter;
import org.apache.hadoop.mapred.jobcontrol.Job;
import org.apache.hadoop.util.Progressable;
import org.apache.log4j.Logger;

public class KafkaOutputFormat<K,V> implements OutputFormat<K, V> {
	private Logger log = Logger.getLogger(KafkaOutputFormat.class);
	public static final String KAFKA_URL = "kafka.output.url";
	/** Bytes to buffer before the OutputFormat does a send (i.e., the amortization window):
	* We set the default to a million bytes so that the server will not reject the batch of messages
	* with a MessageSizeTooLargeException. The actual size will be smaller after compression.
	*/
	public static final int KAFKA_QUEUE_BYTES = 1000000;
	public static final String KAFKA_CONFIG_PREFIX = "kafka.output";
	private static final Map<String, String> kafkaConfigMap;
	static {
	Map<String, String> cMap = new HashMap<String, String>();
	// default Hadoop producer configs
	cMap.put("producer.type", "sync");
	cMap.put("compression.codec", Integer.toString(1));
	cMap.put("request.required.acks", Integer.toString(1));
	kafkaConfigMap = Collections.unmodifiableMap(cMap);
	}
	public KafkaOutputFormat()
	{
	super();
	}
	
/*	public static void setOutputPath(Job job, Path outputUrl)
	{
	job.getConfiguration().set(KafkaOutputFormat.KAFKA_URL, outputUrl.toString());
	job.getConfiguration().setBoolean("mapred.map.tasks.speculative.execution", false);
	job.getConfiguration().setBoolean("mapred.reduce.tasks.speculative.execution", false);
	}*/
	
	public static Path getOutputPath(JobConf job)
	{
	String name = job.get(KafkaOutputFormat.KAFKA_URL);
	return name == null ? null : new Path(name);
	}
	
	
	
	
	
	
	public void checkOutputSpecs(FileSystem arg0, JobConf arg1) throws IOException
	{
	}
	
	
	
	public RecordWriter<K, V> getRecordWriter(FileSystem arg0, JobConf job,String name, Progressable progress) 
	{
	Path outputPath = getOutputPath(job);
	if (outputPath == null)
	throw new KafkaException("no kafka output url specified");
	URI uri = URI.create(outputPath.toString());
	//Configuration job = arg1.getConfiguration();
	Properties props = new Properties();
	String topic;
	props.putAll(kafkaConfigMap); // inject default configuration
	for (Map.Entry<String, String> m : job) { // handle any overrides
	if (!m.getKey().startsWith(KAFKA_CONFIG_PREFIX))
	continue;
	if (m.getKey().equals(KAFKA_URL))
	continue;
	String kafkaKeyName = m.getKey().substring(KAFKA_CONFIG_PREFIX.length()+1);
	props.setProperty(kafkaKeyName, m.getValue()); // set Kafka producer property
	}
	// inject Kafka producer props back into jobconf for easier debugging
	for (Map.Entry<Object, Object> m : props.entrySet()) {
	job.set(KAFKA_CONFIG_PREFIX + "." + m.getKey().toString(), m.getValue().toString());
	}
	// KafkaOutputFormat specific parameters
	final int queueBytes = job.getInt(KAFKA_CONFIG_PREFIX + ".queue.bytes", KAFKA_QUEUE_BYTES);
	if (uri.getScheme().equals("kafka")) {
	// using the direct broker list
	// URL: kafka://<kafka host>/<topic>
	// e.g. kafka://kafka-server:9000,kafka-server2:9000/foobar
	String brokerList = uri.getAuthority();
	props.setProperty("metadata.broker.list", brokerList);
	job.set(KAFKA_CONFIG_PREFIX + ".metadata.broker.list", brokerList);
	if (uri.getPath() == null || uri.getPath().length() <= 1)
	throw new KafkaException("no topic specified in kafka uri");
	topic = uri.getPath().substring(1); // ignore the initial '/' in the path
	job.set(KAFKA_CONFIG_PREFIX + ".topic", topic);
	log.info(String.format("using kafka broker %s (topic %s)", brokerList, topic));
	} else
	throw new KafkaException("missing scheme from kafka uri (must be kafka://)");
	Producer<Object, byte[]> producer = new Producer<Object, byte[]>(new ProducerConfig(props));
	return new KafkaRecordWriter<K, V>(producer, topic, queueBytes);
	}
	
	
	
	

}
