package com.king.flink.files;

import org.junit.Ignore;
import org.junit.Test;

public class LocalFileWrapperTest {
	
	@Test
	@Ignore
	public void testLocalFile(){
		long start = System.currentTimeMillis();
		FileUtils.decompressGzipFile("incognito.statistics.log.2018-01-07T0000.gz",s->{
			//System.out.println(s);
		});
		System.out.println(System.currentTimeMillis() -start);
	}

}
