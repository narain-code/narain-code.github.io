package com.king.flink.files;

import java.io.IOException;
import java.net.URI;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.mapreduce.Job;

public class TestCopyToLocal {

	public static void main(String[] args) throws IOException{
		 String hdfsuri = "hdfs://bihdnn01.skd.midasplayer.com:8020";
	     
	      Configuration conf = new Configuration();
	      // Set FileSystem URI
	      conf.set("fs.defaultFS", hdfsuri);
	      conf.set("fs.hdfs.impl", org.apache.hadoop.hdfs.DistributedFileSystem.class.getName());
	      conf.set("fs.file.impl", org.apache.hadoop.fs.LocalFileSystem.class.getName());
	      // Set HADOOP user
	      System.setProperty("HADOOP_USER_NAME", "narainra");
	      System.setProperty("hadoop.home.dir", "/");
		Job job = Job.getInstance();
		Path inp = new Path("/user/midas/sox-ingestion/hdfs-import/2018-01-20/00/logs/statistics/fbweb98.sto.midasplayer.com/bubblewitch3/statistics.log.2018-01-20T0000.gz");
		//FileSystem fs = inp.getFileSystem(job.getConfiguration());
		 FileSystem fs = FileSystem.get(URI.create(hdfsuri), conf);
		Path tgt =new Path("file:///"+System.getProperty("java.io.tmpdir"));
		System.out.println(tgt.toUri().getPath());
		
		fs.copyToLocalFile( inp, tgt);
		new String(tgt.getName());
	}
}
