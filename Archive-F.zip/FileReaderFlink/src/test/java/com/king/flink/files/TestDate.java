package com.king.flink.files;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import com.king.event.format.EventFormatException;
import com.king.event.format.util.FastDateParser;



public class TestDate {
	
	
	static Map<Integer,Long> epochYear = new HashMap<Integer,Long>(){{
		/*put(2012,1325372400l);
		put(2013,1356994800l);
		put(2014,1388530800l);
		put(2015,1420066800l);
		put(2016,1451602800l);
		put(2017,1483225200l);
		put(2018,1514761200l);*/ //swedish
		
		put(2012,1325376000l);
		put(2013,1356998400l);
		put(2014,1388534400l);
		put(2015,1420070400l);
		put(2016,1451606400l);
		put(2017,1483228800l);
		put(2018,1514764800l); //GMT
	}};

	
	static Map<Integer,Long> secsinMonth = new HashMap<Integer,Long>(){{
		put(1,2678400l);
		put(2,2419200l);
		//
		put(3,2678400l);
		put(4,2592000l);
		put(5,2678400l);
		put(6,2592000l);
		put(7,2678400l);
		put(8,2678400l);
		put(9,2592000l);
		put(10,2678400l);
		put(11,2592000l);
		put(12,2678400l);
	}};
	
	static long perday =86400;
	static long perhour=3600;
	public static void main(String[] args) throws ParseException, EventFormatException{
		
		String d ="20180107T000000.005+0100";
		
		long start = System.nanoTime();
	//	Date dt = sdf.parse(d);
	//	String formattedTime = output.format(dt);
		//System.out.println(dt + " --  "+formattedTime);
		FastDateParser p = new FastDateParser();
		String xx ="201806143.911+0100";
		long oldEp =p.parse(xx, 0, xx.length());
		System.out.println((System.nanoTime() -start)/1000);
		start = System.nanoTime();
		int startM=1000;
		int year=0;
		int month=0;
		int day=0;
		long epoch =0L;
		for(int i=0;i<4;i++){
			year+=Character.getNumericValue(d.charAt(i))*startM;
			startM/=10;
		}
		epoch+=epochYear.get(year);
		//System.out.println(year);
		startM=10;
		for(int i=4;i<6;i++){
			month+=Character.getNumericValue(d.charAt(i))*startM;
			startM/=10;
		}
		//System.out.println(month);
		if(month -1 >0)
		epoch+=secsinMonth.get(month-1);
		startM=10;
		for(int i=6;i<8;i++){
			day+=Character.getNumericValue(d.charAt(i))*startM;
			startM/=10;
		}
		epoch+=(day-1)*perday;
		int hour=0;
		startM=10;
		for(int i=9;i<11;i++){
			hour+=Character.getNumericValue(d.charAt(i))*startM;
			startM/=10;
		}
		epoch+=hour*perhour;
		
		hour=0;
		startM=10;
		for(int i=11;i<13;i++){
			hour+=Character.getNumericValue(d.charAt(i))*startM;
			startM/=10;
		}
		epoch+=hour*60;
		
		hour=0;
		startM=10;
		for(int i=13;i<15;i++){
			hour+=Character.getNumericValue(d.charAt(i))*startM;
			startM/=10;
		}
		epoch+=hour;
		
		//offset hour
				hour=0;
				startM=10;
				for(int i=20;i<22;i++){
					hour+=Character.getNumericValue(d.charAt(i))*startM;
					startM/=10;
				}
				
				epoch-=(hour*perhour);
				
				//offset min
				hour=0;
				startM=10;
				for(int i=22;i<24;i++){
					hour+=Character.getNumericValue(d.charAt(i))*startM;
					startM/=10;
				}
				epoch-=(hour*60);		
		//millis
		hour=0;
		startM=100;
		for(int i=16;i<19;i++){
			hour+=Character.getNumericValue(d.charAt(i))*startM;
			startM/=10;
		}
		
		epoch*=1000;
		epoch+=hour;
		
		
		
		System.out.println((System.nanoTime() -start)/1000);
		
		System.out.println(oldEp + "  " + epoch);
	}
}
