package com.king.flink.files;

import java.io.IOException;
import java.io.InputStream;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.auth.oauth2.ServiceAccountCredentials;
import com.google.cloud.storage.Blob;
import com.google.cloud.storage.Bucket;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;

public class TestGFS {
	
	public static void main(String[] args){
		 try {
			 GoogleCredentials credentials;
				try (InputStream serviceAccountStream = TestGFS.class.getClassLoader().getResourceAsStream("king-splat-dev-f7a0a3aed2ac.json")) {
					credentials = ServiceAccountCredentials.fromStream(serviceAccountStream);
				}
				StorageOptions.Builder optionsBuilder = StorageOptions.newBuilder().setCredentials(credentials).setProjectId("king-splat-dev");
				 Storage storage = optionsBuilder.build().getService();
				
				 for (Bucket bucket : storage.list().iterateAll()) {
			          System.out.println(bucket);
			        }
				Bucket bucket = storage.get("king-statistic-logfiles-prod");
				 for (Blob blob : bucket.list().iterateAll()) {
			          System.out.println(blob);
			        }
		
		 } catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
	}

}
