package com.king.flink.files;

import com.king.event.TypedEventFieldAccessor;

public class LazyEvent extends TypedEventFieldAccessor {
	
	long timestamp;
	String entireEvent;
	int messageStart;
	int bodyStart;
	int flavourId;
	long eventType;
	public  LazyEvent(String entireEvent,long timestamp,int flavourId, long eventType,int messageStart) {
		this.timestamp=timestamp;
		this.messageStart=messageStart;
		this.entireEvent=entireEvent;
		this.flavourId=flavourId;
		this.eventType=eventType;
	}

	
	@Override
	public long getEventType() {
		
		return eventType;
	}

	
	@Override
	public long getTimeStamp() {
		return timestamp;
	}

	@Override
	public int getFlavourId() {
		
		return flavourId;
		
	}

	
	
	@Override
	public Iterable<String> fields() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public String getString(int index) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getInt(int index) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public long getLong(int index) {
		
		int start = getFieldOffset(index);
		int end = entireEvent.indexOf(LazyEventParser.FIELD_DELIMITER, start);
		return Long.parseLong(entireEvent.substring(start,end));
	}

	@Override
	public double getDouble(int index) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public float getFloat(int index) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean getBoolean(int index) {
		// TODO Auto-generated method stub
		return false;
	}

	private int getFieldOffset(int index) {
		int offset = messageStart;
		for (int i=0; i < index; i++) {
			offset = entireEvent.indexOf(LazyEventParser.FIELD_DELIMITER, offset);
			if (offset == -1) {
				throw new ArrayIndexOutOfBoundsException(index);
			}
			offset++;
		}

		return offset;
	}
	
	@Override
	public String toString(){
		return entireEvent;
	}
}
