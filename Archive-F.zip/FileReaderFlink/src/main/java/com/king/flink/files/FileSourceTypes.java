package com.king.flink.files;

public enum FileSourceTypes {

	LOCALFILE,
	HADOOP,
	GFS;
	
}
