package com.king.flink.files;

import java.util.HashMap;
import java.util.Map;

import com.king.event.Event;

public class LazyEventParser {

	static Map<Integer, Long> epochYear = new HashMap<Integer, Long>() {
		{
			/*
			 * put(2012,1325372400l); put(2013,1356994800l);
			 * put(2014,1388530800l); put(2015,1420066800l);
			 * put(2016,1451602800l); put(2017,1483225200l);
			 * put(2018,1514761200l);
			 */
			// swedish

			put(2012, 1325376000l);
			put(2013, 1356998400l);
			put(2014, 1388534400l);
			put(2015, 1420070400l);
			put(2016, 1451606400l);
			put(2017, 1483228800l);
			put(2018, 1514764800l); // GMT
		}
	};

	static Map<Integer, Long> secsinMonth = new HashMap<Integer, Long>() {
		{
			put(1, 2678400l);
			put(2, 2419200l);
			//
			put(3, 2678400l);
			put(4, 2592000l);
			put(5, 2678400l);
			put(6, 2592000l);
			put(7, 2678400l);
			put(8, 2678400l);
			put(9, 2592000l);
			put(10, 2678400l);
			put(11, 2592000l);
			put(12, 2678400l);
		}
	};
	static final char FIELD_DELIMITER = '\t';
	static long perday = 86400;
	static long perhour = 3600;


	public static LazyEvent parse(String event) {
		// all methods inlined to save a few nanos

		// Version --ignore
		// Date
		int dateEnd = event.indexOf(FIELD_DELIMITER, 2);
		
		String dateStr = event.substring(2, dateEnd);
		int startM = 1000;
		int year = 0;
		int month = 0;
		int day = 0;
		int hour = 0;
		int mins = 0;
		int secs = 0;
		int millis = 0;
		long epoch = 0L;

		for (int i = 0; i < 4; i++) {
			year += Character.getNumericValue(dateStr.charAt(i)) * startM;
			startM /= 10;
		}
		epoch += epochYear.get(year);

		startM = 10;
		for (int i = 4; i < 6; i++) {
			month += Character.getNumericValue(dateStr.charAt(i)) * startM;
			startM /= 10;
		}

		if (month - 1 > 0)
			epoch += secsinMonth.get(month - 1);
		startM = 10;
		for (int i = 6; i < 8; i++) {
			day += Character.getNumericValue(dateStr.charAt(i)) * startM;
			startM /= 10;
		}
		epoch += (day - 1) * perday;

		startM = 10;
		for (int i = 9; i < 11; i++) {
			hour += Character.getNumericValue(dateStr.charAt(i)) * startM;
			startM /= 10;
		}
		epoch += hour * perhour;

		startM = 10;
		for (int i = 11; i < 13; i++) {
			mins += Character.getNumericValue(dateStr.charAt(i)) * startM;
			startM /= 10;
		}
		epoch += mins * 60;

		startM = 10;
		for (int i = 13; i < 15; i++) {
			secs += Character.getNumericValue(dateStr.charAt(i)) * startM;
			startM /= 10;
		}
		epoch += secs;

		// offset hour
		hour = 0;
		startM = 10;
		for (int i = 20; i < 22; i++) {
			hour += Character.getNumericValue(dateStr.charAt(i)) * startM;
			startM /= 10;
		}

		epoch -= (hour * perhour);

		// offset min
		mins = 0;
		startM = 10;
		for (int i = 22; i < 24; i++) {
			mins += Character.getNumericValue(dateStr.charAt(i)) * startM;
			startM /= 10;
		}
		epoch -= (mins * 60);

		// millis
	
		startM = 100;
		for (int i = 16; i < 19; i++) {
			millis += Character.getNumericValue(dateStr.charAt(i)) * startM;
			startM /= 10;
		}

		epoch *= 1000;
		epoch += millis;
		
		int flavourIdEnd = event.indexOf(FIELD_DELIMITER, dateEnd +1);
		int flavourId =Integer.parseInt(event.substring(dateEnd+1,flavourIdEnd));
		int newEnd = event.indexOf(FIELD_DELIMITER, flavourIdEnd +1);
		long eventType =Long.parseLong(event.substring(flavourIdEnd+1,newEnd));
		for(int i=0;i<3;i++){
			newEnd = event.indexOf(FIELD_DELIMITER, newEnd );
			newEnd ++;
		}
		
		LazyEvent eventF= new LazyEvent(event, epoch,flavourId,eventType, newEnd);
		
		
		return eventF;
		
	}

}
