package com.king.flink.files;

import org.apache.flink.api.common.ExecutionConfig;
import org.apache.flink.api.common.typeinfo.TypeInformation;

import com.king.event.Event;
import com.king.flink.utils.types.EventTypeInfo;
import com.king.flink.utils.types.EventTypeSerializer;

public class LazyEventTypeInfo extends TypeInformation<LazyEvent> {
		private static final long serialVersionUID = 1L;

		@Override
		public LazyEventTypeSerializer createSerializer(ExecutionConfig config) {
			return LazyEventTypeSerializer.INSTANCE;
		}

		@Override
		public boolean canEqual(Object o) {
			return o instanceof EventTypeInfo;
		}

		@Override
		public boolean equals(Object o) {
			return canEqual(o);
		}

		@Override
		public int getArity() {
			return 0;
		}

		@Override
		public int getTotalFields() {
			return 0;
		}

		@Override
		public Class<LazyEvent> getTypeClass() {
			return LazyEvent.class;
		}

		@Override
		public int hashCode() {
			return 0;
		}

		@Override
		public boolean isBasicType() {
			return false;
		}

		@Override
		public boolean isKeyType() {
			return false;
		}

		@Override
		public boolean isTupleType() {
			return false;
		}

		@Override
		public String toString() {
			return "LazyEventType";
		}

	}


