package com.king.flink.files;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.apache.flink.api.common.functions.AggregateFunction;
import org.apache.flink.api.common.functions.FilterFunction;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.AssignerWithPeriodicWatermarks;
import org.apache.flink.streaming.api.functions.sink.PrintSinkFunction;
import org.apache.flink.streaming.api.watermark.Watermark;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.types.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Main {
	
	public static class SumAccumulator{
		
		public SumAccumulator(){
			count= 0L;
		}
		long count;
	}
	protected static final Logger LOG = LoggerFactory.getLogger(Main.class);
	public static void main(String[] args){
		
		try{
		StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
		env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime);
		
		String inputPath = args[0];
		env.addSource(new EventFileRawSource(inputPath, FileSourceTypes.HADOOP))
			.assignTimestampsAndWatermarks(new AssignerWithPeriodicWatermarks<EventWrapper>() {
			//	SimpleDateFormat sdf =  new SimpleDateFormat("yyyyMMdd'T'HHmmss.SSSz", Locale.ENGLISH);
				 private final long maxOutOfOrderness = 3500; // 3.5 seconds

				    private long currentMaxTimestamp;
				
				@Override
				public long extractTimestamp(EventWrapper element, long previousElementTimestamp) {
					//Date dt = null;
					long timestamp = element.getTimestamp();
					
					 currentMaxTimestamp = Math.max(timestamp, currentMaxTimestamp);
				     return timestamp;
				}
				
				@Override
				public Watermark getCurrentWatermark() {
					 return new Watermark(currentMaxTimestamp - 1000l);
				}
			}).filter(new FilterFunction<EventWrapper>() {
				
				@Override
				public boolean filter(EventWrapper value) throws Exception {
					return value.getCoreUserId().isPresent();
				}
			})
		  // .setParallelism(1)
		   .keyBy(new KeySelector<EventWrapper, Long>() {

			@Override
			public Long getKey(EventWrapper value) throws Exception {
				return value.f1%128;
				//mimicing all
				//return 1l;
			}})
		   .timeWindow(Time.minutes(1))
		   .aggregate(new AggregateFunction<EventWrapper, SumAccumulator, Long>() {

			@Override
			public SumAccumulator createAccumulator() {
				return new SumAccumulator();
			}

			@Override
			public void add(EventWrapper value, SumAccumulator accumulator) {
				//LOG.info("adding is " +accumulator.count);
				accumulator.count+=1L;
				
			}

			@Override
			public Long getResult(SumAccumulator accumulator) {
				//LOG.info("result is " +accumulator.count);
				return accumulator.count;
			}

			@Override
			public SumAccumulator merge(SumAccumulator a, SumAccumulator b) {
				a.count+=b.count;
				return a;
			}}).addSink(new PrintSinkFunction<Long>());
		env.execute("Test ");
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}

}
