package com.king.flink.files;

import java.util.List;

import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.source.RichParallelSourceFunction;
import org.apache.flink.streaming.api.operators.StreamingRuntimeContext;
import org.apache.flink.types.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.king.event.Event;

public class EventFileRawSource extends RichParallelSourceFunction<EventWrapper> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	int indexOfThisSubTask;
	int numberOfParrallelTasks;
	List<FileWrapper> all;

	private final String inputPath;
	private final FileSourceTypes type;

	protected static final Logger LOG = LoggerFactory.getLogger(EventFileRawSource.class);

	public EventFileRawSource(String inputPath, FileSourceTypes type) {
		this.inputPath = inputPath;
		this.type = type;
	}

	public void cancel() {
		// TODO Auto-generated method stub

	}

	
	public long numberofParsingErrors = 0L;
	
	public void run(org.apache.flink.streaming.api.functions.source.SourceFunction.SourceContext<EventWrapper> ctx)
			throws Exception {
		LOG.info(" custom source is being read now " + all.size());
		StreamingRuntimeContext context = (StreamingRuntimeContext) this.getRuntimeContext();
		this.indexOfThisSubTask = context.getIndexOfThisSubtask();
		this.numberOfParrallelTasks = context.getNumberOfParallelSubtasks();
		
		for (int i = 0; i < this.all.size(); i++) {
			if (i % numberOfParrallelTasks == indexOfThisSubTask) {
				
				FileWrapper split = this.all.get(i);
				
				split.consume(s -> {
					/*String[] all = s.split("\\t");
					Row r = Row.of(all);*/
					try{
					LazyEvent e=LazyEventParser.parse(s);
					ctx.collect(new EventWrapper(e));
					}catch(Exception ex){
						LOG.error("error in parsing no. "+numberofParsingErrors+" error msg " + ex.getMessage() + " event " +s);
						numberofParsingErrors ++;
					}

				});
			}
		}
		ctx.close();
	}

	@Override
	public void open(Configuration parameters) throws Exception {

		StreamingRuntimeContext context = (StreamingRuntimeContext) this.getRuntimeContext();
		this.indexOfThisSubTask = context.getIndexOfThisSubtask();
		this.numberOfParrallelTasks = context.getNumberOfParallelSubtasks();
		all = FileWrapper.getWrapperForType(FileSourceTypes.HADOOP).getSplitDirectories(inputPath);

	}

}
