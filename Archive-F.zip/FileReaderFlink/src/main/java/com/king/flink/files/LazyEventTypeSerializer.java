package com.king.flink.files;

import java.io.IOException;

import org.apache.flink.api.common.typeutils.CompatibilityResult;
import org.apache.flink.api.common.typeutils.ParameterlessTypeSerializerConfig;
import org.apache.flink.api.common.typeutils.TypeSerializer;
import org.apache.flink.api.common.typeutils.TypeSerializerConfigSnapshot;
import org.apache.flink.api.common.typeutils.base.StringSerializer;
import org.apache.flink.core.memory.DataInputView;
import org.apache.flink.core.memory.DataOutputView;

import com.king.flink.utils.events.LazyEventFormat;
import com.king.flink.utils.types.EventTypeSerializer;

public class LazyEventTypeSerializer extends TypeSerializer<LazyEvent> {
	
	private static final long serialVersionUID = 1L;
	private static final StringSerializer ss = StringSerializer.INSTANCE;

	public static final LazyEventTypeSerializer INSTANCE = new LazyEventTypeSerializer();

	@Override
	public boolean canEqual(Object o) {
		return o instanceof LazyEventTypeSerializer;
	}

	@Override
	public LazyEvent copy(LazyEvent e) {
		return e;
	}

	@Override
	public LazyEvent copy(LazyEvent e, LazyEvent reuse) {
		return e;
	}

	@Override
	public void copy(DataInputView source, DataOutputView target) throws IOException {
		ss.copy(source, target);
	}

	@Override
	public LazyEvent createInstance() {
		return null;
	}

	@Override
	public LazyEvent deserialize(DataInputView in) throws IOException {
	
			return LazyEventParser.parse(ss.deserialize(in));
		
	}

	@Override
	public LazyEvent deserialize(LazyEvent arg0, DataInputView in) throws IOException {
		return deserialize(in);
	}

	@Override
	public TypeSerializer<LazyEvent> duplicate() {
		return this;
	}

	@Override
	public boolean equals(Object o) {
		return o instanceof LazyEventTypeSerializer;
	}

	@Override
	public int getLength() {
		return 0;
	}

	@Override
	public int hashCode() {
		return 0;
	}

	@Override
	public boolean isImmutableType() {
		return true;
	}

	@Override
	public void serialize(LazyEvent event, DataOutputView out) throws IOException {
		ss.serialize(event.toString(), out);
	}

	@Override
	public TypeSerializerConfigSnapshot snapshotConfiguration() {
		return new ParameterlessTypeSerializerConfig(this.getClass().getSimpleName());
	}

	@Override
	public CompatibilityResult<LazyEvent> ensureCompatibility(TypeSerializerConfigSnapshot arg0) {
		return CompatibilityResult.compatible();
	}
}
