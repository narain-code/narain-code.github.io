package com.king.flink.utils.types;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;

import org.apache.flink.api.common.ExecutionConfig;
import org.apache.flink.api.common.typeutils.TypeSerializer;
import org.apache.flink.api.java.typeutils.TypeExtractor;
import org.apache.flink.util.InstantiationUtil;
import org.junit.Test;

import com.king.event.Event;
import com.king.event.format.EventFormatException;
import com.king.flink.utils.types.SemanticClassTypeInfo;
import com.king.flink.utils.types.SemanticClazzSerializer;
import com.king.kgk.SCGameStart;

public class SCTypeTest {

	@Test
	public void testSerDe() throws IOException, EventFormatException {

		Event gsEvent = SemanticClazzSerializer.eventFormat.parse(
				"B	20161007T112038.968+0200	80058	181011	104709973452422392	fbweb668	0	1336819879	MOIDf9e59cc4d77deb5e5024e42b8920c55e	149647558	147425797	{\"gameName\":\"rummy\",\"version\":\"v21\",\"minNumberOfPlayers\":2,\"maxNumberOfPlayers\":2,\"wagerTable\":4,\"usingLuckyCharms\":true,\"configHash\":\"-1da7vwwg0ck8mym9c98pkf8uvw25huvenq612ywi3jl2xowk8l\",\"waltersWorkshopExperiment\":0}	1	5	1			0	73	4	2	0");

		SCGameStart gs = SCGameStart.process(gsEvent);
		assertTrue(gs != null);

		TypeSerializer<SCGameStart> gsSerNew = new SemanticClassTypeInfo<>(SCGameStart.class).createSerializer(null);

		SCGameStart gsDeserialized = serDe(gs, gsSerNew);
		assertEquals(gs.getLevel(), gsDeserialized.getLevel());

	}

	@Test
	public void benchmark() throws EventFormatException, IOException {
		String raw = "B	20161007T112038.968+0200	80058	181011	104709973452422392	fbweb668	0	1336819879	MOIDf9e59cc4d77deb5e5024e42b8920c55e	149647558	147425797	{\"gameName\":\"rummy\",\"version\":\"v21\",\"minNumberOfPlayers\":2,\"maxNumberOfPlayers\":2,\"wagerTable\":4,\"usingLuckyCharms\":true,\"configHash\":\"-1da7vwwg0ck8mym9c98pkf8uvw25huvenq612ywi3jl2xowk8l\",\"waltersWorkshopExperiment\":0}	1	5	1			0	73	4	2	0";
		Event gsEvent = SemanticClazzSerializer.eventFormat.parse(raw);

		SCGameStart gs = SCGameStart.process(gsEvent);

		TypeSerializer<SCGameStart> gsSerNew = new SemanticClassTypeInfo<>(SCGameStart.class).createSerializer(null);
		TypeSerializer<SCGameStart> gsSerOld = TypeExtractor.getForClass(SCGameStart.class)
				.createSerializer(new ExecutionConfig());

		byte[] bytesNew = InstantiationUtil.serializeToByteArray(gsSerNew, gs);
		byte[] bytesOld = InstantiationUtil.serializeToByteArray(gsSerOld, gs);

		System.out.println("String length: " + raw.getBytes().length);

		System.out.println("New length: " + bytesNew.length);
		System.out.println("Old length: " + bytesOld.length);

		int n = 100000;

		for (int i = 0; i < n / 2; i++) {
			serDe(gs, gsSerNew);
			serDe(gs, gsSerOld);
		}

		long startnew = System.nanoTime();
		for (int i = 0; i < n; i++) {
			serDe(gs, gsSerNew);
		}
		long totalNew = (System.nanoTime() - startnew) / 1000000;

		long startold = System.nanoTime();
		for (int i = 0; i < n; i++) {
			serDe(gs, gsSerOld);
		}
		long totalOld = (System.nanoTime() - startold) / 1000000;

		System.out.println("New time: " + totalNew + " ms");
		System.out.println("Old time: " + totalOld + " ms");
	}

	private static SCGameStart serDe(SCGameStart gs, TypeSerializer<SCGameStart> ser) throws IOException {
		byte[] bytes = InstantiationUtil.serializeToByteArray(ser, gs);
		return InstantiationUtil.deserializeFromByteArray(ser, bytes);
	}
}
