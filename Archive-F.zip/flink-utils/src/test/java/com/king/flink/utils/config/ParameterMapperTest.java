package com.king.flink.utils.config;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.io.IOException;

import org.apache.flink.api.java.utils.ParameterTool;
import org.junit.Test;

public class ParameterMapperTest {

	@Test
	public void test() throws IOException, InstantiationException, IllegalAccessException {
		ParameterTool params = ParameterTool.fromPropertiesFile("src/test/resources/test-params.props");

		ParameterMapper pm = new ParameterMapper(params);

		TestConfig conf = pm.read(TestConfig.class);

		assertEquals(10, conf.parallelism);
		assertEquals("asd", conf.name);
		assertEquals(false, conf.undefined2);
		assertEquals(true, conf.req);
		assertEquals(TestEnum.FIRST, conf.enumTest);

		try {
			new ParameterMapper(
					ParameterTool.fromPropertiesFile("src/test/resources/test-params2.props"))
							.read(TestConfig.class);
			fail();
		} catch (Exception good) {}
	}

	public enum TestEnum {
		FIRST, SECOND;
	}

	public static class TestConfig {

		@ConfigParam(required = true)
		public TestEnum enumTest;

		@ConfigParam
		public int parallelism = 0;

		@ConfigParam(required = true)
		private String name;

		String undefined = "a";

		@ConfigParam
		boolean undefined2 = false;

		@ConfigParam(required = true)
		private boolean req;
	}

}
