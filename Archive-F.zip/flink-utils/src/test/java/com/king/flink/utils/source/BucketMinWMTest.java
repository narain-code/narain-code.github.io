package com.king.flink.utils.source;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.mockito.Mockito;

import com.king.event.Event;

public class BucketMinWMTest {

	@Test
	public void tes() {
		BucketMinWatermark bawm = new BucketMinWatermark(3);
		extractAndCheck(bawm, eventWithTs(100));
		extractAndCheck(bawm, eventWithTs(50));
		assertEquals(50, bawm.getCurrentWatermark().getTimestamp());
		extractAndCheck(bawm, eventWithTs(300));
		assertEquals(50, bawm.getCurrentWatermark().getTimestamp());
		extractAndCheck(bawm, eventWithTs(0));
		extractAndCheck(bawm, eventWithTs(0));
		extractAndCheck(bawm, eventWithTs(0));
		assertEquals(50, bawm.getCurrentWatermark().getTimestamp());
		extractAndCheck(bawm, eventWithTs(1000));
		extractAndCheck(bawm, eventWithTs(1200));
		extractAndCheck(bawm, eventWithTs(900));
		assertEquals(900, bawm.getCurrentWatermark().getTimestamp());
	}

	private void extractAndCheck(BucketMinWatermark bawm, Event e) {
		assertEquals(e.getTimeStamp(), bawm.extractTimestamp(e));
	}

	private static Event eventWithTs(long ts) {
		Event mockEvent = Mockito.mock(Event.class);
		Mockito.when(mockEvent.getTimeStamp()).thenReturn(ts);
		return mockEvent;
	}

}
