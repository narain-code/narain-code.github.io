package com.king.flink.utils.types;

import static org.junit.Assert.assertEquals;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Optional;
import java.util.TreeMap;

import org.apache.flink.api.common.ExecutionConfig;
import org.apache.flink.api.common.typeinfo.BasicTypeInfo;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeutils.TypeSerializer;
import org.apache.flink.api.common.typeutils.base.IntSerializer;
import org.apache.flink.api.common.typeutils.base.LongSerializer;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.typeutils.TupleTypeInfo;
import org.apache.flink.api.java.typeutils.TypeExtractor;
import org.apache.flink.core.memory.DataInputView;
import org.apache.flink.core.memory.DataInputViewStreamWrapper;
import org.apache.flink.core.memory.DataOutputView;
import org.apache.flink.core.memory.DataOutputViewStreamWrapper;
import org.apache.flink.util.InstantiationUtil;
import org.junit.Test;

import com.google.common.collect.Sets;

public class TypeInfoTest {

	@Test
	public void setSerializerTest() throws IOException {

		HashSet<Integer> intSet1 = Sets.newHashSet(1, 2, 3);
		HashSet<Integer> intSet2 = Sets.newHashSet();
		HashSetSerializer<Integer> intSetSerializer = new HashSetSerializer<>(IntSerializer.INSTANCE);

		@SuppressWarnings("unchecked")
		HashSet<Tuple2<String, Integer>> tupleSet1 = Sets.newHashSet(Tuple2.of("a", 1), Tuple2.of("b", 1),
				Tuple2.of("c", 3), Tuple2.of("a", 2));
		TypeSerializer<HashSet<Tuple2<String, Integer>>> tupleSetSerializer = new HashSetTypeInfo<>(
				TypeExtractor.getForObject(Tuple2.of("a", 1))).createSerializer(null);

		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		DataOutputView out = new DataOutputViewStreamWrapper(new DataOutputStream(bos));

		intSetSerializer.serialize(intSet1, out);
		intSetSerializer.serialize(intSet2, out);
		tupleSetSerializer.serialize(tupleSet1, out);

		DataInputView in = new DataInputViewStreamWrapper(new ByteArrayInputStream(bos.toByteArray()));

		assertEquals(intSet1, intSetSerializer.deserialize(in));
		assertEquals(intSet2, intSetSerializer.deserialize(in));
		assertEquals(tupleSet1, tupleSetSerializer.deserialize(in));

	}

	@Test
	public void treeSerializerTest() throws IOException {
		TreeMap<String, Integer> map = new TreeMap<>();
		map.put("a", 1);
		map.put("b", 2);

		TreeMapTypeInfo<String, Integer> t = new TreeMapTypeInfo<>(BasicTypeInfo.STRING_TYPE_INFO,
				BasicTypeInfo.INT_TYPE_INFO);

		TypeSerializer<TreeMap<String, Integer>> s = t.createSerializer(new ExecutionConfig());

		TreeMap<String, Integer> map2 = InstantiationUtil.deserializeFromByteArray(s,
				InstantiationUtil.serializeToByteArray(s, map));

		assertEquals(map, map2);

	}

	@Test
	public void optionSerializerTest() throws IOException {
		OptionSerializer<Long> longOptionSerializer = new OptionSerializer<>(LongSerializer.INSTANCE);
		Optional<Long> longOption1 = Optional.of(2L);
		Optional<Long> longOption2 = Optional.empty();

		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		DataOutputView out = new DataOutputViewStreamWrapper(new DataOutputStream(bos));

		longOptionSerializer.serialize(longOption1, out);
		longOptionSerializer.serialize(longOption2, out);

		DataInputView in = new DataInputViewStreamWrapper(new ByteArrayInputStream(bos.toByteArray()));

		assertEquals(longOption1, longOptionSerializer.deserialize(in));
		assertEquals(longOption2, longOptionSerializer.deserialize(longOption1, in));

	}

	@Test
	public void nullHandlerMapTest() throws IOException {
		HashMap<String, Tuple2<Long, Long>> map = new HashMap<>();
		map.put("a", Tuple2.of(1L, 2L));
		map.put("b", Tuple2.of(null, 3L));
		map.put("c", Tuple2.of(4L, 3L));
		map.put("d", Tuple2.of(null, 5L));

		HashMap<String, Tuple2<Long, Long>> map2 = new HashMap<>();
		map2.put("b", Tuple2.of(null, 8L));
		map2.put("d", Tuple2.of(null, 5L));

		TypeInformation<Tuple2<Long, Long>> nullHundlerTT = new TupleTypeInfo<Tuple2<Long, Long>>(
				new NullHandlerTypeInfo<>(BasicTypeInfo.LONG_TYPE_INFO), BasicTypeInfo.LONG_TYPE_INFO);

		TypeInformation<HashMap<String, Tuple2<Long, Long>>> mapType = new HashMapTypeInfo<>(
				BasicTypeInfo.STRING_TYPE_INFO,
				nullHundlerTT);

		TypeSerializer<HashMap<String, Tuple2<Long, Long>>> mapSerializer = mapType.createSerializer(null);

		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		DataOutputView out = new DataOutputViewStreamWrapper(new DataOutputStream(bos));

		mapSerializer.serialize(map, out);
		mapSerializer.serialize(map2, out);

		DataInputView in = new DataInputViewStreamWrapper(new ByteArrayInputStream(bos.toByteArray()));

		assertEquals(map, mapSerializer.deserialize(in));
		assertEquals(map2, mapSerializer.deserialize(map, in));
	}
}
