package com.king.flink.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.io.IOException;

import org.apache.flink.util.InstantiationUtil;
import org.junit.Test;

import com.king.constants.external.EventField;
import com.king.constants.external.EventType;
import com.king.event.Event;
import com.king.event.EventBuilder;
import com.king.event.format.DelegatingEventFormat;
import com.king.event.format.EventFormatException;

public class CustomEventTest {

	@Test
	public void testFields() throws EventFormatException, ClassNotFoundException, IOException {
		CustomEvent event = CustomEvent.create(EventType.AbTestCaseAssigned)
				.withFlavourId(1)
				.withTimeStamp(2)
				.withHostname("h")
				.withField(coreUserId, 2)
				.withField(abTestName, "t")
				.withField(abTestVersion, 3)
				.withField(5, "Yolo");

		event = (CustomEvent) InstantiationUtil.deserializeObject(InstantiationUtil.serializeObject(event), Thread.currentThread().getContextClassLoader());

		String formatted = new DelegatingEventFormat().format(event);
		Event event2 = new DelegatingEventFormat().parse(formatted);

		assertEquals(2, event.get(coreUserId));
		assertEquals(2, event.getLong(0));
		assertEquals(2, event2.get(coreUserId));
		assertEquals(2, event2.getLong(0));

		assertEquals("t", event.get(abTestName));
		assertEquals("t", event.getString(1));
		assertEquals("t", event2.get(abTestName));
		assertEquals("t", event2.getString(1));

		assertEquals("Yolo", event.getString(5));
		assertEquals("Yolo", event2.getString(5));
	}

	public static int[][] coreUserId = new int[][] { { 9020, 0 } };
	public static int[][][] abTestName = new int[][][] { { { 9020, 1 } } };
	public static int[] abTestVersion = new int[] { 9020, 2 };

	@Test
	public void testFromEvent() {
		Event event = new EventBuilder(1).buildEvent(EventType.AbTestCaseAssigned(1, "a", 2, 3), 3);
		CustomEvent custom = CustomEvent.fromEvent(event);
		custom.withField(4, 10);
		assertEquals(1, custom.getInt(0));
		assertEquals("a", custom.getString(1));
		assertEquals(2, custom.getInt(2));
		assertEquals(3, custom.getInt(3));
		assertEquals(10, custom.getInt(4));
	}

	@Test
	public void testErrors() throws EventFormatException {
		CustomEvent event = CustomEvent.create(2)
				.withField(0, "asd")
				.withField(2, 3);

		try {
			event.get(EventField.AbTestCaseAssigned.abTestName);
			fail();
		} catch (Exception expected) {}

		try {
			event.withField(2, 4);
			fail();
		} catch (Exception expected) {}

		event.getRawField(0);
		try {
			event.getRawField(1);
			fail();
		} catch (Exception expected) {}
	}
}
