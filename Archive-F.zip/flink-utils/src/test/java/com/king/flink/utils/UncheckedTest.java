package com.king.flink.utils;

import static org.junit.Assert.fail;

import java.io.IOException;
import java.util.function.Consumer;

import org.junit.Test;

public class UncheckedTest {

	@Test
	public void uncheckedConsumerTest() {
		Consumer<Integer> unchecked = Unchecked.consumer(i -> {
			if (i > 4) {
				throw new IOException();
			}
		});

		unchecked.accept(3);
		try {
			unchecked.accept(5);
			fail();
		} catch (Exception e) {
			if (e instanceof IOException) {
				// Muhahaha
			} else {
				fail();
			}
		}
	}

}
