package com.king.flink.utils.types;

import java.util.Optional;

import org.apache.flink.api.common.ExecutionConfig;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeutils.TypeSerializer;

public class OptionTypeInfo<T> extends WrapperTypeInfo<T, Optional<T>> {
	private static final long serialVersionUID = 1L;

	public OptionTypeInfo(TypeInformation<T> innerType) {
		super(innerType);
	}

	@Override
	public TypeSerializer<Optional<T>> createSerializer(ExecutionConfig config) {
		return new OptionSerializer<T>(getInnerType().createSerializer(config));
	}

	@SuppressWarnings("unchecked")
	@Override
	public Class<Optional<T>> getTypeClass() {
		return (Class<Optional<T>>) Optional.ofNullable(null).getClass();
	}

	@Override
	public String toString() {
		return "Optional(" + innerType.toString() + ")";
	}

}
