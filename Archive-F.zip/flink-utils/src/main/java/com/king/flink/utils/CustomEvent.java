package com.king.flink.utils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;
import java.util.SortedMap;
import java.util.TreeMap;

import com.king.event.Event;
import com.king.event.TypedEventFieldAccessor;
import com.king.event.format.DelegatingEventFormat;
import com.king.event.format.EventFormat;

public class CustomEvent extends TypedEventFieldAccessor implements Serializable {

	private static final long serialVersionUID = 1L;

	private final long type;
	private long timestamp = System.currentTimeMillis();
	private int flavourId;

	private final SortedMap<Integer, Object> fieldsByPos = new TreeMap<>();

	private long uacid;

	private long uniqueId;

	private String hostName;

	private static final EventFormat eventFormat = new DelegatingEventFormat();

	private CustomEvent(long type) {
		this.type = type;
	}

	public static CustomEvent fromEvent(Event e) {
		CustomEvent custom = CustomEvent.create(e.getEventType())
				.withTimeStamp(e.getTimeStamp())
				.withFlavourId(e.getFlavourId())
				.withUacid(e.getUacid())
				.withUniqueId(e.getUniqueId())
				.withHostname(e.getHostname());
		int index = 0;
		for (String field : e.fields()) {
			custom.put(index++, field);
		}
		return custom;
	}

	public static CustomEvent create(long type) {
		return new CustomEvent(type);
	}

	@Override
	public String toString() {
		return eventFormat.format(this);
	}

	@Override
	public long getEventType() {
		return type;
	}

	public CustomEvent withFlavourId(int flavourId) {
		this.flavourId = flavourId;
		return this;
	}

	@Override
	public int getFlavourId() {
		return flavourId;
	}

	public CustomEvent withTimeStamp(long ts) {
		timestamp = ts;
		return this;
	}

	@Override
	public long getTimeStamp() {
		return timestamp;
	}

	public CustomEvent withUacid(long uacid) {
		this.uacid = uacid;
		return this;
	}

	@Override
	public long getUacid() {
		return uacid;
	}

	public CustomEvent withUniqueId(long uniqueId) {
		this.uniqueId = uniqueId;
		return this;
	}

	@Override
	public long getUniqueId() {
		return uniqueId;
	}

	public CustomEvent withHostname(String hostName) {
		this.hostName = hostName;
		return this;
	}

	@Override
	public String getHostname() {
		return hostName;
	}

	@Override
	public Iterable<String> fields() {
		List<String> fields = new ArrayList<>();

		Integer previousPos = -1;

		for (Entry<Integer, Object> entry : fieldsByPos.entrySet()) {
			for (int i = previousPos + 1; i < entry.getKey(); i++) {
				fields.add("");
			}
			fields.add(entry.getValue().toString());
			previousPos = entry.getKey();
		}

		return fields;
	}

	public Object getRawField(int simpleField) {
		Object value = fieldsByPos.get(simpleField);
		if (value == null) {
			throw new RuntimeException("Missing field");
		} else {
			return value;
		}
	}

	@Override
	public float getFloat(int arg0) {
		Object o = getRawField(arg0);
		try {
			return (float) o;
		} catch (ClassCastException ex) {
			return Float.parseFloat(o.toString());
		}
	}

	@Override
	public boolean getBoolean(int arg0) {
		Object o = getRawField(arg0);
		try {
			return (boolean) o;
		} catch (ClassCastException ex) {
			return Boolean.parseBoolean(o.toString());
		}
	}

	@Override
	public double getDouble(int arg0) {
		Object o = getRawField(arg0);
		try {
			return (double) o;
		} catch (ClassCastException ex) {
			return Double.parseDouble(o.toString());
		}
	}

	@Override
	public int getInt(int arg0) {
		Object o = getRawField(arg0);
		try {
			return (int) o;
		} catch (ClassCastException ex) {
			return Integer.parseInt(o.toString());
		}
	}

	@Override
	public long getLong(int arg0) {
		Object o = getRawField(arg0);
		try {
			return (long) o;
		} catch (ClassCastException ex) {
			return Long.parseLong(o.toString());
		}
	}

	public String getString(int arg0) {
		return getRawField(arg0).toString();
	}

	public CustomEvent withField(int[] intIndex, int value) {
		put(intIndex[1], value);
		return this;
	}

	public CustomEvent withField(int[][] longIndex, long value) {
		put(longIndex[0][1], value);
		return this;
	}

	public CustomEvent withField(int[][][] stringIndex, String value) {
		put(stringIndex[0][0][1], value);
		return this;
	}

	public CustomEvent withField(int[][][][] doubleIndex, double value) {
		put(doubleIndex[0][0][0][1], value);
		return this;
	}

	public CustomEvent withField(int[][][][][] booleanIndex, boolean value) {
		put(booleanIndex[0][0][0][0][1], value);
		return this;
	}

	public CustomEvent withField(int[][][][][][] floatIndex, float value) {
		put(floatIndex[0][0][0][0][0][1], value);
		return this;
	}

	public CustomEvent withField(long[] intIndex, Integer value) {
		put((int) intIndex[1], value);
		return this;
	}

	public CustomEvent withField(long[][] longIndex, Long value) {
		put((int) longIndex[0][1], value);
		return this;
	}

	public CustomEvent withField(long[][][][] doubleIndex, Double value) {
		put((int) doubleIndex[0][0][0][1], value);
		return this;
	}

	public CustomEvent withField(long[][][][][] booleanIndex, Boolean value) {
		put((int) booleanIndex[0][0][0][0][1], value);
		return this;
	}

	public CustomEvent withField(long[][][][][][] floatIndex, Float value) {
		put((int) floatIndex[0][0][0][0][0][1], value);
		return this;
	}

	public CustomEvent withField(int fieldId, String value) {
		return privateWithCustomField(fieldId, value);
	}

	public CustomEvent withField(int fieldId, Integer value) {
		return privateWithCustomField(fieldId, value);
	}

	public CustomEvent withField(int fieldId, Float value) {
		return privateWithCustomField(fieldId, value);
	}

	public CustomEvent withField(int fieldId, Long value) {
		return privateWithCustomField(fieldId, value);
	}

	public CustomEvent withField(int fieldId, Double value) {
		return privateWithCustomField(fieldId, value);
	}

	public CustomEvent withField(int fieldId, Boolean value) {
		return privateWithCustomField(fieldId, value);
	}

	private CustomEvent privateWithCustomField(int fieldIndex, Object value) {
		Object prev = put(fieldIndex, value);
		if (prev != null) {
			throw new RuntimeException("Duplicate field index: " + fieldIndex);
		} else {
			return this;
		}
	}
	
	private Object put(Integer key, Object value) {
		if (value == null) {
			throw new NullPointerException("Value cannot be null for field " + key);
		}
		return fieldsByPos.put(key, value);
	}
}