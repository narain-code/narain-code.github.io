package com.king.flink.utils.types;

import static com.king.flink.utils.Unchecked.consumer;

import java.io.IOException;
import java.util.TreeMap;

import org.apache.flink.api.common.typeutils.CompatibilityResult;
import org.apache.flink.api.common.typeutils.ParameterlessTypeSerializerConfig;
import org.apache.flink.api.common.typeutils.TypeSerializer;
import org.apache.flink.api.common.typeutils.TypeSerializerConfigSnapshot;
import org.apache.flink.core.memory.DataInputView;
import org.apache.flink.core.memory.DataOutputView;

public class TreeMapSerializer<K, V> extends TypeSerializer<TreeMap<K, V>> {

	private static final long serialVersionUID = 1L;

	private final TypeSerializer<K> ks;
	private final TypeSerializer<V> vs;

	public TreeMapSerializer(TypeSerializer<K> keySerializer, TypeSerializer<V> valueSerialize) {
		this.ks = keySerializer;
		this.vs = valueSerialize;
	}

	@Override
	public TreeMap<K, V> copy(TreeMap<K, V> from) {
		TreeMap<K, V> map = new TreeMap<>();
		from.entrySet().forEach(e -> {
			map.put(ks.copy(e.getKey()), vs.copy(e.getValue()));
		});
		return map;
	}

	@Override
	public TreeMap<K, V> copy(TreeMap<K, V> from, TreeMap<K, V> reuse) {
		return copy(from);
	}

	@Override
	public TreeMap<K, V> createInstance() {
		return new TreeMap<>();
	}

	@Override
	public void serialize(TreeMap<K, V> record, DataOutputView target) throws IOException {
		target.writeInt(record.size());
		record.entrySet().stream().forEach(consumer(e -> {
			ks.serialize(e.getKey(), target);
			vs.serialize(e.getValue(), target);
		}));
	}

	@Override
	public TreeMap<K, V> deserialize(DataInputView source) throws IOException {
		int size = source.readInt();
		TreeMap<K, V> out = new TreeMap<>();
		for (int i = 0; i < size; i++) {
			out.put(ks.deserialize(source), vs.deserialize(source));
		}
		return out;
	}

	@Override
	public TreeMap<K, V> deserialize(TreeMap<K, V> reuse, DataInputView source) throws IOException {
		return deserialize(source);
	}

	@Override
	public TypeSerializer<TreeMap<K, V>> duplicate() {
		return new TreeMapSerializer<K, V>(ks, vs);
	}

	@Override
	public boolean canEqual(Object obj) {
		return equals(obj);
	}

	@Override
	public void copy(DataInputView source, DataOutputView target) throws IOException {
		throw new UnsupportedOperationException();
	}

	@Override
	public int getLength() {
		return 0;
	}

	@Override
	public boolean isImmutableType() {
		return false;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((ks == null) ? 0 : ks.hashCode());
		result = prime * result + ((vs == null) ? 0 : vs.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof TreeMapSerializer)) {
			return false;
		}
		TreeMapSerializer<?, ?> other = (TreeMapSerializer<?, ?>) obj;
		if (ks == null) {
			if (other.ks != null) {
				return false;
			}
		} else if (!ks.equals(other.ks)) {
			return false;
		}
		if (vs == null) {
			if (other.vs != null) {
				return false;
			}
		} else if (!vs.equals(other.vs)) {
			return false;
		}
		return true;
	}

	@Override
	public TypeSerializerConfigSnapshot snapshotConfiguration() {
		return new ParameterlessTypeSerializerConfig(this.getClass().getSimpleName());
	}

	@Override
	public CompatibilityResult<TreeMap<K, V>> ensureCompatibility(TypeSerializerConfigSnapshot arg0) {
		return CompatibilityResult.compatible();
	}
}
