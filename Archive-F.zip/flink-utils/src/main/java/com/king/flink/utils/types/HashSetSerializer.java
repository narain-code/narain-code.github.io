package com.king.flink.utils.types;

import static com.king.flink.utils.Unchecked.consumer;
import static com.king.flink.utils.Unchecked.function;

import java.io.IOException;
import java.util.HashSet;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.apache.flink.api.common.typeutils.TypeSerializer;
import org.apache.flink.core.memory.DataInputView;
import org.apache.flink.core.memory.DataOutputView;

public class HashSetSerializer<T> extends WrapperSerializer<T, HashSet<T>> {

	private static final long serialVersionUID = 1L;

	public HashSetSerializer(TypeSerializer<T> innerSerializer) {
		super(innerSerializer);
	}

	@Override
	public HashSet<T> copy(HashSet<T> from) {
		return from.stream().map(s::copy).collect(Collectors.toCollection(() -> new HashSet<>(from.size())));
	}

	@Override
	public HashSet<T> copy(HashSet<T> from, HashSet<T> reuse) {
		return copy(from);
	}

	@Override
	public HashSet<T> createInstance() {
		return new HashSet<>();
	}

	@Override
	public boolean isImmutableType() {
		return false;
	}

	@Override
	public void serialize(HashSet<T> record, DataOutputView target) throws IOException {
		target.writeInt(record.size());
		record.stream().forEach(consumer(e -> {
			s.serialize(e, target);
		}));
	}

	@Override
	public HashSet<T> deserialize(DataInputView source) throws IOException {
		int size = source.readInt();
		return IntStream.range(0, size).boxed().map(function(i -> s.deserialize(source)))
				.collect(Collectors.toCollection(() -> new HashSet<>(size)));
	}

	@Override
	public HashSet<T> deserialize(HashSet<T> reuse, DataInputView source) throws IOException {
		return deserialize(source);
	}

	@Override
	public TypeSerializer<HashSet<T>> duplicate() {
		return new HashSetSerializer<>(getInnerSerializer().duplicate());
	}
}
