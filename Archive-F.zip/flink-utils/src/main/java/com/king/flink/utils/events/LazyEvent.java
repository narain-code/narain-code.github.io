package com.king.flink.utils.events;

import com.king.event.Event;
import com.king.event.format.DelegatingEventFormat;
import com.king.event.format.EventFormat;
import com.king.event.format.EventFormatException;
import com.king.event.format.util.FastDateParser;
import com.king.event.format.util.NumberParser;
import com.king.flink.utils.Unchecked;

public class LazyEvent implements Event {

	private final String raw;

	private boolean tsAndTypeParsed = false;
	private long ts;
	private long eventType;

	private Event event;

	private static final EventFormat format = new DelegatingEventFormat();
	private static final FastDateParser dateParser = new FastDateParser();

	public LazyEvent(String raw) {
		this.raw = raw;
	}

	public String getRaw() {
		return raw;
	}

	public boolean eventParsed() {
		return event != null;
	}

	public boolean headerParsed() {
		return tsAndTypeParsed;
	}

	public Event getEvent() {
		if (event == null) {
			try {
				event = format.parse(raw);
			} catch (EventFormatException e) {
				Unchecked.throwSilently(e);
			}
			if (!tsAndTypeParsed) {
				this.ts = event.getTimeStamp();
				this.eventType = event.getEventType();
				this.tsAndTypeParsed = true;
			}

		}

		return event;
	}

	private void parseTsAndType() {
		if (!tsAndTypeParsed) {
			char firstChar = raw.charAt(0);
			switch (firstChar) {
			case 'B':
				try {
					parseBHeader(raw);
				} catch (EventFormatException e) {
					Unchecked.throwSilently(e);
				}
				break;
			default:
				getEvent();
				break;
			}
		}
	}

	private void parseBHeader(String event) throws EventFormatException {
		if (event == null || event.isEmpty()) {
			throw new EventFormatException("Empty event");
		}
		byte currentHeaderStart = 0;
		int currentHeaderEnd = event.indexOf(9, currentHeaderStart);
		char version = event.charAt(currentHeaderStart);
		if (version != 66) {
			throw new EventFormatException("Unsupported event version " + version + " in event " + event);
		}
		int currentHeaderStart1 = currentHeaderEnd + 1;
		currentHeaderEnd = event.indexOf(9, currentHeaderStart1);
		this.ts = dateParser.parse(event, currentHeaderStart1, currentHeaderEnd);
		currentHeaderStart1 = currentHeaderEnd + 1;
		try {
			currentHeaderEnd = event.indexOf(9, currentHeaderStart1);
			if (currentHeaderEnd == -1) {
				throw new EventFormatException("Invalid event format: " + event);
			}
			currentHeaderStart1 = currentHeaderEnd + 1;
			currentHeaderEnd = event.indexOf(9, currentHeaderStart1);
			if (currentHeaderEnd == -1) {
				throw new EventFormatException("Invalid event format: " + event);
			}
			this.eventType = NumberParser.parseLong(event, currentHeaderStart1, currentHeaderEnd);
			this.tsAndTypeParsed = true;
		} catch (NumberFormatException arg15) {
			throw new EventFormatException(event, arg15);
		}
	}

	@Override
	public Iterable<String> fields() {
		return getEvent().fields();
	}

	@Override
	public int get(int[] arg0) {
		return getEvent().get(arg0);
	}

	@Override
	public long get(int[][] arg0) {
		return getEvent().get(arg0);
	}

	@Override
	public String get(int[][][] arg0) {
		return getEvent().get(arg0);
	}

	@Override
	public double get(int[][][][] arg0) {
		return getEvent().get(arg0);
	}

	@Override
	public boolean get(int[][][][][] arg0) {
		return getEvent().get(arg0);
	}

	@Override
	public float get(int[][][][][][] arg0) {
		return getEvent().get(arg0);
	}

	@Override
	public Integer get(long[] arg0) {
		return getEvent().get(arg0);
	}

	@Override
	public Long get(long[][] arg0) {
		return getEvent().get(arg0);
	}

	@Override
	public Double get(long[][][][] arg0) {
		return getEvent().get(arg0);
	}

	@Override
	public Boolean get(long[][][][][] arg0) {
		return getEvent().get(arg0);
	}

	@Override
	public Float get(long[][][][][][] arg0) {
		return getEvent().get(arg0);
	}

	@Override
	public boolean getBoolean(int arg0) {
		return getEvent().getBoolean(arg0);
	}

	@Override
	public double getDouble(int arg0) {
		return getEvent().getDouble(arg0);
	}

	@Override
	public long getEventType() {
		parseTsAndType();
		return eventType;
	}

	@Override
	public int getFlavourId() {
		return getEvent().getFlavourId();
	}

	@Override
	public float getFloat(int arg0) {
		return getEvent().getFloat(arg0);
	}

	@Override
	public String getHostname() {
		return getEvent().getHostname();
	}

	@Override
	public int getInt(int arg0) {
		return getEvent().getInt(arg0);
	}

	@Override
	public long getLong(int arg0) {
		return getEvent().getLong(arg0);
	}

	@Override
	public String getString(int arg0) {
		return getEvent().getString(arg0);
	}

	@Override
	public long getTimeStamp() {
		parseTsAndType();
		return ts;
	}

	@Override
	public long getUacid() {
		return getEvent().getUacid();
	}

	@Override
	public long getUniqueId() {
		return getEvent().getUniqueId();
	}

	@Override
	public String toString() {
		return raw;
	}

}
