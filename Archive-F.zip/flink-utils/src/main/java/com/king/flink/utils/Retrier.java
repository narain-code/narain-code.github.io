package com.king.flink.utils;

import java.util.concurrent.Callable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Retrier {

	static final Logger LOG = LoggerFactory.getLogger(Retrier.class);

	public static <T> T retry(Callable<T> toRerty, int numRetries, long sleepOnError) throws Exception {
		return retry(toRerty, null, numRetries, sleepOnError);
	}

	public static <T> T retry(Callable<T> toRerty, Runnable onError, int numRetries, long sleepOnError) throws Exception {
		Exception ex = null;
		for (int i = 0; i < numRetries; i++) {
			try {
				return toRerty.call();
			} catch (Exception e) {
				LOG.error("Retrier logged error", e);
				ex = e;
				if (onError != null) {
					onError.run();
				}
				Thread.sleep(sleepOnError);
			}
		}
		throw ex;
	}
}
