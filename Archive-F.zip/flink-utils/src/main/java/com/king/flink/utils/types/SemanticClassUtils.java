package com.king.flink.utils.types;

import java.io.Serializable;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;

import com.king.event.Event;

public class SemanticClassUtils {

	public static SemanticClass mapSCToInterface(Class<?> semanticClazz) {
		try {
			MethodHandles.Lookup caller = MethodHandles.lookup();
			MethodType samMethodType = MethodType.methodType(Object.class, com.king.event.Event.class);
			MethodType actualMethodType = MethodType.methodType(semanticClazz, com.king.event.Event.class);
			MethodType invokedType = MethodType.methodType(SemanticClass.class);

			CallSite site = LambdaMetafactory.metafactory(caller,
					"process",
					invokedType,
					samMethodType,
					caller.findStatic(semanticClazz, "process", actualMethodType),
					samMethodType);
			MethodHandle factory = site.getTarget();
			return (SemanticClass) factory.invokeExact();

		} catch (NoSuchMethodException e) {
			throw new RuntimeException(
					"Missing 'process' method from semantic class:" + semanticClazz.getSimpleName());
		} catch (Throwable e) {
			throw new RuntimeException("Exception while creating semantic class parser.", e);
		}
	}

	public interface SemanticClass {
		Object process(com.king.event.Event event);
	}

	public static class SerializableSC implements SemanticClass, Serializable {

		private static final long serialVersionUID = 1L;
		protected transient SemanticClass sc;
		protected final Class<?> semanticClazz;

		public SerializableSC(Class<?> semanticClazz) {
			this.semanticClazz = semanticClazz;
			init();
		}

		public Class<?> getSemanticClass() {
			return semanticClazz;
		}

		@Override
		public Object process(Event event) {
			init();
			return sc.process(event);
		}

		public void init() {
			if (sc == null) {
				sc = mapSCToInterface(semanticClazz);
			}
		}
	}
}
