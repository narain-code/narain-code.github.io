package com.king.flink.utils;

import java.util.concurrent.Callable;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;

public class Unchecked {

	public interface ThrowingConsumer<T> {
		void accept(T value) throws Exception;
	}

	public interface ThrowingBiConsumer<I1, I2> {
		void accept(I1 value1, I2 value) throws Exception;
	}

	public interface ThrowingFunction<I, O> {
		O apply(I in) throws Exception;
	}

	public interface ThrowingBiFunction<I1, I2, O> {
		O apply(I1 input1, I2 input2) throws Exception;
	}

	public interface ThrowingRunnable {
		void run() throws Exception;
	}

	public interface ThrowingCallable<T> {
		T call() throws Exception;
	}

	@SuppressWarnings("unchecked")
	public static <E extends Throwable> void throwSilently(Throwable e) throws E {
		throw (E) e;
	}

	public static <T> Consumer<T> consumer(ThrowingConsumer<T> consumer) {
		return new UncheckedConsumer<>(consumer);
	}

	public static <I1, I2> BiConsumer<I1, I2> biconsumer(ThrowingBiConsumer<I1, I2> consumer) {
		return new UncheckedBiConsumer<>(consumer);
	}

	public static <I, O> Function<I, O> function(ThrowingFunction<I, O> function) {
		return new UncheckedFunction<>(function);
	}

	public static <I1, I2, O> BiFunction<I1, I2, O> bifunction(ThrowingBiFunction<I1, I2, O> function) {
		return new UncheckedBiFunction<>(function);
	}

	public static <T> Callable<T> callable(ThrowingCallable<T> callable) {
		return new UncheckedCallable<>(callable);
	}

	public static Runnable runnable(ThrowingRunnable runnable) {
		return new UncheckedRunnable(runnable);
	}

	public static class UncheckedRunnable implements Runnable {

		private final ThrowingRunnable innerRunnable;

		public UncheckedRunnable(ThrowingRunnable innerFunction) {
			this.innerRunnable = innerFunction;
		}

		@Override
		public void run() {
			try {
				innerRunnable.run();
			} catch (Exception e) {
				throwSilently(e);
			}
		}

	}

	public static class UncheckedCallable<T> implements Callable<T> {

		private final ThrowingCallable<T> innerCallable;

		public UncheckedCallable(ThrowingCallable<T> callable) {
			this.innerCallable = callable;
		}

		@Override
		public T call() {
			try {
				return innerCallable.call();
			} catch (Exception e) {
				throwSilently(e);
				return null;
			}
		}

	}

	public static class UncheckedFunction<I, O> implements Function<I, O> {

		private final ThrowingFunction<I, O> innerFunction;

		public UncheckedFunction(ThrowingFunction<I, O> innerFunction) {
			this.innerFunction = innerFunction;
		}

		@Override
		public O apply(I t) {
			try {
				return innerFunction.apply(t);
			} catch (Exception e) {
				throwSilently(e);
				return null;
			}
		}

	}

	public static class UncheckedBiFunction<I1, I2, O> implements BiFunction<I1, I2, O> {

		private final ThrowingBiFunction<I1, I2, O> innerFunction;

		public UncheckedBiFunction(ThrowingBiFunction<I1, I2, O> innerFunction) {
			this.innerFunction = innerFunction;
		}

		@Override
		public O apply(I1 input1, I2 input2) {
			try {
				return innerFunction.apply(input1, input2);
			} catch (Exception e) {
				throwSilently(e);
				return null;
			}
		}

	}

	public static class UncheckedConsumer<T> implements Consumer<T> {
		private final ThrowingConsumer<T> innerConsumer;

		public UncheckedConsumer(ThrowingConsumer<T> consumer) {
			this.innerConsumer = consumer;
		}

		@Override
		public void accept(T t) {
			try {
				innerConsumer.accept(t);
			} catch (Exception e) {
				throwSilently(e);
			}
		}
	}

	public static class UncheckedBiConsumer<I1, I2> implements BiConsumer<I1, I2> {
		private final ThrowingBiConsumer<I1, I2> innerConsumer;

		public UncheckedBiConsumer(ThrowingBiConsumer<I1, I2> consumer) {
			this.innerConsumer = consumer;
		}

		@Override
		public void accept(I1 value1, I2 value2) {
			try {
				innerConsumer.accept(value1, value2);
			} catch (Exception e) {
				throwSilently(e);
			}
		}
	}

}