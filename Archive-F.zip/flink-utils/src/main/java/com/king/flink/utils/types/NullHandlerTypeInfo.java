package com.king.flink.utils.types;

import org.apache.flink.api.common.ExecutionConfig;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeutils.TypeSerializer;

public class NullHandlerTypeInfo<T> extends WrapperTypeInfo<T, T> {

	private static final long serialVersionUID = 1L;

	public NullHandlerTypeInfo(TypeInformation<T> innerType) {
		super(innerType);
	}

	@Override
	public TypeSerializer<T> createSerializer(ExecutionConfig config) {
		return new NullHandlerSerializer<>(getInnerType().createSerializer(config));
	}

	@Override
	public Class<T> getTypeClass() {
		return getInnerType().getTypeClass();
	}

	@Override
	public String toString() {
		return "Nullable(" + innerType.toString() + ")";
	}

}
