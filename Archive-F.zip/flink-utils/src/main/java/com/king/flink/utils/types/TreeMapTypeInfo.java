package com.king.flink.utils.types;

import java.util.TreeMap;

import org.apache.flink.api.common.ExecutionConfig;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeutils.TypeSerializer;

public class TreeMapTypeInfo<K, V> extends TypeInformation<TreeMap<K, V>> {

	private static final long serialVersionUID = 1L;
	private final TypeInformation<K> kt;
	private final TypeInformation<V> vt;

	public TreeMapTypeInfo(TypeInformation<K> kt, TypeInformation<V> vt) {
		this.kt = kt;
		this.vt = vt;
	}

	@Override
	public TypeSerializer<TreeMap<K, V>> createSerializer(ExecutionConfig config) {
		return new TreeMapSerializer<K, V>(kt.createSerializer(config), vt.createSerializer(config));
	}

	@SuppressWarnings("unchecked")
	@Override
	public Class<TreeMap<K, V>> getTypeClass() {
		return (Class<TreeMap<K, V>>) new TreeMap<K, V>().getClass();
	}

	@Override
	public boolean canEqual(Object obj) {
		return equals(obj);
	}

	@Override
	public int getArity() {
		return 0;
	}

	@Override
	public int getTotalFields() {
		return 0;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((kt == null) ? 0 : kt.hashCode());
		result = prime * result + ((vt == null) ? 0 : vt.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof TreeMapTypeInfo)) {
			return false;
		}
		TreeMapTypeInfo<?, ?> other = (TreeMapTypeInfo<?, ?>) obj;
		if (kt == null) {
			if (other.kt != null) {
				return false;
			}
		} else if (!kt.equals(other.kt)) {
			return false;
		}
		if (vt == null) {
			if (other.vt != null) {
				return false;
			}
		} else if (!vt.equals(other.vt)) {
			return false;
		}
		return true;
	}

	@Override
	public boolean isBasicType() {
		return false;
	}

	@Override
	public boolean isKeyType() {
		return true;
	}

	@Override
	public boolean isTupleType() {
		return false;
	}

	@Override
	public String toString() {
		return "TreeMap(" + kt.toString() + " -> " + vt.toString() + ")";
	}

}
