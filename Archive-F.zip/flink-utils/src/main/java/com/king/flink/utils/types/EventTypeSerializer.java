package com.king.flink.utils.types;

import java.io.IOException;

import org.apache.flink.api.common.typeutils.CompatibilityResult;
import org.apache.flink.api.common.typeutils.ParameterlessTypeSerializerConfig;
import org.apache.flink.api.common.typeutils.TypeSerializer;
import org.apache.flink.api.common.typeutils.TypeSerializerConfigSnapshot;
import org.apache.flink.api.common.typeutils.base.StringSerializer;
import org.apache.flink.core.memory.DataInputView;
import org.apache.flink.core.memory.DataOutputView;

import com.king.event.Event;
import com.king.event.format.EventFormat;
import com.king.event.format.EventFormatException;
import com.king.flink.utils.events.LazyEventFormat;

public class EventTypeSerializer extends TypeSerializer<Event> {

	private static final long serialVersionUID = 1L;
	private static final StringSerializer ss = StringSerializer.INSTANCE;
	private static final EventFormat eventFormat = new LazyEventFormat();
	public static final EventTypeSerializer INSTANCE = new EventTypeSerializer();

	@Override
	public boolean canEqual(Object o) {
		return o instanceof EventTypeSerializer;
	}

	@Override
	public Event copy(Event e) {
		return e;
	}

	@Override
	public Event copy(Event e, Event reuse) {
		return e;
	}

	@Override
	public void copy(DataInputView source, DataOutputView target) throws IOException {
		ss.copy(source, target);
	}

	@Override
	public Event createInstance() {
		return null;
	}

	@Override
	public Event deserialize(DataInputView in) throws IOException {
		try {
			return eventFormat.parse(ss.deserialize(in));
		} catch (EventFormatException e) {
			throw new IOException(e);
		}
	}

	@Override
	public Event deserialize(Event arg0, DataInputView in) throws IOException {
		return deserialize(in);
	}

	@Override
	public TypeSerializer<Event> duplicate() {
		return this;
	}

	@Override
	public boolean equals(Object o) {
		return o instanceof EventTypeSerializer;
	}

	@Override
	public int getLength() {
		return 0;
	}

	@Override
	public int hashCode() {
		return 0;
	}

	@Override
	public boolean isImmutableType() {
		return true;
	}

	@Override
	public void serialize(Event event, DataOutputView out) throws IOException {
		ss.serialize(eventFormat.format(event), out);
	}

	@Override
	public TypeSerializerConfigSnapshot snapshotConfiguration() {
		return new ParameterlessTypeSerializerConfig(this.getClass().getSimpleName());
	}

	@Override
	public CompatibilityResult<Event> ensureCompatibility(TypeSerializerConfigSnapshot arg0) {
		return CompatibilityResult.compatible();
	}

}
