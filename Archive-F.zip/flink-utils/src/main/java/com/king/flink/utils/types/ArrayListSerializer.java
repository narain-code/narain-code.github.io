package com.king.flink.utils.types;

import static com.king.flink.utils.Unchecked.consumer;
import static com.king.flink.utils.Unchecked.function;

import java.io.IOException;
import java.util.ArrayList;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.apache.flink.api.common.typeutils.TypeSerializer;
import org.apache.flink.core.memory.DataInputView;
import org.apache.flink.core.memory.DataOutputView;

public class ArrayListSerializer<T> extends WrapperSerializer<T, ArrayList<T>> {

	private static final long serialVersionUID = 1L;

	public ArrayListSerializer(TypeSerializer<T> innerSerializer) {
		super(innerSerializer);
	}

	@Override
	public ArrayList<T> copy(ArrayList<T> from) {
		return from.stream().map(s::copy).collect(Collectors.toCollection(() -> new ArrayList<>(from.size())));
	}

	@Override
	public ArrayList<T> copy(ArrayList<T> from, ArrayList<T> reuse) {
		return copy(from);
	}

	@Override
	public ArrayList<T> createInstance() {
		return new ArrayList<>();
	}

	@Override
	public boolean isImmutableType() {
		return false;
	}

	@Override
	public void serialize(ArrayList<T> record, DataOutputView target) throws IOException {
		target.writeInt(record.size());
		record.stream().forEach(consumer(e -> {
			s.serialize(e, target);
		}));
	}

	@Override
	public ArrayList<T> deserialize(DataInputView source) throws IOException {
		int size = source.readInt();
		return IntStream.range(0, size).boxed().map(function(i -> s.deserialize(source)))
				.collect(Collectors.toCollection(() -> new ArrayList<>(size)));
	}

	@Override
	public ArrayList<T> deserialize(ArrayList<T> reuse, DataInputView source) throws IOException {
		return deserialize(source);
	}

	@Override
	public TypeSerializer<ArrayList<T>> duplicate() {
		return new ArrayListSerializer<>(getInnerSerializer().duplicate());
	}
}
