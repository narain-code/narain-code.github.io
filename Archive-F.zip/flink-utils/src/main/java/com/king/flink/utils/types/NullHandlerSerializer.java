package com.king.flink.utils.types;

import java.io.IOException;

import org.apache.flink.api.common.typeutils.TypeSerializer;
import org.apache.flink.core.memory.DataInputView;
import org.apache.flink.core.memory.DataOutputView;

public class NullHandlerSerializer<T> extends WrapperSerializer<T, T> {

	private static final long serialVersionUID = 1L;

	public NullHandlerSerializer(TypeSerializer<T> innerSerializer) {
		super(innerSerializer);
	}

	@Override
	public T copy(T from) {
		return from != null ? s.copy(from) : null;
	}

	@Override
	public T copy(T from, T reuse) {
		if (from == null) {
			return null;
		} else if (reuse == null) {
			return s.copy(from);
		} else {
			return s.copy(from, reuse);
		}
	}

	@Override
	public T createInstance() {
		return s.createInstance();
	}

	@Override
	public T deserialize(DataInputView source) throws IOException {
		return source.readBoolean() ? s.deserialize(source) : null;
	}

	@Override
	public T deserialize(T reuse, DataInputView source) throws IOException {
		if (source.readBoolean()) {
			if (reuse != null) {
				return s.deserialize(reuse, source);
			} else {
				return s.deserialize(source);
			}
		} else {
			return null;
		}
	}

	@Override
	public TypeSerializer<T> duplicate() {
		return new NullHandlerSerializer<>(s);
	}

	@Override
	public void serialize(T record, DataOutputView target) throws IOException {
		if (record != null) {
			target.writeBoolean(true);
			s.serialize(record, target);
		} else {
			target.writeBoolean(false);
		}
	}

}
