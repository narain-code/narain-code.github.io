package com.king.flink.utils.types;

import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.typeutils.EitherTypeInfo;
import org.apache.flink.api.java.typeutils.ResultTypeQueryable;
import org.apache.flink.types.Either;
import org.apache.flink.util.Collector;

public class EitherUtils<Left, Right> {

	public static class ProjectLeft<L, R> implements FlatMapFunction<Either<L, R>, L>, ResultTypeQueryable<L> {

		private static final long serialVersionUID = 1L;
		TypeInformation<L> lt;

		public ProjectLeft(TypeInformation<L> lt) {
			this.lt = lt;
		}

		@Override
		public void flatMap(Either<L, R> value, Collector<L> out) throws Exception {
			if (value.isLeft()) {
				out.collect(value.left());
			}
		}

		@Override
		public TypeInformation<L> getProducedType() {
			return lt;
		}

	}

	public static class ProjectRight<L, R> implements FlatMapFunction<Either<L, R>, R>, ResultTypeQueryable<R> {

		private static final long serialVersionUID = 1L;
		TypeInformation<R> rt;

		public ProjectRight(TypeInformation<R> rt) {
			this.rt = rt;
		}

		@Override
		public void flatMap(Either<L, R> value, Collector<R> out) throws Exception {
			if (value.isRight()) {
				out.collect(value.right());
			}
		}

		@Override
		public TypeInformation<R> getProducedType() {
			return rt;
		}

	}

	public static class ToLeft<L, R>
			implements MapFunction<L, Either<L, R>>, ResultTypeQueryable<Either<L, R>> {
		private static final long serialVersionUID = 1L;

		TypeInformation<L> lt;
		TypeInformation<R> rt;

		public ToLeft(TypeInformation<L> lt, TypeInformation<R> rt) {
			this.lt = lt;
			this.rt = rt;
		}

		@Override
		public Either<L, R> map(L value) throws Exception {
			return Either.Left(value);
		}

		@Override
		public TypeInformation<Either<L, R>> getProducedType() {
			return new EitherTypeInfo<>(lt, rt);
		}
	}

	public static class ToRight<L, R>
			implements MapFunction<R, Either<L, R>>, ResultTypeQueryable<Either<L, R>> {
		private static final long serialVersionUID = 1L;

		TypeInformation<L> lt;
		TypeInformation<R> rt;

		public ToRight(TypeInformation<L> lt, TypeInformation<R> rt) {
			this.lt = lt;
			this.rt = rt;
		}

		@Override
		public Either<L, R> map(R value) throws Exception {
			return Either.Right(value);
		}

		@Override
		public TypeInformation<Either<L, R>> getProducedType() {
			return new EitherTypeInfo<>(lt, rt);
		}
	}

}
