package com.king.flink.utils.source;

import org.apache.flink.streaming.api.functions.AssignerWithPeriodicWatermarks;
import org.apache.flink.streaming.api.watermark.Watermark;

import com.king.event.Event;

public class BucketMinWatermark implements AssignerWithPeriodicWatermarks<Event> {

	private static final long serialVersionUID = 1L;

	private final SlidingWindowMinimum<Long> windowMin;

	private long lastEmittedWatermark = Long.MIN_VALUE;

	public BucketMinWatermark(int bucketSize) {
		if (bucketSize < 1) {
			throw new RuntimeException("Invalid bucket size");
		}

		this.windowMin = SlidingWindowMinimum.ofWindowSize(bucketSize);
	}

	public long extractTimestamp(Event event) {
		long eventTs = event.getTimeStamp();
		windowMin.accept(eventTs);
		return eventTs;
	}

	@Override
	public final Watermark getCurrentWatermark() {
		if (!windowMin.isEmpty()) {
			long potentialWM = windowMin.get();
			if (potentialWM >= lastEmittedWatermark) {
				lastEmittedWatermark = potentialWM;
			}
		}
		return new Watermark(lastEmittedWatermark);
	}

	@Override
	public final long extractTimestamp(Event event, long previousElementTimestamp) {
		return extractTimestamp(event);
	}
}
