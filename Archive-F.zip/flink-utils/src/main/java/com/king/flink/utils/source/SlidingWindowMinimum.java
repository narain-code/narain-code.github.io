package com.king.flink.utils.source;

import java.io.Serializable;
import java.util.ArrayDeque;
import java.util.Comparator;
import java.util.Deque;
import java.util.Iterator;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

public class SlidingWindowMinimum<T extends Comparable<T>> implements Supplier<T>, Consumer<T>, Function<T, T>, Serializable {

	private static final long serialVersionUID = 1L;
	private final Deque<Value> ascendingMinima;
	private final int windowSize;
	private final Comparator<T> comparator;
	private int index = 0;

	public static <C extends Comparable<C>> SlidingWindowMinimum<C> ofWindowSize(int windowSize) {
		return new SlidingWindowMinimum<C>(windowSize, Comparator.naturalOrder());
	}

	public SlidingWindowMinimum(int windowSize, Comparator<T> comparator) {
		this.ascendingMinima = new ArrayDeque<>(windowSize);
		this.windowSize = windowSize;
		this.comparator = comparator;
	}

	@Override
	public void accept(T value) {
		removeFirstIfExpired();
		removeGreaterValuesFromEnd(value);
		addLast(value);
	}

	public boolean isEmpty() {
		return ascendingMinima.isEmpty();
	}

	@Override
	public T get() {
		return ascendingMinima.getFirst().value;
	}

	@Override
	public T apply(T t) {
		accept(t);
		return get();
	}

	private void addLast(T value) {
		ascendingMinima.addLast(new Value(index, value));
		index = (index + 1) % windowSize;
	}

	private void removeFirstIfExpired() {
		Iterator<Value> first = ascendingMinima.iterator();
		if (first.hasNext() && first.next().deathIndex == index) {
			first.remove();
		}
	}

	private void removeGreaterValuesFromEnd(T value) {
		Iterator<Value> descendingIterator = ascendingMinima.descendingIterator();
		while (descendingIterator.hasNext()) {
			if (lessThan(descendingIterator.next().value, value)) {
				break;
			}
			descendingIterator.remove();
		}
	}

	private boolean lessThan(T v1, T v2) {
		return comparator.compare(v1, v2) < 0;
	}

	private class Value {
		private final long deathIndex;
		private final T value;

		public Value(long deathIndex, T value) {
			this.deathIndex = deathIndex;
			this.value = value;
		}
	}
}