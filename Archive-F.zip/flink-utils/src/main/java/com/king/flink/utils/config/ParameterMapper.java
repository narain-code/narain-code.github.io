package com.king.flink.utils.config;

import java.lang.reflect.Field;

import org.apache.commons.lang3.reflect.FieldUtils;
import org.apache.flink.api.java.utils.ParameterTool;

public class ParameterMapper {

	private final ParameterTool params;

	public ParameterMapper(ParameterTool params) {
		this.params = params;
	}

	public <T> T read(Class<T> clazz) throws InstantiationException, IllegalAccessException {
		T instance = clazz.newInstance();

		for (Field field : FieldUtils.getAllFields(clazz)) {
			ConfigParam cp = field.getAnnotation(ConfigParam.class);
			if (cp != null) {
				try {
					field.setAccessible(true);
					field.set(instance, getFromParams(field.getName(), field.getType()));
				} catch (Throwable e) {
					if (cp.required()) {
						throw e;
					}
				}
			}
		}

		return instance;
	}

	@SuppressWarnings("unchecked")
	private Object getFromParams(String name, Class<?> type) {
		if (type.isAssignableFrom(String.class)) {
			return params.getRequired(name);
		} else if (type.isAssignableFrom(Integer.TYPE)) {
			return params.getInt(name);
		} else if (type.isAssignableFrom(Long.TYPE)) {
			return params.getLong(name);
		} else if (type.isAssignableFrom(Boolean.TYPE)) {
			return params.getBoolean(name);
		} else if (type.isAssignableFrom(Double.TYPE)) {
			return params.getDouble(name);
		} else if (type.isAssignableFrom(Float.TYPE)) {
			return params.getFloat(name);
		} else if (type.isAssignableFrom(Short.TYPE)) {
			return params.getShort(name);
		} else if (type.isAssignableFrom(Byte.TYPE)) {
			return params.getByte(name);
		} else if (type.isEnum()) {
			return Enum.valueOf((Class) type, params.getRequired(name));
		} else {
			throw new RuntimeException("Unsupported field type");
		}
	}
}