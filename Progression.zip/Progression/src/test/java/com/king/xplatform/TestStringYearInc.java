package com.king.xplatform;

public class TestStringYearInc {
	
	static int year = 2011;
	static String format = "/warehouse/hive/doughnut.db/f_level_attempt_summary/dt=%d-*-*";
	
	public static void main(String[] args){
	
		for(int i=0;i<=4;i++)
		 System.out.println(String.format(format, year+i));
	}

}
