package com.king.xplatform;

import org.apache.hadoop.io.LongWritable;

import com.king.xplatform.persistence.Utils;

public class FindShard {

	public static void main(String[] args){
      System.out.println( Utils.keyShard( "fe8940f3e20cf6a5befc477f".getBytes(),512));
      System.out.println( Utils.keyShard( "fafd2f9a779fed7a9e80dae8".getBytes(),512));
      
      byte[] a ="fff7dcbb8e326f387d535a18".getBytes();
      byte[] b = "f47293571905bf7142c98186".getBytes();
     // System.out.println( WritableComparator.compareBytes(a, 0, a.length, b, 0, b.length));
      
      LongWritable one= new LongWritable(2128943768L);
      LongWritable two = new LongWritable(2145065475L);
      LongWritable three = new LongWritable(2128943768L);
      System.out.println( Utils.keyShard( "4177607757".getBytes(),512));
      
      System.out.println(one.compareTo(two) + "::" + two.compareTo(three));
      
      String indexPath="/tmp/narain/new_index/*-%d/data";
		System.out.println(String.format(indexPath,15));
       System.out.println(123%512);
    
	}
}
