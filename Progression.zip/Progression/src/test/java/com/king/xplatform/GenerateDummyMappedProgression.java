package com.king.xplatform;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class GenerateDummyMappedProgression {

	
	  public static void main(String[] args) throws IOException{
		 
		  
	       
	       File tmp = new File("DummyGeneratedDataL");
	       BufferedWriter writer = new BufferedWriter(new FileWriter(tmp));  
	       writer.write("1" + '\t' + "A1" + '\n');
	       writer.write("2" + '\t' + "A2" + '\n');
	       writer.write("3" + '\t' + "A3" + '\n');
	       writer.write("7" + '\t' + "A7" + '\n');
	       writer.flush();
	       
		  
	       File tmp2 = new File("DummyGeneratedDataR");
	       BufferedWriter writer2 = new BufferedWriter(new FileWriter(tmp2));  
	       writer2.write("5" + '\t' + "A5" + '\n');
	       writer2.write("7" + '\t' + "A7" + '\n');
	       writer2.write("13" + '\t' + "A13" + '\n');
	       writer2.write("17" + '\t' + "A17" + '\n');
	       writer2.flush();
	  }
}
