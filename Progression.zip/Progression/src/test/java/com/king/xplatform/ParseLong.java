package com.king.xplatform;

import java.nio.ByteBuffer;

import org.apache.hadoop.hive.serde2.lazy.LazyLong;

public class ParseLong {
	
	public static void main(String[] args){
		 
		// String longValue = "3782433992";
		Long longValue = 3782433992l;
		 byte[] bytes=longValue.toString().getBytes();
		 ByteBuffer buffer = ByteBuffer.allocate(64); 
    	 buffer.put(bytes, 0, bytes.length);
    	 buffer.flip();
    	 System.out.println( buffer.getLong());
    	 System.out.println(LazyLong.parseLong(bytes, 0, bytes.length));
	}

}
