package com.king.xplatform;

import java.util.Iterator;
import java.util.Map.Entry;

public class TestMappedProgressionValue {

	 public static void main(String[] args){
		  MappedProgressionValue mapped = new MappedProgressionValue();
		  GroupKey key_1 = new GroupKey();
		  key_1.setAppId(17);
		  key_1.setEpisode(1);
		  key_1.setLevel(1);
		  
		  GroupValue val_1 = new GroupValue();
		  val_1.setFirstPlay("2014-09-29");
		  val_1.setGameendsbefore(0);
		  val_1.setGameendsafter(1);
		  val_1.setSuccessDate("2014-09-29");
		  mapped.add2Group(key_1, val_1);
		  
		  
		  MappedProgressionValue mapped2 = new MappedProgressionValue();
		  GroupKey key_2 = new GroupKey();
		  key_2.setAppId(17);
		  key_2.setEpisode(1301);
		  key_2.setLevel(1);
		  
		  GroupValue val_2 = new GroupValue();
		  val_2.setFirstPlay("2014-09-29");
		  val_2.setGameendsbefore(0);
		  val_2.setGameendsafter(1);
		  val_2.setSuccessDate("2014-09-29");
		  mapped2.add2Group(key_2, val_2);
		  
		 mapped.merge(mapped2);
		  Iterator<Entry<GroupKey, GroupValue>> it=mapped.allGroups.entrySet().iterator();
		  while(it.hasNext()){
			  Entry<GroupKey, GroupValue> e= it.next();
			  System.out.println(e.getKey().appId +""+e.getKey().level+ " "+ e.getKey().episode );
			  System.out.println(e.getValue().firstPlay +""+e.getValue().gameendsafter );
		  }
		  
		  
	 }
}
