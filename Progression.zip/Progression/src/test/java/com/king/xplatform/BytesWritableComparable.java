package com.king.xplatform;

import org.apache.hadoop.io.BytesWritable;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.ByteBufferOutput;

public class BytesWritableComparable {
	
	public static void main(String[] args){
		 MappedProgressionValue mapped = new MappedProgressionValue();
		  GroupKey key_1 = new GroupKey();
		  key_1.setAppId(17);
		  key_1.setEpisode(1);
		  key_1.setLevel(1);
		  
		  GroupValue val_1 = new GroupValue();
		  val_1.setFirstPlay("2014-09-29");
		  val_1.setGameendsbefore(0);
		  val_1.setGameendsafter(1);
		  val_1.setSuccessDate("2014-09-29");
		  mapped.add2Group(key_1, val_1);
		  
		  
		  MappedProgressionValue mapped2 = new MappedProgressionValue();
		  GroupKey key_2 = new GroupKey();
		  key_2.setAppId(17);
		  key_2.setEpisode(1301);
		  key_2.setLevel(1);
		  
		  GroupValue val_2 = new GroupValue();
		  val_2.setFirstPlay("2014-09-29");
		  val_2.setGameendsbefore(0);
		  val_2.setGameendsafter(1);
		  val_2.setSuccessDate("2014-09-29");
		  mapped2.add2Group(key_2, val_2);
		  
		  Kryo kryo = new Kryo();
		  int currentSize = 512;
          ByteBufferOutput output = new ByteBufferOutput(currentSize);
          boolean done = false;
          while (!done) {
            try
            {
              kryo.writeObject(output, mapped);
              done = true;
            }
            catch (Exception e) {
              currentSize *= 2;
              output = new ByteBufferOutput(currentSize);
            }
          }
          byte[] serialized = output.toBytes();
          output.close();
          BytesWritable _comp1 = new BytesWritable(serialized);
          
        
          ByteBufferOutput output2 = new ByteBufferOutput(currentSize);
          boolean done2 = false;
          while (!done2) {
            try
            {
              kryo.writeObject(output2, mapped2);
              done2 = true;
            }
            catch (Exception e) {
              currentSize *= 2;
              output = new ByteBufferOutput(currentSize);
            }
          }
          byte[] serialized2 = output.toBytes();
          output.close();
          
          BytesWritable _comp2 = new BytesWritable(serialized2);
          
          System.out.println(_comp1==_comp2);
          System.out.println(_comp1==_comp1);
	}

}
