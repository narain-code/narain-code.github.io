package com.king.xplatform;

import java.io.ByteArrayInputStream;
import java.io.DataInput;
import java.io.DataInputStream;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.serde2.ColumnProjectionUtils;
import org.apache.hadoop.hive.serde2.columnar.BytesRefArrayWritable;
import org.apache.hadoop.hive.serde2.columnar.ColumnarSerDe;
import org.apache.hadoop.hive.serde2.objectinspector.StructField;
import org.apache.hadoop.hive.serde2.objectinspector.StructObjectInspector;
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.RawComparator;
import org.apache.hadoop.io.SequenceFile.CompressionType;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableComparator;
import org.apache.hadoop.io.WritableUtils;
import org.apache.hadoop.io.compress.GzipCodec;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.JobPriority;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Partitioner;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapred.SequenceFileOutputFormat;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.ByteBufferInput;
import com.esotericsoftware.kryo.io.ByteBufferOutput;
import com.esotericsoftware.kryo.io.Input;
import com.king.xplatform.persistence.ElephantRecordWritable;
import com.king.xplatform.persistence.KeySorter;
import com.king.xplatform.persistence.Utils;

public class NewExporter {
	
	private static ColumnarSerDe serde;
	private static final String defDate = "2014-07-01";
	
	static
	  {
	    try
	    {
	      Configuration conf = new Configuration();
	      Properties tbl = new Properties();

	      tbl.setProperty("serialization.format", "9");

	      tbl.setProperty("columns", "player_key,appid,episode,level,gameendsbefore,gameendsafter,dt");
	      tbl.setProperty("columns.types", "string:int:bigint:bigint:bigint:bigint:string");

	      tbl.setProperty("serialization.null.format", "NULL");

	      serde = new ColumnarSerDe();
	      serde.initialize(conf, tbl);

	      StructObjectInspector oi = (StructObjectInspector)serde.getObjectInspector();
	      List<? extends StructField> fieldRefs = oi.getAllStructFieldRefs();

	      for (StructField structField : fieldRefs) {
	        System.out.println("FIELD: " + structField.getFieldName());
	      }

	    }
	    catch (Exception e)
	    {
	      e.printStackTrace();
	      System.out.println("Failed to setup SERDE.");
	    }
	  }
	
	
	 public static class CompoundKey
	    implements Writable
	  {
	    public int shard;
	    public byte[] shardKey;

	    public CompoundKey()
	    {
	    }

	    public CompoundKey(int shard, byte[] shardKey)
	    {
	      this.shard = shard;
	      this.shardKey = shardKey;
	    }

	    public void write(DataOutput d) throws IOException {
	      WritableUtils.writeVInt(d, this.shard);
	      WritableUtils.writeVInt(d, this.shardKey.length);
	      d.write(this.shardKey);
	    }

	    public void readFields(DataInput di) throws IOException {
	      this.shard = WritableUtils.readVInt(di);
	      this.shardKey = new byte[WritableUtils.readVInt(di)];
	      di.readFully(this.shardKey);
	    }
	  }
	 
	 public static enum REJECTED_COUNTER
	  {
	    NOLEVEL, 
	    NOEPISODE, 
	    NOAPP;
	  }
	 
	 
	 public static final class ElephantSecondarySort
	    implements RawComparator<CompoundKey>
	  {
	   CompoundKey ckey1 = new CompoundKey();
	    CompoundKey ckey2 = new CompoundKey();

	    public int compare(byte[] key1, int start1, int length1, byte[] key2, int start2, int length2) {
	      try {
	        DataInputStream s1 = new DataInputStream(new ByteArrayInputStream(key1, start1, length1));
	        DataInputStream s2 = new DataInputStream(new ByteArrayInputStream(key2, start2, length2));
	        this.ckey1.readFields(s1);
	        this.ckey2.readFields(s2);
	        return compare(this.ckey1, this.ckey2);
	      } catch (IOException e) {
	        throw new RuntimeException(e);
	      }
	    }

	    public int compare(CompoundKey key1, CompoundKey key2) {
	      if (key1.shard != key2.shard) {
	        return key1.shard - key2.shard;
	      }
	      return WritableComparator.compareBytes(key1.shardKey, 0, key1.shardKey.length, key2.shardKey, 0, key2.shardKey.length);
	    }
	  }

	  public static final class ElephantPrimarySort
	    implements RawComparator<CompoundKey>
	  {
	    public int compare(byte[] key1, int start1, int length1, byte[] key2, int start2, int length2)
	    {
	      DataInputStream s1 = new DataInputStream(new ByteArrayInputStream(key1, start1, length1));
	      DataInputStream s2 = new DataInputStream(new ByteArrayInputStream(key2, start2, length2));
	      try {
	        return WritableUtils.readVInt(s1) - WritableUtils.readVInt(s2);
	      } catch (IOException e) {
	        throw new RuntimeException(e);
	      }
	    }

	    public int compare(CompoundKey key1, CompoundKey key2)
	    {
	      return key1.shard - key2.shard;
	    }
	  }
	  
	  public static class ElephantPartitioner
	    implements Partitioner<CompoundKey, ElephantRecordWritable>
	  {
	    public int getPartition(CompoundKey k2, ElephantRecordWritable v2, int numPartitions)
	    {
	      return k2.shard % numPartitions;
	    }

	    public void configure(JobConf jc)
	    {
	    }
	  }

	  
	  public static class ExporterMapper extends MapReduceBase
	    implements Mapper<LongWritable, BytesRefArrayWritable, CompoundKey, ElephantRecordWritable>
	  {
	    KeySorter sorter;
	    int _numShards =NUMBEROFSHARDS;
	    public static final int NOPRESENTEPISODE = 0;
	    public static final int NOLEVEL = -1;
	    Kryo kryo = new Kryo();
	    public static final String DATEST = "dt=";

	    public void map(LongWritable key, BytesRefArrayWritable value, OutputCollector<CompoundKey, ElephantRecordWritable> oc, Reporter rprtr)
	      throws IOException
	    {
	      try
	      {
	       // String parentName = ((CombineFileSplit)rprtr.getInputSplit()).getParent().getName();
	    	 // rprtr.getInputSplit().
	       /* int indexPos = parentName.indexOf("dt=");
	        String parsedDate = null;
	        if (indexPos != -1) {
	          parsedDate = parentName.substring(indexPos + "dt=".length());
	        }*/
	    	  
	    	  String parsedDate=new String(value.get(6).getBytesCopy());
  	    	 // System.out.println(parsedDate);
	       /* StructObjectInspector oi = (StructObjectInspector)NewExporter.serde.getObjectInspector();
	        List fieldRefs = oi.getAllStructFieldRefs();

	        Object raw = NewExporter.serde.deserialize(value);

	        List dataStruct = oi.getStructFieldsDataAsList(raw);

	        StringBuilder txt = new StringBuilder();*/
	      
	        int i = 0;
	        String kingpdJoinKey = new String(value.get(0).getBytesCopy());
             System.out.println(kingpdJoinKey);
	        byte[] keyBytes =kingpdJoinKey.getBytes();
	      
	       
	        
	        byte[] valBytes = null;

	        MappedProgressionValue mappedvalue = new MappedProgressionValue();
	        GroupKey grpkey = new GroupKey();
	        String appID= new String(value.get(1).getBytesCopy());
	       
	        if (appID == null) {
	          grpkey.setEpisode(-1L);
	          rprtr.getCounter(Exporter.REJECTED_COUNTER.NOAPP).increment(1L);
	          return;
	        }
	        
	        grpkey.setAppId(Integer.parseInt(appID));
	        String episode = value.get(2) == null?null:new String(value.get(2).getBytesCopy());
	        
	        if (episode == null || "\\N".equalsIgnoreCase(episode) || "".equalsIgnoreCase(episode))
	        {
	          grpkey.setEpisode(0L);
	        }
	        else
	        {
	          grpkey.setEpisode(Integer.valueOf(episode).intValue());
	        }
	        String level = value.get(3) == null?null:new String(value.get(3).getBytesCopy());
	        
	        if (level == null ||"\\N".equalsIgnoreCase(level) || "".equalsIgnoreCase(level)  ) {
	          rprtr.getCounter(Exporter.REJECTED_COUNTER.NOLEVEL).increment(1L);
	          return;
	        }
	        
	      
	        grpkey.setLevel(Integer.valueOf(level).intValue());

	        GroupValue grpValue = new GroupValue();
	        String gameendsBefore =new String(value.get(4).getBytesCopy());
	        grpValue.setGameendsbefore(Long.valueOf(gameendsBefore).longValue());
	        String gameEndsAfter = (value.get(5) == null) ? null: new String();
	        if (gameEndsAfter == null|| ("".equalsIgnoreCase(gameEndsAfter)))
	          grpValue.setGameendsafter(0L);
	        else {
	          grpValue.setGameendsafter(Long.valueOf(gameEndsAfter).longValue());
	        }
	        if (parsedDate == null)
	          grpValue.setFirstPlay("2014-07-01");
	        else
	          grpValue.setFirstPlay(parsedDate);
	        if (gameEndsAfter != null && !("".equalsIgnoreCase(gameEndsAfter))){
	        if (Long.valueOf(gameEndsAfter).longValue() > 0L) {
	          if (parsedDate == null) {
	            grpValue.setSuccessDate("2014-07-01");
	          }
	          else {
	            grpValue.setSuccessDate(parsedDate);
	            
	          }
	        }
	        }
	        grpValue.setLastPlayDate(parsedDate);
	        System.out.println(kingpdJoinKey + "::" + appID + "::" + episode + "::" + level+ "::"+gameendsBefore + "::"+gameEndsAfter+"::"+parsedDate);
	        mappedvalue.add2Group(grpkey, grpValue);
	        ByteBufferOutput output = new ByteBufferOutput(256);

	        this.kryo.writeObject(output, mappedvalue);
	        valBytes = output.toBytes();
	        output.close();
	        int shard = Utils.keyShard(keyBytes, this._numShards);
	        oc.collect(new CompoundKey(shard, keyBytes), new ElephantRecordWritable(keyBytes, valBytes));
	        
	       
	      } catch (Exception e) {
	    	  e.printStackTrace();
	        throw new RuntimeException("Serde exception", e);
	      }
	    }

	    public void configure(JobConf jc) {
	     
	    }

	    public void close()
	      throws IOException
	    {
	    }
	  }
	  
	  public static class ExporterCombiner extends MapReduceBase
	    implements Reducer<CompoundKey, ElephantRecordWritable, CompoundKey, ElephantRecordWritable>
	  {
		  IntWritable shard = new IntWritable();
		    KyroFactory _factory = new KyroFactory();

		@Override
		public void reduce(CompoundKey key,
				Iterator<ElephantRecordWritable> it,
				OutputCollector<CompoundKey, ElephantRecordWritable> oc,
				Reporter reporter) throws IOException {
			Kryo kryo = this._factory.getKyro();

		      byte[] player_key = key.shardKey;
		      MappedProgressionValue old = null;
		      byte[] oldPlayer_key = null;
		      while (it.hasNext()) {
		        this.shard.set(key.shard);
		        ElephantRecordWritable w = (ElephantRecordWritable)it.next();
		        player_key = w.getKey();
		       
		        Input input = new Input(new ByteBufferInput(w.getValue()));

		        MappedProgressionValue someObject = (MappedProgressionValue)kryo.readObject(input, MappedProgressionValue.class);
		        if (old == null) {
		          old = someObject;
		          oldPlayer_key = player_key;
		        }
		        else if (WritableComparator.compareBytes(player_key, 0, player_key.length, oldPlayer_key, 0, oldPlayer_key.length) == 0)
		        {
		          old.merge(someObject);
		        } else {
		          int currentSize = 512;
		          ByteBufferOutput output = new ByteBufferOutput(currentSize);
		          boolean done = false;
		          while (!done) {
		            try
		            {
		              kryo.writeObject(output, old);
		              done = true;
		            }
		            catch (Exception e) {
		              currentSize *= 2;
		              output = new ByteBufferOutput(currentSize);
		            }
		          }
		          byte[] serialized = output.toBytes();
		          output.close();
		          int shard = Utils.keyShard(oldPlayer_key, NUMBEROFSHARDS);
		          oc.collect( new  CompoundKey(shard,oldPlayer_key), new  ElephantRecordWritable(oldPlayer_key,serialized) );

		        
		          old = someObject;
		          oldPlayer_key = player_key;
		        }

		      }

		      int currentSize = 512;
		      ByteBufferOutput output = new ByteBufferOutput(currentSize);
		      boolean done = false;
		      while (!done) {
		        try
		        {
		          kryo.writeObject(output, old);
		          done = true;
		        }
		        catch (Exception e) {
		          currentSize *= 2;
		          output = new ByteBufferOutput(currentSize);
		        }
		      }
		      byte[] serialized = output.toBytes();
		      output.close();
		      //int shard = Utils.keyShard(oldPlayer_key, NUMBEROFSHARDS);
		      int shard =1;
		      oc.collect(new  CompoundKey(shard,oldPlayer_key), new  ElephantRecordWritable(oldPlayer_key,serialized));
			
		}
		  
	  }

	  public static class ExporterReducer extends MapReduceBase
	    implements Reducer<CompoundKey, ElephantRecordWritable, BytesWritable, BytesWritable>
	  {
	    IntWritable shard = new IntWritable();
	    KyroFactory _factory = new KyroFactory();

	    public void reduce(CompoundKey key, Iterator<ElephantRecordWritable> it, OutputCollector<BytesWritable, BytesWritable> oc, Reporter rprtr)
	      throws IOException
	    {
	      Kryo kryo = this._factory.getKyro();

	      byte[] player_key = key.shardKey;
	      MappedProgressionValue old = null;
	      byte[] oldPlayer_key = null;
	      while (it.hasNext()) {
	        this.shard.set(key.shard);
	        ElephantRecordWritable w = (ElephantRecordWritable)it.next();
	        player_key = w.getKey();
	       
	        Input input = new Input(new ByteBufferInput(w.getValue()));

	        MappedProgressionValue someObject = (MappedProgressionValue)kryo.readObject(input, MappedProgressionValue.class);
	        if (old == null) {
	          old = someObject;
	          oldPlayer_key = player_key;
	        }
	        else if (WritableComparator.compareBytes(player_key, 0, player_key.length, oldPlayer_key, 0, oldPlayer_key.length) == 0)
	        {
	          old.merge(someObject);
	        } else {
	          int currentSize = 512;
	          ByteBufferOutput output = new ByteBufferOutput(currentSize);
	          boolean done = false;
	          while (!done) {
	            try
	            {
	              kryo.writeObject(output, old);
	              done = true;
	            }
	            catch (Exception e) {
	              currentSize *= 2;
	              output = new ByteBufferOutput(currentSize);
	            }
	          }
	          byte[] serialized = output.toBytes();
	          output.close();
	          oc.collect( new  BytesWritable(oldPlayer_key), new  BytesWritable(serialized) );

	        
	          old = someObject;
	          oldPlayer_key = player_key;
	        }

	      }

	      int currentSize = 512;
	      ByteBufferOutput output = new ByteBufferOutput(currentSize);
	      boolean done = false;
	      while (!done) {
	        try
	        {
	          kryo.writeObject(output, old);
	          done = true;
	        }
	        catch (Exception e) {
	          currentSize *= 2;
	          output = new ByteBufferOutput(currentSize);
	        }
	      }
	      byte[] serialized = output.toBytes();
	      output.close();
	      oc.collect(new  BytesWritable(oldPlayer_key), new  BytesWritable(serialized));
	     
	    }

	    public void configure(JobConf jc) {
	      System.out.println("reduce mem" + jc.getMemoryForReduceTask());

	      long total = Runtime.getRuntime().totalMemory();

	      long free = Runtime.getRuntime().freeMemory();

	      long used = total - free;

	      System.out.println("total memory in bytes: " + total);
	    }

	    public void close()
	      throws IOException
	    {
	    }
	  }
	  
	  static String startDate = null;
	  static String endDate = null;
	  static int NUMBEROFSHARDS = 1;
	  public static void main(String[] args){
		  if(args.length > 2){
		  if(args[2] != null)
	    		startDate =args[2];
	    	if(args[3] != null)
	    		endDate =args[3];
		  }
		  JobConf conf = new JobConf(NewExporter.class);
		    if (startDate !=null && endDate != null){
		    	conf.set("StartDate", startDate);
			    conf.set("EndDate", endDate);
			    FileInputFormat.setInputPathFilter(conf, FilteredDateJob.class);
			    
		    }
		    conf.setInputFormat(CombineInputFormat.class);
		    ColumnProjectionUtils.setFullyReadColumns(conf);
		    conf.setMapOutputKeyClass(CompoundKey.class);
		    conf.setMapOutputValueClass(ElephantRecordWritable.class);
		    conf.setOutputKeyClass(BytesWritable.class);
		    conf.setOutputValueClass(BytesWritable.class);
		    conf.setOutputFormat(SequenceFileOutputFormat.class);
		    SequenceFileOutputFormat.setCompressOutput(conf, true);
		    SequenceFileOutputFormat.setOutputCompressionType(conf, CompressionType.BLOCK);
		    SequenceFileOutputFormat.setOutputCompressorClass(conf, GzipCodec.class);
		    conf.setMapperClass(ExporterMapper.class);
		    conf.setReducerClass(ExporterReducer.class);
		    conf.setMapOutputCompressorClass(GzipCodec.class);
		   // conf.setPartitionerClass(ElephantPartitioner.class);
		    conf.setOutputValueGroupingComparator(ElephantPrimarySort.class);
		    conf.setOutputKeyComparatorClass(ElephantSecondarySort.class);
		    conf.setJobPriority(JobPriority.VERY_HIGH);
		    conf.set("mapreduce.map.java.opts", "-Xmx20G");
		    conf.set("mapred.map.child.java.opts", "-Xmx2G");
		    conf.set("mapreduce.reduce.java.opts", "-Xms20G -Xmx20G -XX:+UseCompressedOops");
		    conf.set("mapreduce.task.io.sort.mb", "600m");
		    conf.set("mapred.job.reduce.memory.mb", "20480");
		    conf.setLong("mapred.min.split.size", 67108864L);
		    conf.setLong("mapred.max.split.size", 268435456L);
		    conf.setMemoryForReduceTask(20480L);
		   conf.setCombinerClass(ExporterCombiner.class);
		    conf.setInt("dfs.replication", 2);
		    FileInputFormat.setInputPaths(conf, new Path[] { new Path(args[0]) });

		    FileOutputFormat.setOutputPath(conf, new Path(args[1]));
		    conf.setSpeculativeExecution(false);
		    conf.setNumReduceTasks(NUMBEROFSHARDS);
		    try
		    {
		      JobClient.runJob(conf);
		    }
		    catch (IOException e) {
		      e.printStackTrace();
		    }
		  
	  }
}



