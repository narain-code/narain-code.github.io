package com.king.xplatform;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.fs.PathFilter;

public class FilteredDateJob extends Configured implements PathFilter{

	public Date startDate;
	public Date endDate;
	SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
	
	@Override
	public boolean accept(Path path) {
		try {
			System.out.println(path.getName());
		String parentName = path.getName();
        int indexPos = parentName.indexOf("dt=");
        String parsedDate = null;
        Date parsedDt = null;
        if (indexPos == -1) {
        	parentName = path.getParent().getName();
        	indexPos = parentName.indexOf("dt=");
         
        }
        parsedDate = parentName.substring(indexPos + "dt=".length());
        parsedDt =  format.parse(parsedDate);
        if(startDate == null){
        	 System.out.println(this.getConf().get("StartDate"));
				startDate = format.parse(this.getConf().get("StartDate"));
				endDate = format.parse(this.getConf().get("EndDate"));
			
        }
        //System.out.println(parsedDt);
        if(parsedDt.before(startDate) || parsedDt.after(endDate))
        	 return false;
        
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
         
        
        return true;
	}

	
}
