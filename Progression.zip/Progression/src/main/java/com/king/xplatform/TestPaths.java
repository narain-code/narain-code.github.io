package com.king.xplatform;

import java.io.IOException;
import java.util.List;
import java.util.Properties;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.serde2.columnar.BytesRefArrayWritable;
import org.apache.hadoop.hive.serde2.columnar.ColumnarSerDe;
import org.apache.hadoop.hive.serde2.objectinspector.StructField;
import org.apache.hadoop.hive.serde2.objectinspector.StructObjectInspector;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.JobPriority;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;

public class TestPaths {
	private static ColumnarSerDe serde;
	static
	  {
	    try
	    {
	      Configuration conf = new Configuration();
	      Properties tbl = new Properties();

	      tbl.setProperty("serialization.format", "9");

	      tbl.setProperty("columns", "player_key,appid,episode,level,gameendsbefore,gameendsafter,dt");
	      tbl.setProperty("columns.types", "string:int:bigint:bigint:bigint:bigint:string");

	      tbl.setProperty("serialization.null.format", "NULL");

	      serde = new ColumnarSerDe();
	      serde.initialize(conf, tbl);

	      StructObjectInspector oi = (StructObjectInspector)serde.getObjectInspector();
	      List<? extends StructField> fieldRefs = oi.getAllStructFieldRefs();

	      for (StructField structField : fieldRefs) {
	        System.out.println("FIELD: " + structField.getFieldName());
	      }

	    }
	    catch (Exception e)
	    {
	      e.printStackTrace();
	      System.out.println("Failed to setup SERDE.");
	    }
	  }

		
		public static void main(String[] args)
		  {
			
			
			String start =args[2];
			String end = args[3];
		    JobConf conf = new JobConf(TestPaths.class);
		    conf.set("StartDate", start);
		    conf.set("EndDate", end);
		    conf.setJobName("TestPaths");
		   // conf.setMapRunnerClass(MultithreadedMapRunner.class);
		   // conf.setInt("mapred.map.multithreadedrunner.threads", 8);
		    conf.setMapOutputKeyClass(NullWritable.class);
		    conf.setMapOutputValueClass(NullWritable.class);
		     
		    conf.setMapperClass(TPathMapper.class);
		    
            conf.setNumReduceTasks(0);
		   // conf.setInputFormat(RCFileInputFormat.class);
		   conf.setInputFormat(CombineInputFormat.class);
		 
		    try
		    {
		      FileInputFormat.setInputPaths(conf, new Path[] { new Path(args[0]) });
		    	FileInputFormat.setInputPathFilter(conf, FilteredDateJob.class);
		    	
		      FileOutputFormat.setOutputPath(conf, new Path(args[1]));

		      conf.setJobPriority(JobPriority.VERY_HIGH);
		     
		      conf.setInt("hive.io.rcfile.column.number.conf", 8);

		     

		      JobClient.runJob(conf);
		    }
		    catch (IOException e) {
		      e.printStackTrace();
		    }
		  }
	
		
		 public static class TPathMapper extends MapReduceBase
		    implements Mapper<LongWritable, BytesRefArrayWritable, NullWritable, NullWritable>
		  {

			@Override
			public void map(LongWritable key, BytesRefArrayWritable value,
					OutputCollector<NullWritable, NullWritable> output,
					Reporter reporter) throws IOException {
				// TODO Auto-generated method stub
				//System.out.println(((FileSplit)reporter.getInputSplit()).getPath().toString());
				try{
				  StructObjectInspector oi = (StructObjectInspector)serde.getObjectInspector();
			        List fieldRefs = oi.getAllStructFieldRefs();

			        Object raw = serde.deserialize(value);

			        List dataStruct = oi.getStructFieldsDataAsList(raw);
				String parsedDate = dataStruct.get(6).toString();
		        byte[] keyBytes = dataStruct.get(0).toString().getBytes();
		        String keyString = new String(keyBytes);
				System.out.println("in mapper" +parsedDate);
				}catch(Exception e){
					e.printStackTrace();
				}
			}
			 
		  }

}
