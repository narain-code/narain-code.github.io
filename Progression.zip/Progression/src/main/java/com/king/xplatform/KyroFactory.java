package com.king.xplatform;

import java.io.Serializable;

import com.esotericsoftware.kryo.Kryo;

public class KyroFactory
  implements Serializable
{
  public transient Kryo kryo = null;

  public Kryo getKyro() {
    if (this.kryo == null) {
      this.kryo = new Kryo();
    }
    return this.kryo;
  }
}