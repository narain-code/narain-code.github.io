package com.king.xplatform.persistence;

import java.io.IOException;
import java.io.Serializable;
import java.util.Map;

public abstract class LocalPersistenceFactory
  implements Serializable
{
  public abstract LocalPersistence openPersistenceForRead(String paramString, Map paramMap)
    throws IOException;

  public abstract LocalPersistence openPersistenceForAppend(String paramString, Map paramMap)
    throws IOException;

  public abstract LocalPersistence createPersistence(String paramString, Map paramMap)
    throws IOException;

  public KeySorter getKeySorter()
  {
    return new IdentityKeySorter();
  }
}