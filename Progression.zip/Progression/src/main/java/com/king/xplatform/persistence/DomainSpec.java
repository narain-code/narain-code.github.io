package com.king.xplatform.persistence;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Writable;

public class DomainSpec
  implements Writable, Serializable
{
  private int _numShards;
  private LocalPersistenceFactory _localFact;
  public static final String DOMAIN_SPEC_FILENAME = "domain-spec.yaml";
  private static final String LOCAL_PERSISTENCE_CONF = "local_persistence";
  private static final String NUM_SHARDS_CONF = "num_shards";

  public DomainSpec()
  {
  }

  public DomainSpec(String factClass, int numShards)
  {
    this(Utils.classForName(factClass), numShards);
  }

  public DomainSpec(Class factClass, int numShards) {
    this((LocalPersistenceFactory)Utils.newInstance(factClass), numShards);
  }

  public DomainSpec(LocalPersistenceFactory localFact, int numShards) {
    this._localFact = localFact;
    this._numShards = numShards;
  }

  public String toString()
  {
    return mapify().toString();
  }

  public boolean equals(Object other)
  {
    DomainSpec o = (DomainSpec)other;
    return mapify().equals(o.mapify());
  }

  public int hashCode()
  {
    return mapify().hashCode();
  }

  public int getNumShards() {
    return this._numShards;
  }

  public LocalPersistenceFactory getLPFactory() {
    return this._localFact;
  }

  public static DomainSpec readFromFileSystem(FileSystem fs, String dirpath) throws IOException {
    Path filePath = new Path(dirpath + "/" + "domain-spec.yaml");
    if (!fs.exists(filePath)) {
      return null;
    }

    FSDataInputStream is = fs.open(filePath);
    DomainSpec ret = parseFromStream(is);
    is.close();
    return ret;
  }

  public static boolean exists(FileSystem fs, String dirpath) throws IOException {
    return fs.exists(new Path(dirpath + "/" + "domain-spec.yaml"));
  }

  public static DomainSpec parseFromStream(InputStream is)
  {
    Map format = new HashMap();

    format.put("local_persistence", "com.king.xplatform.persistence.MapFileDB");
    format.put("num_shards", new Integer(256));
    return parseFromMap(format);
  }

  protected static DomainSpec parseFromMap(Map<String, Object> specmap) {
    return new DomainSpec((String)specmap.get("local_persistence"), ((Integer)specmap.get("num_shards")).intValue());
  }

  public void writeToStream(OutputStream os)
  {
  }

  private Map<String, Object> mapify()
  {
    Map spec = new HashMap();
    spec.put("local_persistence", this._localFact.getClass().getName());
    spec.put("num_shards", Integer.valueOf(this._numShards));
    return spec;
  }

  public void writeToFileSystem(FileSystem fs, String dirpath)
    throws IOException
  {
  }

  public void write(DataOutput d)
    throws IOException
  {
  }

  public void readFields(DataInput di)
    throws IOException
  {
    Map format = new HashMap();

    format.put("local_persistence", "com.king.xplatform.persistence.MapFileDB");
    format.put("num_shards", new Integer(512));
    DomainSpec spec = parseFromMap(format);
    this._numShards = spec._numShards;
    this._localFact = spec._localFact;
  }
}