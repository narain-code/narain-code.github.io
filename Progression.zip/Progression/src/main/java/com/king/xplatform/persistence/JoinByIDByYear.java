package com.king.xplatform.persistence;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;

import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.SequenceFile;
import org.apache.hadoop.io.compress.GzipCodec;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.FileSplit;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.JobPriority;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Partitioner;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.Reporter;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.ByteBufferInput;
import com.esotericsoftware.kryo.io.ByteBufferOutput;
import com.esotericsoftware.kryo.io.Input;
import com.king.xplatform.KyroFactory;
import com.king.xplatform.MappedProgressionValue;
import com.king.xplatform.MultipleSequenceFileFormat;

public class JoinByIDByYear
{
  public static void main(String[] args)
  {
    JobConf conf = new JobConf(JoinByIDByYear.class);
    conf.setJobName("JoinByIDByYear");
    conf.setMapOutputKeyClass(LongWritable.class);
    conf.setMapOutputValueClass(BytesWritable.class);
    conf.setOutputKeyClass(LongWritable.class);
    conf.setOutputValueClass(BytesWritable.class);
    conf.setMapperClass(JoinByIDByYearMapper.class);

    conf.setReducerClass(JoinByIDByYearReducer.class);
    conf.setNumReduceTasks(512);
    conf.setCompressMapOutput(true);
    conf.setMapOutputCompressorClass(GzipCodec.class);
    conf.setPartitionerClass(JoinByIDByYearPartitioner.class);
    conf.setInputFormat(MultipleSequenceFileFormat.class);
  // conf.setInputFormat(SequenceFileInputFormat.class);
   
    conf.setOutputFormat(NamedOutputIDSequenceOutputFormat.class);
    try
    {
      FileInputFormat.setInputPaths(conf, new Path[] { new Path(args[0]) });
      FileOutputFormat.setOutputPath(conf, new Path(args[1]));

      conf.setJobPriority(JobPriority.VERY_HIGH);
      conf.set("mapred.child.java.opts", "-Xmx5G");
      conf.set("mapred.map.child.java.opts", "-Xmx5G");
      conf.set("mapreduce.reduce.java.opts", "-Xms2G -Xmx8G -XX:+UseCompressedOops -Xloggc:gc.log -XX:+PrintGCDetails -XX:+PrintGCDateStamps -XX:+PrintHeapAtGC -XX:+PrintTenuringDistribution -XX:PrintFLSStatistics=1 -XX:+PrintGCApplicationStoppedTime");
      conf.set("mapreduce.task.io.sort.mb", "1024");
      conf.setInt("io.sort.mb", 1024);
      conf.set("io.sort.spill.percent", "1.0");

      conf.setInt("mapred.inmem.merge.threshold", 0);
      conf.set("mapred.job.reduce.memory.mb", "2048");
      conf.setLong("mapred.min.split.size", 67108864L);
      conf.setLong("mapred.max.split.size", 268435456L);
      conf.setFloat("mapred.reduce.slowstart.completed.maps", 0.99F);
      conf.setInt("hive.io.rcfile.column.number.conf", 8);

      conf.setMemoryForReduceTask(2048L);
     // conf.setInt("dfs.replication", 1);

      JobClient.runJob(conf);
    }
    catch (IOException e) {
      e.printStackTrace();
    }
  }

  public static class JoinByIDByYearReducer extends MapReduceBase
    implements Reducer<LongWritable, BytesWritable, LongWritable, BytesWritable>
  {
    KyroFactory _factory = new KyroFactory();

    public void reduce(LongWritable key, Iterator<BytesWritable> values, OutputCollector<LongWritable, BytesWritable> output, Reporter reporter)
      throws IOException
    {
      Kryo kryo = this._factory.getKyro();

      MappedProgressionValue mergedValue = null;

      while (values.hasNext())
      {
        BytesWritable currVal = (BytesWritable)values.next();
        byte[] value = currVal.copyBytes();

        Input input = new Input(new ByteBufferInput(value));
        MappedProgressionValue someObject = (MappedProgressionValue)kryo.readObject(input, MappedProgressionValue.class);
        someObject.playerid = key.get();
        input.close();
        if (mergedValue == null) {
          mergedValue = someObject;
          if (mergedValue.allGroups == null)
            System.out.println("all Groups is null in first");
        }
        else {
          mergedValue.merge(someObject);
          if (mergedValue.allGroups == null) {
            System.out.println("all Groups is null in merge");
          }
        }
      }

      if (mergedValue != null) {
        if (mergedValue.allGroups == null)
          System.out.println("all Groups is null at the end");
        int currentSize = 512;
        ByteBufferOutput outputBuffer = new ByteBufferOutput(currentSize);
        boolean done = false;
        while (!done) {
          try {
            kryo.writeClassAndObject(outputBuffer, mergedValue);
            done = true;
          }
          catch (Exception e) {
            currentSize *= 2;
            outputBuffer = new ByteBufferOutput(currentSize);
          }
        }
        byte[] serialized = outputBuffer.toBytes();
        outputBuffer.close();

        output.collect(key, new BytesWritable(serialized));
      }
    }
  }

  public static class JoinByIDByYearPartitioner
    implements Partitioner<LongWritable, BytesWritable>
  {
    public int getPartition(LongWritable k2, BytesWritable v2, int numPartitions)
    {
     // long lV = Utils.deserializeLong(k2.writable);
     // String strKey = "" + lV;

     // return Utils.keyShard(strKey.getBytes(), numPartitions) % numPartitions;
    	return Utils.keyShard(k2.toString().getBytes(), numPartitions)% numPartitions;
    }

    public void configure(JobConf jc)
    {
    }
  }

  public static class JoinByIDByYearMapper extends MapReduceBase
    implements Mapper<BytesWritable, BytesWritable, LongWritable, BytesWritable>
  {
    HashMap<Integer, HashMap<BytesWritable, LongWritable>> cachedParts = new HashMap<Integer, HashMap<BytesWritable, LongWritable>>();
    JobConf conf;
    String source = "/tmp/narain/userkvstore01/part-";
    String indexPath="/tmp/narain/new_index/*-%d/data";
    int joinNumber = 100000;
    FileSystem fs = null;
    Path[] cacheFiles = null;
    int counter = 0;

    public void map(BytesWritable key, BytesWritable value, OutputCollector<LongWritable, BytesWritable> output, Reporter reporter)
      throws IOException
    {
      if (this.fs == null) {
        this.fs = ((FileSplit)reporter.getInputSplit()).getPath().getFileSystem(this.conf);
      }
      String fileSplitName = ((FileSplit)reporter.getInputSplit()).getPath().getParent().getName();
       if(fileSplitName.indexOf("--") == -1)
    	   fileSplitName = ((FileSplit)reporter.getInputSplit()).getPath().getName();
      int shardID = getShardID(fileSplitName, "--");
      HashMap<BytesWritable, LongWritable> toSearchIn;

      if (shardID != -1)
      {
       
       
        if (this.cachedParts.containsKey(Integer.valueOf(shardID))) {
          toSearchIn = (HashMap<BytesWritable, LongWritable>)this.cachedParts.get(Integer.valueOf(shardID));
        }
        else {
          int withShard = this.joinNumber + shardID;
          String partNumber = ("" + withShard).substring(1);

          toSearchIn = new HashMap<BytesWritable, LongWritable>();
          long startTime = System.currentTimeMillis();
          toSearchIn = parseSequenceFile(new Path(this.source + partNumber));
          this.cachedParts.put(Integer.valueOf(shardID), toSearchIn);
          long endTime = System.currentTimeMillis();
          System.out.println("Time taken  for sharID " + shardID + " :: " + (endTime - startTime));
          
          //read the rest of the new indexs under new index same chunk.
        }
      
        if(toSearchIn != null)
         processRecord(toSearchIn,key,value,output,reporter);
      }
    }

    
    public void processRecord(HashMap<BytesWritable, LongWritable> toSearchIn,
    							BytesWritable key, 
    							BytesWritable value, OutputCollector<LongWritable, BytesWritable> output, 
    							Reporter reporter) throws IOException{
    	
    	LongWritable primaryId = toSearchIn.get(key);
        if (primaryId != null)
        {
            
        	/* long lV = Utils.deserializeLong(primaryId);
             String strKey = "" + lV;

             System.out.println( strKey + "  "+Utils.keyShard(strKey.getBytes(), 512) % 512);*/
        	
        	output.collect(primaryId, value);
        	//output.collect(new MyBytesWritable(key), value);
        }
        else
        {
          reporter.getCounter(JoinByIDByYear.REJECTED_COUNTER.NOPRIMARY_ID).increment(1L);
          System.out.println(new String(key.getBytes()));
        }
    }
    
    
    
    public int getShardID(String fileName, String splitBy)
    {
      String[] splits = fileName.split(splitBy);
      if ((splits == null) || (splits.length == 0)) {
        return -1;
      }
      try
      {
        return Integer.parseInt(splits[1]);
      } catch (NumberFormatException nex) {
      }
      return -1;
    }

    public void configure(JobConf jc)
    {
      this.conf = jc;
    }

    public void close()
      throws IOException
    {
    }

    public HashMap<BytesWritable, LongWritable> parseSequenceFile(Path p)
      throws IOException
    {
      HashMap<BytesWritable, LongWritable> cachedData = new HashMap<BytesWritable, LongWritable>();
      SequenceFile.Reader reader = new SequenceFile.Reader(this.conf, new SequenceFile.Reader.Option[] { SequenceFile.Reader.file(p) });
      BytesWritable key = new BytesWritable();
      LongWritable value = new LongWritable();
      while (reader.next(key, value))
      {
       /* long l = Utils.deserializeLong(value.copyBytes());
        if (value.copyBytes().length > 8) {
          System.out.println(l + " " + value.copyBytes().length);
        }
        cachedData.put(key, new BytesWritable(value.copyBytes()));*/
    	  cachedData.put(key,value);
        key = new BytesWritable();
        value = new LongWritable();
      }
      return cachedData;
    }
    
    public void processNewChunk(int shardID,HashMap<BytesWritable, LongWritable> toSearchIn,
			 OutputCollector<LongWritable, BytesWritable> output, 
			Reporter reporter) throws IOException{
  	  Path p = new Path( String.format(indexPath, shardID));
  	SequenceFile.Reader reader = new SequenceFile.Reader(this.conf, new SequenceFile.Reader.Option[] { SequenceFile.Reader.file(p) });
    BytesWritable key = new BytesWritable();
    BytesWritable value = new BytesWritable();
    while (reader.next(key, value))
    {
    	processRecord(toSearchIn, key, value, output, reporter);
    }
    }
    
  }
  
  
 

  public static enum REJECTED_COUNTER
  {
    NOPRIMARY_ID;
  }
}