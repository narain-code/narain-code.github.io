package com.king.xplatform.persistence;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.ql.io.RCFileOutputFormat;
import org.apache.hadoop.hive.serde2.columnar.BytesRefArrayWritable;
import org.apache.hadoop.hive.serde2.columnar.BytesRefWritable;
import org.apache.hadoop.hive.serde2.columnar.ColumnarSerDe;
import org.apache.hadoop.hive.serde2.columnar.ColumnarStruct;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.StructField;
import org.apache.hadoop.hive.serde2.objectinspector.StructObjectInspector;
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.SequenceFile;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.compress.GzipCodec;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.FileSplit;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.JobPriority;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Partitioner;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.Reporter;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.ByteBufferInput;
import com.esotericsoftware.kryo.io.Input;
import com.king.xplatform.GroupKey;
import com.king.xplatform.GroupValue;
import com.king.xplatform.KyroFactory;
import com.king.xplatform.MappedProgressionValue;
import com.king.xplatform.MultipleSequenceFileFormat;
import com.king.xplatform.PartitionUserMapping;

public class JoinByIDProgression
{
  public static void main(String[] args)
  {
    JobConf conf = new JobConf(PartitionUserMapping.class);
    conf.setJobName("JoinByIDProgression");
    conf.setMapOutputKeyClass(BytesWritable.class);
    conf.setMapOutputValueClass(BytesWritable.class);
    conf.setOutputKeyClass(BytesWritable.class);
    conf.setOutputValueClass(BytesWritable.class);
    conf.setMapperClass(JoinMapper.class);

    conf.setReducerClass(JoinReducer.class);
    conf.setNumReduceTasks(1024);
    conf.setCompressMapOutput(true);
    conf.setMapOutputCompressorClass(GzipCodec.class);
    conf.setPartitionerClass(JoinPartitioner.class);
    conf.setInputFormat(MultipleSequenceFileFormat.class);

    conf.setOutputFormat(RCFileOutputFormat.class);

    RCFileOutputFormat.setCompressOutput(conf, true);
    RCFileOutputFormat.setOutputCompressorClass(conf, GzipCodec.class);
    try
    {
      FileInputFormat.setInputPaths(conf, new Path[] { new Path(args[0]) });
      FileOutputFormat.setOutputPath(conf, new Path(args[1]));

      conf.setJobPriority(JobPriority.VERY_HIGH);
      conf.set("mapred.child.java.opts", "-Xmx5G");
      conf.set("mapred.map.child.java.opts", "-Xmx5G");
      conf.set("mapreduce.reduce.java.opts", "-Xms2G -Xmx5G -XX:+UseCompressedOops -Xloggc:gc.log -XX:+PrintGCDetails -XX:+PrintGCDateStamps -XX:+PrintHeapAtGC -XX:+PrintTenuringDistribution -XX:PrintFLSStatistics=1 -XX:+PrintGCApplicationStoppedTime");
      conf.set("mapreduce.task.io.sort.mb", "1024");
      conf.setInt("io.sort.mb", 1024);
      conf.set("io.sort.spill.percent", "1.0");

      conf.set("mapred.job.reduce.memory.mb", "2048");
      conf.setLong("mapred.min.split.size", 67108864L);
      conf.setLong("mapred.max.split.size", 268435456L);
      conf.setFloat("mapred.reduce.slowstart.completed.maps", 0.97F);
      conf.setInt("hive.io.rcfile.column.number.conf", 8);

      conf.setMemoryForReduceTask(2048L);
      conf.setInt("dfs.replication", 1);

      JobClient.runJob(conf);
    }
    catch (IOException e) {
      e.printStackTrace();
    }
  }

  public static class JoinReducer extends MapReduceBase
    implements Reducer<BytesWritable, BytesWritable, NullWritable, BytesRefArrayWritable>
  {
    KyroFactory _factory = new KyroFactory();
    NullWritable nullW = NullWritable.get();
    private static ColumnarSerDe serde;
    final String emptyString = "";

    int keyCounter = 0;

    public void reduce(BytesWritable key, Iterator<BytesWritable> values, OutputCollector<NullWritable, BytesRefArrayWritable> output, Reporter reporter)
      throws IOException
    {
      Kryo kryo = this._factory.getKyro();

      long lV = Utils.deserializeLong(key);
      this.keyCounter += 1;
      if (this.keyCounter > 1605940) {
        System.out.println(lV);
      }
      MappedProgressionValue mergedValue = null;

      while (values.hasNext())
      {
        byte[] value = ((BytesWritable)values.next()).getBytes();

        Input input = new Input(new ByteBufferInput(value));
        MappedProgressionValue someObject = (MappedProgressionValue)kryo.readObject(input, MappedProgressionValue.class);

        if (mergedValue == null) {
          mergedValue = someObject;
          if (mergedValue.allGroups == null)
            System.out.println("all Groups is null in first");
        }
        else {
          mergedValue.merge(someObject);
          if (mergedValue.allGroups == null) {
            System.out.println("all Groups is null in merge");
          }

        }

      }

      Iterator it = mergedValue.allGroups.entrySet().iterator();
      while (it.hasNext()) {
        Map.Entry n = (Map.Entry)it.next();
        GroupKey _gKey = (GroupKey)n.getKey();
        GroupValue _gValue = (GroupValue)n.getValue();
        try
        {
          BytesRefArrayWritable bytes = new BytesRefArrayWritable(8);
          bytes.set(0, new BytesRefWritable(("" + lV).getBytes("UTF-8")));
          bytes.set(1, new BytesRefWritable(("" + _gKey.appId).getBytes("UTF-8")));
          bytes.set(2, new BytesRefWritable(("" + _gKey.episode).getBytes("UTF-8")));
          bytes.set(3, new BytesRefWritable(("" + _gKey.level).getBytes("UTF-8")));
          bytes.set(4, new BytesRefWritable(("" + _gValue.gameendsbefore).getBytes("UTF-8")));
          bytes.set(5, new BytesRefWritable(("" + _gValue.gameendsafter).getBytes("UTF-8")));
          bytes.set(6, new BytesRefWritable(_gValue.firstPlay.getBytes()));
          if (_gValue.successDate != null)
            bytes.set(7, new BytesRefWritable(_gValue.successDate.getBytes()));
          else
            bytes.set(7, new BytesRefWritable("".getBytes()));
          ObjectInspector inspector = serde.getObjectInspector();
          ArrayList notSkipped = new ArrayList();
          ColumnarStruct colStruct = new ColumnarStruct(inspector, notSkipped, new Text(""));
          colStruct.init(bytes);
          output.collect(this.nullW, (BytesRefArrayWritable)serde.serialize(colStruct, inspector));
        }
        catch (Exception e)
        {
          e.printStackTrace();
        }
      }
    }

    static
    {
      try
      {
        Configuration conf = new Configuration();
        Properties tbl = new Properties();

        tbl.setProperty("serialization.format", "9");

        tbl.setProperty("columns", "player_id,appid,episode,level,gameendsbefore,gameendsafter,firstplaydt,successdt");
        tbl.setProperty("columns.types", "bigint:int:bigint:bigint:bigint:bigint:string:string");

        tbl.setProperty("serialization.null.format", "NULL");

        serde = new ColumnarSerDe();
        serde.initialize(conf, tbl);

        StructObjectInspector oi = (StructObjectInspector)serde.getObjectInspector();
        List<? extends StructField> fieldRefs = oi.getAllStructFieldRefs();

        for (StructField structField : fieldRefs) {
          System.out.println("FIELD: " + structField.getFieldName());
        }

      }
      catch (Exception e)
      {
        e.printStackTrace();
        System.out.println("Failed to setup SERDE.");
      }
    }
  }

  public static class JoinPartitioner
    implements Partitioner<BytesWritable, BytesWritable>
  {
    public int getPartition(BytesWritable k2, BytesWritable v2, int numPartitions)
    {
      return Utils.keyShard(k2.getBytes(), numPartitions) % numPartitions;
    }

    public void configure(JobConf jc)
    {
    }
  }

  public static class JoinMapper extends MapReduceBase
    implements Mapper<BytesWritable, BytesWritable, BytesWritable, BytesWritable>
  {
    HashMap<Integer, HashMap<BytesWritable, BytesWritable>> cachedParts = new HashMap();
    JobConf conf;
    String source = "/tmp/narain/userkvstore01/part-";
    int joinNumber = 100000;
    FileSystem fs = null;
    Path[] cacheFiles = null;
    int counter = 0;

    public void map(BytesWritable key, BytesWritable value, OutputCollector<BytesWritable, BytesWritable> output, Reporter reporter)
      throws IOException
    {
      if (this.fs == null) {
        this.fs = ((FileSplit)reporter.getInputSplit()).getPath().getFileSystem(this.conf);
      }
      String fileSplitName = ((FileSplit)reporter.getInputSplit()).getPath().getName();

      int shardID = getShardID(fileSplitName, "--");
      HashMap toSearchIn;
      if (shardID != -1)
      {
       
      
        if (this.cachedParts.containsKey(Integer.valueOf(shardID))) {
          toSearchIn = (HashMap)this.cachedParts.get(Integer.valueOf(shardID));
        }
        else {
          int withShard = this.joinNumber + shardID;
          String partNumber = ("" + withShard).substring(1);

          toSearchIn = new HashMap();
          long startTime = System.currentTimeMillis();
          toSearchIn = parseSequenceFile(new Path(this.source + partNumber));
          this.cachedParts.put(Integer.valueOf(shardID), toSearchIn);
          long endTime = System.currentTimeMillis();
          System.out.println("Time taken  for sharID " + shardID + " :: " + (endTime - startTime));
        }

        BytesWritable primaryId = (BytesWritable)toSearchIn.get(key);
        if ((primaryId != null) && (primaryId.getLength() > 0))
        {
          output.collect(primaryId, value);
        }
        else
        {
          reporter.getCounter(JoinByIDProgression.REJECTED_COUNTER.NOPRIMARY_ID).increment(1L);
        }
      }
    }

    public int getShardID(String fileName, String splitBy)
    {
      String[] splits = fileName.split(splitBy);
      if ((splits == null) || (splits.length == 0)) {
        return -1;
      }
      try
      {
        return Integer.parseInt(splits[1]);
      } catch (NumberFormatException nex) {
      }
      return -1;
    }

    public void configure(JobConf jc)
    {
      this.conf = jc;
    }

    public void close()
      throws IOException
    {
    }

    public HashMap<BytesWritable, BytesWritable> parseSequenceFile(Path p)
      throws IOException
    {
      HashMap cachedData = new HashMap();
      SequenceFile.Reader reader = new SequenceFile.Reader(this.conf, new SequenceFile.Reader.Option[] { SequenceFile.Reader.file(p) });
      BytesWritable key = new BytesWritable();
      BytesWritable value = new BytesWritable();
      while (reader.next(key, value))
      {
        cachedData.put(key, value);
        key = new BytesWritable();
        value = new BytesWritable();
      }
      return cachedData;
    }
  }

  public static enum REJECTED_COUNTER
  {
    NOPRIMARY_ID;
  }
}