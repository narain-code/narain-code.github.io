package com.king.xplatform;

import java.util.concurrent.CyclicBarrier;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

import com.king.xplatform.persistence.JoinByIDByYear;

public class Driver {
	
	public static void main(String[] args){
		
	        CyclicBarrierJobs instance = new CyclicBarrierJobs();
	        try {
	        	
				instance.init(args);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	   
		
		//1.1 export and merge
		
		// 2.1 __ join by id 
		
		// 2.2 -- join by id
		//3.1.merge for 2011 and 12
		//3.2. merge for 2013 and 14.
		
	}
	
	 
	
	public static class CyclicBarrierJobs {
	    // create a cyclic barrier that will wait for three calls before
	    // unlocking
	    private static final int NO_OF_THREADS = 2;
	    private CyclicBarrier barrier = new CyclicBarrier(NO_OF_THREADS);
	 
	    
	 
	    public void init(String[] args) throws InterruptedException {
	        // create three threads that will call await on the cyclic barrier
	           
	            
	            Thread th = new Thread(new MyWorkerThread1(args), "Worker1" );
	            th.start();
	            
	            Thread th2 = new Thread(new MyWorkerThread2(args), "Worker1" );
	            th2.start();
	 
	        
	    }
	 
	   
	    private class MyWorkerThread1 implements Runnable {
	    	
	    	String[] args;
	    	
	    	public MyWorkerThread1(String[] args){
	    		this.args = args;
	    	}
	    	
	        @Override
	        public void run() {
	            System.out.println("Thread started");
	            
	 
	            try {
	            	System.out.println("User mapping started");
	            	args= new String[2];
	            	args[0]="/warehouse/hive/xplatform.db/usermapping";
	            	args[1]="/tmp/narain/userkvstore01";
	            	 Configuration conf = new Configuration();
						FileSystem fs = FileSystem.get(conf);
						Path p=new Path("/tmp/narain/userkvstore01");
						 if(fs.exists(p)){
							 fs.delete(p, true);
						 }
	            	PartitionUserMapping.main(args);
	                barrier.await();
	                args = new String[2];
	                args[0]="/tmp/narain/new_mapkvstore2011";
	                args[1]="/tmp/narain/new_map2011_byID";
	                System.out.println("Job by ID 2011 started");
	               
					 p=new Path("/tmp/narain/new_map2011_byID");
					 if(fs.exists(p)){
						 fs.delete(p, true);
					 }
					JoinByIDByYear.main(args);	 
	                barrier.await();
	                System.out.println("Job by ID 2013 started");
	                args = new String[2];
	                args[0]="/tmp/narain/new_mapkvstore2013";
	                args[1]="/tmp/narain/new_map2013_byID";
	                p=new Path("/tmp/narain/new_map2013_byID");
					 if(fs.exists(p)){
						 fs.delete(p, true);
					 }
					JoinByIDByYear.main(args);	
	                barrier.await();
	                System.out.println("Merge Job by ID 2011-12 started");
	                args = new String[3];
	                args[0]="/tmp/narain/new_map2011_byID";
	                args[1]="/tmp/narain/new_map2012_byID";
	                args[2]="/tmp/narain/new_mergedbyID2011-12";
	                p=new Path("/tmp/narain/new_mergedbyID2011-12");
					 if(fs.exists(p)){
						 fs.delete(p, true);
					 }
					 MergeIDBasedProgessing.main(args);
	                barrier.await();
	                System.out.println("Merge RC Job by ID 2011-12-13-14 started");
	                args = new String[3];
	                args[0]="/tmp/narain/new_mergedbyID2011-12";
	                args[1]="/tmp/narain/new_mergedbyID2013-14";
	                args[2]="/tmp/narain/new_mergedRC";
	                p=new Path("/tmp/narain/new_mergedRC");
					 if(fs.exists(p)){
						 fs.delete(p, true);
					 }
	                MergeAndRCFileByID.main(args);
	                System.out.println("Done");
	                
	            } catch (InterruptedException  e) {
	                e.printStackTrace();
	            }catch(Exception ex){
	            	ex.printStackTrace();
	            }
	 
	            System.out.println("Barrier unlocked");
	        }
	    }
	    
	    
	    private class MyWorkerThread2 implements Runnable {
	    	
	    	String[] args;
	    	public MyWorkerThread2(String[] args){
	    		this.args = args;
	    	}
	    	
	        @Override
	        public void run() {
	            System.out.println("Thread started");
	            
	 
	            try {
	            	System.out.println("Export and Merge started");
	            	 Configuration conf = new Configuration();
						FileSystem fs = FileSystem.get(conf);
	            	ExportAndMerge.main(args);
	                barrier.await();
	                System.out.println("Job by ID 2012 started");
	                args = new String[2];
	                args[0]="/tmp/narain/new_mapkvstore2012";
	                args[1]="/tmp/narain/new_map2012_byID";
	                Path p=new Path("/tmp/narain/new_map2012_byID");
					 if(fs.exists(p)){
						 fs.delete(p, true);
					 }
					JoinByIDByYear.main(args);
	                barrier.await();
	                System.out.println("Job by ID 2014 started");
	                args = new String[2];
	                args[0]="/tmp/narain/new_mapkvstore2014";
	                args[1]="/tmp/narain/new_map2014_byID";
	                p=new Path("/tmp/narain/new_map2014_byID");
					 if(fs.exists(p)){
						 fs.delete(p, true);
					 }
					JoinByIDByYear.main(args);
	                barrier.await();
	                System.out.println("Merge Job by ID 2013-14 started");
	                args = new String[3];
	                args[0]="/tmp/narain/new_map2013_byID";
	                args[1]="/tmp/narain/new_map2014_byID";
	                args[2]="/tmp/narain/new_mergedbyID2013-14";
	                p=new Path("/tmp/narain/new_mergedbyID2013-14");
					 if(fs.exists(p)){
						 fs.delete(p, true);
					 }
					 MergeIDBasedProgessing.main(args);
	                barrier.await();
	               // System.out.println("Merge RC Job by ID 2011-12-13-14 started");
	                System.out.println("Done");
	                
	            } catch (Exception  e) {
	                e.printStackTrace();
	            }
	 
	            System.out.println("Barrier unlocked");
	        }
	    }
	}


}
