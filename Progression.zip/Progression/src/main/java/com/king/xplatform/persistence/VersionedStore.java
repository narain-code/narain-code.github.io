package com.king.xplatform.persistence;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.LocalFileSystem;
import org.apache.hadoop.fs.Path;

public class VersionedStore
{
  private static final String FINISHED_VERSION_SUFFIX = ".version";
  private String _root;
  private FileSystem _fs;

  public VersionedStore(String path)
    throws IOException
  {
    this(Utils.getFS(path, new Configuration()), path);
  }

  public VersionedStore(FileSystem fs, String path) throws IOException {
    this._fs = fs;
    this._root = path;
    mkdirs(this._root);
  }

  public FileSystem getFileSystem() {
    return this._fs;
  }

  public String getRoot() {
    return this._root;
  }

  public String versionPath(long version) {
    return new Path(this._root, "" + version).toString();
  }

  public String mostRecentVersionPath() throws IOException {
    Long v = mostRecentVersion();
    if (v == null) return null;
    return versionPath(v.longValue());
  }

  public String mostRecentVersionPath(long maxVersion) throws IOException {
    Long v = mostRecentVersion(maxVersion);
    if (v == null) return null;
    return versionPath(v.longValue());
  }

  public Long mostRecentVersion() throws IOException {
    List all = getAllVersions();
    if (all.size() == 0) return null;
    return (Long)all.get(0);
  }

  public Long mostRecentVersion(long maxVersion) throws IOException {
    List<Long> all = getAllVersions();
    for (Long v : all) {
      if (v.longValue() <= maxVersion) return v;
    }
    return null;
  }

  public String createVersion() throws IOException {
    return createVersion(System.currentTimeMillis());
  }

  public String createVersion(long version) throws IOException {
    String ret = versionPath(version);
    if (getAllVersions().contains(Long.valueOf(version))) {
      throw new RuntimeException("Version already exists or data already exists");
    }

    this._fs.delete(new Path(versionPath(version)), true);
    return ret;
  }

  public void failVersion(String path) throws IOException
  {
    deleteVersion(validateAndGetVersion(path));
  }

  public void deleteVersion(long version) throws IOException {
    this._fs.delete(new Path(versionPath(version)), true);
    this._fs.delete(new Path(tokenPath(version)), false);
  }

  public void succeedVersion(String path) throws IOException {
    long version = validateAndGetVersion(path);
    createNewFile(tokenPath(version));
  }

  public void cleanup() throws IOException {
    cleanup(-1);
  }

  public void cleanup(int versionsToKeep) throws IOException {
    List versions = getAllVersions();
    if (versionsToKeep >= 0) {
      versions = versions.subList(0, Math.min(versions.size(), versionsToKeep));
    }
    HashSet keepers = new HashSet(versions);

    for (Path p : listDir(this._root)) {
      Long v = parseVersion(p.toString());
      if ((v != null) && (!keepers.contains(v)))
        this._fs.delete(p, true);
    }
  }

  public List<Long> getAllVersions()
    throws IOException
  {
    List ret = new ArrayList();
    for (Path p : listDir(this._root)) {
      if (p.getName().endsWith(".version")) {
        ret.add(Long.valueOf(validateAndGetVersion(p.toString())));
      }
    }
    Collections.sort(ret);
    Collections.reverse(ret);
    return ret;
  }

  public boolean hasVersion(long version) throws IOException {
    return getAllVersions().contains(Long.valueOf(version));
  }

  private String tokenPath(long version) {
    return new Path(this._root, "" + version + ".version").toString();
  }

  private Path normalizePath(String p) {
    return new Path(p).makeQualified(this._fs);
  }

  private long validateAndGetVersion(String path) {
    if (!normalizePath(path).getParent().equals(normalizePath(this._root))) {
      throw new RuntimeException(path + " " + new Path(path).getParent() + " is not part of the versioned store located at " + this._root);
    }
    Long v = parseVersion(path);
    if (v == null) throw new RuntimeException(path + " is not a valid version");
    return v.longValue();
  }

  private Long parseVersion(String path) {
    String name = new Path(path).getName();
    if (name.endsWith(".version"))
      name = name.substring(0, name.length() - ".version".length());
    try
    {
      return Long.valueOf(Long.parseLong(name)); } catch (NumberFormatException e) {
    }
    return null;
  }

  private void createNewFile(String path) throws IOException
  {
    if ((this._fs instanceof LocalFileSystem))
      new File(path).createNewFile();
    else
      this._fs.createNewFile(new Path(path));
  }

  private void mkdirs(String path) throws IOException {
    if ((this._fs instanceof LocalFileSystem))
      new File(path).mkdirs();
    else
      this._fs.mkdirs(new Path(path));
  }

  private List<Path> listDir(String dir) throws IOException
  {
    List ret = new ArrayList();
    if ((this._fs instanceof LocalFileSystem)) {
      for (File f : new File(dir).listFiles())
        ret.add(new Path(f.getAbsolutePath()));
    }
    else {
      for (FileStatus fs : this._fs.listStatus(new Path(dir))) {
        ret.add(fs.getPath());
      }
    }
    return ret;
  }
}