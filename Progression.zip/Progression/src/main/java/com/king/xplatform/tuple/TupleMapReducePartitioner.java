package com.king.xplatform.tuple;

import org.apache.hadoop.conf.Configurable;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.mapreduce.Partitioner;

public class TupleMapReducePartitioner extends Partitioner<Tuple, Object>
  implements Configurable
{
  private Configuration conf;
  private TuplePartitioner partitioner;

  public void setConf(Configuration conf)
  {
    this.partitioner = new TuplePartitioner(conf);
    this.conf = conf;
  }

  public Configuration getConf()
  {
    return this.conf;
  }

  public int getPartition(Tuple key, Object value, int numPartitions)
  {
    return this.partitioner.getPartition(key, numPartitions);
  }
}