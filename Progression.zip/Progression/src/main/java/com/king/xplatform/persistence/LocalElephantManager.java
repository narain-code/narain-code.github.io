package com.king.xplatform.persistence;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.io.FileUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

public class LocalElephantManager
{
  public static final String TMP_DIRS_CONF = "elephantdb.local.tmp.dirs";
  FileSystem _fs;
  File _dirFlag;
  String _localRoot;
  DomainSpec _spec;
  Map<String, Object> _persistenceOptions;

  public static void setTmpDirs(Configuration conf, List<String> dirs)
  {
    conf.setStrings("elephantdb.local.tmp.dirs", (String[])dirs.toArray(new String[dirs.size()]));
  }

  public static List<String> getTmpDirs(Configuration conf)
  {
    String[] res = conf.get("mapred.local.dir").split(",");
    List ret = new ArrayList();
    if (res.length == 0)
      ret.add("/fjord/tmp");
    else {
      for (String s : res) {
        ret.add(s);
      }
    }
    return ret;
  }

  public LocalElephantManager(FileSystem fs, DomainSpec spec, Map<String, Object> persistenceOptions, List<String> tmpDirs)
    throws IOException
  {
    this._localRoot = selectAndFlagRoot(tmpDirs);
    this._fs = fs;
    this._spec = spec;
    this._persistenceOptions = persistenceOptions;
  }

  public String downloadRemoteShard(String id, String remotePath)
    throws IOException
  {
    LocalPersistenceFactory fact = this._spec.getLPFactory();
    String returnDir = localTmpDir(id);
    if ((remotePath == null) || (!this._fs.exists(new Path(remotePath)))) {
      fact.createPersistence(returnDir, this._persistenceOptions).close();
    }
    else
    {
      System.out.println("@@@ start local copy");
      this._fs.copyToLocalFile(new Path(remotePath), new Path(returnDir));
      Collection<File> crcs = FileUtils.listFiles(new File(returnDir), new String[] { "crc" }, true);
      for (File crc : crcs) {
        FileUtils.forceDelete(crc);
      }
    }
    return returnDir;
  }

  public String localTmpDir(String id) {
    return this._localRoot + "/" + id;
  }

  public void progress() {
    this._dirFlag.setLastModified(System.currentTimeMillis());
  }

  public void cleanup() throws IOException
  {
    FileSystem.getLocal(new Configuration()).delete(new Path(this._localRoot), true);
    this._dirFlag.delete();
  }

  private void clearStaleFlags(List<String> tmpDirs)
  {
    for (String tmp : tmpDirs) {
      File flagDir = new File(flagDir(tmp));
      flagDir.mkdirs();
      for (File flag : flagDir.listFiles())
        if (flag.lastModified() < System.currentTimeMillis() - 3600000L)
          flag.delete();
    }
  }

  private String flagDir(String tmpDir)
  {
    return tmpDir + "/flags";
  }

  private String selectAndFlagRoot(List<String> tmpDirs) throws IOException
  {
    clearStaleFlags(tmpDirs);
    Map<String, Integer> flagCounts = new HashMap<String, Integer>();
    for (String tmp : tmpDirs) {
      File flagDir = new File(flagDir(tmp));
      flagDir.mkdirs();
      flagCounts.put(tmp, Integer.valueOf(flagDir.list().length));
    }
    String best = null;
    Integer bestCount = null;
    for (Map.Entry e : flagCounts.entrySet()) {
      if ((best == null) || (((Integer)e.getValue()).intValue() < bestCount.intValue())) {
        best = (String)e.getKey();
        bestCount = (Integer)e.getValue();
      }
    }
    String token = UUID.randomUUID().toString();
    System.out.println("@@@@@@@@ dir before" + best);
    this._dirFlag = new File(flagDir(best) + "/" + token);
    this._dirFlag.createNewFile();
    new File(best).mkdirs();

    return best + "/" + token;
  }
}