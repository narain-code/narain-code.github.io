package com.king.xplatform.persistence;

import java.io.IOException;
import java.util.Map;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.MapFile;
import org.apache.hadoop.io.SequenceFile;
import org.apache.hadoop.io.compress.GzipCodec;
import org.apache.hadoop.util.Progressable;
import org.apache.log4j.Logger;

public class MapFileDB extends LocalPersistenceFactory
{
  public static Logger LOG = Logger.getLogger(MapFileDB.class);

  public LocalPersistence openPersistenceForRead(String root, Map options) throws IOException
  {
    try
    {
      return new MapDBPersistence(root, options, true);
    } catch (Exception e) {
      e.printStackTrace();
      throw new IOException(e.getMessage());
    }
  }

  public LocalPersistence openPersistenceForAppend(String root, Map options) throws IOException
  {
    try {
      return new MapDBPersistence(root, options, false);
    } catch (Exception e) {
      e.printStackTrace();
      throw new IOException(e.getMessage());
    }
  }

  public LocalPersistence createPersistence(String root, Map options) throws IOException
  {
    try {
      return new MapDBPersistence(root, options, false);
    } catch (Exception e) {
      e.printStackTrace();
      throw new IOException(e.getMessage());
    }
  }
  public static class MapDBPersistence implements LocalPersistence {
    MapFile.Writer writer;
    String root;

    public MapDBPersistence(String root, Map options, boolean readOnly) throws Exception { System.out.println("@@@@@ Map" + root);

      if (options.get("oldVersion") == null) {
        root = (String)options.get("newVersion");

        String token = options.get("SHARDID").toString();
        root = root.concat("--" + token);
        this.root = root;
      }
      Configuration conf = (Configuration)options.get("CONF");
      FileSystem fs = (FileSystem)options.get("FS");
      this.writer = new MapFile.Writer(conf, fs, root, BytesWritable.class, BytesWritable.class, SequenceFile.CompressionType.BLOCK, new GzipCodec(), (Progressable)options.get("progressable"));
    }

    public byte[] get(byte[] key)
      throws IOException
    {
      return null;
    }

    public void add(byte[] key, byte[] value)
      throws IOException
    {
     
     
    	this.writer.append(new BytesWritable(key), new BytesWritable(value));
    	
    	
    }

    public void close()
      throws IOException
    {
      this.writer.close();
    }

    public CloseableIterator<LocalPersistence.KeyValuePair> iterator()
    {
      return null;
    }
  }
}