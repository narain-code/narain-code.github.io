package com.king.xplatform;

import java.io.IOException;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapred.SequenceFileInputFormat;
import org.apache.hadoop.mapred.TextOutputFormat;

public class FindUser {
	
	public static void main(String[] args)
		    throws IOException
		  {
		    JobConf conf = new JobConf(FindUser.class);

		    conf.setInputFormat(SequenceFileInputFormat.class);
		    conf.setOutputFormat(TextOutputFormat.class);
		    conf.setMapperClass(Row10Mapper.class);
		    conf.setMapOutputKeyClass(Text.class);
		    conf.setMapOutputValueClass(Text.class);
		    conf.setNumReduceTasks(0);

		    FileInputFormat.setInputPaths(conf, new Path[] { new Path(args[0]) });

		    FileOutputFormat.setOutputPath(conf, new Path(args[1]));

		    if (args.length >= 3) {
		     // System.out.println(Long.parseLong(args[2]));
		      conf.set("searchString",args[2]);
		      
		    }

		    JobClient.runJob(conf);
		  }

		  public static class Row10Mapper extends MapReduceBase
		    implements Mapper<BytesWritable, LongWritable, Text, NullWritable>
		  {
		    NullWritable nvl = NullWritable.get();
		    String searchingFor;
		    long i = 0L;

		    public void map(BytesWritable key, LongWritable value, OutputCollector<Text, NullWritable> output, Reporter reporter)
		      throws IOException
		    {
		      

		    	output.collect(new Text(key.getBytes()),nvl);
		      if( (new String(key.getBytes())).equalsIgnoreCase(this.searchingFor)){
		    	  System.out.println("Success");
		        return;
		      
		      }
		    }

		    public void configure(JobConf jc)
		    {
		      this.searchingFor = jc.get("searchString");
		    }

		    public void close()
		      throws IOException
		    {
		    }
		  }

}
