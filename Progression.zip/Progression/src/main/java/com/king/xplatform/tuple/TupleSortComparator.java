package com.king.xplatform.tuple;

public class TupleSortComparator extends TupleComparator
{
  public String getIndexConfigName()
  {
    return "org.htuple.sorting.indexes";
  }
}