package com.king.xplatform.persistence;

import java.io.IOException;

import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.compress.GzipCodec;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.RecordWriter;
import org.apache.hadoop.mapred.SequenceFileOutputFormat;
import org.apache.hadoop.mapred.lib.MultipleSequenceFileOutputFormat;
import org.apache.hadoop.util.Progressable;

public class NamedOutputIDSequenceOutputFormat<K, V> extends MultipleSequenceFileOutputFormat<K, V>
{
  private SequenceFileOutputFormat<K, V> theSequenceFileOutputFormat = null;

  protected String generateFileNameForKeyValue(K key, V value, String name)
  {
   /* if (((BytesWritable)key).getLength() == 0) {
      System.out.println("0 length");
      return "ID--0--" + name;
    }

    System.out.println(((BytesWritable)key).getLength());
    long lV = Utils.deserializeLong((BytesWritable)key);
    String strKey = "" + lV;

    int shardId = Utils.keyShard(strKey.getBytes(), 512) % 512;*/
	  
	  int shardId = Utils.keyShard(((LongWritable)key).toString().getBytes(), 512) % 512;
    return "ID--" + shardId + "--" + name;
  }

  protected RecordWriter<K, V> getBaseRecordWriter(FileSystem fs, JobConf job, String name, Progressable arg3)
    throws IOException
  {
    if (this.theSequenceFileOutputFormat == null) {
      this.theSequenceFileOutputFormat = new SequenceFileOutputFormat();
      SequenceFileOutputFormat.setCompressOutput(job, true);
      SequenceFileOutputFormat.setOutputCompressorClass(job, GzipCodec.class);
    }
    return this.theSequenceFileOutputFormat.getRecordWriter(fs, job, name, arg3);
  }
}