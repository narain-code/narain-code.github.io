package com.king.xplatform;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapred.TextInputFormat;
import org.apache.hadoop.mapred.TextOutputFormat;
import org.apache.hadoop.mapred.lib.MultipleInputs;

import com.king.xplatform.tuple.ShuffleUtils;
import com.king.xplatform.tuple.Tuple;

public class BlockMerge
{
  public static void main(String[] args)
    throws IOException, InterruptedException, ClassNotFoundException
  {
    JobConf conf = new JobConf(BlockMerge.class);
    conf.setJobName("BlockMerge");
    ShuffleUtils.configBuilder().useOldApi().setPartitionerIndices(new Enum[] { TupleKeyFields.PLAYER_KEY }).setSortIndices(TupleKeyFields.values()).setGroupIndices(TupleKeyFields.values()).configure(conf);

    conf.setMapOutputKeyClass(Tuple.class);
    conf.setMapOutputValueClass(Tuple.class);

    conf.setOutputKeyClass(Text.class);
    conf.setOutputValueClass(Text.class);

    conf.setMapperClass(MergeMapper.class);
    conf.setReducerClass(ReduceMerger.class);
    conf.setNumReduceTasks(128);

    conf.setInputFormat(TextInputFormat.class);

    conf.setLong("mapred.min.split.size", 67108864L);
    conf.setLong("mapred.max.split.size", 268435456L);
    conf.setOutputFormat(TextOutputFormat.class);
    System.out.println(args[0]);

    MultipleInputs.addInputPath(conf, new Path(args[0]), TextInputFormat.class);
    MultipleInputs.addInputPath(conf, new Path(args[1]), TextInputFormat.class);
    FileOutputFormat.setOutputPath(conf, new Path(args[2]));

    JobClient.runJob(conf);
  }

  public static class ReduceMerger extends MapReduceBase
    implements Reducer<Tuple, Tuple, Text, Text>
  {
    public void reduce(Tuple key, Iterator<Tuple> value, OutputCollector<Text, Text> output, Reporter arg3)
      throws IOException
    {
      try
      {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

        Date date1 = null;
        String date1String = null;
        Date date2 = null;
        String date2String = "";
        long gameendsbefore = 0L;
        long gameendsafter = 0L;
        while (value.hasNext()) {
          Tuple records = (Tuple)value.next();
          if ((date1 == null) && (!records.getString(BlockMerge.TupleValueFields.FIRSTPLAYDATE).isEmpty())) {
            date1String = records.getString(BlockMerge.TupleValueFields.FIRSTPLAYDATE);
            date1 = format.parse(date1String);
          } else {
            String currentDateString = records.getString(BlockMerge.TupleValueFields.FIRSTPLAYDATE);
            Date current = format.parse(records.getString(BlockMerge.TupleValueFields.FIRSTPLAYDATE));
            boolean after = current.after(date1);
            if (!after)
            {
              date1String = currentDateString;
              date1 = current;
            }
          }

          if ((date2 == null) && (!records.getString(BlockMerge.TupleValueFields.SUCCESSDATE).isEmpty())) {
            date2String = records.getString(BlockMerge.TupleValueFields.SUCCESSDATE);
            date2 = format.parse(date2String);
          }
          else if (!records.getString(BlockMerge.TupleValueFields.SUCCESSDATE).isEmpty()) {
            String currentDate2String = records.getString(BlockMerge.TupleValueFields.SUCCESSDATE);
            Date current = format.parse(currentDate2String);
            boolean after = current.after(date2);
            if (!after)
            {
              date2String = currentDate2String;
              date2 = current;
            }

          }

        }

        Text val = new Text(gameendsbefore + "\t" + gameendsafter + "\t" + date1String + "\t" + date2String);
        output.collect(new Text(key.toString()), val);
      } catch (Exception e) {
        throw new RuntimeException("exception in reducer " + e.getMessage(), e);
      }
    }
  }

  public static class MergeMapper extends MapReduceBase
    implements Mapper<LongWritable, Text, Tuple, Tuple>
  {
    public void map(LongWritable key, Text value, OutputCollector<Tuple, Tuple> output, Reporter report)
      throws IOException
    {
      Tuple outputKey = new Tuple();
      Tuple outputValue = new Tuple();
      String[] splits = value.toString().split("\t");

      outputKey.set(BlockMerge.TupleKeyFields.PLAYER_KEY, splits[0]);
      outputKey.set(BlockMerge.TupleKeyFields.APP_ID, Integer.valueOf(Integer.parseInt(splits[1])));
      outputKey.set(BlockMerge.TupleKeyFields.EPISODE, Long.valueOf(splits[2]));
      outputKey.set(BlockMerge.TupleKeyFields.LEVEL, Long.valueOf(splits[3]));
      if ((splits[4] == null) || ("".equalsIgnoreCase(splits[4])))
        outputValue.set(BlockMerge.TupleValueFields.GAMEENDSBEFORE, Long.valueOf(0L));
      else
        outputValue.set(BlockMerge.TupleValueFields.GAMEENDSBEFORE, Long.valueOf(splits[4]));
      if ((splits[5] == null) || ("".equalsIgnoreCase(splits[5])))
        outputValue.set(BlockMerge.TupleValueFields.GAMEENDSAFTER, Long.valueOf(0L));
      else {
        outputValue.set(BlockMerge.TupleValueFields.GAMEENDSAFTER, Long.valueOf(splits[5]));
      }
      if ((splits[6] != null) || (splits[6] != ""))
        outputValue.set(BlockMerge.TupleValueFields.FIRSTPLAYDATE, splits[6]);
      else
        outputValue.set(BlockMerge.TupleValueFields.FIRSTPLAYDATE, "");
      if (splits.length < 8) {
        outputValue.set(BlockMerge.TupleValueFields.SUCCESSDATE, "");
      }
      else if ((splits[7] != null) || (splits[7] != ""))
        outputValue.set(BlockMerge.TupleValueFields.SUCCESSDATE, splits[7]);
      else {
        outputValue.set(BlockMerge.TupleValueFields.SUCCESSDATE, "");
      }

      output.collect(outputKey, outputValue);
    }
  }

  public static enum TupleValueFields
  {
    GAMEENDSBEFORE, 
    GAMEENDSAFTER, 
    FIRSTPLAYDATE, 
    SUCCESSDATE;
  }

  public static enum TupleKeyFields
  {
    PLAYER_KEY, 
    APP_ID, 
    EPISODE, 
    LEVEL;
  }
}