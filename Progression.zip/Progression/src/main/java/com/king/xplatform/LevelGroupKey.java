package com.king.xplatform;

import java.util.Arrays;

public class LevelGroupKey
{
  public int appId;
 public String levelKey;

  public int getAppId()
  {
    return this.appId;
  }
  public void setAppId(int appId) {
    this.appId = appId;
  }
  public String getLevelKey() {
    return this.levelKey;
  }
  public void setLevelKey(String level) {
    this.levelKey = level;
  }
  

  public int hashCode() {
    Object[] val = new Object[2];
    val[0] = Integer.valueOf(this.appId);
    val[1] = this.levelKey;
   
    return Arrays.hashCode(val);
  }

  public boolean equals(Object object) {
    if (!(object instanceof LevelGroupKey)) {
      return false;
    }
    LevelGroupKey otherKey = (LevelGroupKey)object;
    if (otherKey.appId != this.appId)
      return false;
    
    if (otherKey.levelKey != this.levelKey)
      return false;
    return true;
  }
}