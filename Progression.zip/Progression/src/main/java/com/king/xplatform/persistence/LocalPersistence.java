package com.king.xplatform.persistence;

import java.io.IOException;

public abstract interface LocalPersistence extends Iterable
{
  public abstract byte[] get(byte[] paramArrayOfByte)
    throws IOException;

  public abstract void add(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
    throws IOException;

  public abstract void close()
    throws IOException;

  public abstract CloseableIterator<KeyValuePair> iterator();

  public static class KeyValuePair
  {
    public byte[] key;
    public byte[] value;

    public KeyValuePair(byte[] key, byte[] value)
    {
      this.key = key;
      this.value = value;
    }
  }
}