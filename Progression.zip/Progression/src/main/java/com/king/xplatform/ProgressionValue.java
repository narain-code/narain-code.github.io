package com.king.xplatform;

public class ProgressionValue
{
  public String firstPlay;
  public String successDate;
  public int episode;
  public int level;
  public int appid;
  public long gameendsbefore;
  public long gameendsafter;

  public int getLevel()
  {
    return this.level;
  }

  public void setLevel(int level) {
    this.level = level;
  }

  public int getAppid() {
    return this.appid;
  }

  public void setAppid(int appid) {
    this.appid = appid;
  }

  public long getGameendsbefore() {
    return this.gameendsbefore;
  }

  public void setGameendsbefore(long gameendsbefore) {
    this.gameendsbefore = gameendsbefore;
  }

  public long getGameendsafter() {
    return this.gameendsafter;
  }

  public void setGameendsafter(long gameendsafter) {
    this.gameendsafter = gameendsafter;
  }

  public String getFirstPlay() {
    return this.firstPlay;
  }

  public void setFirstPlay(String firstPlay) {
    this.firstPlay = firstPlay;
  }

  public String getSuccessDate() {
    return this.successDate;
  }

  public void setSuccessDate(String successDate) {
    this.successDate = successDate;
  }

  public int getEpisode() {
    return this.episode;
  }

  public void setEpisode(int episode) {
    this.episode = episode;
  }
}