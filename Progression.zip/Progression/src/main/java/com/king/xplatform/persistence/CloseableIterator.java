package com.king.xplatform.persistence;

import java.io.Closeable;
import java.util.Iterator;

public abstract interface CloseableIterator<T> extends Iterator<T>, Closeable
{
}