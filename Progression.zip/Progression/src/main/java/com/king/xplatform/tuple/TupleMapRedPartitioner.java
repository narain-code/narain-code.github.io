package com.king.xplatform.tuple;

import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.Partitioner;

public class TupleMapRedPartitioner
  implements Partitioner<Tuple, Object>
{
  private TuplePartitioner partitioner;

  public void configure(JobConf job)
  {
    this.partitioner = new TuplePartitioner(job);
  }

  public int getPartition(Tuple key, Object value, int numPartitions)
  {
    return this.partitioner.getPartition(key, numPartitions);
  }
}