package com.king.xplatform;

import java.io.IOException;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.serde2.columnar.BytesRefArrayWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.mapred.InputSplit;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.JobContext;
import org.apache.hadoop.mapred.RecordReader;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapred.lib.CombineFileInputFormat;
import org.apache.hadoop.mapred.lib.CombineFileSplit;

public class CombineInputFormat extends CombineFileInputFormat<LongWritable, BytesRefArrayWritable>
{
	Path currentPath;
  public CombineInputFormat(){
	  super();
	 //setMaxSplitSize(134217728); // 128 MB
	// setMaxSplitSize(268435456); // 256 MB
	 setMaxSplitSize(536870912);// 512 MB
	 
  }
  public RecordReader<LongWritable, BytesRefArrayWritable> getRecordReader(InputSplit split, JobConf job, Reporter reporter)
    throws IOException
  {
    return new CombineReader(job, ((CombineFileSplit)split));
  }
  
  
  protected boolean isSplitable(JobContext context, Path file){
	   this.currentPath = file;
	    return false;
	  }
}