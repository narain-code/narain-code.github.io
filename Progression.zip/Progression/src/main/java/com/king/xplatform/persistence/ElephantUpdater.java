package com.king.xplatform.persistence;

import java.io.IOException;
import java.io.Serializable;

public abstract interface ElephantUpdater extends Serializable
{
  public abstract void updateElephant(LocalPersistence paramLocalPersistence, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
    throws IOException;
}