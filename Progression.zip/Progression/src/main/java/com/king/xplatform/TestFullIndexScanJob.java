package com.king.xplatform;

import java.io.IOException;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.compress.GzipCodec;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapred.FileOutputFormat;



public class TestFullIndexScanJob {
	
	public static void main(String[] args){
		try{
			JobConf conf = new JobConf(TestFullIndexScanJob.class);
			 conf.setJobName("Test Full Scan");
			 FileInputFormat.setInputPaths(conf, new Path[] { new Path(args[0]) });
			  conf.setMapOutputKeyClass(NullWritable.class);
		 	    conf.setMapOutputValueClass(NullWritable.class);
		 	   
		 	    conf.setMapperClass(TestMapper.class);

		 
		 	    conf.setNumReduceTasks(0);
		 	    conf.setCompressMapOutput(true);
		 	    conf.setMapOutputCompressorClass(GzipCodec.class);
		 	   conf.setInputFormat(MultipleSequenceFileFormat.class);
		 	   FileOutputFormat.setOutputPath(conf, new Path(args[1]));
		 	  JobClient.runJob(conf);
		}catch(Exception exp){
			exp.printStackTrace();
		}
	}
	
	public static class TestMapper extends MapReduceBase implements Mapper<BytesWritable, BytesWritable, NullWritable, NullWritable>{
		
		 NullWritable nullOut = NullWritable.get();
		 
		@Override
		public void map(BytesWritable key, BytesWritable value,
				OutputCollector<NullWritable, NullWritable> output,
				Reporter reporter) throws IOException {
			// TODO Auto-generated method stub
			System.out.println(new String(key.copyBytes()));
			output.collect(nullOut, nullOut);
			
		}
		
	}

}
