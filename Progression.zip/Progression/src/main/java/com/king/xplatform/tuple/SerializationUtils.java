package com.king.xplatform.tuple;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Map;

import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.WritableUtils;

public class SerializationUtils
{
  public static final int NULL_ELEMENT_TYPE = 9;
  private static final Map<Class, TupleElementSerializer> staticTupleElementWriters = new IdentityHashMap();
  private static final Map<Integer, TupleElementSerializer> staticElementIdWriters = new HashMap();

  private static void populateSerializationDetails(Class clazz, TupleElementSerializer serializer) {
    staticTupleElementWriters.put(clazz, serializer);
    staticElementIdWriters.put(Integer.valueOf(serializer.getElementTypeId()), serializer);
  }

  public static void write(DataOutput stream, Object element)
    throws IOException
  {
    Class elementClass;

    if (element == null)
      elementClass = NullWritable.class;
    else {
      elementClass = element.getClass();
    }

    TupleElementSerializer serializer = (TupleElementSerializer)staticTupleElementWriters.get(elementClass);
    if (serializer == null) {
      throw new IllegalArgumentException("Unsupported type: " + elementClass.getName());
    }

    serializer.write(stream, element);
  }

  public static Object read(DataInput stream) throws IOException
  {
    int type = WritableUtils.readVInt(stream);

    TupleElementSerializer serializer = (TupleElementSerializer)staticElementIdWriters.get(Integer.valueOf(type));
    if (serializer == null) {
      throw new IllegalArgumentException("Unsupported type: " + type);
    }

    return serializer.read(stream);
  }

  static
  {
    populateSerializationDetails(String.class, new TupleElementSerializer()
    {
      public void write(DataOutput stream, Object element) throws IOException {
        WritableUtils.writeVInt(stream, getElementTypeId());
        WritableUtils.writeString(stream, (String)element);
      }

      public Object read(DataInput stream) throws IOException
      {
        return WritableUtils.readString(stream);
      }

      public int getElementTypeId()
      {
        return 1;
      }
    });
    populateSerializationDetails(Float.class, new TupleElementSerializer()
    {
      public void write(DataOutput stream, Object element) throws IOException {
        WritableUtils.writeVInt(stream, getElementTypeId());
        stream.writeFloat(((Float)element).floatValue());
      }

      public Object read(DataInput stream) throws IOException
      {
        return Float.valueOf(stream.readFloat());
      }

      public int getElementTypeId()
      {
        return 2;
      }
    });
    populateSerializationDetails(Double.class, new TupleElementSerializer()
    {
      public void write(DataOutput stream, Object element) throws IOException {
        WritableUtils.writeVInt(stream, getElementTypeId());
        stream.writeDouble(((Double)element).doubleValue());
      }

      public Object read(DataInput stream) throws IOException
      {
        return Double.valueOf(stream.readDouble());
      }

      public int getElementTypeId()
      {
        return 3;
      }
    });
    populateSerializationDetails(Integer.class, new TupleElementSerializer()
    {
      public void write(DataOutput stream, Object element) throws IOException {
        WritableUtils.writeVInt(stream, getElementTypeId());
        WritableUtils.writeVInt(stream, ((Integer)element).intValue());
      }

      public Object read(DataInput stream) throws IOException
      {
        return Integer.valueOf(WritableUtils.readVInt(stream));
      }

      public int getElementTypeId()
      {
        return 4;
      }
    });
    populateSerializationDetails(Long.class, new TupleElementSerializer()
    {
      public void write(DataOutput stream, Object element) throws IOException {
        WritableUtils.writeVInt(stream, getElementTypeId());
        WritableUtils.writeVLong(stream, ((Long)element).longValue());
      }

      public Object read(DataInput stream) throws IOException
      {
        return Long.valueOf(WritableUtils.readVLong(stream));
      }

      public int getElementTypeId()
      {
        return 5;
      }
    });
    populateSerializationDetails(Boolean.class, new TupleElementSerializer()
    {
      public void write(DataOutput stream, Object element) throws IOException {
        WritableUtils.writeVInt(stream, getElementTypeId());
        stream.writeBoolean(((Boolean)element).booleanValue());
      }

      public Object read(DataInput stream) throws IOException
      {
        return Boolean.valueOf(stream.readBoolean());
      }

      public int getElementTypeId()
      {
        return 6;
      }
    });
    populateSerializationDetails(Short.class, new TupleElementSerializer()
    {
      public void write(DataOutput stream, Object element) throws IOException {
        WritableUtils.writeVInt(stream, getElementTypeId());
        stream.writeShort(((Short)element).shortValue());
      }

      public Object read(DataInput stream) throws IOException
      {
        return Short.valueOf(stream.readShort());
      }

      public int getElementTypeId()
      {
        return 7;
      }
    });
    populateSerializationDetails(BytesWritable.class, new TupleElementSerializer()
    {
      public void write(DataOutput stream, Object element) throws IOException {
        WritableUtils.writeVInt(stream, getElementTypeId());
        ((BytesWritable)element).write(stream);
      }

      public Object read(DataInput stream) throws IOException
      {
        BytesWritable writable = new BytesWritable();
        writable.readFields(stream);
        return writable;
      }

      public int getElementTypeId()
      {
        return 8;
      }
    });
    populateSerializationDetails(NullWritable.class, new TupleElementSerializer()
    {
      public void write(DataOutput stream, Object element) throws IOException {
        WritableUtils.writeVInt(stream, getElementTypeId());
      }

      public Object read(DataInput stream) throws IOException
      {
        return null;
      }

      public int getElementTypeId()
      {
        return 9;
      }
    });
  }

  protected static abstract interface TupleElementSerializer
  {
    public abstract void write(DataOutput paramDataOutput, Object paramObject)
      throws IOException;

    public abstract Object read(DataInput paramDataInput)
      throws IOException;

    public abstract int getElementTypeId();
  }
}