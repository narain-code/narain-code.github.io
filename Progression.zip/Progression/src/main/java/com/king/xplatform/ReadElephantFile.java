package com.king.xplatform;

import java.io.IOException;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapred.SequenceFileInputFormat;
import org.apache.hadoop.mapred.TextOutputFormat;

import com.king.xplatform.persistence.ElephantInputFormat;
import com.king.xplatform.persistence.Utils;

public class ReadElephantFile
{
  public static void main(String[] args)
    throws IOException
  {
    JobConf conf = new JobConf(ReadElephantFile.class);
    ElephantInputFormat.Args arg = new ElephantInputFormat.Args(args[0]);

    //conf.setInputFormat(MultipleSequenceFileFormat.class);
    conf.setInputFormat(SequenceFileInputFormat.class);
    conf.setOutputFormat(TextOutputFormat.class);
    conf.setMapperClass(EMapper.class);
    conf.setMapOutputKeyClass(Text.class);
    conf.setMapOutputValueClass(NullWritable.class);
    conf.setNumReduceTasks(0);
    Utils.setObject(conf, "elephant.output.args", arg);
    FileInputFormat.setInputPaths(conf, new Path[] { new Path(args[0]) });

    FileOutputFormat.setOutputPath(conf, new Path(args[1]));

    JobClient.runJob(conf);
  }

  public static class EMapper extends MapReduceBase
    implements Mapper<BytesWritable, BytesWritable, Text, NullWritable>
  {
	  
	  public static enum FOUND_COUNTER
	  {
	    FOUND,
	    notfound
	  }
	  
    NullWritable nullWriter = NullWritable.get();

    public void map(BytesWritable key, BytesWritable value, OutputCollector<Text, NullWritable> output, Reporter reporter)
      throws IOException
    {
     
       String pd=new String(key.copyBytes());
      if(pd.equalsIgnoreCase("fffe49a7e1f114af95e52311")){
    	  System.out.println("Success");
    	  reporter.getCounter(FOUND_COUNTER.FOUND).increment(1L);
    	  output.collect(new Text(key.getBytes()), this.nullWriter);
    	  
      } else
    	  reporter.getCounter(FOUND_COUNTER.notfound).increment(1L);
    }

    public void configure(JobConf jc)
    {
    }

    public void close()
      throws IOException
    {
    }
  }
}