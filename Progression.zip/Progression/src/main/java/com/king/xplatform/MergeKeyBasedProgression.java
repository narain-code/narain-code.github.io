package com.king.xplatform;

import java.io.IOException;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.compress.GzipCodec;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.FileSplit;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.JobPriority;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapred.join.CompositeInputFormat;
import org.apache.hadoop.mapred.join.CompositeInputSplit;
import org.apache.hadoop.mapred.join.TupleWritable;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.ByteBufferOutput;
import com.esotericsoftware.kryo.io.Input;
import com.king.xplatform.persistence.NamedOutputSequenceOutputFormat;

public class MergeKeyBasedProgression {
	

	  public static void main(String[] args)
	  {
	    JobConf conf = new JobConf(MergeKeyBasedProgression.class);
	    conf.setJobName("MergeKeyBasedProgression");
	    conf.setMapOutputKeyClass(BytesWritable.class);
	    conf.setMapOutputValueClass(BytesWritable.class);
	    conf.setOutputKeyClass(BytesWritable.class);
	    conf.setOutputValueClass(BytesWritable.class);
	    conf.setMapperClass(MergeKeyMapper.class);

	    conf.setNumReduceTasks(0);
	    conf.setCompressMapOutput(true);
	    conf.setMapOutputCompressorClass(GzipCodec.class);

	    conf.setInputFormat(CompositeInputFormat.class);
	    String strJoinStmt = CompositeInputFormat.compose("outer", MultipleSequenceFileFormat.class, new String[] { args[0], args[1] });

	    conf.set("mapred.join.expr", strJoinStmt);
	    conf.setOutputFormat(NamedOutputSequenceOutputFormat.class);
	    try
	    {
	      FileOutputFormat.setOutputPath(conf, new Path(args[2]));

	      conf.setJobPriority(JobPriority.VERY_HIGH);
	      conf.set("mapred.child.java.opts", "-Xmx5G");
	      conf.set("mapred.map.child.java.opts", "-Xmx5G");
	      conf.set("mapreduce.reduce.java.opts", "-Xms1G -Xmx2G -XX:+UseCompressedOops -Xloggc:gc.log -XX:+PrintGCDetails -XX:+PrintGCDateStamps -XX:+PrintHeapAtGC -XX:+PrintTenuringDistribution -XX:PrintFLSStatistics=1 -XX:+PrintGCApplicationStoppedTime");
	      conf.set("mapreduce.task.io.sort.mb", "1024");
	      conf.setInt("io.sort.mb", 1024);
	      conf.set("io.sort.spill.percent", "1.0");
	      conf.set("mapred.job.reduce.memory.mb", "2048");
	      conf.setLong("mapred.min.split.size", 67108864L);
	      conf.setLong("mapred.max.split.size", 268435456L);

	      conf.setInt("dfs.replication", 1);

	      JobClient.runJob(conf);
	    }
	    catch (IOException e) {
	      e.printStackTrace();
	    }
	  }

	  public static class MergeKeyMapper extends MapReduceBase	
	    implements Mapper<LongWritable, TupleWritable, LongWritable, BytesWritable>
	  {
	    KyroFactory _factory = new KyroFactory();
	    String toMerge = null;
	    int shardID = -1;
	    JobConf conf;

	    public int getShardID(String fileName, String splitBy)
	    {
	      String[] splits = fileName.split(splitBy);
	      if ((splits == null) || (splits.length == 0)) {
	        return -1;
	      }
	      try
	      {
	        return Integer.parseInt(splits[1]);
	      } catch (NumberFormatException nex) {
	      }
	      return -1;
	    }

	    public void configure(JobConf job)
	    {
	      this.conf = job;
	    }

	     MappedProgressionValue previous_left = null;
	     
	    public void map(LongWritable key, TupleWritable value, OutputCollector<LongWritable, BytesWritable> output, Reporter reporter)
	      throws IOException
	    {
	      boolean merge = true;
	      String parentName1 = ((FileSplit)((CompositeInputSplit)reporter.getInputSplit()).get(0)).getPath().getName();
	      String parentName2 = ((FileSplit)((CompositeInputSplit)reporter.getInputSplit()).get(1)).getPath().getName();
	     // System.out.println(parentName1 + " -- " + parentName2);

	      int shardId = getShardID(parentName1, "--");
	      if (shardId != this.shardID) {
	        this.conf.setInt("shardID", shardId);
	        this.shardID = shardId;
	      }

	      Kryo kryo = this._factory.getKyro();
	      BytesWritable firstValue = (BytesWritable)value.get(0);

	      BytesWritable secondValue = (BytesWritable)value.get(1);

	      if ((firstValue != null) && (firstValue.getBytes().length > 0) && (secondValue != null) && (secondValue.getBytes().length > 0)) {
	        byte[] fByte = firstValue.getBytes();
	        Input input = new Input(fByte.length * 2);
	        input.setBuffer(fByte, 0, fByte.length);

	        //MappedProgressionValue someObject = (MappedProgressionValue)kryo.readObject(input, MappedProgressionValue.class);
	        MappedProgressionValue someObject =(MappedProgressionValue)kryo.readClassAndObject(input);
	        input.close();
	        
	        if(previous_left != null && someObject.playerid.longValue() ==previous_left.playerid.longValue())
	        	merge = false;
	        else
	        	 previous_left = someObject;
	        if(!merge)
	        	System.out.println("not merge "+ someObject.playerid+" :: " +previous_left.playerid);
	       
	        byte[] sByte = secondValue.getBytes();
	        Input input2 = new Input(sByte);
	        MappedProgressionValue mergedObject = null;

	        mergedObject = (MappedProgressionValue)kryo.readClassAndObject(input2);

	        input2.close();
	        if(merge)
	          mergedObject.merge(someObject);
	        int currentSize = 512;
	        ByteBufferOutput outputBuffer = new ByteBufferOutput(currentSize);
	        boolean done = false;
	        while (!done) {
	          try {
	            kryo.writeClassAndObject(outputBuffer, mergedObject);
	            done = true;
	          }
	          catch (Exception e) {
	            currentSize *= 2;
	            outputBuffer = new ByteBufferOutput(currentSize);
	          }
	        }
	        byte[] serialized = outputBuffer.toBytes();
	        outputBuffer.close();
	        output.collect(key, new BytesWritable(serialized));
	      }
	      else if ((firstValue == null) || (firstValue.getBytes().length == 0)) {
	        output.collect(key, secondValue);
	      } else {
	        output.collect(key, firstValue);
	      }
	    }
	  }
	

}
