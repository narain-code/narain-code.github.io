package com.king.xplatform;

import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.ql.io.RCFileOutputFormat;
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.compress.GzipCodec;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.JobPriority;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Partitioner;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapred.SequenceFileInputFormat;
import org.apache.hadoop.mapred.SequenceFileOutputFormat;
import org.apache.hadoop.mapred.lib.MultipleInputs;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.ByteBufferInput;
import com.esotericsoftware.kryo.io.ByteBufferOutput;
import com.esotericsoftware.kryo.io.Input;
import com.king.xplatform.persistence.Utils;




public class MergeNewIndex {
	
	public static void main(String[] args)
	  {
	    JobConf conf = new JobConf(MergeNewIndex.class);
	    conf.setJobName("MergeNewIndex");
	    conf.setMapOutputKeyClass(LongWritable.class);
	    conf.setMapOutputValueClass(BytesWritable.class);
	   
	    conf.setMapperClass(NewIndexIDRCMapper.class);

	    conf.setReducerClass(NewIndexIDRCReducer.class);
	    conf.setNumReduceTasks(512);
	    conf.setCompressMapOutput(true);
	    conf.setMapOutputCompressorClass(GzipCodec.class);
	    conf.setPartitionerClass(NewIndexIDRCPartitioner.class);
	    conf.setCombinerClass(NewIndexbyIDRCCombiner.class);
	   // conf.setInputFormat(MultipleSequenceFileFormat.class);
	   conf.setInputFormat(SequenceFileInputFormat.class);
	   
	   // conf.setOutputFormat(NamedOutputIDSequenceOutputFormat.class);
	    conf.setOutputFormat(SequenceFileOutputFormat.class);
	    RCFileOutputFormat.setCompressOutput(conf, true);
	    RCFileOutputFormat.setOutputCompressorClass(conf, GzipCodec.class);
	    try
	    {
	      //FileInputFormat.setInputPaths(conf, new Path[] { new Path(args[0]) });
	    	 MultipleInputs.addInputPath(conf, new Path(args[0]), SequenceFileInputFormat.class);
	    	//MultipleInputs.addInputPath(conf, new Path(args[0]), MultipleSequenceFileFormat.class);
	    	
	      FileOutputFormat.setOutputPath(conf, new Path(args[1]));

	      conf.setJobPriority(JobPriority.VERY_HIGH);
	      conf.set("mapred.child.java.opts", "-Xmx5G");
	      conf.set("mapred.map.child.java.opts", "-Xmx5G");
	      conf.set("mapreduce.reduce.java.opts", "-Xms2G -Xmx8G -XX:+UseCompressedOops -Xloggc:gc.log -XX:+PrintGCDetails -XX:+PrintGCDateStamps -XX:+PrintHeapAtGC -XX:+PrintTenuringDistribution -XX:PrintFLSStatistics=1 -XX:+PrintGCApplicationStoppedTime");
	      conf.set("mapreduce.task.io.sort.mb", "1024");
	      conf.setInt("io.sort.mb", 1024);
	      conf.set("io.sort.spill.percent", "1.0");

	      conf.setInt("mapred.inmem.merge.threshold", 0);
	      conf.set("mapred.job.reduce.memory.mb", "2048");
	      conf.setLong("mapred.min.split.size", 67108864L);
	      conf.setLong("mapred.max.split.size", 268435456L);
	      conf.setFloat("mapred.reduce.slowstart.completed.maps", 0.99F);
	      conf.setInt("hive.io.rcfile.column.number.conf", 9);

	      conf.setMemoryForReduceTask(2048L);
	      conf.setInt("dfs.replication", 3);

	      JobClient.runJob(conf);
	    }
	    catch (IOException e) {
	      e.printStackTrace();
	    }
	  }
	
	 public static class NewIndexbyIDRCCombiner extends MapReduceBase
	    implements Reducer<LongWritable, BytesWritable, LongWritable,BytesWritable>
	 {
		 KyroFactory _factory = new KyroFactory();

		    public void reduce(LongWritable key, Iterator<BytesWritable> values, OutputCollector<LongWritable, BytesWritable> output, Reporter reporter)
		      throws IOException
		    {
		      Kryo kryo = this._factory.getKyro();

		      MappedProgressionValue mergedValue = null;

		      while (values.hasNext())
		      {
		        BytesWritable currVal = (BytesWritable)values.next();
		        byte[] value = currVal.copyBytes();

		        Input input = new Input(new ByteBufferInput(value));
		        MappedProgressionValue someObject = (MappedProgressionValue)kryo.readObject(input,MappedProgressionValue.class);
		        someObject.playerid = key.get();
		        input.close();
		        if (mergedValue == null) {
		          mergedValue = someObject;
		          if (mergedValue.allGroups == null)
		            System.out.println("all Groups is null in first");
		        }
		        else {
		          mergedValue.merge(someObject);
		          if (mergedValue.allGroups == null) {
		            System.out.println("all Groups is null in merge");
		          }
		        }
		      }

		      if (mergedValue != null) {
		    	  int currentSize = 512;
		          ByteBufferOutput outputBuffer = new ByteBufferOutput(currentSize);
		          boolean done = false;
		          while (!done) {
		            try {
		              kryo.writeObject(outputBuffer, mergedValue);
		              done = true;
		            }
		            catch (Exception e) {
		              currentSize *= 2;
		              outputBuffer = new ByteBufferOutput(currentSize);
		            }
		          }
		          byte[] serialized = outputBuffer.toBytes();
		          outputBuffer.close();

		          output.collect(key, new BytesWritable(serialized));
		      }
		 
	 }
	 }

	 
	 public static class NewIndexIDRCReducer extends MapReduceBase
	    implements Reducer<BytesWritable, BytesWritable, BytesWritable, BytesWritable>
	  {
	    KyroFactory _factory = new KyroFactory();

	    public void reduce(BytesWritable key, Iterator<BytesWritable> values, OutputCollector<BytesWritable, BytesWritable> output, Reporter reporter)
	      throws IOException
	    {
	      Kryo kryo = this._factory.getKyro();

	      MappedProgressionValue mergedValue = null;

	      while (values.hasNext())
	      {
	        BytesWritable currVal = (BytesWritable)values.next();
	        byte[] value = currVal.copyBytes();

	        Input input = new Input(new ByteBufferInput(value));
	        MappedProgressionValue someObject = ( MappedProgressionValue)kryo.readObject(input,MappedProgressionValue.class);
	        
	        input.close();
	        if (mergedValue == null) {
	          mergedValue = someObject;
	          if (mergedValue.allGroups == null)
	            System.out.println("all Groups is null in first");
	        }
	        else {
	          mergedValue.merge(someObject);
	          if (mergedValue.allGroups == null) {
	            System.out.println("all Groups is null in merge");
	          }
	        }
	      }

	      if (mergedValue != null) {
	    	  int currentSize = 512;
	          ByteBufferOutput outputBuffer = new ByteBufferOutput(currentSize);
	          boolean done = false;
	          while (!done) {
	            try {
	              kryo.writeObject(outputBuffer, mergedValue);
	              done = true;
	            }
	            catch (Exception e) {
	              currentSize *= 2;
	              outputBuffer = new ByteBufferOutput(currentSize);
	            }
	          }
	          byte[] serialized = outputBuffer.toBytes();
	          outputBuffer.close();

	          output.collect(key, new BytesWritable(serialized));
	        
	      }
	    }
	  }
	 
	 
	 public static class NewIndexIDRCPartitioner
	    implements Partitioner<LongWritable, BytesWritable>
	  {
	    public int getPartition(LongWritable k2, BytesWritable v2, int numPartitions)
	    {
	     // long lV = Utils.deserializeLong(k2.writable);
	     // String strKey = "" + lV;

	     // return Utils.keyShard(strKey.getBytes(), numPartitions) % numPartitions;
	    	return Utils.keyShard(k2.toString().getBytes(), numPartitions)% numPartitions;
	    }

	    public void configure(JobConf jc)
	    {
	    }
	  }
	 
	 public static class NewIndexIDRCMapper extends MapReduceBase
	    implements Mapper<BytesWritable, BytesWritable, BytesWritable, BytesWritable>
	  {
	    
	    public void map(BytesWritable key, BytesWritable value, OutputCollector<BytesWritable, BytesWritable> output, Reporter reporter)
	      throws IOException
	    {
	    	output.collect(key, value);
	    }
	  }
}
