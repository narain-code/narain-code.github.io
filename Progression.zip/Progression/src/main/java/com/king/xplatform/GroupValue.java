package com.king.xplatform;

public class GroupValue
{
  public String firstPlay;
  public String successDate;
  public String lastPlayDate;
  
public long gameendsbefore;
  public long gameendsafter;

  public String getFirstPlay()
  {
    return this.firstPlay;
  }
  public void setFirstPlay(String firstPlay) {
    this.firstPlay = firstPlay;
  }
  public String getSuccessDate() {
    return this.successDate;
  }
  public void setSuccessDate(String successDate) {
    this.successDate = successDate;
  }
  public long getGameendsbefore() {
    return this.gameendsbefore;
  }
  public void setGameendsbefore(long gameendsbefore) {
    this.gameendsbefore = gameendsbefore;
  }
  public long getGameendsafter() {
    return this.gameendsafter;
  }
  public void setGameendsafter(long gameendsafter) {
    this.gameendsafter = gameendsafter;
  }
  public String getLastPlayDate() {
		return lastPlayDate;
	}
	public void setLastPlayDate(String lastPlayDate) {
		this.lastPlayDate = lastPlayDate;
	}
}