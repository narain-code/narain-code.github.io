package com.king.xplatform;

import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.mapred.SequenceFileInputFormat;

public class MultipleSequenceFileFormat<K, V> extends SequenceFileInputFormat<K, V>
{
  protected boolean isSplitable(FileSystem fs, Path filename)
  {
    return false;
  }
}