package com.king.xplatform.tuple;

public class TupleGroupingComparator extends TupleComparator
{
  public String getIndexConfigName()
  {
    return "org.htuple.grouping.indexes";
  }
}