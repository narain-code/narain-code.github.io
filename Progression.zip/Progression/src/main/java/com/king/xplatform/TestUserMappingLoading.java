package com.king.xplatform;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.WeakHashMap;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.SequenceFile;
import org.nustaq.offheap.FSTLongOffheapMap;

import com.king.xplatform.persistence.OHMap;

public class TestUserMappingLoading {

	
	public static void main(String[] args){
		try{
			
			 Configuration conf = new Configuration();
			 FileSystem fs = FileSystem.get(conf);
			 Path p = new Path(args[0]);
			//fs.copyToLocalFile(src, dst);
			 
			 for(int loaded=1;loaded<3;loaded++){
			 //Map cachedData = new OHMap<byte[], Long>(13);
			 Map cachedData = new HashMap<BytesWritable, LongWritable>();
			
			 SequenceFile.Reader reader = new SequenceFile.Reader(conf, new SequenceFile.Reader.Option[] { SequenceFile.Reader.file(p) });
		      BytesWritable key = new BytesWritable();
		      LongWritable value = new LongWritable(1);
		      int i=0,n=0;
		      while (reader.next(key, value) && i < (6500000*loaded))
		     // while (reader.next(key, value))
		      {
		    	  if(i <(6500000*(loaded -1)) ){
		    		   i++;
		    		   continue;
		    	  }
		    		  
		    	  if(value != null){
		       /* long l = Utils.deserializeLong(value.copyBytes());
		        if (value.copyBytes().length > 8) {
		          System.out.println(l + " " + value.copyBytes().length);
		        }
		        cachedData.put(key, new BytesWritable(value.copyBytes()));*/
		    	  //cachedData.put(key.copyBytes(),value.get());
		    	  cachedData.put(key, value);
		    	  
		        key = new BytesWritable();
		        value = new LongWritable(1);
		    	  }
		    	  else System.out.println("value is null "+ n ++);
		        i ++;
		       // System.out.println(i);
		      }
		      System.out.println(cachedData.size() + " " + i);
		      Iterator<BytesWritable> it =cachedData.keySet().iterator();
		      for (int j=0;j<10;j ++){
		    	 BytesWritable k= it.next();
		    	 System.out.println(k+" , "+cachedData.get(k));
		      }
		      System.out.println(String.format("End of %d round", loaded));
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
}
