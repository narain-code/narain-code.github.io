package com.king.xplatform;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.ql.io.RCFileInputFormat;
import org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat;
import org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe;
import org.apache.hadoop.hive.serde2.AbstractSerDe;
import org.apache.hadoop.hive.serde2.ColumnProjectionUtils;
import org.apache.hadoop.hive.serde2.columnar.BytesRefArrayWritable;
import org.apache.hadoop.hive.serde2.columnar.ColumnarSerDe;
import org.apache.hadoop.hive.serde2.lazy.LazyLong;
import org.apache.hadoop.hive.serde2.objectinspector.StructField;
import org.apache.hadoop.hive.serde2.objectinspector.StructObjectInspector;
import org.apache.hadoop.io.ArrayWritable;
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.SequenceFile;
import org.apache.hadoop.io.compress.GzipCodec;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Partitioner;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapred.SequenceFileOutputFormat;
import org.apache.hadoop.util.bloom.BloomFilter;
import org.apache.hadoop.util.bloom.Key;
import org.apache.hadoop.util.hash.Hash;

import com.king.xplatform.persistence.Utils;

public class PartitionUserMapping
{
  private static AbstractSerDe serde;
  private static Properties tbl;
  static boolean withNewUserMapping = false;
  static final int numberOfReducers = 1024;
  public static void main(String[] args)
  {
	  JobConf conf = new JobConf(PartitionUserMapping.class);
	  try
	    {
		 
	     
	      
	      if(args.length > 2){
				 if(args[2].equalsIgnoreCase("newusermapping")){
					 withNewUserMapping = true;
					System.out.println("turning the new usermapping on"); 
				 }
			 }
	      
	       tbl = new Properties();
	      if(!withNewUserMapping){
		      tbl.setProperty("serialization.format", "9");
	
		      tbl.setProperty("columns", "kingpdjoinkey,coreuserid,installid,player_id,facebookid");
		      tbl.setProperty("columns.types", "string:bigint:string:bigint:string");
		      conf.setBoolean("new.usermapping", false);
		      conf.setJobName("PartitionUserMapping");
		      serde = new ColumnarSerDe();
		      conf.setInputFormat(RCFileInputFormat.class);
		      conf.setMapperClass(UserMappingMapper.class);
	      }
	      else{
	    	  
	    	  tbl.setProperty("serialization.format", "\t");
	    	  tbl.setProperty("field.delim", "\t");
	    		
		      tbl.setProperty("columns", "kingpdjoinkey,valid_from_date,valid_to_date,kingplayerid,coreuserid,installid");
		      tbl.setProperty("columns.types", "string:string:string:bigint:bigint:string");
		      conf.setBoolean("new.usermapping", true);
		      conf.setJobName("PartitionNewUserMapping");
		     
		     // serde = new ColumnarSerDe();
		      serde = new ParquetHiveSerDe();
		      conf.setInputFormat(MapredParquetInputFormat.class);
		      conf.setMapperClass(TextUserMappingMapper.class);
	      }
		      tbl.setProperty("serialization.null.format", "NULL");
	     
	      serde.initialize(conf, tbl);
	      Utils.setObject(conf, "serialaztion.Object", tbl);
	      StructObjectInspector oi = (StructObjectInspector)serde.getObjectInspector();
	      List<? extends StructField> fieldRefs;
	      fieldRefs = oi.getAllStructFieldRefs();
	   
    
   // conf.setJobName("PartitionUserMapping");
    conf.setMapOutputKeyClass(BytesWritable.class);
    conf.setMapOutputValueClass(LongWritable.class);
    conf.setOutputKeyClass(BytesWritable.class);
    conf.setOutputValueClass(LongWritable.class);

    
    conf.setReducerClass(UserMappingReducer.class);
    conf.setNumReduceTasks(numberOfReducers);
    conf.setPartitionerClass(UserMappingPartitioner.class);

    ColumnProjectionUtils.setFullyReadColumns(conf);
   

    conf.setOutputFormat(SequenceFileOutputFormat.class);
    SequenceFileOutputFormat.setOutputCompressionType(conf, SequenceFile.CompressionType.BLOCK);
    SequenceFileOutputFormat.setCompressOutput(conf, true);
    SequenceFileOutputFormat.setOutputCompressorClass(conf, GzipCodec.class);
    
    //System.out.println(args[1]);
    FileInputFormat.setInputPaths(conf, new Path[] { new Path(args[0]) });
    FileOutputFormat.setOutputPath(conf, new Path(args[1]));
    
   // MultipleOutputs.addNamedOutput(conf, "firsthalf", SequenceFileOutputFormat.class, BytesWritable.class, LongWritable.class);
    //MultipleOutputs.addNamedOutput(conf, "secondhalf", SequenceFileOutputFormat.class, BytesWritable.class, LongWritable.class);
      JobClient.runJob(conf);
    
	    }
	    catch (Exception e)
	    {
	      
	      e.printStackTrace();
	      System.out.println("Failed to setup SERDE.");
	    }  
  }

  /*static
  {
    try
    {
      Configuration conf = new Configuration();
      boolean withNewUserMapping = false;
      
      
      Properties tbl = new Properties();

      tbl.setProperty("serialization.format", "9");

      tbl.setProperty("columns", "kingpdjoinkey,coreuserid,installid,player_id,facebookid");
      tbl.setProperty("columns.types", "string:bigint:string:bigint:string");
      tbl.setProperty("serialization.null.format", "NULL");
      serde = new ColumnarSerDe();
      serde.initialize(conf, tbl);
      StructObjectInspector oi = (StructObjectInspector)serde.getObjectInspector();
      List<? extends StructField> fieldRefs;
      fieldRefs = oi.getAllStructFieldRefs();
    }
    catch (Exception e)
    {
      
      e.printStackTrace();
      System.out.println("Failed to setup SERDE.");
    }
  }*/

  public static class UserMappingReducer extends MapReduceBase
    implements Reducer<BytesWritable, LongWritable, BytesWritable, LongWritable>
  {
	  /*int size = 0;
	  boolean use2= false;
	  public static int SIZE = 6000000;
	  public MultipleOutputs  mos ;*/
	  public static int SIZE =6500000;
	  int size = 0;
	  BloomFilter filter;
	  Path bloomfilterSavePath;
	  JobConf jobConf;
	  
    public void reduce(BytesWritable key, Iterator<LongWritable> values, OutputCollector<BytesWritable, LongWritable> output, Reporter reporter)
      throws IOException
    {
      	
      while (values.hasNext()) {
        LongWritable value = (LongWritable)values.next();
        output.collect(key, value);
        if(size >SIZE)
          filter.add(new Key(key.copyBytes()));
        size ++;
      }
       /* if(use2){
        	mos.getCollector("secondhalf", reporter).collect(key, value);
        }else{
        	mos.getCollector("firsthalf", reporter).collect(key, value);
        }
       
       }
      size ++;
      if(size <SIZE )
    	  use2=true;*/
    	  
    }
    
    public void configure(JobConf job) {
    	//this.mos =new MultipleOutputs(job);
    	filter = new BloomFilter(30*1024*1024*8, 6, Hash.MURMUR_HASH);
    	bloomfilterSavePath =FileOutputFormat.getPathForCustomFile(job, "bloom");
    	this.jobConf =job;
    }
    
    public void close() throws IOException {
      //this.mos.close();
    	//Path out = new Path(bloomfilterSavePath.toString()+"/bloom");
    	FSDataOutputStream outStream = bloomfilterSavePath.getFileSystem(jobConf).create(bloomfilterSavePath, true);
        filter.write(outStream);
        outStream.close();
    }
  }

  public static class UserMappingPartitioner
    implements Partitioner<BytesWritable, LongWritable>
  {
    public int getPartition(BytesWritable k2, LongWritable v2, int numPartitions)
    {
      return Utils.keyShard(k2.getBytes(), numPartitions) % numPartitions;
    }

    public void configure(JobConf jc)
    {
    }
  }

  public static class UserMappingMapper extends MapReduceBase
    implements Mapper<LongWritable, BytesRefArrayWritable, BytesWritable, LongWritable>
  {
	  JobConf conf;
	  ColumnarSerDe serDe;
	  
    public void map(LongWritable key, BytesRefArrayWritable value, OutputCollector<BytesWritable, LongWritable> output, Reporter reporter)
      throws IOException
    {
      try
      {
        StructObjectInspector oi = (StructObjectInspector)this.serDe.getObjectInspector();
        List fieldRefs = oi.getAllStructFieldRefs();

        Object raw = this.serDe.deserialize(value);

        List<Object> dataStruct = oi.getStructFieldsDataAsList(raw);
        BytesWritable outputkey = new BytesWritable(dataStruct.get(0).toString().getBytes());
        
        //byte[] bArray = dataStruct.get(3).toString().getBytes();
        byte[] bArray;
        if(conf.getBoolean("new.usermapping", false)){
        	bArray = dataStruct.get(1).toString().getBytes();
        }else{
        	bArray = dataStruct.get(3).toString().getBytes();
        }
        long lv = LazyLong.parseLong(bArray, 0, bArray.length);
       
        //System.out.println(lv + " ::: " + LazyLong.parseLong(bArray, 0, bArray.length));
       // BytesWritable outputValue = new BytesWritable(Utils.serializeLong(lv));
        LongWritable outputValue = new LongWritable(lv);
        output.collect(outputkey, outputValue);
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
    
    public void configure(JobConf jc)
    {
    	try{  
    	    this.conf = jc;
    	    Properties tbl = (Properties) Utils.getObject(jc, "serialaztion.Object");	
    	    if(tbl == null)
    	    	 System.out.println("table is null");
    	    this.serDe = new ColumnarSerDe();
    	    this.serDe.initialize(jc, tbl);
    		}catch(Exception e){
    			e.printStackTrace();
    		}
    }
    
  }
  
  
  public static class TextUserMappingMapper extends MapReduceBase
  implements Mapper<LongWritable, ArrayWritable, BytesWritable, LongWritable>
{
	  JobConf conf;
	  //LazySimpleSerDe serDe;
	  ParquetHiveSerDe serDe;
	  
  public void map(LongWritable key, ArrayWritable value, OutputCollector<BytesWritable, LongWritable> output, Reporter reporter)
    throws IOException
  {
    try
    {
     
      StructObjectInspector oi = (StructObjectInspector)this.serDe.getObjectInspector();
      List fieldRefs = oi.getAllStructFieldRefs();

      Object raw = this.serDe.deserialize(value);

      List<Object> dataStruct = oi.getStructFieldsDataAsList(raw);
      BytesWritable outputkey = new BytesWritable(dataStruct.get(0).toString().getBytes());
      
      //byte[] bArray = dataStruct.get(3).toString().getBytes();
      byte[] bArray;
      if(conf.getBoolean("new.usermapping", false)){
    		//System.out.println(new String(dataStruct.get(0).toString().getBytes()) + " :: " + dataStruct.get(1).toString().getBytes() + " :: " +dataStruct.get(2).toString() + " :: " + dataStruct.get(3).toString() );
      	bArray = dataStruct.get(3).toString().getBytes();
      
      }else{
      	bArray = dataStruct.get(3).toString().getBytes();
      }
      long lv = LazyLong.parseLong(bArray, 0, bArray.length);
     
     // System.out.println(lv + " ::: " + LazyLong.parseLong(bArray, 0, bArray.length));
     // BytesWritable outputValue = new BytesWritable(Utils.serializeLong(lv));
      LongWritable outputValue = new LongWritable(lv);
      output.collect(outputkey, outputValue);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
  
  public void configure(JobConf jc)
  {
	try{  
    this.conf = jc;
    Properties tbl = (Properties) Utils.getObject(jc, "serialaztion.Object");	
    if(tbl == null)
    	 System.out.println("table is null");
   // this.serDe = new LazySimpleSerDe();
   // this.serDe = new ColumnarSerDe();
    this.serDe = new ParquetHiveSerDe();
    this.serDe.initialize(jc, tbl);
	}catch(Exception e){
		e.printStackTrace();
	}
  }
  
}
}