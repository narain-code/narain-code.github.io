package com.king.xplatform;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Iterator;
import java.util.Map;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapred.TextOutputFormat;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Input;
import com.king.xplatform.persistence.Utils;

public class Read10ProgressionData
{
  public static void main(String[] args)
    throws IOException
  {
    JobConf conf = new JobConf(Read10ProgressionData.class);

    conf.setInputFormat(MultipleSequenceFileFormat.class);
    conf.setOutputFormat(TextOutputFormat.class);
    conf.setMapperClass(Row10Mapper.class);
    conf.setMapOutputKeyClass(Text.class);
    conf.setMapOutputValueClass(Text.class);
    conf.setNumReduceTasks(0);

    FileInputFormat.setInputPaths(conf, new Path[] { new Path(args[0]) });

    FileOutputFormat.setOutputPath(conf, new Path(args[1]));

    if (args.length >= 3) {
      System.out.println(Long.parseLong(args[2]));
      conf.setLong("searchString", Long.parseLong(args[2]));
    }

    JobClient.runJob(conf);
  }

  public static class Row10Mapper extends MapReduceBase
    implements Mapper<BytesWritable, BytesWritable, Text, Text>
  {
    KyroFactory _factory = new KyroFactory();
    long searchingFor;
    long i = 0L;

    public void map(BytesWritable key, BytesWritable value, OutputCollector<Text, Text> output, Reporter reporter)
      throws IOException
    {
      Kryo kryo = this._factory.getKyro();

      System.out.println(this.searchingFor);
      if (Utils.deserializeLong(key) != this.searchingFor)
        return;
      if ((value.getBytes() != null) && (value.getBytes().length > 0)) {
        Input input = new Input(value.getBytes());
        MappedProgressionValue someObject = (MappedProgressionValue)kryo.readClassAndObject(input);
        Iterator it = someObject.allGroups.entrySet().iterator();
        while (it.hasNext()) {
          Map.Entry n = (Map.Entry)it.next();
          GroupKey _gKey = (GroupKey)n.getKey();
          GroupValue _gValue = (GroupValue)n.getValue();
          output.collect(new Text(key.getBytes()), new Text(_gKey.appId + new String(ByteBuffer.allocate(4).putInt(_gKey.appId).array())));
        }
      }
    }

    public void configure(JobConf jc)
    {
      this.searchingFor = jc.getLong("searchString", 0L);
    }

    public void close()
      throws IOException
    {
    }
  }
}