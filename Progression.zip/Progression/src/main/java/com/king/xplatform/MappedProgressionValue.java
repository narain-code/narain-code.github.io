package com.king.xplatform;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class MappedProgressionValue
{
  public Map<GroupKey, GroupValue> allGroups = new HashMap();
  public Long playerid=0L;

  public MappedProgressionValue()
  {
    this.allGroups = new HashMap();
  }

  public void add2Group(GroupKey key, GroupValue val) {
    this.allGroups.put(key, val);
  }

  public void merge(MappedProgressionValue other) {
    try {
      SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
      Set otherGrps = other.allGroups.keySet();
      HashMap<GroupKey, GroupValue> addLater = new HashMap<GroupKey, GroupValue>();
      Iterator it = otherGrps.iterator();
      while (it.hasNext()) {
        GroupKey key = (GroupKey)it.next();
        if (this.allGroups.containsKey(key)) {
          GroupValue v = (GroupValue)this.allGroups.get(key);
          GroupValue otherGV = (GroupValue)other.allGroups.get(key);
          Date lastPlayDt1 =format.parse(v.lastPlayDate);
          Date lastPlayDtother =format.parse(otherGV.lastPlayDate);
          if(lastPlayDtother.after(lastPlayDt1))
        	   v.setLastPlayDate(otherGV.lastPlayDate);
        	  
          
          Date firstDate1 = format.parse(v.firstPlay);
          Date firstDateother = format.parse(otherGV.firstPlay);
          if (!firstDate1.before(firstDateother))
          {
            v.setFirstPlay(otherGV.firstPlay);
          }

          Date successDate1 = null;
          Date successDateOther = null;
          if (v.successDate == null) {
            if (otherGV.successDate == null) {
              v.gameendsafter += otherGV.gameendsafter;
              v.gameendsbefore += otherGV.gameendsbefore;
            } else {
              v.successDate = otherGV.successDate;
              v.gameendsafter += otherGV.gameendsafter;
              v.gameendsbefore += otherGV.gameendsbefore;
            }
          }
          else if (otherGV.successDate == null) {
            v.gameendsafter += otherGV.gameendsafter;
            v.gameendsbefore += otherGV.gameendsbefore;
          } else {
            successDate1 = format.parse(v.successDate);
            successDateOther = format.parse(otherGV.successDate);
            if (successDateOther.after(successDate1)) {
              v.gameendsafter = (otherGV.gameendsbefore + otherGV.gameendsbefore);
            } else {
              v.successDate = otherGV.successDate;
              v.gameendsafter = (v.gameendsafter + otherGV.gameendsafter + v.gameendsbefore);
              v.gameendsbefore = otherGV.gameendsbefore;
            }
          }
        }
        else
        {
          this.allGroups.put(key, other.allGroups.get(key));
        	
        }
      }
     
    }
    catch (Exception e) {
    }
  }

  public String toString() {
    return "" + this.allGroups.entrySet().size();
  }
  
  
  public boolean equals(Object other){
	  if(this.playerid != 0)
	     return other instanceof MappedProgressionValue && ((MappedProgressionValue)other).playerid == this.playerid ;
	  else
		 return super.equals(other);
  }
  
}