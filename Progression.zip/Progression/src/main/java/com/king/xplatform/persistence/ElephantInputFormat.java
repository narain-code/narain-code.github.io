package com.king.xplatform.persistence;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.WritableUtils;
import org.apache.hadoop.mapred.InputFormat;
import org.apache.hadoop.mapred.InputSplit;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.RecordReader;
import org.apache.hadoop.mapred.Reporter;

public class ElephantInputFormat
  implements InputFormat<BytesWritable, BytesWritable>
{
  public static final String ARGS_CONF = "elephant.output.args";

  public InputSplit[] getSplits(JobConf jc, int ignored)
    throws IOException
  {
    Args args = (Args)Utils.getObject(jc, "elephant.output.args");
    FileSystem fs = Utils.getFS(args.inputDirHdfs, jc);
    DomainStore store = new DomainStore(fs, args.inputDirHdfs);
    String versionPath;
  
    if (args.version == null)
      versionPath = store.mostRecentVersionPath();
    else {
      versionPath = store.versionPath(args.version.longValue());
    }
    DomainSpec spec = store.getSpec();
    List ret = new ArrayList();
    for (int i = 0; i < spec.getNumShards(); i++) {
      String shardPath = versionPath + "/" + i;
      if (fs.exists(new Path(shardPath))) {
        ret.add(new ElephantInputSplit(shardPath, spec, jc));
      }
    }
    return (InputSplit[])ret.toArray(new InputSplit[ret.size()]);
  }

  public RecordReader<BytesWritable, BytesWritable> getRecordReader(InputSplit is, JobConf jc, Reporter reporter) throws IOException
  {
    return new ElephantRecordReader((ElephantInputSplit)is, reporter);
  }

  public static class ElephantInputSplit
    implements InputSplit
  {
    private String shardPath;
    private DomainSpec spec;
    private JobConf conf;

    public ElephantInputSplit()
    {
    }

    public ElephantInputSplit(String shardPath, DomainSpec spec, JobConf conf)
    {
      this.shardPath = shardPath;
      this.spec = spec;
      this.conf = conf;
    }

    public long getLength() throws IOException {
      FileSystem fs = Utils.getFS(this.shardPath, this.conf);
      return fs.getContentSummary(new Path(this.shardPath)).getLength();
    }

    public String[] getLocations() throws IOException
    {
      return new String[0];
    }

    public void write(DataOutput d) throws IOException {
      this.spec.write(d);
      WritableUtils.writeString(d, this.shardPath);
      this.conf.write(d);
    }

    public void readFields(DataInput di) throws IOException {
      this.spec = new DomainSpec();
      this.spec.readFields(di);
      this.shardPath = WritableUtils.readString(di);
      this.conf = new JobConf();
      this.conf.readFields(di);
    }
  }

  public static class ElephantRecordReader
    implements RecordReader<BytesWritable, BytesWritable>
  {
    ElephantInputFormat.ElephantInputSplit _split;
    Reporter _reporter;
    ElephantInputFormat.Args _args;
    LocalElephantManager _manager;
    LocalPersistence _lp;
    CloseableIterator<LocalPersistence.KeyValuePair> _iterator;
    boolean finished = false;
    int numRead = 0;

    public ElephantRecordReader(ElephantInputFormat.ElephantInputSplit split, Reporter reporter) throws IOException {
      this._split = split;
      this._reporter = reporter;
      this._args = ((ElephantInputFormat.Args)Utils.getObject(this._split.conf, "elephant.output.args"));
      this._manager = new LocalElephantManager(Utils.getFS(this._split.shardPath, split.conf), this._split.spec, this._args.persistenceOptions, LocalElephantManager.getTmpDirs(this._split.conf));

      String localpath = this._manager.downloadRemoteShard("shard", this._split.shardPath);
      this._lp = this._split.spec.getLPFactory().openPersistenceForRead(localpath, this._args.persistenceOptions);
      this._iterator = this._lp.iterator();
    }

    public boolean next(BytesWritable k, BytesWritable v) throws IOException {
      if (this._iterator.hasNext()) {
        LocalPersistence.KeyValuePair pair = (LocalPersistence.KeyValuePair)this._iterator.next();
        k.set(pair.key, 0, pair.key.length);
        v.set(pair.value, 0, pair.value.length);
        this.numRead += 1;
        if (this._reporter != null) this._reporter.progress();
        return true;
      }
      if (this._reporter != null) this._reporter.progress();
      return false;
    }

    public BytesWritable createKey()
    {
      return new BytesWritable();
    }

    public BytesWritable createValue() {
      return new BytesWritable();
    }

    public long getPos() throws IOException {
      return this.numRead;
    }

    public void close() throws IOException {
      this._iterator.close();
      this._lp.close();
      this._manager.cleanup();
    }

    public float getProgress() throws IOException {
      if (this.finished) {
        return 1.0F;
      }
      return 0.0F;
    }
  }

  public static class Args
    implements Serializable
  {
    public Map<String, Object> persistenceOptions = new HashMap();
    public String inputDirHdfs;
    public Long version = null;

    public Args(String inputDirHdfs) {
      this.inputDirHdfs = inputDirHdfs;
    }
  }
}