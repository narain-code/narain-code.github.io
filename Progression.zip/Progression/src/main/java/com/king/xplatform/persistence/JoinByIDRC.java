package com.king.xplatform.persistence;

import java.io.IOException;
import java.lang.reflect.Method;
import java.security.PrivilegedExceptionAction;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.ql.io.RCFileOutputFormat;
import org.apache.hadoop.hive.serde2.columnar.BytesRefArrayWritable;
import org.apache.hadoop.hive.serde2.columnar.BytesRefWritable;
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.SequenceFile;
import org.apache.hadoop.io.compress.GzipCodec;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.FileSplit;
import org.apache.hadoop.mapred.InputSplit;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.JobPriority;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Partitioner;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapred.SequenceFileInputFormat;
import org.apache.hadoop.mapred.lib.MultipleInputs;
import org.apache.hadoop.security.UserGroupInformation;
import org.apache.hadoop.util.bloom.BloomFilter;
import org.apache.hadoop.util.hash.Hash;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.ByteBufferInput;
import com.esotericsoftware.kryo.io.ByteBufferOutput;
import com.esotericsoftware.kryo.io.Input;
import com.king.xplatform.GroupKey;
import com.king.xplatform.GroupValue;
import com.king.xplatform.KyroFactory;
import com.king.xplatform.MappedProgressionValue;
import com.king.xplatform.MultipleSequenceFileFormat;


public class JoinByIDRC {
	public static void main(String[] args)
	  {
		 final String[] f_args = args; 
		 final int numberOfReducers = 1024;
		
	    	UserGroupInformation ugi = UserGroupInformation.createRemoteUser("narainra"); 
	    	try {
				ugi.doAs(new PrivilegedExceptionAction<Void>() {
				    public Void run() throws Exception {
				    	 boolean withNewUserMapping = false;
						 if(f_args.length > 2){
							 if(f_args[2].equalsIgnoreCase("newusermapping")){
								 withNewUserMapping = true;
								 
							 }
						 }
				    	JobConf conf = new JobConf(JoinByIDRC.class);
				    	if(withNewUserMapping){
				  		 	 conf.setJobName("JoinByIDRCWithUserMapping");
				  		 	 conf.setBoolean("new.usermapping",true);
				    	}
				    	else{
				    		 conf.setJobName("JoinByIDRC");
				    		 conf.setBoolean("new.usermapping",false);
				    	}
				 	    conf.setMapOutputKeyClass(LongWritable.class);
				 	    conf.setMapOutputValueClass(BytesWritable.class);
				 	   
				 	    conf.setMapperClass(JoinByIDRCMapper.class);

				 	    conf.setReducerClass(JoinByIDRCReducer.class);
				 	    conf.setNumReduceTasks(numberOfReducers);
				 	   // conf.setCompressMapOutput(true);
				 	    //conf.setMapOutputCompressorClass(GzipCodec.class);
				 	    conf.setPartitionerClass(JoinByIDRCPartitioner.class);
				 	    conf.setCombinerClass(JoinByIDRCCombiner.class);
				 	   // conf.setInputFormat(MultipleSequenceFileFormat.class);
				 	   conf.setInputFormat(SequenceFileInputFormat.class);
				 	   
				 	   // conf.setOutputFormat(NamedOutputIDSequenceOutputFormat.class);
				 	    conf.setOutputFormat(RCFileOutputFormat.class);
				 	    RCFileOutputFormat.setCompressOutput(conf, true);
				 	    RCFileOutputFormat.setOutputCompressorClass(conf, GzipCodec.class);
				 	    try
				 	    {
				 	      //FileInputFormat.setInputPaths(conf, new Path[] { new Path(args[0]) });
				 	    	 MultipleInputs.addInputPath(conf, new Path(f_args[0]), SequenceFileInputFormat.class);
				 	    	//MultipleInputs.addInputPath(conf, new Path(f_args[0]), MultipleSequenceFileFormat.class);
				 	    	// MultipleInputs.addInputPath(conf, new Path("/tmp/narain/new_index/*/*/data"), SequenceFileInputFormat.class);
				 	    	MultipleInputs.addInputPath(conf,new Path("/warehouse/mapred-data/progression/2014-1125-2016-12-04/*/data"),SequenceFileInputFormat.class);
				 	    	MultipleInputs.addInputPath(conf,new Path("/warehouse/mapred-data/progression/new_index/*/*/data"),SequenceFileInputFormat.class);
				 	      FileOutputFormat.setOutputPath(conf, new Path(f_args[1]));

				 	     // conf.setJobPriority(JobPriority.VERY_HIGH);
				 	    //  conf.set("mapred.child.java.opts", "-Xmx2G");
				 	      conf.set("mapreduce.map.memory.mb", "10024");
				 	      conf.set("mapreduce.reduce.memory.mb", "32768");
				 	      conf.set("mapreduce.reduce.java.opts", "-Xms3G -Xmx45G");
				 	      conf.set("mapreduce.map.java.opts", "-Xms5G -Xmx20G");
				 	     // conf.set("mapreduce.task.io.sort.mb", "1024");
				 	      //conf.setInt("io.sort.mb", 1024);
				 	      //conf.set("io.sort.spill.percent", "1.0");

				 	      conf.setInt("mapred.inmem.merge.threshold", 0);
				 	     // conf.set("mapred.job.reduce.memory.mb", "2048");
			
				 	      /**
				 	       * commenting all below because mappers run out of memory
				 	       */
				 	      
				 	     /* conf.setLong("mapred.min.split.size", 268435456L);
				 	     conf.setLong("mapreduce.input.fileinputformat.split.minsize", 536870912L);//512 MB
				 	      conf.setLong("mapreduce.input.fileinputformat.split.maxsize", 536870912L);//512 MB
				 	      conf.setLong("mapred.max.split.size", 536870912L);*/
				 	     // conf.setFloat("mapred.reduce.slowstart.completed.maps", 0.99F);
				 	      conf.setInt("hive.io.rcfile.column.number.conf", 9);
				 	     // conf.setInt("mapred.task.timeout",1800000);
				 	     // conf.setInt("mapreduce.map.maxattempts",1);
				 	      //conf.setMemoryForReduceTask(2048L);
				 	      conf.setInt("dfs.replication", 3);
				 	      conf.setJobPriority(JobPriority.NORMAL);
				 	      conf.set("hadoop.job.ugi", "narainra");
				 	     conf.set("fs.permissions.umask-mode", "000");
				 	    conf.set("dfs.umaskmode", "000");
				 	      JobClient.runJob(conf);
				 	      ;
				 	    }
				 	    catch (IOException e) {
				 	      e.printStackTrace();
				 	      System.exit(-1);
				 	    }
				 	    return null;
				    }
				});   
	    	}catch(Exception ex){
	    		ex.printStackTrace();
	    		System.exit(-1);
	    	}
	   
	  }
	
	 public static class JoinByIDRCCombiner extends MapReduceBase
	    implements Reducer<LongWritable, BytesWritable, LongWritable,BytesWritable>
	 {
		 KyroFactory _factory = new KyroFactory();

		    public void reduce(LongWritable key, Iterator<BytesWritable> values, OutputCollector<LongWritable, BytesWritable> output, Reporter reporter)
		      throws IOException
		    {
		      Kryo kryo = this._factory.getKyro();

		      MappedProgressionValue mergedValue = null;

		      while (values.hasNext())
		      {
		        BytesWritable currVal = (BytesWritable)values.next();
		        byte[] value = currVal.copyBytes();

		        Input input = new Input(new ByteBufferInput(value));
		        MappedProgressionValue someObject = (MappedProgressionValue)kryo.readObject(input,MappedProgressionValue.class);
		        someObject.playerid = key.get();
		        input.close();
		        if (mergedValue == null) {
		          mergedValue = someObject;
		          if (mergedValue.allGroups == null)
		            System.out.println("all Groups is null in first");
		        }
		        else {
		          mergedValue.merge(someObject);
		          if (mergedValue.allGroups == null) {
		            System.out.println("all Groups is null in merge");
		          }
		        }
		      }

		      if (mergedValue != null) {
		    	  int currentSize = 512;
		          ByteBufferOutput outputBuffer = new ByteBufferOutput(currentSize);
		          boolean done = false;
		          while (!done) {
		            try {
		              kryo.writeObject(outputBuffer, mergedValue);
		              done = true;
		            }
		            catch (Exception e) {
		              currentSize *= 2;
		              outputBuffer = new ByteBufferOutput(currentSize);
		            }
		          }
		          byte[] serialized = outputBuffer.toBytes();
		          outputBuffer.close();

		          output.collect(key, new BytesWritable(serialized));
		      }
		 
	 }
	 }
	 
	  public static class JoinByIDRCReducer extends MapReduceBase
	    implements Reducer<LongWritable, BytesWritable, NullWritable, BytesRefArrayWritable>
	  {
	    KyroFactory _factory = new KyroFactory();

	    public void reduce(LongWritable key, Iterator<BytesWritable> values, OutputCollector<NullWritable, BytesRefArrayWritable> output, Reporter reporter)
	      throws IOException
	    {
	      Kryo kryo = this._factory.getKyro();

	      MappedProgressionValue mergedValue = null;

	      while (values.hasNext())
	      {
	        BytesWritable currVal = (BytesWritable)values.next();
	        byte[] value = currVal.copyBytes();

	        Input input = new Input(new ByteBufferInput(value));
	        MappedProgressionValue someObject = ( MappedProgressionValue)kryo.readObject(input,MappedProgressionValue.class);
	        someObject.playerid = key.get();
	        input.close();
	        if (mergedValue == null) {
	          mergedValue = someObject;
	          if (mergedValue.allGroups == null)
	            System.out.println("all Groups is null in first");
	        }
	        else {
	          mergedValue.merge(someObject);
	          if (mergedValue.allGroups == null) {
	            System.out.println("all Groups is null in merge");
	          }
	        }
	      }

	      if (mergedValue != null) {
	    	  toRC(key.get(), mergedValue, output);
	        
	      }
	    }
	    NullWritable nullW = NullWritable.get();
	    
	    public void toRC(Long lV, MappedProgressionValue val, OutputCollector<NullWritable, BytesRefArrayWritable> output) {
	        try {
	          Iterator it = val.allGroups.entrySet().iterator();
	          while (it.hasNext()) {
	            Map.Entry n = (Map.Entry)it.next();
	            GroupKey _gKey = (GroupKey)n.getKey();
	            GroupValue _gValue = (GroupValue)n.getValue();
	            //System.out.println(("" + _gKey.appId).getBytes("UTF-8"));
	            BytesRefArrayWritable bytes = new BytesRefArrayWritable(9);
	            bytes.set(0, new BytesRefWritable(("" + lV).getBytes("UTF-8")));
	            bytes.set(1, new BytesRefWritable(("" + _gKey.appId).getBytes("UTF-8")));
	            bytes.set(2, new BytesRefWritable(("" + _gKey.episode).getBytes("UTF-8")));
	            bytes.set(3, new BytesRefWritable(("" + _gKey.level).getBytes("UTF-8")));
	            bytes.set(4, new BytesRefWritable(("" + _gValue.gameendsbefore).getBytes("UTF-8")));
	            bytes.set(5, new BytesRefWritable(("" + _gValue.gameendsafter).getBytes("UTF-8")));
	            bytes.set(6, new BytesRefWritable(_gValue.firstPlay.getBytes()));
	            if (_gValue.successDate != null)
	              bytes.set(7, new BytesRefWritable(_gValue.successDate.getBytes()));
	            else
	              bytes.set(7, new BytesRefWritable("".getBytes()));
	            bytes.set(8, new BytesRefWritable(_gValue.lastPlayDate.getBytes()));
	            
	            output.collect(this.nullW, bytes);
	          }
	        }
	        catch (Exception e) {
	          e.printStackTrace();
	          //throw new RuntimeException(e.getMessage());
	        }
	      }
	  }

	  public static class JoinByIDRCPartitioner
	    implements Partitioner<LongWritable, BytesWritable>
	  {
	    public int getPartition(LongWritable k2, BytesWritable v2, int numPartitions)
	    {
	     // long lV = Utils.deserializeLong(k2.writable);
	     // String strKey = "" + lV;

	     // return Utils.keyShard(strKey.getBytes(), numPartitions) % numPartitions;
	    	return Utils.keyShard(k2.toString().getBytes(), numPartitions)% numPartitions;
	    }

	    public void configure(JobConf jc)
	    {
	    }
	  }

	  public static class JoinByIDRCMapper extends MapReduceBase
	    implements Mapper<BytesWritable, BytesWritable, LongWritable, BytesWritable>
	  {
	 //  HashMap<Integer, HashMap<BytesWritable, LongWritable>> cachedParts = new HashMap<Integer, HashMap<BytesWritable, LongWritable>>();
		//  HashMap<Integer, HTreeMap<BytesWritable, LongWritable>> cachedParts = new HashMap<Integer, HTreeMap<BytesWritable, LongWritable>>();
	    JobConf conf;
	    String source = "/tmp/narain/userkvstore01/part-";
	    String sourceNewUserMapping = "/warehouse/mapred-data/userkvstore01/part-";
	    String indexPath="/tmp/narain/new_index/*-%d/data";
	    String bloomsource = "/tmp/narain/userkvstore01/bloom-r-";
	    String bloomsourceNewUserMapping = "/warehouse/mapred-data/userkvstore01/bloom-r-";
	    int joinNumber = 100000;
	    FileSystem fs = null;
	    Path[] cacheFiles = null;
	    int counter = 0;
	    HashMap<BytesWritable, LongWritable> toSearchIn;
	    int MAX_LOADED_IN_ONEROUND =1000000;
	    int loaded = 1;
	    BloomFilter filter;
	    boolean fullyLoaded = false;
	    int fail = 0;
	    BytesWritable minLoaded;
	    BytesWritable maxLoaded;
	    int currentCounter;
	    
	    public void map(BytesWritable key, BytesWritable value, OutputCollector<LongWritable, BytesWritable> output, Reporter reporter)
	      throws IOException
	    {

	    	if (this.fs == null) {
	    	 
	        //this.fs = ((org.apache.hadoop.mapred.lib.TaggedInputSplit)reporter.getInputSplit()).getPath().getFileSystem(this.conf);
	    	  this.fs =getFileSplit(reporter.getInputSplit()).getPath().getFileSystem(conf);
	      }
	      //String fileSplitName = ((FileSplit)reporter.getInputSplit()).getPath().getParent().getName();
	      String fileSplitName =getFileSplit(reporter.getInputSplit()).getPath().getParent().getName();
	       if(fileSplitName.indexOf("--") == -1)
	    	   fileSplitName = ((FileSplit)reporter.getInputSplit()).getPath().getName();
	      int shardID = getShardID(fileSplitName, "--");
	      int withShard = this.joinNumber + shardID;
          String partNumber = ("" + withShard).substring(1);
	    //  HTreeMap<BytesWritable, LongWritable> toSearchIn;
	      if (shardID != -1)
	      {
	       
	       
	      /*  if (this.cachedParts.containsKey(Integer.valueOf(shardID))) {
	          toSearchIn = (HashMap<BytesWritable, LongWritable>)this.cachedParts.get(Integer.valueOf(shardID));
	        	// toSearchIn = (HTreeMap<BytesWritable, LongWritable>)this.cachedParts.get(Integer.valueOf(shardID));
	        }
	        else {*/
	    	  if(toSearchIn == null){
	          //int withShard = this.joinNumber + shardID;
	          //String partNumber = ("" + withShard).substring(1);

	         // toSearchIn = new HashMap<BytesWritable, LongWritable>();
	          long startTime = System.currentTimeMillis();
	          if(conf.getBoolean("new.usermapping", false)){
	        	  parseSequenceFile(new Path(this.sourceNewUserMapping + partNumber));
	        	  //parseBloom(new Path(this.bloomsourceNewUserMapping+partNumber));
	          }
	          else{
	             parseSequenceFile(new Path(this.source + partNumber));
	             //parseBloom(new Path(this.bloomsource+partNumber));
	          }
	          
	          //this.cachedParts.put(Integer.valueOf(shardID), toSearchIn);
	          long endTime = System.currentTimeMillis();
	          System.out.println("Time taken  for sharID " + shardID + " :: " + (endTime - startTime));
	          
	          //read the rest of the new indexs under new index same chunk.
	         }
	       int loopCounter = 0;
	        if(toSearchIn != null){
	        	
	         while(!processRecord(this.toSearchIn,key,value,output,reporter) && loopCounter < 30){
	        	 if(loopCounter > 12)
	        		  System.out.println(loopCounter);
	        	/* if(filter.membershipTest(new Key(key.copyBytes()))){
	        		 System.out.println(" are we loading seq again " + new String(key.copyBytes()));
	        		 fail ++;
	        	 if(fail > 9){	*/
	        	 if(key.compareTo(maxLoaded)>0  ){
	        	 if(conf.getBoolean("new.usermapping", false))
		        	  toSearchIn = parseSequenceFile(new Path(this.sourceNewUserMapping + partNumber));
		          else
		             toSearchIn = parseSequenceFile(new Path(this.source + partNumber));
	        	 }else{
	        		 reporter.getCounter(JoinByIDByYear.REJECTED_COUNTER.NOPRIMARY_ID).increment(1L);
		           //  System.out.println("key  ::  " + new String(key.getBytes()) + " is not found and less than max :: " + new String(maxLoaded.copyBytes()));
		             break;
	        	 }
	        	
	        	 
	        /*	 }else{
	        		 reporter.getCounter(JoinByIDByYear.REJECTED_COUNTER.NOPRIMARY_ID).increment(1L);
		             System.out.println("membership failed" + new String(key.getBytes()));
	        	 }*/
	        	 loopCounter ++;
	         }
	         currentCounter ++;
	         if(currentCounter %1000 == 0)
	        	 System.out.println(System.currentTimeMillis() + "Finished " + currentCounter + " records");
	         
	        }
	        else
	        {
	        	currentCounter ++;
	        	if(currentCounter %1000 == 0)
	        		System.out.println(System.currentTimeMillis() + "else block Finished " + currentCounter + " records");
	      	        	
	        	
	        }
	      }
	    }

	    
	    public FileSplit getFileSplit(InputSplit split) throws IOException{
	    	//System.out.println(split.getClass().getName());
	    	Class splitClass = split.getClass();
	    		
	    	    if (splitClass.getName().equals("org.apache.hadoop.mapred.lib.TaggedInputSplit")){
	    	    	try {
	    	    		
	    	            Method getInputSplitMethod = splitClass
	    	                    .getDeclaredMethod("getInputSplit");
	    	            getInputSplitMethod.setAccessible(true);
	    	            return (FileSplit) getInputSplitMethod.invoke(split);
	    	        } catch (Exception e) {
	    	            // wrap and re-throw error
	    	            throw new IOException(e);
	    	        }
	    	    }
	    	
	    	throw new IOException("FileSplit is not got!!");
	    }
	    
	    public boolean processRecord(HashMap<BytesWritable, LongWritable> toSearchIn,
	    							BytesWritable key, 
	    							BytesWritable value, OutputCollector<LongWritable, BytesWritable> output, 
	    							Reporter reporter) throws IOException{
	    	if(currentCounter %1000 == 0)
        		System.out.println(System.currentTimeMillis() + "started process Record" + currentCounter + " records");
	    	LongWritable primaryId = toSearchIn.get(key);
	        if (primaryId != null)
	        {
	            
	        	/* long lV = Utils.deserializeLong(primaryId);
	             String strKey = "" + lV;

	             System.out.println( strKey + "  "+Utils.keyShard(strKey.getBytes(), 512) % 512);*/
	        	
	        	output.collect(primaryId, value);
	        	//output.collect(new MyBytesWritable(key), value);
	        	
	        	if(currentCounter %1000 == 0)
	        		System.out.println(System.currentTimeMillis() + "true Finished process Record" + currentCounter + " records");
	        	return true;
	        }
	        else
	        {
	         //load other and check
	        	if(currentCounter %1000 == 0)
	        		System.out.println(System.currentTimeMillis() + "false Finished process Record" + currentCounter + " records");
	        	 return false;
	        	
	          
	        }
	    }
	    
	    
	    
	    public int getShardID(String fileName, String splitBy)
	    {
	      String[] splits = fileName.split(splitBy);
	      if ((splits == null) || (splits.length == 0)) {
	        return -1;
	      }
	      try
	      {
	        return Integer.parseInt(splits[1]);
	      } catch (NumberFormatException nex) {
	      }
	      return -1;
	    }

	    public void configure(JobConf jc)
	    {
	      this.conf = jc;
	    }

	    public void close()
	      throws IOException
	    {
	    }
	    
	    
	    public void parseBloom(Path p) throws IOException{
	    	System.out.println(p.toString());
	    	FSDataInputStream in = new FSDataInputStream(p.getFileSystem(conf).open(p));
	    	
	         filter = new BloomFilter(30*1024*1024*8, 6, Hash.MURMUR_HASH);
	        filter.readFields(in);
	    }
	    
	    public HashMap<BytesWritable, LongWritable> parseSequenceFile(Path p)
	      throws IOException
	    {
	     // HashMap<BytesWritable, LongWritable> cachedData = new HashMap<BytesWritable, LongWritable>();
	     /* String dstPath =conf.get("mapred.local.dir");
	      System.out.println("mapred local path" + dstPath);
	      Path dst = new Path(dstPath);
	      
	      p.getFileSystem(conf).copyToLocalFile(p, dst);*/
	    	System.out.println(System.currentTimeMillis() + "begin Reading Seq " + loaded + " " + fullyLoaded + " " + (this.toSearchIn == null));
	    	if(fullyLoaded)
	    		 return this.toSearchIn;
	    	
	      this.toSearchIn = null;	
	      this.toSearchIn = new HashMap<BytesWritable, LongWritable>();
	      SequenceFile.Reader reader = new SequenceFile.Reader(this.conf, new SequenceFile.Reader.Option[] { SequenceFile.Reader.file(p) });
	      BytesWritable key = new BytesWritable();
	      LongWritable value = new LongWritable();
	      int loadedRows =0;
	      boolean firstRow =true;
	      while (reader.next(key, value) && loadedRows< (MAX_LOADED_IN_ONEROUND*loaded))
	      {
	       /* long l = Utils.deserializeLong(value.copyBytes());
	        if (value.copyBytes().length > 8) {
	          System.out.println(l + " " + value.copyBytes().length);
	        }
	        cachedData.put(key, new BytesWritable(value.copyBytes()));*/
	    	 // cachedData.put(key,value);
	    	  if(loadedRows <(MAX_LOADED_IN_ONEROUND*(loaded -1)) ){
	    		  loadedRows++;
	    		   continue;
	    	  }
	    	  if(firstRow){
	    		minLoaded=key;  
	    	   firstRow = false;
	    	  }
	    	  toSearchIn.put(key, value);
	    	  //System.out.println ("Loaded key " + new String(key.copyBytes()));
	    	  maxLoaded = key;
	        key = new BytesWritable();
	        value = new LongWritable();
	        loadedRows ++;
	      }
	     
	      if(!reader.next(key,value)){
	    	   fullyLoaded = true;
	        		//System.out.println(System.currentTimeMillis() + "Finished Reading");
	      }
	     // return cachedData;
	      loaded ++;
	      System.out.println(System.currentTimeMillis() + "Finished Reading Seq " + loaded);
	      reader.close();
	      return toSearchIn;
	    }
	    
	    public void processNewChunk(int shardID,HashMap<BytesWritable, LongWritable> toSearchIn,
				 OutputCollector<LongWritable, BytesWritable> output, 
				Reporter reporter) throws IOException{
	  	  Path p = new Path( String.format(indexPath, shardID));
	  	SequenceFile.Reader reader = new SequenceFile.Reader(this.conf, new SequenceFile.Reader.Option[] { SequenceFile.Reader.file(p) });
	    BytesWritable key = new BytesWritable();
	    BytesWritable value = new BytesWritable();
	    while (reader.next(key, value))
	    {
	    	processRecord(toSearchIn, key, value, output, reporter);
	    }
	    }
	    
	  }
	  
	  
	 

	  public static enum REJECTED_COUNTER
	  {
	    NOPRIMARY_ID;
	  }
	}

