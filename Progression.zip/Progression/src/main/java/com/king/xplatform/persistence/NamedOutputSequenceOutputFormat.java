package com.king.xplatform.persistence;

import java.io.IOException;

import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.compress.GzipCodec;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.RecordWriter;
import org.apache.hadoop.mapred.SequenceFileOutputFormat;
import org.apache.hadoop.mapred.lib.MultipleSequenceFileOutputFormat;
import org.apache.hadoop.util.Progressable;

public class NamedOutputSequenceOutputFormat<K, V> extends MultipleSequenceFileOutputFormat<K, V>
{
  private SequenceFileOutputFormat<K, V> theSequenceFileOutputFormat = null;

  protected String generateFileNameForKeyValue(K key, V value, String name)
  {
    String strKey = new String(((BytesWritable)key).getBytes()).trim();

    int shardId = Utils.keyShard(strKey.getBytes(), 512) % 512;

    return "ID--" + shardId + "--" + name;
  }

  protected RecordWriter<K, V> getBaseRecordWriter(FileSystem fs, JobConf job, String name, Progressable arg3)
    throws IOException
  {
    if (this.theSequenceFileOutputFormat == null) {
      this.theSequenceFileOutputFormat = new SequenceFileOutputFormat();
      SequenceFileOutputFormat.setCompressOutput(job, true);
      SequenceFileOutputFormat.setOutputCompressorClass(job, GzipCodec.class);
    }
    return this.theSequenceFileOutputFormat.getRecordWriter(fs, job, name, arg3);
  }
}