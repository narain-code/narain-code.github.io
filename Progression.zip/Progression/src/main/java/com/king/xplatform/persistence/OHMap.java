package com.king.xplatform.persistence;

import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class OHMap<K , V > implements Map<K, V> {
    private final BOHMap map;
    
   
    
    /**
     * Create a new map wrapper around a {@code BOHMap} with the given
     * partition count. The default methods on {@code JavaSerializer} will
     * be used to convert between object and binary form.
     * 
     * @param partitionCount Number of partitions used within {@code BOHMap}
     */
    public OHMap(int partitionCount) {
        this(new BOHMap(partitionCount));
    }

    /**
     * Create a new map wrapper around a {@code BOHMap} with the given
     * partition count. Constructor allows you to define what serialization
     * methods to use, in addition to explicitly passing in the underlying
     * {@code BOHMap} instance used by the wrapper.
     * 
     * 
     */
    public OHMap(BOHMap map) {
        this.map = map;
       
    }

    @Override
    public int size() {
        return map.size();
    }

    @Override
    public boolean isEmpty() {
        return map.isEmpty();
    }

    @Override
    public boolean containsKey(Object key) {
    	
        return map.containsKey(key == null ? null : JavaSerializer.serialize(key));
    }

    @Override
    public boolean containsValue(Object value) {
        return map.containsValue(value == null ? null : JavaSerializer.serialize(value));
    }

    @Override
    public V get(Object key) {
        return (V) JavaSerializer.deserialize(map.get(JavaSerializer.serialize(key)));
    }

    @Override
    public V put(K key, V value) {
        return (V) JavaSerializer.deserialize(map.put(JavaSerializer.serialize(key), JavaSerializer.serialize(value)));
    }

    @Override
    public V remove(Object key) {
        return (V) JavaSerializer.deserialize(map.remove(JavaSerializer.serialize(key)));
    }

    @Override
    public void putAll(Map<? extends K, ? extends V> m) {
       // m.forEach((k, v) -> put(k, v));
    }

    @Override
    public void clear() {
        map.clear();
    }

    @Override
    public Set<K> keySet() {
        return new KeySet(map.keySet());
    }

    @Override
    public Collection<V> values() {
        return new Values(map.values());
    }

    @Override
    public Set<Entry<K, V>> entrySet() {
        return new EntrySet(map.entrySet());
    }
    
    private class KeySet implements Set<K> {
        private final Set<Binary> keySet;
        
        private KeySet(Set<Binary> keySet) {
            this.keySet = keySet;
        }
        
        @Override
        public int size() {
            return keySet.size();
        }

        @Override
        public boolean isEmpty() {
            return keySet.isEmpty();
        }

        @Override
        public boolean contains(Object o) {
            return keySet.contains(JavaSerializer.serialize(o));
        }

        @Override
        public Iterator<K> iterator() {
            final Iterator<Binary> iterator = keySet.iterator();
            
            return new Iterator<K>() {
                @Override
                public boolean hasNext() {
                    return iterator.hasNext();
                }

                @Override
                public K next() {
                    return (K) JavaSerializer.deserialize(iterator.next());
                }

				@Override
				public void remove() {
					// TODO Auto-generated method stub
					
				}
            };
        }

        @Override
        public Object[] toArray() {
            Object[] bArray = keySet.toArray();
            Object[] oArray = new Object[bArray.length];
            
            for (int i = 0; i < bArray.length; i++) {
                oArray[i] = JavaSerializer.deserialize((Binary) bArray[i]);
            }
            
            return oArray;
        }

        @Override
        public <T> T[] toArray(T[] a) {
            int size = size();
            T[] r = a.length >= size ? a : (T[])java.lang.reflect.Array.newInstance(a.getClass().getComponentType(), size);
            
            Iterator<K> it = iterator();
            for (int i = 0; i < r.length; i++) {
                if (!it.hasNext()) {
                    // Null terminate
                    r[i] = null;
                    return r;
                }
                
                r[i] = (T) it.next();
            }
            
            return r;
        }

        @Override
        public boolean add(K e) {
            return keySet.add(JavaSerializer.serialize(e));
        }

        @Override
        public boolean remove(Object o) {
            return keySet.remove(JavaSerializer.serialize(o));
        }

        @Override
        public boolean containsAll(Collection<?> c) {
           // return c.stream().noneMatch((o) -> (!contains((K)o)));
        	return true;
        }

        @Override
        public boolean addAll(Collection<? extends K> c) {
            boolean changed = false;
            for (K k : c) {
                changed = add(k) || changed;
            }
            return changed;
        }

        @Override
        public boolean retainAll(Collection<?> c) {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean removeAll(Collection<?> c) {
            boolean changed = false;
            for (Object k : c) {
                changed = remove((K)k) || changed;
            }
            return changed;
        }

        @Override
        public void clear() {
            keySet.clear();
        }
    }
    
    private class Values implements Collection<V> {
        private final Collection<Binary> values;
        
        private Values(Collection<Binary> values) {
            this.values = values;
        }

        @Override
        public int size() {
            return values.size();
        }

        @Override
        public boolean isEmpty() {
            return values.isEmpty();
        }

        @Override
        public boolean contains(Object o) {
            return values.contains(JavaSerializer.serialize(o));
        }

        @Override
        public Iterator<V> iterator() {
            final Iterator<Binary> iterator = values.iterator();
            
            return new Iterator<V>() {
                @Override
                public boolean hasNext() {
                    return iterator.hasNext();
                }

                @Override
                public V next() {
                    return (V) JavaSerializer.deserialize(iterator.next());
                }

				@Override
				public void remove() {
					// TODO Auto-generated method stub
					
				}
            };
        }

        @Override
        public Object[] toArray() {
            Object[] bArray = values.toArray();
            Object[] oArray = new Object[bArray.length];
            
            for (int i = 0; i < bArray.length; i++) {
                oArray[i] = JavaSerializer.deserialize((Binary) bArray[i]);
            }
            
            return oArray;
        }

        @Override
        public <T> T[] toArray(T[] a) {
            int size = size();
            T[] r = a.length >= size ? a : (T[])java.lang.reflect.Array.newInstance(a.getClass().getComponentType(), size);
            
            Iterator<V> it = iterator();
            for (int i = 0; i < r.length; i++) {
                if (!it.hasNext()) {
                    // Null terminate
                    r[i] = null;
                    return r;
                }
                
                r[i] = (T) it.next();
            }
            
            return r;
        }

        @Override
        public boolean add(V e) {
            return values.add(JavaSerializer.serialize(e));
        }

        @Override
        public boolean remove(Object o) {
            return values.remove(JavaSerializer.serialize(o));
        }

        @Override
        public boolean containsAll(Collection<?> c) {
           // return c.stream().noneMatch((o) -> (!contains((V)o)));
        	return true;
        }

        @Override
        public boolean addAll(Collection<? extends V> c) {
            boolean changed = false;
            for (V k : c) {
                changed = add(k) || changed;
            }
            return changed;
        }

        @Override
        public boolean removeAll(Collection<?> c) {
            boolean changed = false;
            for (Object k : c) {
                changed = remove((V)k) || changed;
            }
            return changed;
        }

        @Override
        public boolean retainAll(Collection<?> c) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void clear() {
            values.clear();
        }
    }
    
    private class EntrySet implements Set<Entry<K, V>> {
        private final Set<Entry<Binary, Binary>> entrySet;
        
        private EntrySet(Set<Entry<Binary, Binary>> entrySet) {
            this.entrySet = entrySet;
        }

        @Override
        public int size() {
            return entrySet.size();
        }

        @Override
        public boolean isEmpty() {
            return entrySet.isEmpty();
        }

        @Override
        public boolean contains(Object o) {
            if (!(o instanceof Map.Entry))
                return false;
            
            Map.Entry entry = (Map.Entry) o;
            
            final K key = (K) entry.getKey();
            final V value = (V) entry.getValue();
            
            return entrySet.contains(new Map.Entry<Binary, Binary>() {
                @Override
                public Binary getKey() {
                    return JavaSerializer.serialize(key);
                }

                @Override
                public Binary getValue() {
                    return JavaSerializer.serialize(value);
                }

                @Override
                public Binary setValue(Binary value) {
                    throw new UnsupportedOperationException();
                }
            });
        }

        @Override
        public Iterator<Entry<K, V>> iterator() {
            final Iterator<Entry<Binary, Binary>> iterator = entrySet.iterator();
            
            return new Iterator<Entry<K, V>>() {
                @Override
                public boolean hasNext() {
                    return iterator.hasNext();
                }

                @Override
                public Entry<K, V> next() {
                    final Entry<Binary, Binary> next = iterator.next();
                    
                    return new Entry<K, V>() {
                        @Override
                        public K getKey() {
                            return (K) JavaSerializer.deserialize(next.getKey());
                        }

                        @Override
                        public V getValue() {
                            return (V) JavaSerializer.deserialize(next.getValue());
                        }

                        @Override
                        public V setValue(V value) {
                            return (V) JavaSerializer.deserialize(next.setValue(JavaSerializer.serialize(value)));
                        }
                    };
                }

				@Override
				public void remove() {
					// TODO Auto-generated method stub
					
				}
            };
        }

        @Override
        public Object[] toArray() {
            Object[] values = new Object[size()];
            
            Iterator<Entry<K, V>> it = iterator();
            for (int i = 0; i < values.length && it.hasNext(); i++) {
                values[i] = it.next();
            }
            
            return values;
        }

        @Override
        public <T> T[] toArray(T[] a) {
            int size = size();
            T[] r = a.length >= size ? a : (T[])java.lang.reflect.Array.newInstance(a.getClass().getComponentType(), size);
            
            Iterator<Entry<K, V>> it = iterator();
            for (int i = 0; i < r.length; i++) {
                if (!it.hasNext()) {
                    // Null terminate
                    r[i] = null;
                    return r;
                }
                
                r[i] = (T) it.next();
            }
            
            return r;
        }

        @Override
        public boolean add(Entry<K, V> e) {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean remove(Object o) {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean containsAll(Collection<?> c) {
            //return c.stream().noneMatch((o) -> (!contains((Entry<K,V>)o)));
        	return true;
        }

        @Override
        public boolean addAll(Collection<? extends Entry<K, V>> c) {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean retainAll(Collection<?> c) {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean removeAll(Collection<?> c) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void clear() {
            entrySet.clear();
        }
    }
}
