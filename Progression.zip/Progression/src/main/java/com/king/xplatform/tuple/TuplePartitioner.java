package com.king.xplatform.tuple;

import java.util.ArrayList;

import org.apache.hadoop.conf.Configuration;

import com.google.common.hash.Funnel;
import com.google.common.hash.HashFunction;
import com.google.common.hash.Hashing;
import com.google.common.hash.Sink;
import com.king.xplatform.RendezvousHash;

public class TuplePartitioner
{
  private final Configuration conf;
  private final int[] indices;
  private static final HashFunction hfunc = Hashing.murmur3_128();
  private static final Funnel<String> strFunnel = new Funnel<String>() {
    public void funnel(String from, Sink into) {
      into.putBytes(from.getBytes());
    }

  };

  private RendezvousHash<String, String> ren = new RendezvousHash(hfunc, strFunnel, strFunnel, new ArrayList());

  public TuplePartitioner(Configuration conf) {
    this.conf = conf;
    this.indices = ShuffleUtils.indexesFromConfig(conf, "org.htuple.partitioner.indexes");
    for (int j = 0; j < 128; j++)
      this.ren.add("" + j);
  }

  public Configuration getConf()
  {
    return this.conf;
  }

  public int getPartition(Tuple key, int numPartitions)
  {
    int indexOffset = 0;
    for (int i = 0; i < key.size(); i++) {
      if (i == this.indices[indexOffset]) {
        Object element = key.getObject(i);
        indexOffset++;
        String part = (String)this.ren.get(element.toString());
        if (numPartitions == 0) {
          return 0;
        }
        return Integer.parseInt(part);
      }

    }

    return 0;
  }
}