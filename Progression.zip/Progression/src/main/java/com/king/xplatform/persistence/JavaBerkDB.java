package com.king.xplatform.persistence;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sleepycat.je.CheckpointConfig;
import com.sleepycat.je.Cursor;
import com.sleepycat.je.Database;
import com.sleepycat.je.DatabaseConfig;
import com.sleepycat.je.DatabaseEntry;
import com.sleepycat.je.Environment;
import com.sleepycat.je.EnvironmentConfig;
import com.sleepycat.je.LockMode;
import com.sleepycat.je.OperationStatus;

public class JavaBerkDB extends LocalPersistenceFactory
{
  public static Logger LOG = Logger.getLogger(JavaBerkDB.class);

  public LocalPersistence openPersistenceForRead(String root, Map options)
    throws IOException
  {
    return new JavaBerkDBPersistence(root, options, true);
  }

  public LocalPersistence openPersistenceForAppend(String root, Map options) throws IOException
  {
    return new JavaBerkDBPersistence(root, options, false);
  }

  public LocalPersistence createPersistence(String root, Map options) throws IOException
  {
    return new JavaBerkDBPersistence(root, options, false);
  }
  public static class JavaBerkDBPersistence implements LocalPersistence {
    Environment _env;
    Database _db;
    private static final String DATABASE_NAME = "elephant";

    public JavaBerkDBPersistence(String root, Map options, boolean readOnly) {
      System.out.println("@@@@@ " + root);
      new File(root).mkdirs();
      EnvironmentConfig envConf = new EnvironmentConfig();
      envConf.setAllowCreate(true);
      envConf.setReadOnly(readOnly);
      envConf.setLocking(false);
      envConf.setTransactional(false);
      envConf.setConfigParam("je.cleaner.minUtilization", "80");
      envConf.setConfigParam("je.env.runCleaner", "false");
      envConf.setConfigParam("je.checkpointer.bytesInterval", "2147483648");
      envConf.setConfigParam("je.cleaner.bytesInterval", "15728640");
      envConf.setConfigParam("je.cleaner.lazyMigration", "false");
      envConf.setConfigParam("je.cleaner.minFileUtilization", "0");
      envConf.setConfigParam("je.cleaner.threads", "1");

      envConf.setConfigParam("je.maxMemoryPercent", "80");

      this._env = new Environment(new File(root), envConf);

      DatabaseConfig dbConf = new DatabaseConfig();
      dbConf.setAllowCreate(true);
      dbConf.setReadOnly(readOnly);
      dbConf.setDeferredWrite(true);

      this._db = this._env.openDatabase(null, "elephant", dbConf);
    }

    public byte[] get(byte[] key) throws IOException {
      DatabaseEntry val = new DatabaseEntry();
      OperationStatus stat = this._db.get(null, new DatabaseEntry(key), val, LockMode.READ_UNCOMMITTED);
      if (stat == OperationStatus.SUCCESS) {
        return val.getData();
      }
      return null;
    }

    public void add(byte[] key, byte[] value) throws IOException
    {
      this._db.put(null, new DatabaseEntry(key), new DatabaseEntry(value));
    }

    public void close() throws IOException {
      if (!this._db.getConfig().getReadOnly()) {
        JavaBerkDB.LOG.info("Syncing environment at " + this._env.getHome().getPath());
        this._env.sync();
        JavaBerkDB.LOG.info("Done syncing environment at " + this._env.getHome().getPath());

        JavaBerkDB.LOG.info("Cleaning environment log at " + this._env.getHome().getPath());
        boolean anyCleaned = false;
        while (this._env.cleanLog() > 0) {
          anyCleaned = true;
        }
        JavaBerkDB.LOG.info("Done cleaning environment log at " + this._env.getHome().getPath());
        if (anyCleaned) {
          JavaBerkDB.LOG.info("Checkpointing environment at " + this._env.getHome().getPath());
          CheckpointConfig checkpoint = new CheckpointConfig();
          checkpoint.setForce(true);
          this._env.checkpoint(checkpoint);
          JavaBerkDB.LOG.info("Done checkpointing environment at " + this._env.getHome().getPath());
        }
      }

      this._db.close();
      this._env.close();
    }

    public CloseableIterator<LocalPersistence.KeyValuePair> iterator() {
      return new CloseableIterator() {
        Cursor cursor = null;
        LocalPersistence.KeyValuePair next = null;

        private void cacheNext() {
          DatabaseEntry key = new DatabaseEntry();
          DatabaseEntry val = new DatabaseEntry();
          OperationStatus stat = this.cursor.getNext(key, val, LockMode.READ_UNCOMMITTED);
          if (stat == OperationStatus.SUCCESS) {
            this.next = new LocalPersistence.KeyValuePair(key.getData(), val.getData());
          } else {
            this.next = null;
            close();
          }
        }

        private void initCursor() {
          if (this.cursor == null) {
            this.cursor = JavaBerkDB.JavaBerkDBPersistence.this._db.openCursor(null, null);
            cacheNext();
          }
        }

        public boolean hasNext() {
          initCursor();
          return this.next != null;
        }

        public LocalPersistence.KeyValuePair next() {
          initCursor();
          if (this.next == null) throw new RuntimeException("No key/value pair available");
          LocalPersistence.KeyValuePair ret = this.next;
          cacheNext();
          return ret;
        }

        public void remove() {
          throw new UnsupportedOperationException("Not supported.");
        }

        public void close() {
          if (this.cursor != null) this.cursor.close();
        }
      };
    }
  }
}