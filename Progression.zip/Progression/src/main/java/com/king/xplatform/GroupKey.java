package com.king.xplatform;

import java.util.Arrays;

public class GroupKey
{
  public int appId;
  public int level;
  public long episode;

  public int getAppId()
  {
    return this.appId;
  }
  public void setAppId(int appId) {
    this.appId = appId;
  }
  public int getLevel() {
    return this.level;
  }
  public void setLevel(int level) {
    this.level = level;
  }
  public long getEpisode() {
    return this.episode;
  }
  public void setEpisode(long episode) {
    this.episode = episode;
  }

  public int hashCode() {
    Object[] val = new Object[3];
    val[0] = Integer.valueOf(this.appId);
    val[1] = Integer.valueOf(this.level);
    val[2] = Long.valueOf(this.episode);
    return Arrays.hashCode(val);
  }

  public boolean equals(Object object) {
    if (!(object instanceof GroupKey)) {
      return false;
    }
    GroupKey otherKey = (GroupKey)object;
    if (otherKey.appId != this.appId)
      return false;
    if (otherKey.episode != this.episode)
      return false;
    if (otherKey.level != this.level)
      return false;
    return true;
  }
}