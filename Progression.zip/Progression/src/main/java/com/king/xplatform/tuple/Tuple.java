package com.king.xplatform.tuple;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableUtils;

public class Tuple
  implements WritableComparable<Tuple>
{
  private List<Object> fields = new ArrayList();

  public Tuple clear()
  {
    this.fields.clear();
    return this;
  }

  public int size()
  {
    return this.fields.size();
  }

  public Tuple set(int idx, Object val)
  {
    while (idx >= this.fields.size()) {
      this.fields.add(null);
    }
    this.fields.set(idx, val);
    return this;
  }

  public Tuple set(Enum<?> eval, Object val)
  {
    set(eval.ordinal(), val);
    return this;
  }

  /** @deprecated */
  public Tuple set(Enum<?> eval, Short val)
  {
    set(eval, val);
    return this;
  }

  public Tuple setShort(Enum<?> eval, Short val)
  {
    set(eval, val);
    return this;
  }

  /** @deprecated */
  public Tuple set(int idx, Short val)
  {
    set(idx, val);
    return this;
  }

  public Tuple setShort(int idx, Short val)
  {
    set(idx, val);
    return this;
  }

  /** @deprecated */
  public Tuple set(Enum<?> eval, Integer val)
  {
    set(eval, val);
    return this;
  }

  public Tuple setInt(Enum<?> eval, Integer val)
  {
    set(eval, val);
    return this;
  }

  /** @deprecated */
  public Tuple set(int idx, Integer val)
  {
    set(idx, val);
    return this;
  }

  public Tuple setInt(int idx, Integer val)
  {
    set(idx, val);
    return this;
  }

  /** @deprecated */
  public Tuple set(Enum<?> eval, Long val)
  {
    set(eval, val);
    return this;
  }

  public Tuple setLong(Enum<?> eval, Long val)
  {
    set(eval, val);
    return this;
  }

  public Tuple setLong(int idx, Integer val)
  {
    set(idx, val);
    return this;
  }

  /** @deprecated */
  public Tuple set(int idx, String val)
  {
    set(idx, val);
    return this;
  }

  public Tuple setString(int idx, String val)
  {
    set(idx, val);
    return this;
  }

  /** @deprecated */
  public Tuple set(Enum<?> eval, String val)
  {
    set(eval, val);
    return this;
  }

  public Tuple setString(Enum<?> eval, String val)
  {
    set(eval, val);
    return this;
  }

  /** @deprecated */
  public Tuple set(int idx, Boolean val)
  {
    set(idx, val);
    return this;
  }

  public Tuple setBoolean(int idx, Boolean val)
  {
    set(idx, val);
    return this;
  }

  /** @deprecated */
  public Tuple set(Enum<?> eval, Double val)
  {
    set(eval, val);
    return this;
  }

  public Tuple setDouble(Enum<?> eval, Double val)
  {
    set(eval, val);
    return this;
  }

  /** @deprecated */
  public Tuple set(int idx, Double val)
  {
    set(idx, val);
    return this;
  }

  public Tuple setDouble(int idx, Double val)
  {
    set(idx, val);
    return this;
  }

  /** @deprecated */
  public Tuple set(Enum<?> eval, Float val)
  {
    set(eval, val);
    return this;
  }

  /** @deprecated */
  public Tuple set(int idx, Float val)
  {
    set(idx, val);
    return this;
  }

  public Tuple setFloat(Enum<?> eval, Float val)
  {
    set(eval, val);
    return this;
  }

  public Tuple setFloat(int idx, Float val)
  {
    set(idx, val);
    return this;
  }

  /** @deprecated */
  public Tuple set(Enum<?> eval, BytesWritable val)
  {
    set(eval, val);
    return this;
  }

  /** @deprecated */
  public Tuple set(int idx, BytesWritable val)
  {
    set(idx, val);
    return this;
  }

  public Tuple setBytes(Enum<?> eval, BytesWritable val)
  {
    set(eval, val);
    return this;
  }

  public Tuple setBytes(int idx, BytesWritable val)
  {
    set(idx, val);
    return this;
  }

  public Tuple add(Short val)
  {
    this.fields.add(val);
    return this;
  }

  public Tuple addShort(Short val)
  {
    this.fields.add(val);
    return this;
  }

  public Tuple add(Integer val)
  {
    this.fields.add(val);
    return this;
  }

  public Tuple addInt(Integer val)
  {
    this.fields.add(val);
    return this;
  }

  public Tuple add(Long val)
  {
    this.fields.add(val);
    return this;
  }

  public Tuple addLong(Long val)
  {
    this.fields.add(val);
    return this;
  }

  public Tuple add(String val)
  {
    this.fields.add(val);
    return this;
  }

  public Tuple addString(String val)
  {
    this.fields.add(val);
    return this;
  }

  public Tuple add(Boolean val)
  {
    this.fields.add(val);
    return this;
  }

  public Tuple addBoolean(Boolean val)
  {
    this.fields.add(val);
    return this;
  }

  public Tuple add(Double val)
  {
    this.fields.add(val);
    return this;
  }

  public Tuple addDouble(Double val)
  {
    this.fields.add(val);
    return this;
  }

  public Tuple add(Float val)
  {
    this.fields.add(val);
    return this;
  }

  public Tuple addFloat(Float val)
  {
    this.fields.add(val);
    return this;
  }

  public Tuple add(BytesWritable val)
  {
    this.fields.add(val);
    return this;
  }

  public Tuple addBytes(BytesWritable val)
  {
    this.fields.add(val);
    return this;
  }

  public Object getObject(int idx)
  {
    if (idx < 0) {
      throw new IllegalArgumentException(new StringBuilder().append("Negative size: ").append(idx).toString());
    }
    if (idx >= this.fields.size()) {
      return null;
    }
    return this.fields.get(idx);
  }

  public Object getObject(Enum<?> eval)
  {
    return getObject(eval.ordinal());
  }

  public Short getShort(Enum<?> eval)
  {
    return (Short)getObject(eval);
  }

  public Short getShort(int idx)
  {
    return (Short)getObject(idx);
  }

  public Integer getInt(Enum<?> eval)
  {
    return (Integer)getObject(eval);
  }

  public Integer getInt(int idx)
  {
    return (Integer)getObject(idx);
  }

  public Long getLong(Enum<?> eval)
  {
    return (Long)getObject(eval);
  }

  public Long getLong(int idx)
  {
    return (Long)getObject(idx);
  }

  public String getString(Enum<?> eval)
  {
    return (String)getObject(eval);
  }

  public String getString(int idx)
  {
    return (String)getObject(idx);
  }

  public Boolean getBoolean(Enum<?> eval)
  {
    return (Boolean)getObject(eval);
  }

  public Boolean getBoolean(int idx)
  {
    return (Boolean)getObject(idx);
  }

  public Double getDouble(Enum<?> eval)
  {
    return (Double)getObject(eval);
  }

  public Double getDouble(int idx)
  {
    return (Double)getObject(idx);
  }

  public Float getFloat(Enum<?> eval)
  {
    return (Float)getObject(eval);
  }

  public Float getFloat(int idx)
  {
    return (Float)getObject(idx);
  }

  public BytesWritable getBytes(Enum<?> eval)
  {
    return (BytesWritable)getObject(eval);
  }

  public BytesWritable getBytes(int idx)
  {
    return (BytesWritable)getObject(idx);
  }

  public void write(DataOutput out) throws IOException
  {
    WritableUtils.writeVInt(out, this.fields.size());
    for (Iterator i$ = this.fields.iterator(); i$.hasNext(); ) { Object element = i$.next();
      SerializationUtils.write(out, element); }
  }

  public void readFields(DataInput in)
    throws IOException
  {
    this.fields.clear();
    int elementCount = WritableUtils.readVInt(in);
    while (elementCount-- > 0)
      this.fields.add(SerializationUtils.read(in));
  }

  public int hashCode()
  {
    return Arrays.hashCode(this.fields.toArray());
  }

  public boolean equals(Object object)
  {
    if (!(object instanceof Tuple)) {
      return false;
    }
    Tuple other = (Tuple)object;

    if (this.fields.size() != other.fields.size()) {
      return false;
    }
    for (int i = 0; i < this.fields.size(); i++) {
      Object lhs = this.fields.get(i);
      Object rhs = other.fields.get(i);

      if ((lhs != null) || (rhs != null))
      {
        if ((lhs == null) || (rhs == null)) {
          return false;
        }

        if (!lhs.equals(rhs)) {
          return false;
        }
      }
    }
    return true;
  }

  public String toString()
  {
    StringBuilder sb = new StringBuilder();
    for (int i = 0; i < this.fields.size(); i++)
    {
      if (i < this.fields.size() - 1)
        sb.append(this.fields.get(i)).append("\t");
      else
        sb.append(this.fields.get(i));
    }
    return sb.toString();
  }

  public int compareTo(Tuple other)
  {
    for (int i = 0; (i < this.fields.size()) && (i < other.fields.size()); i++)
    {
      Object lhs = this.fields.get(i);
      Object rhs = other.fields.get(i);

      if ((lhs != null) || (rhs != null))
      {
        int cmp = rhs == null ? 1 : lhs == null ? -1 : 0;

        if (cmp != 0) {
          return cmp;
        }

        cmp = ((Comparable)lhs).compareTo(rhs);

        if (cmp != 0) {
          return cmp;
        }
      }
    }
    return this.fields.size() - other.fields.size();
  }
}