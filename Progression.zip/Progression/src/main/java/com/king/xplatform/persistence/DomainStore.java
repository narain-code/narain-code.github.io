package com.king.xplatform.persistence;

import java.io.IOException;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.FileUtil;
import org.apache.hadoop.fs.Path;

public class DomainStore
{
  VersionedStore _vs;
  DomainSpec _spec;

  public DomainStore(FileSystem fs, String path)
    throws IOException
  {
    this(new VersionedStore(fs, path), null);
  }

  public DomainStore(FileSystem fs, String path, DomainSpec spec) throws IOException {
    this(new VersionedStore(fs, path), spec);
  }

  public DomainStore(String path) throws IOException {
    this(path, null);
  }

  public DomainStore(String path, DomainSpec spec) throws IOException {
    this(new VersionedStore(path), spec);
  }

  protected DomainStore(VersionedStore vs, DomainSpec spec) throws IOException {
    this._vs = vs;
    String path = vs.getRoot();
    FileSystem fs = vs.getFileSystem();
    if (DomainSpec.exists(fs, path)) {
      this._spec = DomainSpec.readFromFileSystem(fs, path);

      if ((spec != null) && (!this._spec.equals(spec)))
        throw new IllegalArgumentException(spec.toString() + " does not match existing " + this._spec.toString());
    }
    else {
      if (spec == null) {
        throw new IllegalArgumentException("You must supply a DomainSpec when creating a DomainStore.");
      }
      this._spec = spec;
      spec.writeToFileSystem(fs, path);
    }
  }

  public DomainSpec getSpec()
  {
    return this._spec;
  }

  public FileSystem getFileSystem() {
    return this._vs.getFileSystem();
  }

  public String getRoot() {
    return this._vs.getRoot();
  }

  public String versionPath(long version) {
    return this._vs.versionPath(version);
  }

  public String mostRecentVersionPath() throws IOException {
    return this._vs.mostRecentVersionPath();
  }

  public String mostRecentVersionPath(long maxVersion) throws IOException {
    return this._vs.mostRecentVersionPath(maxVersion);
  }

  public Long mostRecentVersion() throws IOException {
    return this._vs.mostRecentVersion();
  }

  public Long mostRecentVersion(long maxVersion) throws IOException {
    return this._vs.mostRecentVersion(maxVersion);
  }

  public String createVersion() throws IOException {
    return this._vs.createVersion();
  }

  public String createVersion(long version) throws IOException {
    return this._vs.createVersion(version);
  }

  public void failVersion(String path) throws IOException {
    this._vs.failVersion(path);
  }

  public void deleteVersion(long version) throws IOException {
    this._vs.deleteVersion(version);
  }

  public void succeedVersion(String path) throws IOException {
    this._vs.succeedVersion(path);
  }

  public static void synchronizeVersions(FileSystem fs, DomainSpec spec, String oldv, String newv)
    throws IOException
  {
    if (oldv != null)
      for (int i = 0; i < spec.getNumShards(); i++) {
        String currPath = oldv + "/" + i;
        String newPath = newv + "/" + i;
        if ((fs.exists(new Path(currPath))) && (!fs.exists(new Path(newPath))) && 
          (!FileUtil.copy(fs, new Path(currPath), fs, new Path(newPath), false, false, new Configuration())))
          throw new IOException("Unable to synchronize versions");
      }
  }

  public void synchronizeInProgressVersion(String path)
    throws IOException
  {
    synchronizeVersions(getFileSystem(), getSpec(), mostRecentVersionPath(), path);
  }

  public void cleanup() throws IOException {
    this._vs.cleanup();
  }

  public void cleanup(int versionsToKeep) throws IOException {
    this._vs.cleanup(versionsToKeep);
  }

  public List<Long> getAllVersions() throws IOException {
    return this._vs.getAllVersions();
  }

  public boolean hasVersion(long version) throws IOException {
    return this._vs.hasVersion(version);
  }
}