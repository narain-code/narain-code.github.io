package com.king.xplatform;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.ql.io.RCFileInputFormat;
import org.apache.hadoop.hive.serde2.ColumnProjectionUtils;
import org.apache.hadoop.hive.serde2.SerDeException;
import org.apache.hadoop.hive.serde2.columnar.BytesRefArrayWritable;
import org.apache.hadoop.hive.serde2.columnar.ColumnarSerDe;
import org.apache.hadoop.hive.serde2.objectinspector.StructField;
import org.apache.hadoop.hive.serde2.objectinspector.StructObjectInspector;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.FileSplit;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Partitioner;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapred.TextOutputFormat;

import com.google.common.hash.Funnel;
import com.google.common.hash.HashFunction;
import com.google.common.hash.Hashing;
import com.google.common.hash.Sink;

public class BlockPartition
{
  private static ColumnarSerDe serde;
  private static final HashFunction hfunc = Hashing.murmur3_128();

  public static void main(String[] args)
    throws IOException, InterruptedException, ClassNotFoundException
  {
    JobConf conf = new JobConf(BlockPartition.class);
    conf.setJobName("BlockPartioning");

    conf.setMapOutputKeyClass(Text.class);
    conf.setMapOutputValueClass(Text.class);

    conf.setOutputKeyClass(Text.class);
    conf.setOutputValueClass(Text.class);

    conf.setMapperClass(RcMapper.class);
    conf.setReducerClass(RcReducer.class);
    conf.setNumReduceTasks(8);
    conf.setPartitionerClass(RendezovousPartioning.class);

    ColumnProjectionUtils.setFullyReadColumns(conf);
    conf.setInputFormat(RCFileInputFormat.class);
    conf.setOutputFormat(TextOutputFormat.class);
    System.out.println(args[1]);
    FileInputFormat.setInputPaths(conf, new Path[] { new Path(args[1]) });
    FileOutputFormat.setOutputPath(conf, new Path(args[2]));

    JobClient.runJob(conf);
  }

  static
  {
    try
    {
      Configuration conf = new Configuration();
      Properties tbl = new Properties();

      tbl.setProperty("serialization.format", "9");

      tbl.setProperty("columns", "player_key,player_id");
      tbl.setProperty("columns.types", "string:bigint");
      tbl.setProperty("serialization.null.format", "NULL");

      serde = new ColumnarSerDe();
      serde.initialize(conf, tbl);

      StructObjectInspector oi = (StructObjectInspector)serde.getObjectInspector();
      List<? extends StructField> fieldRefs = oi.getAllStructFieldRefs();

      for (StructField structField : fieldRefs) {
        System.out.println("FIELD: " + structField.getFieldName());
      }

    }
    catch (Exception e)
    {
      e.printStackTrace();
      System.out.println("Failed to setup SERDE.");
    }
  }

  public static class RcReducer extends MapReduceBase
    implements Reducer<Text, Text, Text, Text>
  {
    public void reduce(Text arg0, Iterator<Text> arg1, OutputCollector<Text, Text> arg2, Reporter arg3)
      throws IOException
    {
      while (arg1.hasNext()) {
        Text record = (Text)arg1.next();
        arg2.collect(arg0, record);
      }
    }
  }

  static class RendezovousPartioning
    implements Partitioner<Text, Text>
  {
    private static final Funnel<String> strFunnel = new Funnel<String>() {
      public void funnel(String from, Sink into) {
        into.putBytes(from.getBytes());
      }
    };

    private RendezvousHash<String, String> ren = new RendezvousHash(BlockPartition.hfunc, strFunnel, strFunnel, new ArrayList());

    public int getPartition(Text key, Text value, int numReduceTasks)
    {
      String part = (String)this.ren.get(key.toString());
      if (numReduceTasks == 0) {
        return 0;
      }
      return Integer.parseInt(part);
    }

    public void configure(JobConf arg0)
    {
      for (int j = 0; j < 8; j++)
        this.ren.add("" + j);
    }
  }

  public static class RcMapper extends MapReduceBase
    implements Mapper<LongWritable, BytesRefArrayWritable, Text, Text>
  {
    public void map(LongWritable key, BytesRefArrayWritable value, OutputCollector<Text, Text> output, Reporter reporter)
      throws IOException
    {
      FileSplit fileSplit = (FileSplit)reporter.getInputSplit();
      System.out.println(new StringBuilder().append("GET PATH: ").append(fileSplit.getPath()).toString());

      System.out.println(new StringBuilder().append(value.size()).append(" size.  LINE: ").append(value.toString()).toString());
      try
      {
        StructObjectInspector oi = (StructObjectInspector)BlockPartition.serde.getObjectInspector();
        List fieldRefs = oi.getAllStructFieldRefs();

        Object raw = BlockPartition.serde.deserialize(value);

        List dataStruct = oi.getStructFieldsDataAsList(raw);

        StringBuilder txt = new StringBuilder();
        System.out.println(new StringBuilder().append("Size: ").append(dataStruct.size()).toString());
        int i = 0;
        Text patKey = null;
        Text patValue = null;
        for (Iterator i$ = dataStruct.iterator(); i$.hasNext(); ) { Object object = i$.next();

          if (i == 0)
          {
            String playerKey = object.toString();

            patKey = new Text(playerKey);
            i++;
          }
          else {
            patValue = new Text(object.toString());
          }
        }

        output.collect(patKey, patValue);
      }
      catch (SerDeException e)
      {
        throw new RuntimeException("Serde exception", e);
      }
    }
  }
}