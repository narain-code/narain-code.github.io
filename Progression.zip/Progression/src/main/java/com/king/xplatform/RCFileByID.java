package com.king.xplatform;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.ql.io.RCFileOutputFormat;
import org.apache.hadoop.hive.serde2.columnar.BytesRefArrayWritable;
import org.apache.hadoop.hive.serde2.columnar.BytesRefWritable;
import org.apache.hadoop.hive.serde2.columnar.ColumnarSerDe;
import org.apache.hadoop.hive.serde2.columnar.ColumnarStruct;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.StructField;
import org.apache.hadoop.hive.serde2.objectinspector.StructObjectInspector;
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.compress.GzipCodec;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.JobPriority;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Input;

public class RCFileByID {
	public static void main(String[] args)
	  {
	    JobConf conf = new JobConf(RCFileByID.class);
	    conf.setJobName("RCFileByID");
	    conf.setMapOutputKeyClass(NullWritable.class);
	    conf.setMapOutputValueClass(BytesRefArrayWritable.class);

	    conf.setMapperClass(RCKeyMapper.class);

	    conf.setNumReduceTasks(0);
	    conf.setCompressMapOutput(true);
	    conf.setMapOutputCompressorClass(GzipCodec.class);

	   // conf.setInputFormat(CompositeInputFormat.class);
	    //String strJoinStmt = CompositeInputFormat.compose("outer", MultipleSequenceFileFormat.class, new String[] { args[0], args[1] });
	   // conf.set("mapred.join.expr", strJoinStmt);
	    conf.setInputFormat(MultipleSequenceFileFormat.class);
	   
	    conf.setOutputFormat(RCFileOutputFormat.class);
	    RCFileOutputFormat.setCompressOutput(conf, true);
	    RCFileOutputFormat.setOutputCompressorClass(conf, GzipCodec.class);
	    try
	    {
	     FileInputFormat.setInputPaths(conf, new Path[] { new Path(args[0]) });
	      FileOutputFormat.setOutputPath(conf, new Path(args[1]));

	      conf.setJobPriority(JobPriority.VERY_HIGH);
	      conf.set("mapred.child.java.opts", "-Xmx5G");
	      conf.set("mapred.map.child.java.opts", "-Xmx5G");
	      conf.set("mapreduce.reduce.java.opts", "-Xms1G -Xmx2G -XX:+UseCompressedOops -Xloggc:gc.log -XX:+PrintGCDetails -XX:+PrintGCDateStamps -XX:+PrintHeapAtGC -XX:+PrintTenuringDistribution -XX:PrintFLSStatistics=1 -XX:+PrintGCApplicationStoppedTime");
	      conf.set("mapreduce.task.io.sort.mb", "1024");
	      conf.setInt("io.sort.mb", 1024);
	      conf.set("io.sort.spill.percent", "1.0");
	      conf.set("mapred.job.reduce.memory.mb", "2048");
	      conf.setLong("mapred.min.split.size", 67108864L);
	      conf.setLong("mapred.max.split.size", 268435456L);

	      conf.setInt("hive.io.rcfile.column.number.conf", 8);

	      conf.setInt("dfs.replication", 1);

	      JobClient.runJob(conf);
	    }
	    catch (IOException e) {
	      e.printStackTrace();
	    }
	  }

	  public static class RCKeyMapper extends MapReduceBase
	    implements Mapper<LongWritable, BytesWritable, NullWritable, BytesRefArrayWritable>
	  {
	    NullWritable nullW = NullWritable.get();
	    private static ColumnarSerDe serde;
	    final String emptyString = "";

	    KyroFactory _factory = new KyroFactory();
	    String toMerge = null;
	    int shardID = -1;
	    JobConf conf;

	    public int getShardID(String fileName, String splitBy)
	    {
	      String[] splits = fileName.split(splitBy);
	      if ((splits == null) || (splits.length == 0)) {
	        return -1;
	      }
	      try
	      {
	        return Integer.parseInt(splits[1]);
	      } catch (NumberFormatException nex) {
	      }
	      return -1;
	    }

	    public void configure(JobConf job)
	    {
	      this.conf = job;
	    }

	    public void map(LongWritable key, BytesWritable value, OutputCollector<NullWritable, BytesRefArrayWritable> output, Reporter reporter)
	      throws IOException
	    {
	   /*   String parentName1 = ((FileSplit)((CompositeInputSplit)reporter.getInputSplit()).get(0)).getPath().getName();
	      String parentName2 = ((FileSplit)((CompositeInputSplit)reporter.getInputSplit()).get(1)).getPath().getName();
	      System.out.println(parentName1 + " -- " + parentName2);

	      int shardId = getShardID(parentName1, "--");
	      if (shardId != this.shardID) {
	        this.conf.setInt("shardID", shardId);
	        this.shardID = shardId;
	      }
*/
	      Kryo kryo = this._factory.getKyro();
	     

	    
	        byte[] fByte = value.getBytes();
	        Input input = new Input(fByte.length * 2);
	        input.setBuffer(fByte, 0, fByte.length);

	        MappedProgressionValue someObject = (MappedProgressionValue)kryo.readClassAndObject(input);

	        input.close();
	       
	        toRC(key.get(), someObject, output);
	      
	    }

	    public void toMappedAndRC(BytesWritable secondValue, Kryo kryo, LongWritable key, OutputCollector<NullWritable, BytesRefArrayWritable> output)
	    {
	      MappedProgressionValue mergedObject = null;
	      byte[] sByte = secondValue.getBytes();
	      if (sByte.length == 0) {
	        System.out.println("length ");
	        return;
	      }

	      Input input2 = new Input(sByte);

	      mergedObject = (MappedProgressionValue)kryo.readClassAndObject(input2);

	     // toRC(Long.valueOf(Utils.deserializeLong(key)), mergedObject, output);
	      
	      toRC(key.get(), mergedObject, output);
	    }

	    public void toRC(Long lV, MappedProgressionValue val, OutputCollector<NullWritable, BytesRefArrayWritable> output) {
	      try {
	        Iterator it = val.allGroups.entrySet().iterator();
	        while (it.hasNext()) {
	          Map.Entry n = (Map.Entry)it.next();
	          GroupKey _gKey = (GroupKey)n.getKey();
	          GroupValue _gValue = (GroupValue)n.getValue();
	          //System.out.println(("" + _gKey.appId).getBytes("UTF-8"));
	          BytesRefArrayWritable bytes = new BytesRefArrayWritable(8);
	          
	          String value = lV.toString();
	          bytes.set(0, new BytesRefWritable(("" + value).getBytes("UTF-8")));
	          bytes.set(1, new BytesRefWritable(("" + _gKey.appId).getBytes("UTF-8")));
	          bytes.set(2, new BytesRefWritable(("" + _gKey.episode).getBytes("UTF-8")));
	          bytes.set(3, new BytesRefWritable(("" + _gKey.level).getBytes("UTF-8")));
	          bytes.set(4, new BytesRefWritable(("" + _gValue.gameendsbefore).getBytes("UTF-8")));
	          bytes.set(5, new BytesRefWritable(("" + _gValue.gameendsafter).getBytes("UTF-8")));
	          bytes.set(6, new BytesRefWritable(_gValue.firstPlay.getBytes()));
	          if (_gValue.successDate != null)
	            bytes.set(7, new BytesRefWritable(_gValue.successDate.getBytes()));
	          else
	            bytes.set(7, new BytesRefWritable("".getBytes()));
	          ObjectInspector inspector = serde.getObjectInspector();
	          ArrayList notSkipped = new ArrayList();
	          ColumnarStruct colStruct = new ColumnarStruct(inspector, notSkipped, new Text(""));
	          colStruct.init(bytes);
	         // output.collect(this.nullW, (BytesRefArrayWritable)serde.serialize(colStruct, inspector));
	          output.collect(this.nullW, bytes);
	        }
	      }
	      catch (Exception e) {
	        e.printStackTrace();
	        throw new RuntimeException(e.getMessage());
	      }
	    }

	    static
	    {
	      try
	      {
	        Configuration conf = new Configuration();
	        Properties tbl = new Properties();

	        tbl.setProperty("serialization.format", "9");

	        tbl.setProperty("columns", "kingpdjoinkey,appid,episode,level,gameendsbefore,gameendsafter,firstplaydt,successdt");
	        tbl.setProperty("columns.types", "string:int:bigint:bigint:bigint:bigint:string:string");

	        tbl.setProperty("serialization.null.format", "NULL");

	        serde = new ColumnarSerDe();
	        serde.initialize(conf, tbl);

	        StructObjectInspector oi = (StructObjectInspector)serde.getObjectInspector();
	        List<? extends StructField> fieldRefs = oi.getAllStructFieldRefs();

	        for (StructField structField : fieldRefs) {
	          System.out.println("FIELD: " + structField.getFieldName());
	        }

	      }
	      catch (Exception e)
	      {
	        e.printStackTrace();
	        System.out.println("Failed to setup SERDE.");
	      }
	    }
	  }

}
