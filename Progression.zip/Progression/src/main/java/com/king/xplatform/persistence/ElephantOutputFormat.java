package com.king.xplatform.persistence;

import java.io.IOException;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.mapred.InvalidJobConfException;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.OutputFormat;
import org.apache.hadoop.mapred.RecordWriter;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.util.Progressable;
import org.apache.log4j.Logger;

import com.king.xplatform.Exporter.CompoundKey;

public class ElephantOutputFormat
  implements OutputFormat<CompoundKey, ElephantRecordWritable>
{
  public static Logger LOG = Logger.getLogger(ElephantOutputFormat.class);
  public static final String ARGS_CONF = "elephant.output.args";

  public RecordWriter<CompoundKey, ElephantRecordWritable> getRecordWriter(FileSystem fs, JobConf conf, String string, Progressable progressable)
    throws IOException
  {
    return new ElephantRecordWriter(conf, (Args)Utils.getObject(conf, "elephant.output.args"), progressable);
  }

  public void checkOutputSpecs(FileSystem fs, JobConf conf) throws IOException {
    Args args = (Args)Utils.getObject(conf, "elephant.output.args");
    fs = Utils.getFS(args.outputDirHdfs, conf);
    if (conf.getBoolean("mapred.reduce.tasks.speculative.execution", true)) {
      throw new InvalidJobConfException("Speculative execution should be false");
    }
    if (fs.exists(new Path(args.outputDirHdfs))) {
      throw new InvalidJobConfException("Output dir already exists " + args.outputDirHdfs);
    }
    if ((args.updateDirHdfs != null) && (!fs.exists(new Path(args.updateDirHdfs))))
      throw new InvalidJobConfException("Shards to update does not exist " + args.updateDirHdfs);
  }

  public class ElephantRecordWriter
    implements RecordWriter<CompoundKey, ElephantRecordWritable>
  {
    FileSystem _fs;
    ElephantOutputFormat.Args _args;
    Map<Integer, LocalPersistence> _lps = new HashMap();
    Progressable _progressable;
    LocalElephantManager _localManager;
    int _numWritten = 0;
    long _lastCheckpoint = System.currentTimeMillis();

    public ElephantRecordWriter(Configuration conf, ElephantOutputFormat.Args args, Progressable progressable) throws IOException {
      this._fs = Utils.getFS(args.outputDirHdfs, conf);
      this._args = args;
      this._progressable = progressable;
      args.persistenceOptions.put("CONF", this._fs.getConf());
      args.persistenceOptions.put("FS", this._fs);
      args.persistenceOptions.put("progressable", progressable);
      this._localManager = new LocalElephantManager(this._fs, args.spec, args.persistenceOptions, LocalElephantManager.getTmpDirs(conf));
    }

    private String remoteUpdateDirForShard(int shard) {
      System.out.println("@@@@@@" + this._args.updateDirHdfs);
      if (this._args.updateDirHdfs == null) return null;
      return this._args.updateDirHdfs + "/" + shard;
    }

    public void write(CompoundKey shard, ElephantRecordWritable record) throws IOException
    {
      LocalPersistence lp = null;
      LocalPersistenceFactory fact = this._args.spec.getLPFactory();
      Map options = this._args.persistenceOptions;
      options.put("SHARDID", Integer.valueOf(shard.shard));
      if (this._lps.containsKey(Integer.valueOf(shard.shard))) {
        lp = (LocalPersistence)this._lps.get(Integer.valueOf(shard.shard));
      } else {
        String updateDir = remoteUpdateDirForShard(shard.shard);
        String localShard = this._localManager.downloadRemoteShard("" + shard.shard, updateDir);
        lp = fact.openPersistenceForAppend(localShard, options);

        this._lps.put(Integer.valueOf(shard.shard), lp);
        progress();
      }

      this._args.updater.updateElephant(lp, record.key, record.val);

      this._numWritten += 1;
      if (this._numWritten % 25000 == 0) {
        long now = System.currentTimeMillis();
        long delta = now - this._lastCheckpoint;
        this._lastCheckpoint = now;
        ElephantOutputFormat.LOG.info("Wrote last 25000 records in " + delta + " ms");
        this._localManager.progress();
      }
    }

    public void close(Reporter reporter)
      throws IOException
    {
    	Set<Integer> keys =this._lps.keySet();
    	for(Integer i:keys){
    		LocalPersistence p=this._lps.get(i);
    		if(p!=null)
    			p.close();
    	}
    }

    private void progress()
    {
      if (this._progressable != null) this._progressable.progress();
    }
  }

  public static class Args
    implements Serializable
  {
    public DomainSpec spec;
    public String outputDirHdfs;
    public ElephantUpdater updater = new ReplaceUpdater();
    public String updateDirHdfs = null;
    public Map<String, Object> persistenceOptions = new HashMap();

    public Args(DomainSpec spec, String outputDirHdfs) {
      this.spec = spec;
      this.outputDirHdfs = outputDirHdfs;
    }
  }
}