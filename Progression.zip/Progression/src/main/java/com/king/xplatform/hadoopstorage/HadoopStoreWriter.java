package com.king.xplatform.hadoopstorage;

public class HadoopStoreWriter {

}
