package com.king.xplatform;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.ql.io.RCFileInputFormat;
import org.apache.hadoop.hive.serde2.ColumnProjectionUtils;
import org.apache.hadoop.hive.serde2.SerDeException;
import org.apache.hadoop.hive.serde2.columnar.BytesRefArrayWritable;
import org.apache.hadoop.hive.serde2.columnar.ColumnarSerDe;
import org.apache.hadoop.hive.serde2.objectinspector.StructField;
import org.apache.hadoop.hive.serde2.objectinspector.StructObjectInspector;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapred.TextOutputFormat;

import com.google.common.hash.HashFunction;
import com.google.common.hash.Hashing;
import com.king.xplatform.tuple.ShuffleUtils;
import com.king.xplatform.tuple.Tuple;

public class BlockPartitionProgression
{
  private static ColumnarSerDe serde;
  private static final HashFunction hfunc = Hashing.murmur3_128();

  public static void main(String[] args)
    throws IOException, InterruptedException, ClassNotFoundException
  {
    JobConf conf = new JobConf(BlockPartitionProgression.class);
    conf.setJobName("BlockPartitionProgression");
    ShuffleUtils.configBuilder().useOldApi().setPartitionerIndices(new Enum[] { TupleKeyFields.PLAYER_KEY }).setSortIndices(TupleKeyFields.values()).setGroupIndices(TupleKeyFields.values()).configure(conf);

    conf.setMapOutputKeyClass(Tuple.class);
    conf.setMapOutputValueClass(Tuple.class);

    conf.setOutputKeyClass(Text.class);
    conf.setOutputValueClass(Text.class);

    conf.setMapperClass(RcMapper.class);
    conf.setReducerClass(RcReducer.class);
    conf.setNumReduceTasks(128);

    ColumnProjectionUtils.setFullyReadColumns(conf);
    conf.setInputFormat(RCFileInputFormat.class);

    conf.setLong("mapred.min.split.size", 67108864L);
    conf.setLong("mapred.max.split.size", 268435456L);
    conf.setOutputFormat(TextOutputFormat.class);
    System.out.println(args[0]);
    FileInputFormat.setInputPaths(conf, new Path[] { new Path(args[0]) });
    FileOutputFormat.setOutputPath(conf, new Path(args[1]));

    JobClient.runJob(conf);
  }

  static
  {
    try
    {
      Configuration conf = new Configuration();
      Properties tbl = new Properties();

      tbl.setProperty("serialization.format", "9");

      tbl.setProperty("columns", "player_key,appid,episode,level,gameendsbefore,gameendsafter,dt");
      tbl.setProperty("columns.types", "string:int:bigint:bigint:bigint:bigint:string");
      tbl.setProperty("serialization.null.format", "NULL");

      serde = new ColumnarSerDe();
      serde.initialize(conf, tbl);

      StructObjectInspector oi = (StructObjectInspector)serde.getObjectInspector();
      List<? extends StructField> fieldRefs = oi.getAllStructFieldRefs();

      for (StructField structField : fieldRefs) {
        System.out.println("FIELD: " + structField.getFieldName());
      }

    }
    catch (Exception e)
    {
      e.printStackTrace();
      System.out.println("Failed to setup SERDE.");
    }
  }

  public static class RcReducer extends MapReduceBase
    implements Reducer<Tuple, Tuple, Text, Text>
  {
    public void reduce(Tuple arg0, Iterator<Tuple> arg1, OutputCollector<Text, Text> arg2, Reporter arg3)
      throws IOException
    {
      long gameendsbefore = 0L;
      long gameendsafter = 0L;
      String date = "";
      String date2 = "";
      while (arg1.hasNext()) {
        Tuple record = (Tuple)arg1.next();
        if (record.getLong(BlockPartitionProgression.TupleValueFields.GAMEENDSBEFORE) != null)
          gameendsbefore += record.getLong(BlockPartitionProgression.TupleValueFields.GAMEENDSBEFORE).longValue();
        if (record.getLong(BlockPartitionProgression.TupleValueFields.GAMEENDSAFTER) != null)
          gameendsafter += record.getLong(BlockPartitionProgression.TupleValueFields.GAMEENDSAFTER).longValue();
        date = record.getString(BlockPartitionProgression.TupleValueFields.FIRSTPLAYDATE);
        date2 = record.getString(BlockPartitionProgression.TupleValueFields.SUCCESSDATE);
      }
      Text val = new Text(gameendsbefore + "\t" + gameendsafter + "\t" + date + "\t" + date2);
      arg2.collect(new Text(arg0.toString()), val);
    }
  }

  public static class RcMapper extends MapReduceBase
    implements Mapper<LongWritable, BytesRefArrayWritable, Tuple, Tuple>
  {
    HashMap<Tuple, Tuple> inmemoryValues = new HashMap();

    public void map(LongWritable key, BytesRefArrayWritable value, OutputCollector<Tuple, Tuple> output, Reporter reporter)
      throws IOException
    {
      System.out.println(value.size() + " size.  LINE: " + value.toString());
      try
      {
        StructObjectInspector oi = (StructObjectInspector)BlockPartitionProgression.serde.getObjectInspector();
        List fieldRefs = oi.getAllStructFieldRefs();

        Object raw = BlockPartitionProgression.serde.deserialize(value);

        List dataStruct = oi.getStructFieldsDataAsList(raw);

        Tuple outputKey = new Tuple();
        Tuple outputValue = new Tuple();
        System.out.println("Size: " + dataStruct.size());

        outputKey.set(BlockPartitionProgression.TupleKeyFields.PLAYER_KEY, dataStruct.get(0).toString());
        outputKey.set(BlockPartitionProgression.TupleKeyFields.APP_ID, Integer.valueOf(Integer.parseInt(dataStruct.get(1).toString())));
        outputKey.set(BlockPartitionProgression.TupleKeyFields.EPISODE, Long.valueOf(dataStruct.get(2).toString()));
        outputKey.set(BlockPartitionProgression.TupleKeyFields.LEVEL, Long.valueOf(dataStruct.get(3).toString()));
        outputValue.set(BlockPartitionProgression.TupleValueFields.GAMEENDSBEFORE, Long.valueOf(dataStruct.get(4).toString()));
        if ((dataStruct.get(5) == null) || ("".equalsIgnoreCase(dataStruct.get(5).toString())))
          outputValue.set(BlockPartitionProgression.TupleValueFields.GAMEENDSAFTER, Long.valueOf(0L));
        else {
          outputValue.set(BlockPartitionProgression.TupleValueFields.GAMEENDSAFTER, Long.valueOf(dataStruct.get(5).toString()));
        }
        outputValue.set(BlockPartitionProgression.TupleValueFields.FIRSTPLAYDATE, "2014-07-02");
        if (Long.valueOf(dataStruct.get(5).toString()).longValue() > 0L)
          outputValue.set(BlockPartitionProgression.TupleValueFields.SUCCESSDATE, "2014-07-02");
        else
          outputValue.set(BlockPartitionProgression.TupleValueFields.SUCCESSDATE, "");
        if (this.inmemoryValues.containsKey(outputKey)) {
          Tuple val = (Tuple)this.inmemoryValues.get(outputKey);

          val.set(BlockPartitionProgression.TupleValueFields.GAMEENDSAFTER, Long.valueOf(val.getLong(1).longValue() + outputValue.getLong(1).longValue()));
          val.set(BlockPartitionProgression.TupleValueFields.GAMEENDSBEFORE, Long.valueOf(val.getLong(2).longValue() + outputValue.getLong(2).longValue()));
        }

        output.collect(outputKey, outputValue);
      }
      catch (SerDeException e)
      {
        throw new RuntimeException("Serde exception", e);
      }
    }
  }

  public static enum TupleValueFields
  {
    GAMEENDSBEFORE, 
    GAMEENDSAFTER, 
    FIRSTPLAYDATE, 
    SUCCESSDATE;
  }

  public static enum TupleKeyFields
  {
    PLAYER_KEY, 
    APP_ID, 
    EPISODE, 
    LEVEL;
  }
}