package com.king.xplatform.persistence;

import java.io.IOException;

import com.king.xplatform.KyroFactory;

public class ReplaceUpdater
  implements ElephantUpdater
{
  KyroFactory factory = new KyroFactory();

  public void updateElephant(LocalPersistence lp, byte[] newKey, byte[] newVal) throws IOException {
    lp.add(newKey, newVal);
  }
}