package com.king.xplatform;

import java.io.ByteArrayInputStream;
import java.io.DataInput;
import java.io.DataInputStream;
import java.io.DataOutput;
import java.io.IOException;
import java.security.PrivilegedExceptionAction;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.ql.io.RCFileInputFormat;
import org.apache.hadoop.hive.serde2.ColumnProjectionUtils;
import org.apache.hadoop.hive.serde2.SerDeException;
import org.apache.hadoop.hive.serde2.columnar.BytesRefArrayWritable;
import org.apache.hadoop.hive.serde2.columnar.ColumnarSerDe;
import org.apache.hadoop.hive.serde2.objectinspector.StructField;
import org.apache.hadoop.hive.serde2.objectinspector.StructObjectInspector;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.RawComparator;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableComparator;
import org.apache.hadoop.io.WritableUtils;
import org.apache.hadoop.io.compress.SnappyCodec;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.JobPriority;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Partitioner;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapred.RunningJob;
import org.apache.hadoop.security.UserGroupInformation;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.ByteBufferInput;
import com.esotericsoftware.kryo.io.ByteBufferOutput;
import com.esotericsoftware.kryo.io.Input;
import com.king.xplatform.persistence.DomainSpec;
import com.king.xplatform.persistence.DomainStore;
import com.king.xplatform.persistence.ElephantOutputFormat;
import com.king.xplatform.persistence.ElephantRecordWritable;
import com.king.xplatform.persistence.ElephantUpdater;
import com.king.xplatform.persistence.KeySorter;
import com.king.xplatform.persistence.MapFileDB;
import com.king.xplatform.persistence.ReplaceUpdater;
import com.king.xplatform.persistence.Utils;

public class Exporter
{
  private static ColumnarSerDe serde;
  private static final String defDate = "2014-07-01";

  public static void export(String srcDir, String outDir, Args args)
    throws IOException, InterruptedException
  {
    DomainStore store = new DomainStore(outDir, args.spec);
    String newVersion = store.createVersion();
    System.out.println(newVersion);
    String oldVersion = store.mostRecentVersionPath();
    System.out.println(oldVersion);
    ElephantOutputFormat.Args jobargs = new ElephantOutputFormat.Args(args.spec, newVersion);
    args.persistenceOptions.put("newVersion", newVersion);
    args.persistenceOptions.put("oldVersion", oldVersion);
    jobargs.persistenceOptions = args.persistenceOptions;

    if (args.updater != null) {
      jobargs.updater = args.updater;
      jobargs.updateDirHdfs = oldVersion;
    }

    JobConf conf = new JobConf(Exporter.class);
    if (startDate !=null && endDate != null){
    	conf.set("StartDate", startDate);
	    conf.set("EndDate", endDate);
	    FileInputFormat.setInputPathFilter(conf, FilteredDateJob.class);
	    conf.setInputFormat(CombineInputFormat.class);
    }else
     conf.setInputFormat(RCFileInputFormat.class);

    ColumnProjectionUtils.setFullyReadColumns(conf);
    conf.setMapOutputKeyClass(CompoundKey.class);
    conf.setMapOutputValueClass(ElephantRecordWritable.class);
    conf.setOutputKeyClass(IntWritable.class);
    conf.setOutputValueClass(ElephantRecordWritable.class);
    conf.setOutputFormat(ElephantOutputFormat.class);
    conf.setMapperClass(ExporterMapper.class);
    conf.setReducerClass(ExporterReducer.class);
    conf.setMapOutputCompressorClass(SnappyCodec.class);
    conf.setPartitionerClass(ElephantPartitioner.class);
    conf.setOutputValueGroupingComparator(ElephantPrimarySort.class);
    conf.setOutputKeyComparatorClass(ElephantSecondarySort.class);
    conf.setJobPriority(JobPriority.NORMAL);
    conf.set("hadoop.job.ugi", "dwhuser");
    conf.set("mapreduce.map.memory.mb", "20480");
    conf.set("mapreduce.reduce.shuffle.input.buffer.percent","0.3");
    conf.set("mapreduce.reduce.shuffle.memory.limit.percent","0.25");
    conf.set ("mapreduce.reduce.shuffle.parallelcopies ","5");
   
     //conf.set("mapreduce.reduce.java.opts", "-Xms6G -Xmx10G");
     conf.set("mapreduce.map.java.opts", "-Xms20G -Xmx20G");
    conf.set("mapreduce.map.java.opts", "-Xmx20G");
   // conf.set("mapred.map.child.java.opts", "-Xmx2G");
    conf.set("mapreduce.reduce.java.opts", "-Xmx20G");
  //  conf.set("mapreduce.task.io.sort.mb", "600m");
    conf.set("mapred.job.reduce.memory.mb", "32768");
  //  conf.set("mapreduce.reduce.merge.inmem.threshold","1");
   // conf.setLong("mapred.min.split.size", 67108864L);
   // conf.setLong("mapred.max.split.size", 268435456L);
    conf.setMemoryForReduceTask(32768l);
    conf.setCombinerClass(ExporterReducer.class);
    conf.setInt("dfs.replication", 3);
    FileInputFormat.setInputPaths(conf, new Path[] { new Path(srcDir) });

    FileOutputFormat.setOutputPath(conf, new Path(outDir));
   // conf.setSpeculativeExecution(false);
    conf.setNumReduceTasks(args.spec.getNumShards());

    conf.setJobName("EDB Exporter: " + srcDir + " -> " + newVersion);
    conf.set("fs.permissions.umask-mode", "000");
	    conf.set("dfs.umaskmode", "000");
    Utils.setObject(conf, "elephant.output.args", jobargs);
    try
    {
     /* RunningJob job = new JobClient(conf).submitJob(conf);
      while (!job.isComplete()) {
        Thread.sleep(100L);
      }

      if (!job.isSuccessful()) throw new IOException("Job failed" + job.getFailureInfo()); */
    	new JobClient(conf).runJob(conf);

      if (oldVersion != null) {
        DomainStore.synchronizeVersions(Utils.getFS(outDir, conf), args.spec, oldVersion, newVersion);
      }
      store.succeedVersion(newVersion);
    } catch (IOException e) {
      store.failVersion(newVersion);
      throw e;
    }
  }

  public static void export(String srcDir, String outDir, DomainSpec spec) throws IOException, InterruptedException
  {
    export(srcDir, outDir, new Args(spec));
  }

  static String startDate;
  static String endDate;
  
   static final int numberOfShards = 1024;
  public static void main(String[] args) {
        final String[] f_args = args; 
    	UserGroupInformation ugi = UserGroupInformation.createRemoteUser("narainra"); 
    	try {
			ugi.doAs(new PrivilegedExceptionAction<Void>() {
			    public Void run() throws Exception {
			    	
			       // int res = ToolRunner.run(configuration, new YourTool(), args);
			       
			        if(f_args.length > 2 && f_args[2] != null)
			    		startDate =f_args[2];
			    	if(f_args.length > 3 &&  f_args[3] != null)
			    		endDate =f_args[3];
			      export(f_args[0], f_args[1], new DomainSpec(MapFileDB.class, numberOfShards));
			    	
			     return null;
			    }   
			});
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
  }

  static
  {
    try
    {
      Configuration conf = new Configuration();
      conf.set("hadoop.job.ugi", "narainra");
      Properties tbl = new Properties();

      tbl.setProperty("serialization.format", "9");

      tbl.setProperty("columns", "player_key,appid,episode,level,gameendsbefore,gameendsafter,dt");
      tbl.setProperty("columns.types", "string:int:bigint:bigint:bigint:bigint:string");

      tbl.setProperty("serialization.null.format", "NULL");

      serde = new ColumnarSerDe();
      serde.initialize(conf, tbl);

      StructObjectInspector oi = (StructObjectInspector)serde.getObjectInspector();
      List<? extends StructField> fieldRefs = oi.getAllStructFieldRefs();

      for (StructField structField : fieldRefs) {
        System.out.println("FIELD: " + structField.getFieldName());
      }

    }
    catch (Exception e)
    {
      e.printStackTrace();
      System.out.println("Failed to setup SERDE.");
    }
  }

  public static final class ElephantSecondarySort
    implements RawComparator<Exporter.CompoundKey>
  {
    Exporter.CompoundKey ckey1 = new Exporter.CompoundKey();
    Exporter.CompoundKey ckey2 = new Exporter.CompoundKey();

    public int compare(byte[] key1, int start1, int length1, byte[] key2, int start2, int length2) {
      try {
        DataInputStream s1 = new DataInputStream(new ByteArrayInputStream(key1, start1, length1));
        DataInputStream s2 = new DataInputStream(new ByteArrayInputStream(key2, start2, length2));
        this.ckey1.readFields(s1);
        this.ckey2.readFields(s2);
        return compare(this.ckey1, this.ckey2);
      } catch (IOException e) {
        throw new RuntimeException(e);
      }
    }

    public int compare(Exporter.CompoundKey key1, Exporter.CompoundKey key2) {
      if (key1.shard != key2.shard) {
        return key1.shard - key2.shard;
      }
      return WritableComparator.compareBytes(key1.shardKey, 0, key1.shardKey.length, key2.shardKey, 0, key2.shardKey.length);
    }
  }

  public static final class ElephantPrimarySort
    implements RawComparator<Exporter.CompoundKey>
  {
    public int compare(byte[] key1, int start1, int length1, byte[] key2, int start2, int length2)
    {
      DataInputStream s1 = new DataInputStream(new ByteArrayInputStream(key1, start1, length1));
      DataInputStream s2 = new DataInputStream(new ByteArrayInputStream(key2, start2, length2));
      try {
        return WritableUtils.readVInt(s1) - WritableUtils.readVInt(s2);
      } catch (IOException e) {
        throw new RuntimeException(e);
      }
    }

    public int compare(Exporter.CompoundKey key1, Exporter.CompoundKey key2)
    {
      return key1.shard - key2.shard;
    }
  }

  public static class Args
  {
    public DomainSpec spec;
    public ElephantUpdater updater = new ReplaceUpdater();
    public Map<String, Object> persistenceOptions = new HashMap();

    public Args(DomainSpec spec) {
      this.spec = spec;
    }
  }

  public static class ElephantPartitioner
    implements Partitioner<Exporter.CompoundKey, ElephantRecordWritable>
  {
    public int getPartition(Exporter.CompoundKey k2, ElephantRecordWritable v2, int numPartitions)
    {
      return k2.shard % numPartitions;
    }

    public void configure(JobConf jc)
    {
    }
  }

  public static class ExporterReducer extends MapReduceBase
    implements Reducer<Exporter.CompoundKey, ElephantRecordWritable, Exporter.CompoundKey, ElephantRecordWritable>
  {
    IntWritable shard = new IntWritable();
    KyroFactory _factory = new KyroFactory();

    public void reduce(Exporter.CompoundKey key, Iterator<ElephantRecordWritable> it, OutputCollector<Exporter.CompoundKey, ElephantRecordWritable> oc, Reporter rprtr)
      throws IOException
    {
      Kryo kryo = this._factory.getKyro();

      byte[] player_key = key.shardKey;
      MappedProgressionValue old = null;
      byte[] oldPlayer_key = null;
      while (it.hasNext()) {
        this.shard.set(key.shard);
        ElephantRecordWritable w = (ElephantRecordWritable)it.next();
        player_key = w.getKey();
       
        Input input = new Input(new ByteBufferInput(w.getValue()));

        MappedProgressionValue someObject = (MappedProgressionValue)kryo.readObject(input, MappedProgressionValue.class);
        if (old == null) {
          old = someObject;
          oldPlayer_key = player_key;
        }
        else if (WritableComparator.compareBytes(player_key, 0, player_key.length, oldPlayer_key, 0, oldPlayer_key.length) == 0)
        {
          old.merge(someObject);
        } else {
          int currentSize = numberOfShards;
          ByteBufferOutput output = new ByteBufferOutput(currentSize);
          boolean done = false;
          while (!done) {
            try
            {
              kryo.writeObject(output, old);
              done = true;
            }
            catch (Exception e) {
              currentSize *= 2;
              output = new ByteBufferOutput(currentSize);
            }
          }
          byte[] serialized = output.toBytes();
          output.close();
          oc.collect(key, new ElephantRecordWritable(oldPlayer_key, serialized));

        
          old = someObject;
          oldPlayer_key = player_key;
        }

      }

      int currentSize = numberOfShards;
      ByteBufferOutput output = new ByteBufferOutput(currentSize);
      boolean done = false;
      while (!done) {
        try
        {
          kryo.writeObject(output, old);
          done = true;
        }
        catch (Exception e) {
          currentSize *= 2;
          output = new ByteBufferOutput(currentSize);
        }
      }
      byte[] serialized = output.toBytes();
      output.close();
      oc.collect(key, new ElephantRecordWritable(oldPlayer_key, serialized));
     
    }

    public void configure(JobConf jc) {
      System.out.println("reduce mem" + jc.getMemoryForReduceTask());

      long total = Runtime.getRuntime().totalMemory();

      long free = Runtime.getRuntime().freeMemory();

      long used = total - free;

      System.out.println("total memory in bytes: " + total);
    }

    public void close()
      throws IOException
    {
    }
  }

  public static class ExporterMapper extends MapReduceBase
    implements Mapper<LongWritable, BytesRefArrayWritable, Exporter.CompoundKey, ElephantRecordWritable>
  {
    KeySorter sorter;
    int _numShards;
    public static final int NOPRESENTEPISODE = 0;
    public static final int NOLEVEL = -1;
    Kryo kryo = new Kryo();
    public static final String DATEST = "dt=";

    public void map(LongWritable key, BytesRefArrayWritable value, OutputCollector<Exporter.CompoundKey, ElephantRecordWritable> oc, Reporter rprtr)
      throws IOException
    {
      try
      {
       /* String parentName = ((FileSplit)rprtr.getInputSplit()).getPath().getParent().getName();
        int indexPos = parentName.indexOf("dt=");
        String parsedDate = null;
        if (indexPos != -1) {
          parsedDate = parentName.substring(indexPos + "dt=".length());
        }*/

        StructObjectInspector oi = (StructObjectInspector)Exporter.serde.getObjectInspector();
        List fieldRefs = oi.getAllStructFieldRefs();

        Object raw = Exporter.serde.deserialize(value);

        List dataStruct = oi.getStructFieldsDataAsList(raw);

        StringBuilder txt = new StringBuilder();

        int i = 0;
        String parsedDate = dataStruct.get(6).toString();
        byte[] keyBytes = dataStruct.get(0).toString().getBytes();
        String keyString = new String(keyBytes);
       
        byte[] sortKey = this.sorter.getSortableKey(keyBytes);
        byte[] valBytes = null;

        MappedProgressionValue mappedvalue = new MappedProgressionValue();
        GroupKey grpkey = new GroupKey();
        if (dataStruct.get(1) == null) {
          grpkey.setEpisode(-1L);
          rprtr.getCounter(Exporter.REJECTED_COUNTER.NOAPP).increment(1L);
          return;
        }

        grpkey.setAppId(Integer.parseInt(dataStruct.get(1).toString()));
        if (dataStruct.get(2) == null)
        {
          grpkey.setEpisode(0L);
        }
        else
        {
          grpkey.setEpisode(Integer.valueOf(dataStruct.get(2).toString()).intValue());
        }if (dataStruct.get(3) == null) {
          rprtr.getCounter(Exporter.REJECTED_COUNTER.NOLEVEL).increment(1L);
          return;
        }
        
       
        grpkey.setLevel(Integer.valueOf(dataStruct.get(3).toString()).intValue());

        GroupValue grpValue = new GroupValue();
        grpValue.setGameendsbefore(Long.valueOf(dataStruct.get(4).toString()).longValue());
        if ((dataStruct.get(5) == null) || ("".equalsIgnoreCase(dataStruct.get(5).toString())))
          grpValue.setGameendsafter(0L);
        else {
          grpValue.setGameendsafter(Long.valueOf(dataStruct.get(5).toString()).longValue());
        }
        if (parsedDate == null)
          grpValue.setFirstPlay("2014-07-01");
        else
          grpValue.setFirstPlay(parsedDate);
        if (Long.valueOf(dataStruct.get(5).toString()).longValue() > 0L) {
          if (parsedDate == null) {
            grpValue.setSuccessDate("2014-07-01");
          }
          else {
            grpValue.setSuccessDate(parsedDate);
            
          }
        }
        grpValue.setLastPlayDate(parsedDate);
        mappedvalue.add2Group(grpkey, grpValue);
        ByteBufferOutput output = new ByteBufferOutput(256);

        this.kryo.writeObject(output, mappedvalue);
        valBytes = output.toBytes();
        output.close();
        int shard = Utils.keyShard(keyBytes, this._numShards);
        oc.collect(new Exporter.CompoundKey(shard, keyBytes), new ElephantRecordWritable(keyBytes, valBytes));
        
       
      } catch (SerDeException e) {
    	  e.printStackTrace();
        throw new RuntimeException("Serde exception", e);
      }
    }

    public void configure(JobConf jc) {
      ElephantOutputFormat.Args args = (ElephantOutputFormat.Args)Utils.getObject(jc, "elephant.output.args");
      this._numShards = args.spec.getNumShards();
      this.sorter = args.spec.getLPFactory().getKeySorter();
    }

    public void close()
      throws IOException
    {
    }
  }

  public static class CompoundKey
    implements Writable
  {
    public int shard;
    public byte[] shardKey;

    public CompoundKey()
    {
    }

    public CompoundKey(int shard, byte[] shardKey)
    {
      this.shard = shard;
      this.shardKey = shardKey;
    }

    public void write(DataOutput d) throws IOException {
      WritableUtils.writeVInt(d, this.shard);
      WritableUtils.writeVInt(d, this.shardKey.length);
      d.write(this.shardKey);
    }

    public void readFields(DataInput di) throws IOException {
      this.shard = WritableUtils.readVInt(di);
      this.shardKey = new byte[WritableUtils.readVInt(di)];
      di.readFully(this.shardKey);
    }
  }

  public static enum REJECTED_COUNTER
  {
    NOLEVEL, 
    NOEPISODE, 
    NOAPP;
  }
  
  
}