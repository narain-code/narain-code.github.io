package com.king.xplatform;

public interface ExecuteWithReturnCode {

	public int run(String[] args);
}
