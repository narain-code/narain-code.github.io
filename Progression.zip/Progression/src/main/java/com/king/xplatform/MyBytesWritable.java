package com.king.xplatform;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.WritableComparator;

public class MyBytesWritable extends BytesWritable
{
  private static final int LENGTH_BYTES = 4;
  private static final byte[] EMPTY_BYTES = new byte[0];
  public BytesWritable writable;
  private int size;
  private byte[] bytes;

  public MyBytesWritable()
  {
    this.writable = new BytesWritable(EMPTY_BYTES);
  }

  public MyBytesWritable(byte[] bytes)
  {
    this.writable = new BytesWritable(bytes, bytes.length);
  }

  public MyBytesWritable(byte[] bytes, int length)
  {
    this.writable = new BytesWritable(bytes, length);
  }

  public MyBytesWritable(BytesWritable writable)
  {
    this.writable = writable;
  }

  public byte[] copyBytes()
  {
    return this.writable.copyBytes();
  }

  public byte[] getBytes()
  {
    return this.writable.getBytes();
  }

  @Deprecated
  public byte[] get()
  {
    return getBytes();
  }

  public int getLength()
  {
    return this.writable.getLength();
  }

  @Deprecated
  public int getSize()
  {
    return getLength();
  }

  public void setSize(int size)
  {
    if (size > getCapacity()) {
      setCapacity(size);
    }
    this.size = size;
  }

  public int getCapacity()
  {
    return this.writable.getCapacity();
  }

  public void setCapacity(int new_cap)
  {
    this.writable.setCapacity(new_cap);
  }

  public void set(MyBytesWritable newData)
  {
    this.writable.set(newData.writable);
  }

  public void set(byte[] newData, int offset, int length)
  {
    this.writable.set(newData, offset, length);
  }

  public void readFields(DataInput in) throws IOException
  {
    this.writable.setSize(0);

    int size = in.readInt();
    this.writable.setCapacity(size);
    //System.out.println(" SIZE IS " + size);
    if(size <= 8)
     in.readFully(this.writable.getBytes(), 0, size);
    else{
    	System.out.println(" SIZE IS " + size);	
    	
     long key= in.readLong();
     System.out.println("key is "+ key);
    }
  }

  public void write(DataOutput out) throws IOException
  {
	  int size =this.writable.getLength(); 
	  if(size > 8)
	  System.out.println(" SIZE IS " + size);	
	  this.writable.write(out);
  }

  public int hashCode()
  {
    return this.writable.hashCode();
  }

  public boolean equals(Object right_obj)
  {
    return this.writable.equals(((MyBytesWritable)right_obj).writable);
  }

  public String toString()
  {
    return this.writable.toString();
  }

  static
  {
    WritableComparator.define(MyBytesWritable.class, new BytesWritable.Comparator());
  }
}