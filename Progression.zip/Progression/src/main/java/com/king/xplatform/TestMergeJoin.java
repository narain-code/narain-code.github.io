package com.king.xplatform;

import java.io.IOException;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.compress.GzipCodec;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.JobPriority;
import org.apache.hadoop.mapred.KeyValueTextInputFormat;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapred.TextOutputFormat;
import org.apache.hadoop.mapred.join.CompositeInputFormat;
import org.apache.hadoop.mapred.join.TupleWritable;


public class TestMergeJoin {
	
	public static void main(String[] args){
		{
		    JobConf conf = new JobConf(TestMergeJoin.class);
		    conf.setJobName("TestMergeJoin");
		    conf.setMapOutputKeyClass(Text.class);
		    conf.setMapOutputValueClass(Text.class);
		    conf.setOutputKeyClass(Text.class);
		    conf.setOutputValueClass(Text.class);
		    conf.setMapperClass(TextMapper.class);

		    conf.setNumReduceTasks(0);
		    conf.setCompressMapOutput(true);
		    conf.setMapOutputCompressorClass(GzipCodec.class);

		    conf.setInputFormat(CompositeInputFormat.class);
		    String strJoinStmt = CompositeInputFormat.compose("outer", KeyValueTextInputFormat.class, new String[] { args[0], args[1] });

		    conf.set("mapred.join.expr", strJoinStmt);
		    conf.setOutputFormat(TextOutputFormat.class);
		    conf.set("mapreduce.input.keyvaluelinerecordreader.key.value.separator", "\t");
		    try
		    {
		      FileOutputFormat.setOutputPath(conf, new Path(args[2]));

		      conf.setJobPriority(JobPriority.VERY_HIGH);
		    

		      conf.setInt("dfs.replication", 1);

		      JobClient.runJob(conf);
		    }
		    catch (IOException e) {
		      e.printStackTrace();
		    }
		}
		
		
		
	}
	
	 public static class TextMapper extends MapReduceBase
	    implements Mapper<Text, TupleWritable, Text, Text>
	  {
		 	String previous_l = null; 
		@Override
		public void map(Text key, TupleWritable value,
				OutputCollector<Text, Text> output, Reporter reporter)
				throws IOException {
			// TODO Auto-generated method stub
			 String l =value.get(0).toString();
			 boolean notSame = false;
			 if(previous_l == null){
				 ;
			 }
			 else {	  
			 if ( previous_l.equalsIgnoreCase(l)){
				 notSame = true;
			 }else{
				 ;
			 }
				 
			 }	 
			 String r =value.get(1).toString();
			 if(notSame){
				 l="";
				 
			 }else
				  previous_l =l;
			output.collect(key, new Text( l + "--"+r));
			
		}
		 
	  }
	 
}
