package com.king.xplatform;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.ql.io.RCFileRecordReader;
import org.apache.hadoop.hive.serde2.columnar.BytesRefArrayWritable;
import org.apache.hadoop.hive.serde2.columnar.BytesRefWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.mapred.FileSplit;
import org.apache.hadoop.mapred.RecordReader;
import org.apache.hadoop.mapred.lib.CombineFileSplit;

public class CombineReader
  implements RecordReader<LongWritable, BytesRefArrayWritable>
{
  private CombineFileSplit split;
  private long offset;
  private long totLength;
  private FileSystem fs;
  private int count = 0;
  private Path[] paths;
  private String parsedDate;
  Configuration conf;
  private FSDataInputStream currentStream;
  private RCFileRecordReader<LongWritable, BytesRefArrayWritable> currentReader;

  public CombineReader(Configuration conf, CombineFileSplit split)
    throws IOException
  {
    this.conf = conf;
    this.split = split;
    this.fs = FileSystem.get(conf);
    this.paths = split.getPaths();
    this.totLength = split.getLength();
    this.offset = 0L;

    Path file = this.paths[this.count];
    this.parsedDate= getDate(file.getParent().getName());
    this.currentStream = this.fs.open(file);
    
    long len = this.fs.getFileStatus(file).getLen();
    this.currentReader = new RCFileRecordReader(conf, new FileSplit(file, 0L, len, split.getJob()));
  }

   public String getDate(String parentName){
	   int indexPos = parentName.indexOf("dt=");
       String parsedDate = null;
       if (indexPos != -1) {
         parsedDate = parentName.substring(indexPos + "dt=".length());
       }
       return parsedDate;
   }
  public void close()
    throws IOException
  {
  }

  public LongWritable createKey()
  {
    return this.currentReader.createKey();
  }

  public BytesRefArrayWritable createValue()
  {
    return this.currentReader.createValue();
    
  }

  public long getPos() throws IOException
  {
    long currentOffset = this.currentStream == null ? 0L : this.currentReader.getPos();
    return this.offset + currentOffset;
  }

  public float getProgress()
    throws IOException
  {
    return (float)getPos() / (float)this.totLength;
  }

  public boolean next(LongWritable key, BytesRefArrayWritable value)
    throws IOException
  {
    if (this.count >= this.split.getNumPaths()) {
      return false;
    }
   
    boolean next = this.currentReader.next(key, value);
  //  System.out.println("@@@ "+parsedDate);
    if(next){
    	value.resetValid(value.size() +1);
    	value.set(value.size() -1 ,new BytesRefWritable(parsedDate.getBytes()) );
    }
  //  System.out.println("!!!! "+ value.size() + " "+value.get(value.size() -1));
    if (!next) {
      this.currentReader.close();
      this.offset += this.split.getLength(this.count);

      if (++this.count >= this.split.getNumPaths())
        return false;
      Path file = this.paths[this.count];
      this.parsedDate= getDate(file.getParent().getName());
      this.currentStream = this.fs.open(file);
      long len = this.fs.getFileStatus(file).getLen();
      this.currentReader = new RCFileRecordReader(this.conf, new FileSplit(file, 0L, len, this.split.getJob()));

      next = this.currentReader.next(key, value);
      if(next){
    	  value.resetValid(value.size() +1);
      	value.set(value.size() -1 ,new BytesRefWritable(parsedDate.getBytes()) );
      }
    }

    return next;
  }
}