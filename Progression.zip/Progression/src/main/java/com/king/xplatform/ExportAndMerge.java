package com.king.xplatform;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

import com.king.xplatform.persistence.DomainSpec;
import com.king.xplatform.persistence.MapFileDB;

public class ExportAndMerge {
	
	
	public static void main(String[] args){
		
		 try {
			 
			 Configuration conf = new Configuration();
			 FileSystem fs = FileSystem.get(conf);
			 Path firstOutFile = new Path(args[1]);
			 if (fs.exists(firstOutFile))
				 delete(fs, firstOutFile);
			 
		      Exporter.export(args[0], args[1], new DomainSpec(MapFileDB.class, 512));
		      if (fs.exists(firstOutFile)){
		    	  FileStatus[] _statuses =fs.listStatus(firstOutFile);
		    	  for(int i =0;i<_statuses.length;i++){
		    		 if(  _statuses[i].getPath().getName().indexOf("version") != -1){
		    			 System.out.println(_statuses[i]);
		    			 delete(fs, _statuses[i].getPath());
		    		 }
		    	  }
		    	 //delete(fs, new Path(args[1]+"/*.version"));
		    	 
		    	 delete(fs, new Path(firstOutFile+"/_SUCCESS"));
		      }
		    	  
		      String[] toNext = new String[3];
		      toNext[0]=args[2];
		      toNext[1]= args[1]+"/*/data";
		      //
		      DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		      Date date = new Date();
		      String today=dateFormat.format(date);
		      
		      toNext[2]="/tmp/narain/new_merged2014_till_"+today;
		      Path secOutFile = new Path(toNext[2]);
		  
		      System.out.println(toNext[2]);
		      MergeKeyBasedProgression.main(toNext);
		      System.out.println(""+ secOutFile.toString() + " "+ fs.exists(secOutFile));
		      if (fs.exists(secOutFile)){
		      // take care of deleting the old and mv the new to the old
		       //delete(fs,new Path("/tmp/narain/new_merged_2014"));
		      // mv to new_merged_2014
		       fs.rename(new Path("/tmp/narain/new_merged2014_till_"+today+"/*"), new Path("/tmp/narain/new_merged_2014"));
		      //delete the next[2]
	
					// delete(fs, secOutFile);
		      //
		      }
		    }
		    catch (IOException e) {
		      e.printStackTrace();
		    }
		    catch (InterruptedException e) {
		      e.printStackTrace();
		    }
	}
	
	public static void delete(FileSystem fs, Path p) throws IOException{
		 
			fs.delete(p, true);
		
	}

}
