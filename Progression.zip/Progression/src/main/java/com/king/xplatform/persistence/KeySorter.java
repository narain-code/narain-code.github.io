package com.king.xplatform.persistence;

public abstract interface KeySorter
{
  public abstract byte[] getSortableKey(byte[] paramArrayOfByte);
}