package com.king.xplatform;

import java.io.IOException;
import java.util.List;
import java.util.Properties;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.serde2.ColumnProjectionUtils;
import org.apache.hadoop.hive.serde2.columnar.BytesRefArrayWritable;
import org.apache.hadoop.hive.serde2.columnar.ColumnarSerDe;
import org.apache.hadoop.hive.serde2.objectinspector.StructField;
import org.apache.hadoop.hive.serde2.objectinspector.StructObjectInspector;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.SequenceFile.CompressionType;
import org.apache.hadoop.io.compress.GzipCodec;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.JobPriority;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapred.SequenceFileOutputFormat;

public class Testfactivity {
	
	private static ColumnarSerDe serde;
	private static final String defDate = "2014-07-01";
	
	/**
	 * flavourid           	int                 	from deserializer   
kingappid           	int                 	from deserializer   
kingpdjoinkey       	string              	from deserializer   
coreuserid          	bigint              	from deserializer   
installid           	string              	from deserializer   
level_metadata_key  	string              	from deserializer   
num_attempt_complete	int                 	from deserializer   
num_attempt_start   	int                 	from deserializer   
num_attempt_end     	int                 	from deserializer   
num_attempt_end_success	int                 	from deserializer   
num_attempt_before_first_success	int                 	from deserializer   
num_attempt_after_first_success	int                 	from deserializer   
num_attempt_before_first_success_clean	int                 	from deserializer   
num_attempt_after_first_success_clean	int                 	from deserializer   
first_attempt_start_ts	bigint              	from deserializer   
first_attempt_success_end_ts	bigint              	from deserializer   
total_time_sec_before_first_success	bigint              	from deserializer   
total_time_sec_after_first_success	bigint              	from deserializer   
total_time_sec_before_first_success_clean	bigint              	from deserializer   
total_time_sec_after_first_success_clean	bigint              	from deserializer 
	 * 
	 * 
	 */
	static
	  {
	    try
	    {
	      Configuration conf = new Configuration();
	      Properties tbl = new Properties();

	      tbl.setProperty("serialization.format", "9");

	      tbl.setProperty("columns", "flavourid,kingappid,kingpdjoinkey,coreuserid,installid,level_metadata_key,num_attempt_complete,"
	      		+ "num_attempt_start,num_attempt_end,num_attempt_end_success,num_attempt_before_first_success,num_attempt_after_first_success,"
	      		+ "num_attempt_before_first_success_clean,num_attempt_after_first_success_clean,first_attempt_start_ts,first_attempt_success_end_ts,"
	      		+ "total_time_sec_before_first_success,total_time_sec_after_first_success,total_time_sec_before_first_success_clean,total_time_sec_after_first_success_clean");
	      tbl.setProperty("columns.types", "int:int:string:bigint:string:string:int:int:int:int:int:int:int:int:bigint:bigint:bigint:bigint:bigint:bigint");

	      tbl.setProperty("serialization.null.format", "NULL");

	      serde = new ColumnarSerDe();
	      serde.initialize(conf, tbl);

	      StructObjectInspector oi = (StructObjectInspector)serde.getObjectInspector();
	      List<? extends StructField> fieldRefs = oi.getAllStructFieldRefs();

	      for (StructField structField : fieldRefs) {
	        System.out.println("FIELD: " + structField.getFieldName());
	      }

	    }
	    catch (Exception e)
	    {
	      e.printStackTrace();
	      System.out.println("Failed to setup SERDE.");
	    }
	  }
	
	static String startDate = null;
	  static String endDate = null;
	  static int NUMBEROFSHARDS = 0;

	 public static void main(String[] args){
		  if(args.length > 2){
		  if(args[2] != null)
	    		startDate =args[2];
	    	if(args[3] != null)
	    		endDate =args[3];
		  }
		  JobConf conf = new JobConf(Testfactivity.class);
		    if (startDate !=null && endDate != null){
		    	conf.set("StartDate", startDate);
			    conf.set("EndDate", endDate);
			    FileInputFormat.setInputPathFilter(conf, FilteredDateJob.class);
			    
		    }
		    conf.setInputFormat(CombineInputFormat.class);
		    ColumnProjectionUtils.setFullyReadColumns(conf);
		    
		    conf.setOutputFormat(SequenceFileOutputFormat.class);
		    SequenceFileOutputFormat.setCompressOutput(conf, true);
		    SequenceFileOutputFormat.setOutputCompressionType(conf, CompressionType.BLOCK);
		    SequenceFileOutputFormat.setOutputCompressorClass(conf, GzipCodec.class);
		    conf.setMapperClass(LevelMapper.class);
		   
		    conf.setMapOutputCompressorClass(GzipCodec.class);
		   // conf.setPartitionerClass(ElephantPartitioner.class);
		  
		    conf.setJobPriority(JobPriority.VERY_HIGH);
		    conf.set("mapreduce.map.java.opts", "-Xmx20G");
		    conf.set("mapred.map.child.java.opts", "-Xmx2G");
		    conf.set("mapreduce.reduce.java.opts", "-Xms20G -Xmx20G -XX:+UseCompressedOops");
		    conf.set("mapreduce.task.io.sort.mb", "600m");
		    conf.set("mapred.job.reduce.memory.mb", "20480");
		    conf.setLong("mapred.min.split.size", 67108864L);
		    conf.setLong("mapred.max.split.size", 268435456L);
		    conf.setMemoryForReduceTask(20480L);
		  
		    conf.setInt("dfs.replication", 3);
		    FileInputFormat.setInputPaths(conf, new Path[] { new Path(args[0]) });

		    FileOutputFormat.setOutputPath(conf, new Path(args[1]));
		    conf.setSpeculativeExecution(false);
		    conf.setNumReduceTasks(NUMBEROFSHARDS);
		    try
		    {
		      JobClient.runJob(conf);
		    }
		    catch (IOException e) {
		      e.printStackTrace();
		    }
		  
	  }
	
	 public static class LevelMapper extends MapReduceBase
	    implements Mapper<LongWritable, BytesRefArrayWritable, NullWritable, NullWritable>
	  {

		@Override
		public void map(LongWritable key, BytesRefArrayWritable value,
				OutputCollector<NullWritable, NullWritable> output,
				Reporter reporter) throws IOException {
			// TODO Auto-generated method stub
			 for(int i=0; i<21; i++){
			 String flavourId = new String(value.get(i).getBytesCopy());
			 System.out.println(flavourId);
			 }
		}
		 
	  } 
	  
}
