package com.king.dag;

import java.util.Map;

public abstract class PathProcessor {
	protected String timeUnit;
	public abstract void initialize(Map<String, String> inputProcessorArgMap);
	public String processInputPath(String inputPath){
	return inputPath;
	}
	public String processOutputPath(String outputPath){
	return outputPath;
	}
	public void setTimeUnit(String timeUnit){
	this.timeUnit = timeUnit;
	}
}
