package com.king.dag;

public class Alert {
		private String counterGroup;
		private String counter;
		private String expression;
		private String message;
		public String getCounterGroup() {
		return counterGroup;
		}
		public void setCounterGroup(String counterGroup) {
		this.counterGroup = counterGroup;
		}
		public String getCounter() {
		return counter;
		}
		public void setCounter(String counter) {
		this.counter = counter;
		}
		public String getExpression() {
		return expression;
		}
		public void setExpression(String expression) {
		this.expression = expression;
		}
		public String getMessage() {
		return message;
		}
		public void setMessage(String message) {
		this.message = message;
		}
}
