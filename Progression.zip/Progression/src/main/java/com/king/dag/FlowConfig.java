package com.king.dag;

import java.util.List;

public class FlowConfig {
		private String name;
		private String description;
		private String author;
		private List<FlowNode> flowNodes;
		private String iterClassName;
		/**
		* @return the name
		*/
		public String getName() {
		return name;
		}
		/**
		* @param name the name to set
		*/
		public void setName(String name) {
		this.name = name;
		}
		/**
		* @return the description
		*/
		public String getDescription() {
		return description;
		}
		/**
		* @param description the description to set
		*/
		public void setDescription(String description) {
		this.description = description;
		}
		/**
		* @return the author
		*/
		public String getAuthor() {
		return author;
		}
		/**
		* @param author the author to set
		*/
		public void setAuthor(String author) {
		this.author = author;
		}
		/**
		* @return the flowNodes
		*/
		public List<FlowNode> getFlowNodes() {
		return flowNodes;
		}
		/**
		* @param flowNodes the flowNodes to set
		*/
		public void setFlowNodes(List<FlowNode> flowNodes) {
		this.flowNodes = flowNodes;
		}
		/**
		* @return the iterClassName
		*/
		public String getIterClassName() {
		return iterClassName;
		}
		/**
		* @param iterClassName the iterClassName to set
		*/
		public void setIterClassName(String iterClassName) {
		this.iterClassName = iterClassName;
		}
}
