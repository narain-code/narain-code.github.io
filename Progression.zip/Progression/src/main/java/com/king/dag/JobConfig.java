package com.king.dag;

import java.util.List;
import java.util.Map;

public class JobConfig {
	private String name;
	private String description;
	private String author;
	private String className;
	private List<String> inputPaths;
	private String outputPath;
	private List<String> libjars;
	private List<String> files;
	private List<String> userParams;
	private boolean outputToBeDeleted;
	private boolean useDependentOutput;
	private String inputProcessorClass;
	private List<String> inputProcessorParams;
	private Map<String, String> inputProcessorArgMap;
	private List<Alert> alerts;
	/**
	* @return the inputPaths
	*/
	public List<String> getInputPaths() {
	return inputPaths;
	}
	/**
	* @param inputPaths the inputPaths to set
	*/
	public void setInputPaths(List<String> inputPaths) {
	this.inputPaths = inputPaths;
	}
	/**
	* @return the outputPath
	*/
	public String getOutputPath() {
	return outputPath;
	}
	/**
	* @param outputPath the outputPath to set
	*/
	public void setOutputPath(String outputPath) {
	this.outputPath = outputPath;
	}
	/**
	* @return the libjars
	*/
	public List<String> getLibjars() {
	return libjars;
	}
	/**
	* @param libjars the libjars to set
	*/
	public void setLibjars(List<String> libjars) {
	this.libjars = libjars;
	}
	/**
	* @return the files
	*/
	public List<String> getFiles() {
	return files;
	}
	/**
	* @param files the files to set
	*/
	public void setFiles(List<String> files) {
	this.files = files;
	}
	/**
	* @return the userParams
	*/
	public List<String> getUserParams() {
	return userParams;
	}
	/**
	* @param userParams the userParams to set
	*/
	public void setUserParams(List<String> userParams) {
	this.userParams = userParams;
	}
	/**
	* @return the name
	*/
	public String getName() {
	return name;
	}
	/**
	* @param name the name to set
	*/
	public void setName(String name) {
	this.name = name;
	}
	/**
	* @return the description
	*/
	public String getDescription() {
	return description;
	}
	/**
	* @param description the description to set
	*/
	public void setDescription(String description) {
	this.description = description;
	}
	/**
	* @return the author
	*/
	public String getAuthor() {
	return author;
	}
	/**
	* @param author the author to set
	*/
	public void setAuthor(String author) {
	this.author = author;
	}
	/**
	* @return the className
	*/
	public String getClassName() {
	return className;
	}
	/**
	* @param className the className to set
	*/
	public void setClassName(String className) {
	this.className = className;
	}
	/**
	* @return the outputToBeDeleted
	*/
	public boolean isOutputToBeDeleted() {
	return outputToBeDeleted;
	}
	/**
	* @param outputToBeDeleted the outputToBeDeleted to set
	*/
	public void setOutputToBeDeleted(boolean outputToBeDeleted) {
	this.outputToBeDeleted = outputToBeDeleted;
	}
	/**
	* @return the useDependentOutput
	*/
	public boolean isUseDependentOutput() {
	return useDependentOutput;
	}
	/**
	* @param useDependentOutput the useDependentOutput to set
	*/
	public void setUseDependentOutput(boolean useDependentOutput) {
	this.useDependentOutput = useDependentOutput;
	}
	/**
	* @return the inputProcessorClass
	*/
	public String getInputProcessorClass() {
	return inputProcessorClass;
	}
	/**
	* @param inputProcessorClass the inputProcessorClass to set
	*/
	public void setInputProcessorClass(String inputProcessorClass) {
	this.inputProcessorClass = inputProcessorClass;
	}
	/**
	* @return the inputProcessorArgs
	*/
	public List<String> getInputProcessorParams() {
	return inputProcessorParams;
	}
	/**
	* @param inputProcessorArgs the inputProcessorArgs to set
	*/
	public void setInputProcessorParams(List<String> inputProcessorParams) {
	this.inputProcessorParams = inputProcessorParams;
	}
	/**
	* @return the inputProcessorArgMap
	*/
	public Map<String, String> getInputProcessorArgMap() {
	if (null == inputProcessorArgMap){
	for (int i = 0; i < inputProcessorParams.size(); i += 2){
	inputProcessorArgMap.put(inputProcessorParams.get(i), inputProcessorParams.get(i+1));
	}
	}
	return inputProcessorArgMap;
	}
	public List<Alert> getAlerts() {
	return alerts;
	}
	public void setAlerts(List<Alert> alerts) {
	this.alerts = alerts;
	}
}

