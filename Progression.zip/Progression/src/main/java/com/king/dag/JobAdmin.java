package com.king.dag;

import java.util.ArrayList;
import java.util.List;


public class JobAdmin {
		public JobAdmin() {
		}
		
		public List<JobParameter> getJobParameter(String jobName, String jobInstance, List<String> inputPaths)
		throws Exception{
		List<JobParameter> jobParams = new ArrayList<JobParameter>();
		System.out.println("Configuring job parameters job name :" + jobName +
		(null != inputPaths? (" intput paths: " + inputPaths) : ""));
		JobConfig jobConfig = Configurator.instance().findJobConfig(jobName);
		if (null != jobConfig){
		String className = jobConfig.getClassName();
		/*Class<?> cls = Class.forName(className);*/
		List<String> args = new ArrayList<String>();
		/*Tool job = (Tool)cls.newInstance();*/
		Object job = "test";
		List<String> distFiles = jobConfig.getFiles();
		if (null != distFiles && !distFiles.isEmpty()){
		String fileSt = buildComaSepString(distFiles);
		args.add("-files");
		args.add(fileSt);
		}
		List<String> libJars = jobConfig.getLibjars();
		if (null != libJars && !libJars.isEmpty()){
		String libJarSt = buildComaSepString(libJars);
		args.add("-libjars");
		args.add(libJarSt);
		}
		List<String> params = jobConfig.getUserParams();
		if (null != params && !params.isEmpty()){
		for (String param : params){
		args.add("-D");
		args.add(param);
		}
		}
		args.add("-D");
		args.add("job.name=" + jobConfig.getName());
		args.add("-D");
		args.add("job.instance=" + jobInstance);
		List<String> allInputPaths = new ArrayList<String>();
		List<String> confInputPaths = jobConfig.getInputPaths();
		//input and output paths
		String outputPath = jobConfig.getOutputPath();
		if (null != confInputPaths && !confInputPaths.isEmpty()){
		String inpProcClass = jobConfig.getInputProcessorClass();
		if (null != inpProcClass){
		//process input and output paths
		Class<?> pathCls = Class.forName(inpProcClass);
		PathProcessor pathProc = (PathProcessor)pathCls.newInstance();
		pathProc.initialize(jobConfig.getInputProcessorArgMap());
		List<String> processedPaths = new ArrayList<String>();
		for (String inpPath : confInputPaths){
		processedPaths.add(pathProc.processInputPath(inpPath));
		}
		allInputPaths.addAll(processedPaths);
		outputPath = pathProc.processOutputPath(outputPath);
		} else {
		allInputPaths.addAll(confInputPaths);
		}
		}
		//dependent job output paths
		if (null != inputPaths && !inputPaths.isEmpty()){
		allInputPaths.addAll(inputPaths);
		}
		String inputPathSt = buildComaSepString(allInputPaths);
		args.add(inputPathSt);
		args.add(outputPath);
		String[] argArr = {};
		argArr = args.toArray(argArr);
		JobParameter jobParam = new JobParameter(jobName, jobInstance, job, argArr);
		jobParams.add(jobParam);
		} else {
		throw new Exception("Invalid job name " + jobName);
		}
		return jobParams;
		}
		private String buildComaSepString(List<String> items){
		StringBuilder stBuilder = new StringBuilder();
		for (int i = 0; i < items.size(); ++i){
		if (i > 0){
		stBuilder.append(",");
		}
		stBuilder.append(items.get(i));
		}
		return stBuilder.toString();
		}
		public static class JobParameter {
		private String jobName;
		private String jobInstance;
		//private Tool job;
		private Object job = "test";
		private String[] args;
		public JobParameter(String jobName, String jobInstance, Object job, String[] args) {
		this.jobName = jobName;
		this.jobInstance = jobInstance;
		this.job = job;
		this.args = args;
		}
		/**
		* @return the job
		*/
		public Object getJob() {
		return job;
		}
		/**
		* @return the args
		*/
		public String[] getArgs() {
		return args;
		}
		/**
		* @return the jobName
		*/
		public String getJobName() {
		return jobName;
		}
		/**
		* @return the instanceId
		*/
		public String getJobInstance() {
		return jobInstance;
		}
		public String toString(){
		StringBuilder stBuilder = new StringBuilder("JobParameter: job name: " + jobName + " instance: " +
		jobInstance + "\n" + " args ");
		for (String arg : args) {
		stBuilder.append(arg).append(" ");
		}
		return stBuilder.toString();
		}
		
	}
}
