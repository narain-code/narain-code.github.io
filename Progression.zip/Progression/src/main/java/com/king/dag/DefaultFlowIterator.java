package com.king.dag;

import java.util.Iterator;

public class DefaultFlowIterator implements Iterator {
	private int count = 0;
	@Override
	public boolean hasNext() {
	boolean has = count == 0;
	++count;
	return has;
	}
	@Override
	public Object next() {
	return null;
	}
	@Override
	public void remove() {
	}
}