package com.king.dag;

import org.apache.hadoop.mapred.jobcontrol.Job;

public class JobContext {
	private String jobName;
	private String instanceName;
	private Job job;
	/**
	* @return the jobName
	*/
	public String getJobName() {
	return jobName;
	}
	/**
	* @param jobName the jobName to set
	*/
	public void setJobName(String jobName) {
	this.jobName = jobName;
	}
	/**
	* @return the instanceName
	*/
	public String getInstanceName() {
	return instanceName;
	}
	/**
	* @param instanceName the instanceName to set
	*/
	public void setInstanceName(String instanceName) {
	this.instanceName = instanceName;
	}
	/**
	* @return the job
	*/
	public Job getJob() {
	return job;
	}
	/**
	* @param job the job to set
	*/
	public void setJob(Job job) {
	this.job = job;
	}
}
