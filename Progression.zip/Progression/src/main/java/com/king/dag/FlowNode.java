package com.king.dag;

import java.util.ArrayList;
import java.util.List;

public class FlowNode {
	private String job;
	private List<String> preReqJobs = new ArrayList<String>();
	/**
	* @return the job
	*/
	public String getJob() {
	return job;
	}
	/**
	* @param job the job to set
	*/
	public void setJob(String job) {
	this.job = job;
	}
	/**
	* @return the preReqJobs
	*/
	public List<String> getPreReqJobs() {
	return preReqJobs;
	}
	/**
	* @param preReqJobs the preReqJobs to set
	*/
	public void setPreReqJobs(List<String> preReqJobs) {
	this.preReqJobs = preReqJobs;
	}
}