package com.king.splat.kafka;

import java.util.List;

import org.junit.Test;

import com.king.event.Event;
import com.king.splat.kafka.HighLevelConsumer.Builder;

public class HighLevelConsumerTest {
	
	@Test
	public void testKafkaHighLevel(){
		
		IBatchFactory fac = new IBatchFactory() {
			
			@Override
			public IBatchAction create() {
				// TODO Auto-generated method stub
				return new IBatchAction() {
					
					@Override
					public boolean doBatch(List<Event> batchMessages) {
						System.out.println(batchMessages.get(0));
						System.out.println(batchMessages.size());
						return true;
					}
				};
			}
		};
		
		
		HighLevelConsumer.Builder  builder = new Builder();
		HighLevelConsumer consumer =builder.batchSize(20)
				.groupId("rr99")
				.zkConnect("zk05.sto.midasplayer.com:2181/kafka")
				.topic("event.candycrush.log")
				 .factory(fac)
				 .parallelism(4)
				.build();
		consumer.consume();
	}

}
