package com.king.splat.kafka;

import java.util.List;

import com.king.event.Event;

public interface IBatchAction {

	
	public boolean doBatch(List<Event> batchMessages);
}
