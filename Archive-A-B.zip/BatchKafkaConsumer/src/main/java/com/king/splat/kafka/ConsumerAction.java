package com.king.splat.kafka;

import java.util.List;
import java.util.concurrent.CountedCompleter;

import kafka.message.MessageAndMetadata;

public class ConsumerAction extends CountedCompleter<Void>  {
	
	
	

	@Override
	public void compute() {
		// TODO Auto-generated method stub
		
		System.out.println("compute");
		propagateCompletion();
		tryComplete();
	}

	  public void onCompletion(CountedCompleter<?> caller) {
		  System.out.println("complete");
		  
	    }
	
}
