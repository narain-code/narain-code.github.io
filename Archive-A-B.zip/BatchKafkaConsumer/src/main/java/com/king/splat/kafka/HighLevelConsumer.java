package com.king.splat.kafka;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.atomic.AtomicBoolean;

import com.king.event.Event;
import com.king.event.format.DelegatingEventFormat;
import com.king.event.format.EventFormat;
import com.king.event.format.EventFormatException;
import com.king.event.format.util.HTMLEntityEncoder;
import com.king.event.format.util.IdentityDecoder;

import kafka.consumer.Consumer;
import kafka.consumer.ConsumerConfig;
import kafka.consumer.ConsumerIterator;
import kafka.consumer.KafkaStream;
import kafka.javaapi.consumer.ConsumerConnector;

public class HighLevelConsumer {
	
	ConsumerConnector connector;
	
	int batchSize;
	String topic;
	int numberOfThreads;
	String zkConnectString;
	String groupId;
	IBatchFactory factory;
	String autoOffset;
	public HighLevelConsumer(int batchSize, String topic,int numberOfThreads,
							  String zkConnectString,String groupId, IBatchFactory factory,String autoOffset){
		
		this.batchSize = batchSize;
		this.topic = topic;
		this.numberOfThreads = numberOfThreads;
		this.zkConnectString = zkConnectString;
		this.groupId = groupId;
		this.factory = factory;
		this.autoOffset = autoOffset;
		
		Runtime.getRuntime().addShutdownHook( new Thread(new Runnable() {
			
			@Override
			public void run() {
				stop();
				
			}
		}));
	}
	
	
	AtomicBoolean stopped = new AtomicBoolean(false);
	
	public void stop(){
		this.stopped.set(true);
	}
	
	ConsumerBarrier barrier ;
	
	public void createKafkaConsumer(String zkConnectString,String groupId){
		
		Properties consumerProps = new Properties();
		consumerProps.put("zookeeper.connect",zkConnectString);
		consumerProps.put("zookeeper.session.timeout.ms", "400");
		consumerProps.put("zookeeper.sync.time.ms", "200");
		consumerProps.put("auto.commit.enable", "false");
		consumerProps.put("auto.offset.reset", autoOffset);
		consumerProps.put("group.id", groupId);
		ConsumerConfig config = new ConsumerConfig(consumerProps);
		
		connector =Consumer.createJavaConsumerConnector(config);
		barrier= new ConsumerBarrier(connector, factory);
		
	}
	  String encoding = "UTF-8";
	  EventFormat eventFormat = new DelegatingEventFormat(new HTMLEntityEncoder(),
				new IdentityDecoder());
	  
	public void consume(){
		 Map<String, Integer> topicCountMap = new HashMap<>();
         topicCountMap.put(topic, numberOfThreads);
         Map<String, List<KafkaStream<byte[], byte[]>>> consumerMap = connector.createMessageStreams(topicCountMap);
         List<KafkaStream<byte[], byte[]>> streams = consumerMap.get(topic);
        
         streams.parallelStream().forEach(stream -> {
        	
        	 ConsumerIterator<byte[], byte[]> iter = stream.iterator();
        	 ArrayList<Event> messages = new ArrayList<Event>();
        	 int count = 0;
        	 boolean registered = false;
        	 try {
        	 while(iter.hasNext() && !stopped.get()){
        		if(!registered ){
        			if(barrier.canStart()){
        				registered = true;
        			}
        			if(barrier.state.get() == 3){
        				System.out.println("something wrong happened in other error");
        				System.exit(0);
        			}
        		}
        		if(barrier.state.get() == 3){
    				System.out.println("something wrong happened in other error");
    				System.exit(0);
    			}
        		byte[] msg =iter.next().message();
        		String strMsg = new String(msg,encoding);
        		Event ev = null;
        		try{
        		ev =eventFormat.parse(strMsg);
        		}catch(EventFormatException ex){
        			continue;
        			
        		}
        		messages.add(ev);
        		 count ++;
        		 if(count >= batchSize){
        			// System.out.println("calling batch " +Thread.currentThread().getName());
        			barrier.doBatch(messages);
					registered = false;
					messages.clear();
					count = 0;
        		 }
        	
        	 }
        	 
        	 } catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
         });
	}
	
	
	public static class Builder{
		
		public static String AUTOOFFSET_RESET_SMALLEST = "smallest";
		public static String AUTOOFFSET_RESET_LARGEST = "largest";
		
		String topic;
		int numberofThreads;
		int batchSize;
		String zkConnectString;
		String groupId;
		IBatchFactory factory;
		String autoOffset;
		
		public Builder(){
			numberofThreads =1;
			this.autoOffset = AUTOOFFSET_RESET_SMALLEST;
		}
		
		public Builder topic(String topic){
			this.topic = topic;	
			return this;
		}
		
		public Builder factory(IBatchFactory factory){
			this.factory = factory;
			return this;
		}
		
		public Builder parallelism(int numberOfThreads){
			this.numberofThreads =numberOfThreads;
			return this;
		}
		
		public Builder batchSize(int numberOfMessagesToBuffer){
			this.batchSize =numberOfMessagesToBuffer;
			return this;
		}
		
		public Builder zkConnect(String zkConnect){
			this.zkConnectString =zkConnect;
			return this;
		}
		
		public Builder groupId(String groupId){
			this.groupId =groupId;
			return this;
		}
		
		public Builder offset(String offset){
			if(!offset.equalsIgnoreCase(AUTOOFFSET_RESET_SMALLEST)){
				if(!offset.equalsIgnoreCase(AUTOOFFSET_RESET_LARGEST)){
					throw new IllegalArgumentException("only values allowed for offset is smallest or largest");
				}
			}
			this.autoOffset = offset;
			return this;
		}
		
		public HighLevelConsumer build(){
			
			HighLevelConsumer consumer = new HighLevelConsumer(batchSize, topic,numberofThreads,zkConnectString,groupId,factory,autoOffset);
			consumer.createKafkaConsumer(zkConnectString, groupId);
			return consumer;
		}
		
		
	}

}
