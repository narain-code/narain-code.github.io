package com.king.splat.kafka;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.atomic.AtomicInteger;

import com.king.event.Event;

import kafka.javaapi.consumer.ConsumerConnector;

public class ConsumerBarrier {
	
	 AtomicInteger state = new AtomicInteger(1);
	 AtomicInteger started = new AtomicInteger(0);
	 AtomicInteger arrived = new AtomicInteger(0);
	 
	ConsumerConnector connector;
	IBatchFactory factory;
	
	List<Event> buffer = new ArrayList<Event>();
	
	public ConsumerBarrier(ConsumerConnector connector, IBatchFactory factory){
		this.connector = connector;
		this.factory = factory;
	}
	
	
		
	
	
	public boolean canStart() {
		if(state.get() == 3)
			return false;
		if((state.get() == 1)){
			started.incrementAndGet();
			return true;
		}
		try{
		synchronized (lock) {
			
			lock.wait();

			if((state.get() == 1)){
				started.incrementAndGet();
				return true;
			}
		}	
		
		}catch(InterruptedException ex){
			ex.printStackTrace();
			
		}
		return false;
	}
	
	Object lock = new Object();

	public void doBatch(List<Event> msgs ) throws Exception{
		synchronized (lock) {
		buffer.addAll(msgs);
		arrived.incrementAndGet();
	
		if(arrived.get() == started.get()){
			state.compareAndSet(1, 2);
			// 
			Callable<Boolean> call = new Callable<Boolean>() {

				@Override
				public Boolean call() throws Exception {
					//factory create
					return factory.create().doBatch(buffer);
					
					//return true;
				}
			};
			try{
			Boolean result =call.call();
			if(result.booleanValue()){
				connector.commitOffsets();
				buffer.clear();
				
				started.set(0);
				arrived.set(0);
				state.compareAndSet(2, 1);
				lock.notifyAll();
			}else{
				state.set(3);
				lock.notifyAll();
			}
			}catch(Exception ex){
				state.set(3);
				lock.notifyAll();
			}
		}else{
		
			lock.wait();	
		
		   
		}
		}
		
	}
	
	
	
	
	
	

}
