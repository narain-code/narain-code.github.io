package com.king.splat.kafka;

public interface IBatchFactory {
	
	public IBatchAction create();

}
