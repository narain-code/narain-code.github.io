package com.king.dwh;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;

import com.google.common.base.Splitter;

public class BitMapIndexMapper extends MapReduceBase implements Mapper<LongWritable, Text, Bucket, ParsedRow>{

	public static final String METADATA ="METADATA";
	
	public void map(LongWritable key, Text value,
			OutputCollector<Bucket, ParsedRow> output, Reporter reporter)
			throws IOException {
		
		Iterable<String> columns =Splitter.on(',').split(value.toString());
		 output.collect(new Bucket(columns.iterator().next()),new ParsedRow(columns));
	}

	
	public void configure(JobConf jc)
    {
		Utils.getObject(jc, METADATA);
    }
}
