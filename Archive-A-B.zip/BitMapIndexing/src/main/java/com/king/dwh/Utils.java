package com.king.dwh;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.util.StringUtils;

public class Utils {

	public static final String COMMA=",";
	public static final String MD5="MD5";
	public static final String ALGO=MD5;
	
	public static BigInteger getBucketNumber(byte[] key){
		try {
			byte[] hashKey =MessageDigest.getInstance(ALGO).digest(key);
			return new BigInteger(hashKey);
			
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}
		
	}
	
	  public static void setObject(JobConf conf, String key, Object o) {
		    conf.set(key, StringUtils.byteToHexString(serializeObject(o)));
		  }

		  public static Object getObject(JobConf conf, String key) {
		    String s = conf.get(key);
		    if (s == null) return null;
		    byte[] val = StringUtils.hexStringToByte(s);
		    return deserializeObject(val);
		  }
		  
	
	 public static byte[] serializeObject(Object obj) {
		    try {
		      ByteArrayOutputStream bos = new ByteArrayOutputStream();
		      ObjectOutputStream oos = new ObjectOutputStream(bos);
		      oos.writeObject(obj);
		      oos.close();
		      return bos.toByteArray();
		    } catch (IOException ioe) {
		      throw new RuntimeException(ioe);
		    }
		  }

		  public static Object deserializeObject(byte[] serialized) {
		    try {
		      ByteArrayInputStream bis = new ByteArrayInputStream(serialized);
		      ObjectInputStream ois = new ObjectInputStream(bis);
		      Object ret = ois.readObject();
		      ois.close();
		      return ret;
		    } catch (IOException ioe) {
		      throw new RuntimeException(ioe);
		    } catch (ClassNotFoundException e) {
		      throw new RuntimeException(e);
		    }
		  }
	
}
