package com.king.dwh;

public class BitMapIndexingHadoop {

}
