package com.king.dwh;

import java.math.BigInteger;

public class Bucket {

	 public BigInteger bucketNumber;
	 public byte[] keyBytes;
	 
	  public Bucket(String key){
		  keyBytes = key.getBytes();
		  bucketNumber=Utils.getBucketNumber(keyBytes);
	  }
}
