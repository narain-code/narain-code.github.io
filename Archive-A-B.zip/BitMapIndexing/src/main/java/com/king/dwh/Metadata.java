package com.king.dwh;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class Metadata implements Map<String, Integer>{

	HashMap<String,Integer> columnToIntMap ;
	int size;
	public Metadata(String[] columnName){
	   columnToIntMap = new HashMap<String, Integer>(columnName.length);	
	   int colNumber =0;
	   for(String col:columnName){
		    columnToIntMap.put(col, colNumber);
		    colNumber ++;
	   }
	}

	public int size() {
		if(size == 0)
			size = columnToIntMap.size();
		// TODO Auto-generated method stub
		return size;
	}

	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean containsKey(Object key) {
		// TODO Auto-generated method stub
		return columnToIntMap.containsKey(key);
	}

	public boolean containsValue(Object value) {
		// TODO Auto-generated method stub
		return false;
	}

	public Integer get(Object key) {
		// TODO Auto-generated method stub
		return columnToIntMap.get(key);
	}

	public Integer put(String key, Integer value) {
		// TODO Auto-generated method stub
		return null;
	}

	public Integer remove(Object key) {
		// TODO Auto-generated method stub
		return null;
	}

	public void putAll(Map<? extends String, ? extends Integer> m) {
		// TODO Auto-generated method stub
		
	}

	public void clear() {
		// TODO Auto-generated method stub
		
	}

	public Set<String> keySet() {
		// TODO Auto-generated method stub
		return null;
	}

	public Collection<Integer> values() {
		// TODO Auto-generated method stub
		return null;
	}

	public Set<java.util.Map.Entry<String, Integer>> entrySet() {
		// TODO Auto-generated method stub
		return null;
	}
}
