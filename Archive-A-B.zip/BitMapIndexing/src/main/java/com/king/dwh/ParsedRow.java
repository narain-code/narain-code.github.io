package com.king.dwh;

import java.util.ArrayList;
import java.util.Arrays;

public class ParsedRow {

	 String key;
	 
	 
	 public ParsedRow(Iterable<String> it){
		 ArrayList<String> listOfCols = new ArrayList<String>();
		 for(String col:it){
			 listOfCols.add(col);
		 }
		 this.searchableCols = new String[listOfCols.size()];
		 listOfCols.toArray(searchableCols);
	 }
	 
	 public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String[] getSearchableCols() {
		return searchableCols;
	}
	public void setSearchableCols(String[] searchableCols) {
		this.searchableCols = searchableCols;
	}
	String[] searchableCols;
	
	// we need metadata which is a sorted list of column names
	public String getColumn(Metadata metadata,String colName){
		return searchableCols[metadata.get(colName)];
	}
	
	 
}
