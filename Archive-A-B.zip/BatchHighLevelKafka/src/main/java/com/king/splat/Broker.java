package com.king.splat;



import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;






public class Broker  {

    private int id;
    private String host;
    private int port;

    /**
     * The {@link Writable} constructor; use {@link #Broker(String, int, int)}
     */
    public Broker() {
    }

    public Broker(final String host, final int port, final int id) {
        this.port = port;
        this.host = host;
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public String getHost() {
        return host;
    }

    public int getPort() {
        return port;
    }

    public void setId(final int id) {
        this.id = id;
    }

    public void setHost(final String host) {
        this.host = host;
    }

    public void setPort(final int port) {
        this.port = port;
    }

   
    @Override
    public String toString() {
    	StringBuilder builder = new StringBuilder(32).append("Broker").append('{');
      return   builder.append(" id  = " + id)
         .append(" , " )
         .append(" host = " +host)
         .append(" , " )
         .append("port = " + port)
         .append('}').toString();
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o)
            return true;
        if (!(o instanceof Broker))
            return false;

        final Broker broker = (Broker) o;

        if (id != broker.id)
            return false;
        if (port != broker.port)
            return false;
        if (host != null ? !host.equals(broker.host) : broker.host != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (host != null ? host.hashCode() : 0);
        result = 31 * result + port;
        return result;
    }
}

