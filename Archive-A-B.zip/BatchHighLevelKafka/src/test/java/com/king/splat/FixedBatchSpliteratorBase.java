package com.king.splat;

import java.util.Spliterator;
import java.util.function.Consumer;

import kafka.message.MessageAndMetadata;

public class FixedBatchSpliteratorBase implements Spliterator<MessageAndMetadata<byte[], byte[]>> {

	@Override
	public boolean tryAdvance(Consumer<? super MessageAndMetadata<byte[], byte[]>> action) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Spliterator<MessageAndMetadata<byte[], byte[]>> trySplit() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long estimateSize() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int characteristics() {
		// TODO Auto-generated method stub
		return 0;
	}

}
