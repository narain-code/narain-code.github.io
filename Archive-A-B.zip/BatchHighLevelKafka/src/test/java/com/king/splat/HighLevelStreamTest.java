package com.king.splat;

import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import kafka.consumer.ConsumerConfig;
import kafka.message.MessageAndMetadata;
import rx.functions.Action0;
import rx.functions.Action1;
import rx.functions.Func1;


public class HighLevelStreamTest {
	
	public static void main(String[] args){
		
		ZkUtils utils = new ZkUtils("zk05.sto.midasplayer.com:2181", "kafka", 400, 200);
		String group="kafka-mysql";
		String topic ="event.papapear.log";
		Action1<List<MessageAndMetadata<byte[], byte[]>>> mySubscriber = new Action1<List<MessageAndMetadata<byte[], byte[]>>>() {
		    @Override
		    public void call(List<MessageAndMetadata<byte[], byte[]>> s) { System.out.println("got " +s.size());
		   for(MessageAndMetadata b:s){
			  ;
		   }
		    
		   // utils.commit(group, topic, );
		    }

		  
		};
		
		
		  
		
		Properties props = new Properties();
        props.put("zookeeper.connect", "zk05.sto.midasplayer.com:2181/kafka");
        props.put("group.id", "test1234");
        props.put("zookeeper.session.timeout.ms", "400");
        props.put("zookeeper.sync.time.ms", "200");
        props.put("auto.commit.enable", "false");
		ConsumerConfig config = new ConsumerConfig(props);
		
		
		HighLevelKafkaStream.create(topic, config)
		.buffer(2, TimeUnit.SECONDS, 100)
		;
		
	}

}
