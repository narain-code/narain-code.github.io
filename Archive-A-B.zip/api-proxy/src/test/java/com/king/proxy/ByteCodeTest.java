package com.king.proxy;

public class ByteCodeTest {

	public void main() {
		doIt();
		return;
	}

	public Object doIt() {
		return null;
	}

	public int m1() {
		return 2;
	}

}
