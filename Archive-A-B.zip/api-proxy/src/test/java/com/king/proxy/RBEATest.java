package com.king.proxy;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Method;

import org.junit.Test;

import com.king.proxy.methods.MethodCallTransformer;

import net.bytebuddy.implementation.Implementation.Context;
import net.bytebuddy.implementation.bytecode.StackManipulation;
import net.bytebuddy.implementation.bytecode.constant.LongConstant;
import net.bytebuddy.implementation.bytecode.member.MethodVariableAccess;
import net.bytebuddy.jar.asm.Label;
import net.bytebuddy.jar.asm.MethodVisitor;
import net.bytebuddy.jar.asm.Opcodes;

public class RBEATest {

	@Test
	public void test() throws Exception {

		Object o = new Object() {

			@FirstAnnotation({ 2, 3, 4 })
			public void myMethod() {
				System.out.println("ran");
			}
		};

		TestInterface ti = ProxyGenerator
				.forClass(TestInterface.class)
				.bindingMethod("doIt")
				.toAnnotation(FirstAnnotation.class)
				.withMethodCallTransformer(new ConditionalInvoker())
				.generateProxy(o);

		ti.doIt(10);

	}

	@Retention(RetentionPolicy.RUNTIME)
	public @interface FirstAnnotation {
		long[] value() default {};
	}

	public interface TestInterface {

		void doIt(long value);

	}

	public static class ConditionalInvoker implements MethodCallTransformer {
		private static final long serialVersionUID = 1L;

		@Override
		public StackManipulation transform(Method targetMethod, StackManipulation sm) {
			return new StackManipulation() {

				@Override
				public Size apply(MethodVisitor methodVisitor, Context implementationContext) {

					Label anyTrue = new Label();
					Label allFalse = new Label();

					for (long l : ((FirstAnnotation) targetMethod.getAnnotations()[0]).value()) {
						MethodVariableAccess.LONG.loadFrom(1).apply(methodVisitor, implementationContext);
						LongConstant.forValue(l).apply(methodVisitor, implementationContext);
						methodVisitor.visitInsn(Opcodes.LCMP);
						methodVisitor.visitJumpInsn(Opcodes.IFEQ, anyTrue);
					}
					methodVisitor.visitJumpInsn(Opcodes.GOTO, allFalse);
					methodVisitor.visitLabel(anyTrue);
					methodVisitor.visitFrame(Opcodes.F_SAME, 0, null, 0, null);
					Size methodSize = sm.apply(methodVisitor, implementationContext);
					methodVisitor.visitLabel(allFalse);
					methodVisitor.visitFrame(Opcodes.F_SAME, 0, null, 0, null);
					return new Size(
							Math.max(4, methodSize.getSizeImpact()),
							Math.max(4, methodSize.getMaximalSize()));
				}

				@Override
				public boolean isValid() {
					return true;
				}

			};
		}

	}

	public int asd(boolean a, int b) {

		if (a) {
			return 1;
		} else {
			return 2;
		}
	}

}
