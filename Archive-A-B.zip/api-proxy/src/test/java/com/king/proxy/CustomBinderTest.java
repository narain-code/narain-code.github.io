package com.king.proxy;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Optional;

import org.junit.Test;

import com.king.proxy.parameters.ParameterBinder;
import com.king.proxy.parameters.ParameterBinding;

import net.bytebuddy.description.method.MethodDescription;
import net.bytebuddy.implementation.bytecode.StackManipulation;
import net.bytebuddy.implementation.bytecode.StackManipulation.Compound;
import net.bytebuddy.implementation.bytecode.constant.TextConstant;
import net.bytebuddy.implementation.bytecode.member.MethodInvocation;
import net.bytebuddy.implementation.bytecode.member.MethodVariableAccess;

public class CustomBinderTest {

	@Test
	public void test() throws Exception {

		Object o = new Object() {

			@MyAnnotation
			public void myMethod(String s) {
				System.out.println(s);
			}

		};

		TestInterface ti = ProxyGenerator
				.forClass(TestInterface.class)
				.bindingMethod("doIt")
				.toAnnotation(MyAnnotation.class)
				.withParameterBinder(String.class, new ParameterBinder() {

					@Override
					public Optional<ParameterBinding> bind(
							Method sourceMethod,
							Method targetMethod,
							Class<?> paramClass,
							int i,
							List<Annotation> methodAnnotations,
							List<ParameterBinding> bindings) {

						try {
							Compound sm = new StackManipulation.Compound(
									MethodVariableAccess.REFERENCE.loadFrom(1),
									new TextConstant("yo"),
									MethodInvocation.invoke(
											new MethodDescription.ForLoadedMethod(
													CustomParam.class.getMethod("getString",
															String.class))));

							return Optional.of(
									ParameterBinding.forComposite(String.class, sm, CustomParam.class,
											CustomParam.class.getMethod("getString", String.class)));

						} catch (Exception e) {
							return Optional.empty();
						}
					}
				})
				.generateProxy(o);

		ti.doIt(new CustomParam() {});

	}

	@Retention(RetentionPolicy.RUNTIME)
	public @interface MyAnnotation {}

	public interface TestInterface {
		void doIt(CustomParam c);
	}

	public interface CustomParam {

		default String getString(String s) {
			return s;
		}
	}

}
