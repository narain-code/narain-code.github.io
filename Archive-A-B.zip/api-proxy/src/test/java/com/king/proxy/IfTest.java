package com.king.proxy;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Method;
import java.util.function.Function;

import org.junit.Test;

import com.king.proxy.methods.MethodCallTransformer;

import net.bytebuddy.implementation.Implementation.Context;
import net.bytebuddy.implementation.bytecode.StackManipulation;
import net.bytebuddy.implementation.bytecode.constant.IntegerConstant;
import net.bytebuddy.jar.asm.Label;
import net.bytebuddy.jar.asm.MethodVisitor;
import net.bytebuddy.jar.asm.Opcodes;

public class IfTest {

	@Test
	public void test() throws Exception {

		Object o = new Object() {

			@FirstAnnotation
			public void myMethod(String s) {
				System.out.println(s);
			}

			@FirstAnnotation(enabled = true)
			public <T> T myMethod2(Integer i) {
				System.out.println(i);
				return null;
			}
		};

		TestInterface ti = ProxyGenerator
				.forClass(TestInterface.class)
				.bindingMethod("doThis")
				.toAnnotation(FirstAnnotation.class)
				.withMethodCallTransformer(new ConditionalInvoker(method -> {
					FirstAnnotation annot = (FirstAnnotation) method.getAnnotations()[0];
					return annot.enabled() ? IntegerConstant.ONE : IntegerConstant.ZERO;
				}))
				.generateProxy(o);

		ti.doThis("This", 2);

	}

	@Retention(RetentionPolicy.RUNTIME)
	public @interface FirstAnnotation {
		boolean enabled() default true;
	}

	public interface TestInterface {

		void doThis(String s, Integer i);

	}

	public static class ConditionalInvoker implements MethodCallTransformer {

		private Function<Method, StackManipulation> condition;

		public ConditionalInvoker(Function<Method, StackManipulation> condition) {
			this.condition = condition;
		}

		@Override
		public StackManipulation transform(Method targetMethod, StackManipulation sm) {
			return new StackManipulation() {

				@Override
				public Size apply(MethodVisitor methodVisitor, Context implementationContext) {
					Label elseLabel = new Label();
					StackManipulation conditionSM = condition.apply(targetMethod);
					Size conditionSize = conditionSM.apply(methodVisitor, implementationContext);
					methodVisitor.visitJumpInsn(Opcodes.IFEQ, elseLabel);
					Size methodSize = sm.apply(methodVisitor, implementationContext);
					methodVisitor.visitLabel(elseLabel);
					methodVisitor.visitFrame(Opcodes.F_SAME, 0, null, 0, null);
					return new Size(
							Math.max(conditionSize.getSizeImpact(), methodSize.getSizeImpact()),
							Math.max(conditionSize.getMaximalSize(), methodSize.getMaximalSize()));
				}

				@Override
				public boolean isValid() {
					return true;
				}

			};
		}

	}

	public int asd(boolean a, int b) {

		if (a) {
			return 1;
		} else {
			return 2;
		}
	}

}
