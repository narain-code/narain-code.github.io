package com.king.proxy;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import org.junit.Test;

public class CompositeBindTest {

	@Test
	public void test() throws Exception {

		Object o = new Object() {

			@MyAnnotation
			public void myMethod(String s) {
				System.out.println(s);
			}

		};

		TestInterface ti = ProxyGenerator
				.forClass(TestInterface.class)
				.bindingMethod("doIt")
				.toAnnotation(MyAnnotation.class)
				.withCompositeParameters(CompositeParam.class)
				.generateProxy(o);

		ti.doIt(new CompositeParam() {}); // o.myMethod(cp.getString());

	}

	@Retention(RetentionPolicy.RUNTIME)
	public @interface MyAnnotation {}

	public interface TestInterface {
		void doIt(CompositeParam c);
	}

	public interface CompositeParam {

		default String getString() {
			return "Nice!!";
		}
	}

}
