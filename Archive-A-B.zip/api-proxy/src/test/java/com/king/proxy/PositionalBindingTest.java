package com.king.proxy;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import org.junit.Test;

public class PositionalBindingTest {

	@Test
	public void test() throws Exception {

		Object o = new Object() {

			@FirstAnnotation
			public void myMethod(String s, Integer i) {
				System.out.println(s);
			}

			@SecondAnnotation
			public void myMethod2(Object s, long i) {
				System.out.println(i);
			}

		};

		TestInterface ti = ProxyGenerator
				.forClass(TestInterface.class)
				.bindingMethod("doThis")
				.toAnnotation(FirstAnnotation.class)
				.withPositionalParameterMapping(true)
				.bindingMethod("doThis")
				.toAnnotation(SecondAnnotation.class)
				.withPositionalParameterMapping(false)
				.generateProxy(o);

		ti.doThis("This", 2);

	}

	@Retention(RetentionPolicy.RUNTIME)
	public @interface FirstAnnotation {}

	@Retention(RetentionPolicy.RUNTIME)
	public @interface SecondAnnotation {}

	public interface TestInterface {

		void doThis(String s, Integer i);
	}

}
