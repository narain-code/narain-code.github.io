package com.king.proxy;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import org.junit.Test;

public class BasicBindingTest {

	@Test
	public void test() throws Exception {

		Object o = new Object() {

			@FirstAnnotation
			public void myMethod(String s) {
				System.out.println(s);
			}

			@FirstAnnotation
			public long myMethod2(int i) {
				System.out.println(i);
				return 0l;
			}

			@SecondAnnotation
			public int myOtherMethod() {
				System.out.println("That");
				return 1;
			}

		};

		ProxyGenerator<TestInterface> proxy = ProxyGenerator
				.forClass(TestInterface.class)
				.bindingMethod("doThis")
				.toAnnotation(FirstAnnotation.class)
				.bindingMethod("doThat")
				.toAnnotation(SecondAnnotation.class);

		TestInterface ti = proxy.generateProxy(o);

		ti.doThis("This", 2);
		ti.doThat(null);
	}

	@Retention(RetentionPolicy.RUNTIME)
	public @interface FirstAnnotation {}

	@Retention(RetentionPolicy.RUNTIME)
	public @interface SecondAnnotation {}

	public interface TestInterface {

		void doThis(String s, Integer i);

		void doThat(Object o);
	}

}
