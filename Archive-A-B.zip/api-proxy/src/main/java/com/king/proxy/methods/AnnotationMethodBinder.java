package com.king.proxy.methods;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class AnnotationMethodBinder implements TargetMethodBinder {

	private static final long serialVersionUID = 1L;
	private final Class<? extends Annotation> annotation;

	public AnnotationMethodBinder(Class<? extends Annotation> annotation) {
		Retention ret = annotation.getAnnotation(Retention.class);

		if (ret == null || ret.value() != RetentionPolicy.RUNTIME) {
			throw new RuntimeException("Annotation must have runtime retention policy");
		} else {
			this.annotation = annotation;
		}
	}

	@Override
	public List<Method> getTargetMethods(Object target) {
		final List<Method> methods = new ArrayList<>();
		Class<?> klass = target.getClass();
		while (klass != Object.class) {
			final List<Method> allMethods = new ArrayList<Method>(Arrays.asList(klass.getDeclaredMethods()));
			for (final Method method : allMethods) {
				for (Annotation a : method.getAnnotations()) {
					if (a.annotationType().equals(annotation)) {
						methods.add(method);
					}
				}
			}
			klass = klass.getSuperclass();
		}
		return methods;
	}

}
