package com.king.proxy.methods;

import java.io.Serializable;
import java.lang.reflect.Method;

import net.bytebuddy.implementation.bytecode.StackManipulation;

public interface MethodCallTransformer extends Serializable {

	StackManipulation transform(Method targetMethod, StackManipulation implementation) throws Exception;

}
