package com.king.proxy.parameters;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.google.common.collect.Lists;

import net.bytebuddy.description.method.MethodDescription;
import net.bytebuddy.implementation.bytecode.StackManipulation;
import net.bytebuddy.implementation.bytecode.member.MethodInvocation;
import net.bytebuddy.implementation.bytecode.member.MethodVariableAccess;

public enum TypeMatchingParameterBinder implements DefaultParameterBinder {

	INSTANCE;

	@Override
	public List<ParameterBinding> bind(Method sourceMethod, Method targetMethod, Class<?> targetType, int paramIndex,
			Set<Class<?>> compositeParamTypes, List<Annotation> parameterAnnotations) {

		Class<?>[] sourceParamTypes = sourceMethod.getParameterTypes();
		List<ParameterBinding> possibleBindings = new ArrayList<>();

		for (int i = 0; i < sourceParamTypes.length; i++) {

			// First try to match the parameter directly
			Class<?> type = sourceParamTypes[i];
			if (DefaultParameterBinder.isTypeCompatible(type, targetType)) {
				possibleBindings
						.add(ParameterBinding.forNonComposite(type,
								DefaultParameterBinder.load(type, targetType,
										MethodVariableAccess.REFERENCE.loadFrom(i + 1))));
			}

			// If unwrapping is allowed try to find all the getters with
			// compatible return types and add to bindings
			if (compositeParamTypes.contains(type)) {
				for (Method method : type.getDeclaredMethods()) {
					if (method.getName().startsWith("get") &&
							method.getParameterTypes().length == 0 &&
							DefaultParameterBinder.isTypeCompatible(method.getReturnType(), targetType)) {

						Class<?> getterType = method.getReturnType();
						possibleBindings.add(ParameterBinding.forComposite(getterType,
								DefaultParameterBinder.load(getterType, targetType,
										new StackManipulation.Compound(Lists.newArrayList(
												MethodVariableAccess.REFERENCE.loadFrom(i + 1),
												MethodInvocation
														.invoke(new MethodDescription.ForLoadedMethod(method))))),
								type, method));

					}
				}
			}
		}

		return possibleBindings;
	}

}
