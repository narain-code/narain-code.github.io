package com.king.proxy.parameters;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import net.bytebuddy.implementation.bytecode.member.MethodVariableAccess;

public enum StrictPositionalParameterBinder implements DefaultParameterBinder {

	INSTANCE;

	@Override
	public List<ParameterBinding> bind(Method sourceMethod, Method targetMethod, Class<?> targetType, int paramIndex,
			Set<Class<?>> compositeParamTypes, List<Annotation> parameterAnnotations) {

		if (sourceMethod.getParameterTypes().length <= paramIndex) {
			throw new RuntimeException("Argument cannot be matched");
		}

		Class<?> type = sourceMethod.getParameterTypes()[paramIndex];
		if (DefaultParameterBinder.isTypeCompatible(type, targetType)) {
			return Collections.singletonList(ParameterBinding.forNonComposite(type,
					DefaultParameterBinder.load(type, targetType,
							MethodVariableAccess.REFERENCE.loadFrom(paramIndex + 1))));
		} else {
			return Collections.emptyList();
		}
	}

}
