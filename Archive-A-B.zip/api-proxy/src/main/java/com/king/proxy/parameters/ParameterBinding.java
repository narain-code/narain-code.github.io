package com.king.proxy.parameters;

import java.lang.reflect.Method;
import java.util.Optional;

import net.bytebuddy.implementation.bytecode.StackManipulation;

public class ParameterBinding {

	private final Class<?> compositeClass;
	private final Class<?> sourceClass;
	private final StackManipulation sm;
	private final Method method;

	private ParameterBinding(Class<?> sourceClass, StackManipulation sm, Class<?> compositeClass, Method method) {
		this.compositeClass = compositeClass;
		this.sourceClass = sourceClass;
		this.sm = sm;
		this.method = method;
	}

	public static ParameterBinding forNonComposite(Class<?> sourceClass, StackManipulation sm) {
		return new ParameterBinding(sourceClass, sm, null, null);
	}

	public static ParameterBinding forComposite(Class<?> sourceClass, StackManipulation sm, Class<?> compositeClass,
			Method method) {
		return new ParameterBinding(sourceClass, sm, compositeClass, method);
	}

	public boolean isComposite() {
		return compositeClass != null;
	}

	public Optional<Class<?>> getCompositeClass() {
		return Optional.ofNullable(compositeClass);
	}

	public Optional<Method> getMethod() {
		return Optional.ofNullable(method);
	}

	public Class<?> getSourceClass() {
		return sourceClass;
	}

	public StackManipulation load() {
		return sm;
	}

}
