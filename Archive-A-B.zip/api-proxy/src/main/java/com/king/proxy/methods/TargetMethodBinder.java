package com.king.proxy.methods;

import java.io.Serializable;
import java.lang.reflect.Method;
import java.util.List;

public interface TargetMethodBinder extends Serializable {

	List<Method> getTargetMethods(Object target) throws Exception;

}
