package com.king.proxy;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import com.king.proxy.methods.AnnotationMethodBinder;
import com.king.proxy.methods.MethodCallTransformer;
import com.king.proxy.methods.TargetMethodBinder;
import com.king.proxy.methods.implementation.BindingImplementation;
import com.king.proxy.parameters.CastingPositionalParameterBinding;
import com.king.proxy.parameters.DefaultParameterBinder;
import com.king.proxy.parameters.ParameterBinder;
import com.king.proxy.parameters.ParameterBinding;
import com.king.proxy.parameters.StrictPositionalParameterBinder;
import com.king.proxy.parameters.TypeMatchingParameterBinder;

import net.bytebuddy.description.method.MethodDescription;
import net.bytebuddy.description.method.MethodDescription.ForLoadedMethod;
import net.bytebuddy.description.type.TypeDescription;
import net.bytebuddy.implementation.bytecode.StackManipulation;
import net.bytebuddy.matcher.ElementMatcher;

public class MethodBinding<Source> extends ProxyGenerator<Source> {

	private static final long serialVersionUID = 1L;

	private final Set<Class<?>> compositeParamTypes = new HashSet<>();
	private final List<TargetMethodBinder> methodBinders = new ArrayList<>();
	private final List<ParameterBinder> customBinders = new ArrayList<>();
	private final List<MethodCallTransformer> transformers = new ArrayList<>();
	private final ElementMatcher<? super MethodDescription> sourceMethodMatcher;

	private DefaultParameterBinder defaultBinder = TypeMatchingParameterBinder.INSTANCE;

	public MethodBinding(ProxyGenerator<Source> proxy, ElementMatcher<? super MethodDescription> sourceMethodMatcher) {
		super(proxy);
		this.sourceMethodMatcher = sourceMethodMatcher;
		sourceMethod();
	}

	public MethodBinding<Source> withMethodCallTransformer(MethodCallTransformer transformer) {
		transformers.add(transformer);
		return this;
	}

	public MethodBinding<Source> withParameterBinder(Class<?> paramClass, ParameterBinder binder) {
		return withParameterBinder(new ParameterBinder() {
			private static final long serialVersionUID = 1L;

			@Override
			public Optional<ParameterBinding> bind(Method sourceMethod, Method targetMethod, Class<?> targetParamClass,
					int targetParamIndex, List<Annotation> parameterAnnotations,
					List<ParameterBinding> possibleBindings) throws Exception {

				if (targetParamClass.equals(paramClass)) {
					return binder.bind(sourceMethod, targetMethod, targetParamClass, targetParamIndex,
							parameterAnnotations, possibleBindings);
				} else {
					return Optional.empty();
				}
			}
		});
	}

	public MethodBinding<Source> withParameterBinder(ParameterBinder binder) {
		customBinders.add(binder);
		return this;
	}

	public MethodBinding<Source> withCompositeParameters(Class<?>... type) {
		Arrays.stream(type).forEach(compositeParamTypes::add);
		return this;
	}

	public MethodBinding<Source> toAnnotation(Class<? extends Annotation> annotation) {
		return withMethodBinder(new AnnotationMethodBinder(annotation));
	}

	public MethodBinding<Source> toName(String targetMethodName) {
		return withMethodBinder(
				target -> Arrays.stream(target.getClass().getMethods())
						.filter(m -> m.getName().equals(targetMethodName))
						.collect(Collectors.toList()));
	}

	public MethodBinding<Source> withMethodBinder(TargetMethodBinder binder) {
		methodBinders.add(binder);
		return this;
	}

	public MethodBinding<Source> withPositionalParameterMapping(boolean strict) {
		defaultBinder = strict ? StrictPositionalParameterBinder.INSTANCE : CastingPositionalParameterBinding.INSTANCE;
		return this;
	}

	public BindingImplementation implementation(Object target) throws Exception {
		Set<Method> targetMethods = getTargetMethods(target);
		List<List<StackManipulation>> allParamGetters = new ArrayList<>();

		for (Method targetMethod : targetMethods) {
			List<StackManipulation> paramGetters = new ArrayList<>();
			allParamGetters.add(paramGetters);

			Class<?>[] targetParamTypes = targetMethod.getParameterTypes();

			for (int i = 0; i < targetParamTypes.length; i++) {

				List<Annotation> paramAnnotations = Arrays.asList(targetMethod.getParameterAnnotations()[i]);
				Class<?> targetParamClass = targetParamTypes[i];

				List<ParameterBinding> possibleBindings = defaultBinder.bind(
						sourceMethod(),
						targetMethod,
						targetParamClass,
						i,
						compositeParamTypes,
						paramAnnotations);

				int paramIndex = i;

				List<ParameterBinding> customBindings = new ArrayList<>();

				for (ParameterBinder cb : customBinders) {
					cb.bind(sourceMethod(), targetMethod, targetParamClass, paramIndex,
							paramAnnotations, possibleBindings).ifPresent(customBindings::add);
				}

				if (customBindings.size() == 1) {
					paramGetters.add(customBindings.get(0).load());
				} else if (customBindings.size() > 1) {
					throw new RuntimeException(
							"Ambiguous custom binding for " + targetParamClass.getSimpleName());
				} else {
					if (possibleBindings.isEmpty()) {
						throw new RuntimeException(
								"Cannot map parameter: " + targetParamClass.getSimpleName());
					} else if (possibleBindings.size() > 1) {
						throw new RuntimeException(
								"Ambiguous binding for " + targetParamClass.getSimpleName());
					} else {
						paramGetters.add(possibleBindings.get(0).load());
					}
				}
			}

		}

		return new BindingImplementation(
				targetMethods
						.stream()
						.map(method -> new MethodDescription.ForLoadedMethod(method))
						.collect(Collectors.toList()),
				allParamGetters
						.stream()
						.map(StackManipulation.Compound::new)
						.collect(Collectors.toList()),
				transformers);
	}

	public Method sourceMethod() {
		ForLoadedMethod sourceMethod = (ForLoadedMethod) new TypeDescription.ForLoadedType(sourceClass)
				.getDeclaredMethods().filter(sourceMethodMatcher).getOnly();

		if (!sourceMethod.getLoadedMethod().getReturnType().equals(void.class)) {
			throw new RuntimeException("Can only bind to void methods");
		}

		return sourceMethod.getLoadedMethod();
	}

	public ElementMatcher<? super MethodDescription> sourceMethodMatcher() {
		return sourceMethodMatcher;
	}

	private Set<Method> getTargetMethods(Object target) throws Exception {
		Set<Method> all = new HashSet<>();
		for (TargetMethodBinder mb : methodBinders) {
			mb.getTargetMethods(target).forEach(all::add);
		}
		return all;
	}

	public boolean matchesAny(Object target) throws Exception {
		return !getTargetMethods(target).isEmpty();
	}
}
