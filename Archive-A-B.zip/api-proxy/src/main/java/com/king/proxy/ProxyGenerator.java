package com.king.proxy;

import java.io.Serializable;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import com.king.proxy.methods.implementation.BindingImplementation;

import net.bytebuddy.ByteBuddy;
import net.bytebuddy.NamingStrategy.SuffixingRandom;
import net.bytebuddy.description.field.FieldDescription;
import net.bytebuddy.description.method.MethodDescription;
import net.bytebuddy.description.modifier.Visibility;
import net.bytebuddy.description.type.TypeDescription;
import net.bytebuddy.description.type.TypeDescription.Generic;
import net.bytebuddy.dynamic.DynamicType.Builder;
import net.bytebuddy.implementation.FieldAccessor;
import net.bytebuddy.implementation.MethodCall;
import net.bytebuddy.matcher.ElementMatcher;
import net.bytebuddy.matcher.ElementMatchers;

public class ProxyGenerator<Source> implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final String TARGET_OBJECT_FIELDNAME = "target";
	private final List<MethodBinding<Source>> methodBindings;
	protected final Class<Source> sourceClass;

	protected ProxyGenerator(ProxyGenerator<Source> proxy) {
		this.sourceClass = proxy.sourceClass;
		this.methodBindings = proxy.methodBindings;
	}

	private ProxyGenerator(Class<Source> source) {
		this.sourceClass = source;
		this.methodBindings = new ArrayList<>();
	}

	public static <I> ProxyGenerator<I> forClass(Class<I> target) {
		return new ProxyGenerator<>(target);
	}

	public MethodBinding<Source> bindingMethod(Method method) {
		return bindingMethod(ElementMatchers.anyOf(method));
	}

	public MethodBinding<Source> bindingMethod(String methodName) {
		return bindingMethod(ElementMatchers.named(methodName));
	}

	public MethodBinding<Source> bindingMethod(ElementMatcher<? super MethodDescription> sourceMethodMatcher) {
		MethodBinding<Source> binding = new MethodBinding<>(this, sourceMethodMatcher);
		methodBindings.add(binding);
		return binding;
	}

	public Source generateProxy(Object target) throws Exception {
		return generateProxy(target, "auxiliary");
	}

	public Source generateProxy(Object target, String nameSuffix) throws Exception {
		return generateProxy(target, nameSuffix, target.getClass().getClassLoader());
	}

	public Source generateProxy(Object target, String nameSuffix, ClassLoader cl) throws Exception {
		FieldDescription definedField = new FieldDescription.Latent(
				new TypeDescription.ForLoadedType(sourceClass),
				new FieldDescription.Token(TARGET_OBJECT_FIELDNAME, Modifier.PUBLIC,
						new Generic.OfNonGenericType.ForLoadedType(target.getClass())));

		Builder<Source> builder = new ByteBuddy()
				.with(new SuffixingRandom(nameSuffix) {
					@Override
					public String subclass(Generic superClass) {
						return super.name(new TypeDescription.ForLoadedType(target.getClass()));
					}
				})
				.subclass(sourceClass)
				.define(definedField)
				.defineConstructor(Visibility.PUBLIC)
				.withParameters(target.getClass())
				.intercept(
						MethodCall
								.invoke(Object.class.getDeclaredConstructor())
								.andThen(FieldAccessor
										.ofField(TARGET_OBJECT_FIELDNAME)
										.setsArgumentAt(0)));

		Map<Method, List<MethodBinding<Source>>> partitioned = methodBindings.stream()
				.collect(Collectors.groupingBy(MethodBinding::sourceMethod));

		for (Entry<Method, List<MethodBinding<Source>>> e : partitioned.entrySet()) {

			List<BindingImplementation> implementations = new ArrayList<>();
			for (MethodBinding<Source> mb : e.getValue()) {
				implementations.add(mb.implementation(target));
			}

			builder = builder
					.method(e.getValue().get(0).sourceMethodMatcher())
					.intercept(BindingImplementation.combine(implementations));
		}

		Class<? extends Source> loaded = builder.make()
				.load(cl)
				.getLoaded();

		return loaded.getConstructor(target.getClass()).newInstance(target);
	}

}
