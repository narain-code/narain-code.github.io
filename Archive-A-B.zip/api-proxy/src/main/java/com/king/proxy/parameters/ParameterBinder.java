package com.king.proxy.parameters;

import java.io.Serializable;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Optional;

public interface ParameterBinder extends Serializable {

	Optional<ParameterBinding> bind(
			Method sourceMethod,
			Method targetMethod,
			Class<?> targetParamClass,
			int targetParamIndex,
			List<Annotation> parameterAnnotations,
			List<ParameterBinding> possibleBindings) throws Exception;
}