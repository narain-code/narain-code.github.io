package com.king.proxy.methods.implementation;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import com.king.proxy.ProxyGenerator;
import com.king.proxy.methods.MethodCallTransformer;

import net.bytebuddy.description.field.FieldDescription;
import net.bytebuddy.description.method.MethodDescription;
import net.bytebuddy.description.method.MethodDescription.ForLoadedMethod;
import net.bytebuddy.dynamic.scaffold.InstrumentedType;
import net.bytebuddy.implementation.Implementation;
import net.bytebuddy.implementation.bytecode.ByteCodeAppender;
import net.bytebuddy.implementation.bytecode.StackManipulation;
import net.bytebuddy.implementation.bytecode.member.FieldAccess;
import net.bytebuddy.implementation.bytecode.member.MethodInvocation;
import net.bytebuddy.implementation.bytecode.member.MethodReturn;
import net.bytebuddy.implementation.bytecode.member.MethodVariableAccess;
import net.bytebuddy.jar.asm.MethodVisitor;
import net.bytebuddy.jar.asm.Opcodes;
import net.bytebuddy.matcher.ElementMatchers;

public class BindingImplementation implements Implementation {

	private final List<ForLoadedMethod> targetMethods;
	private final List<StackManipulation> methodArguments;

	private FieldDescription targetObject;
	private List<MethodCallTransformer> methodCallTransformers;

	public BindingImplementation(List<ForLoadedMethod> methods, List<StackManipulation> arguments,
			List<MethodCallTransformer> transformers) {
		this.targetMethods = methods;
		this.methodArguments = arguments;
		this.methodCallTransformers = transformers;
	}

	@Override
	public InstrumentedType prepare(InstrumentedType stubType) {
		targetObject = stubType
				.getDeclaredFields()
				.filter(ElementMatchers.named(ProxyGenerator.TARGET_OBJECT_FIELDNAME))
				.getOnly();
		return stubType;
	}

	@Override
	public ByteCodeAppender appender(Target implementationTarget) {
		return new ByteCodeAppender() {
			public Size apply(MethodVisitor methodVisitor, Context implementationContext,
					MethodDescription instrumentedMethod) {

				StackManipulation targetCalls = null;
				try {
					targetCalls = createTargetMethodCalls(true);
				} catch (Exception e) {
					throwSilently(e);
				}
				StackManipulation.Size size = targetCalls.apply(methodVisitor, implementationContext);

				return new Size(size.getMaximalSize(), instrumentedMethod.getStackSize());
			}

		};
	}

	public StackManipulation createTargetMethodCalls(boolean returnAtEnd) throws Exception {
		List<StackManipulation> allStackManipulations = new ArrayList<>();

		// We call target method one after the other
		for (int i = 0; i < targetMethods.size(); i++) {
			ForLoadedMethod loadedMethod = targetMethods.get(i);
			Method method = loadedMethod.getLoadedMethod();

			StackManipulation methodCall = new StackManipulation.Compound(
					MethodVariableAccess.loadThis(),
					FieldAccess.forField(targetObject).read(),
					// Push all method arguments to stack
					methodArguments.get(i),
					// Call target method without return value
					new StackManipulation() {

						@Override
						public Size apply(MethodVisitor methodVisitor, Context implementationContext) {
							Size s = MethodInvocation.invoke(loadedMethod).apply(methodVisitor, implementationContext);

							int returnedSize = loadedMethod.getReturnType().getStackSize().getSize();

							// Single word types have to use pop and double
							// words use pop2
							if (returnedSize == 1) {
								methodVisitor.visitInsn(Opcodes.POP);
							} else if (returnedSize == 2) {
								methodVisitor.visitInsn(Opcodes.POP2);
							}

							return s;
						}

						@Override
						public boolean isValid() {
							return true;
						}

					});

			// Apply all the supplied transformers (if any)
			for (MethodCallTransformer t : methodCallTransformers) {
				methodCall = t.transform(method, methodCall);
			}

			allStackManipulations.add(methodCall);
		}

		if (returnAtEnd) {
			allStackManipulations.add(MethodReturn.VOID);
		}

		return new StackManipulation.Compound(allStackManipulations);
	}

	public static Implementation combine(List<BindingImplementation> bindingImplementations) {

		if (bindingImplementations.size() == 1) {
			return bindingImplementations.get(0);
		}

		return new Implementation() {

			@Override
			public InstrumentedType prepare(InstrumentedType it) {
				for (BindingImplementation bi : bindingImplementations) {
					bi.prepare(it);
				}
				return it;
			}

			@Override
			public ByteCodeAppender appender(Target implementationTarget) {
				return new ByteCodeAppender() {
					public Size apply(MethodVisitor methodVisitor, Context implementationContext,
							MethodDescription instrumentedMethod) {

						List<StackManipulation> allMethodCalls = new ArrayList<>();

						for (BindingImplementation bi : bindingImplementations) {
							try {
								allMethodCalls.add(bi.createTargetMethodCalls(false));
							} catch (Exception e) {
								throwSilently(e);
							}
						}

						allMethodCalls.add(MethodReturn.VOID);

						StackManipulation.Size size = new StackManipulation.Compound(allMethodCalls)
								.apply(methodVisitor, implementationContext);

						return new Size(size.getMaximalSize(), instrumentedMethod.getStackSize());
					}
				};
			}

		};
	}

	@SuppressWarnings("unchecked")
	public static <E extends Throwable> void throwSilently(Throwable e) throws E {
		throw (E) e;
	}
}
