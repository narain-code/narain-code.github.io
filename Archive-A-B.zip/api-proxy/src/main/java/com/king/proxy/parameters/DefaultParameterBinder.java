package com.king.proxy.parameters;

import java.io.Serializable;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Set;

import net.bytebuddy.description.type.TypeDescription;
import net.bytebuddy.description.type.TypeDescription.Generic;
import net.bytebuddy.implementation.bytecode.StackManipulation;
import net.bytebuddy.implementation.bytecode.assign.Assigner.Typing;
import net.bytebuddy.implementation.bytecode.assign.primitive.PrimitiveTypeAwareAssigner;
import net.bytebuddy.implementation.bytecode.assign.reference.ReferenceTypeAwareAssigner;

public interface DefaultParameterBinder extends Serializable {

	List<ParameterBinding> bind(
			Method sourceMethod,
			Method targetMethod,
			Class<?> targetParamClass,
			int targetParamIndex,
			Set<Class<?>> compositeTypes,
			List<Annotation> parameterAnnotations);

	public static boolean isTypeCompatible(Class<?> sourceType, Class<?> targetType) {
		if (targetType.isAssignableFrom(sourceType)) {
			return true;
		}

		boolean boxedCompatible = checkCompatibleTypes(sourceType, targetType, int.class, Integer.class) ||
				checkCompatibleTypes(sourceType, targetType, long.class, Long.class) ||
				checkCompatibleTypes(sourceType, targetType, short.class, Short.class) ||
				checkCompatibleTypes(sourceType, targetType, byte.class, Byte.class) ||
				checkCompatibleTypes(sourceType, targetType, double.class, Double.class) ||
				checkCompatibleTypes(sourceType, targetType, float.class, Float.class) ||
				checkCompatibleTypes(sourceType, targetType, boolean.class, Boolean.class);

		return boxedCompatible;
	}

	public static boolean checkCompatibleTypes(Class<?> sourceType, Class<?> targetType, Class<?>... compatible) {

		boolean sourceCompatible = false;
		boolean targetCompatible = false;

		for (Class<?> c : compatible) {
			if (sourceType.isAssignableFrom(c)) {
				sourceCompatible = true;
			}
			if (targetType.isAssignableFrom(c)) {
				targetCompatible = true;
			}
		}

		return sourceCompatible && targetCompatible;
	}

	public static StackManipulation load(Class<?> sourceType, Class<?> targetType, StackManipulation getter) {
		if (sourceType.equals(targetType)) {
			return getter;
		}
		Generic source = Generic.Builder.rawType(new TypeDescription.ForLoadedType(sourceType)).build();
		Generic target = Generic.Builder.rawType(new TypeDescription.ForLoadedType(targetType)).build();

		StackManipulation assignment = new PrimitiveTypeAwareAssigner(ReferenceTypeAwareAssigner.INSTANCE)
				.assign(source, target, Typing.DYNAMIC);

		if (assignment.equals(StackManipulation.Illegal.INSTANCE)) {
			throw new RuntimeException(
					"Cannot assign " + sourceType.getSimpleName() + " to " + targetType.getSimpleName());
		} else {
			return new StackManipulation.Compound(getter, assignment);
		}
	}
}