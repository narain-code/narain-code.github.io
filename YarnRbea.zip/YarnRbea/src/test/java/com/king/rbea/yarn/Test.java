package com.king.rbea.yarn;
import java.util.Scanner;

public class Test {

	
	public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        double pos=0.0;
        double neg =0.0;
        double zero = 0.0;
        int n = in.nextInt();
        int arr[] = new int[n];
        for(int arr_i=0; arr_i < n; arr_i++){
           int th = in.nextInt();
             arr[arr_i]=th;
            if(th == 0)
                zero ++;
            else{
                if(th <0){
                    neg ++;
                }else{
                    pos ++;
                }
            }
        }
       System.out.println( pos/ ((double)n) );
       System.out.println(zero/((double)n) );
        System.out.println(neg/ ((double)n) );
        
    }
}
