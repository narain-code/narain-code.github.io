# King Streaming SDK

How to release:
```
mvn release:prepare release:perform
```
