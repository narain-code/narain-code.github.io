package com.king.utils;

import com.king.splat.fxrate.CurrencyManagerImpl;
import com.king.splat.fxrate.OandaCurrencyProvider;

public class CurrencyManagerSingleton {

	private static final CurrencyManager CURRENCY_MANAGER = new CurrencyManager(new CurrencyManagerImpl(new OandaCurrencyProvider(), true));

	public static CurrencyManager getInstance() {
		return CURRENCY_MANAGER;
	}

}
