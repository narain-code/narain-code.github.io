package com.king.utils;

import java.math.BigDecimal;

import com.king.splat.fxrate.MissingRateException;

public class CurrencyManager implements com.king.splat.fxrate.CurrencyManager {

	private final com.king.splat.fxrate.CurrencyManager cm;

	public CurrencyManager(com.king.splat.fxrate.CurrencyManager cm) {
		this.cm = cm;
	}

	/**
	 * Converts local currency amount to USD based on the event timestamp.
	 * (timestamp, localCurrencyString, amountDouble"
	 */
	public BigDecimal convertToUsd(long msts, String currency, double localAmount) throws MissingRateException {
		return cm.convertToUsd(msts, currency, localAmount);
	}

	/**
	 * Converts local currency amount to USD cents based on the event timestamp.
	 * (timestamp, localCurrencyString, amountCents)
	 */
	public long convertCentsToUsdCents(long msts, String currency, long localAmountCents) throws MissingRateException {
		return cm.convertCentsToUsdCents(msts, currency, localAmountCents);
	}
}
