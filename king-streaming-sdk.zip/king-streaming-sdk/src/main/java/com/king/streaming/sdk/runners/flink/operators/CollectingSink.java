package com.king.streaming.sdk.runners.flink.operators;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;

import com.king.event.Event;
import com.king.streaming.sdk.eventstream.ResultIterator;

public class CollectingSink extends RichSinkFunction<Event> implements ResultIterator {

	private static final long serialVersionUID = 1L;
	private static final List<BlockingQueue<Event>> queues = Collections
			.synchronizedList(new ArrayList<>());
	private static final AtomicInteger numSinks = new AtomicInteger(-1);
	private final int index;

	public CollectingSink() {
		index = numSinks.incrementAndGet();
		queues.add(new LinkedBlockingQueue<>());
	}

	@Override
	public boolean hasNext() {
		return queues.isEmpty();
	}

	@Override
	public void invoke(Event event) throws Exception {
		queues.get(index).add(event);
	}

	@Override
	public Event poll(Duration duration) throws TimeoutException {
		Event e = null;
		try {
			e = queues.get(index).poll(duration.toMillis(), TimeUnit.MILLISECONDS);
		} catch (InterruptedException ex) {
			throw new RuntimeException(ex);
		}

		if (e == null) {
			throw new TimeoutException();
		} else {
			return e;
		}
	}
}
