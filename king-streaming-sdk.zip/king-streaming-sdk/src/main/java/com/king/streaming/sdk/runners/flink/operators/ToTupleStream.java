package com.king.streaming.sdk.runners.flink.operators;

import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.typeinfo.BasicTypeInfo;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.typeutils.ResultTypeQueryable;
import org.apache.flink.api.java.typeutils.TupleTypeInfo;

import com.king.event.Event;
import com.king.streaming.sdk.runners.flink.FlinkEventStream;

public final class ToTupleStream
		implements MapFunction<Event, Tuple2<Short, Event>>, ResultTypeQueryable<Tuple2<Short, Event>> {
	private static final long serialVersionUID = 1L;

	private final Short id;

	public ToTupleStream(Short id) {
		this.id = id;
	}

	@Override
	public Tuple2<Short, Event> map(Event event) throws Exception {
		return Tuple2.of(id, event);
	}

	@Override
	public TypeInformation<Tuple2<Short, Event>> getProducedType() {
		return new TupleTypeInfo<Tuple2<Short, Event>>((Class) Tuple2.class,
				BasicTypeInfo.SHORT_TYPE_INFO,
				FlinkEventStream.eventType);
	}
}