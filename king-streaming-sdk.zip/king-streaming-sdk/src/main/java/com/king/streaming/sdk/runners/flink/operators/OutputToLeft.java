package com.king.streaming.sdk.runners.flink.operators;

import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.typeutils.ResultTypeQueryable;
import org.apache.flink.types.Either;
import org.apache.flink.util.Collector;

import com.king.event.Event;
import com.king.streaming.sdk.runners.flink.FlinkEventStream;
import com.king.streaming.sdk.runners.flink.types.AggregateEvent;

public class OutputToLeft implements FlatMapFunction<Either<Event, AggregateEvent>, Event>, ResultTypeQueryable<Event> {
	private static final long serialVersionUID = 1L;

	@Override
	public TypeInformation<Event> getProducedType() {
		return FlinkEventStream.eventType;
	}

	@Override
	public void flatMap(Either<Event, AggregateEvent> in, Collector<Event> out) throws Exception {
		if (in.isLeft()) {
			out.collect(in.left());
		}
	}

}
