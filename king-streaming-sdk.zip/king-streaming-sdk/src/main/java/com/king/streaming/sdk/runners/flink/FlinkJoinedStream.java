package com.king.streaming.sdk.runners.flink;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.KeyedStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.types.Either;

import com.king.event.Event;
import com.king.streaming.sdk.context.Context;
import com.king.streaming.sdk.context.JoinContext;
import com.king.streaming.sdk.eventstream.BroadcastState;
import com.king.streaming.sdk.eventstream.JoinedEventStream;
import com.king.streaming.sdk.eventstream.join.JoinField;
import com.king.streaming.sdk.functions.EventFilter;
import com.king.streaming.sdk.functions.EventProcessor;
import com.king.streaming.sdk.functions.Key;
import com.king.streaming.sdk.runners.flink.operators.JoinContextEventProcessor;
import com.king.streaming.sdk.runners.flink.operators.OutputToLeft;
import com.king.streaming.sdk.runners.flink.types.AggregateEvent;

public class FlinkJoinedStream<C extends JoinContext> extends FlinkKeyedEventStream<C> implements JoinedEventStream<C> {

	private JoinField<?>[] joinFields;

	protected FlinkJoinedStream(FlinkRunner runner, KeyedStream<Event, ?> keyedStream, Key key,
			JoinField<?>[] joinFields) {
		this(runner, keyedStream, key, joinFields, new ArrayList<>());
	}

	protected FlinkJoinedStream(FlinkRunner runner, KeyedStream<Event, ?> keyedStream, Key key,
			JoinField<?>[] joinFields,
			Collection<BroadcastState<?>> broadcastStates) {
		super(runner, keyedStream, key, broadcastStates);
		this.joinFields = joinFields;
	}

	@Override
	public FlinkProcessorOutput process(EventProcessor<C> eventProcessor) {
		Map<BroadcastState<?>, Short> bcsMapping = getStateMapping();
		JoinContextEventProcessor procesor = new JoinContextEventProcessor(
				new FlinkEventProcessor<>(runner.clean(eventProcessor)),
				bcsMapping,
				joinFields);

		Tuple2<SingleOutputStreamOperator<Either<Event, AggregateEvent>>, SingleOutputStreamOperator<AggregateEvent>> out = applyProcess(
				procesor, bcsMapping);

		SingleOutputStreamOperator<Either<Event, AggregateEvent>> outStream = out.f0.name(eventProcessor.name());

		return new FlinkProcessorOutput(runner, outStream
				.flatMap(new OutputToLeft())
				.name("Select Events"), out.f1);
	}

	@SuppressWarnings("unchecked")
	public FlinkJoinedStream<C> filter(EventFilter eventFilter) {
		return (FlinkJoinedStream<C>) super.filter(eventFilter).matchPrivate(joinFields);
	}

	@Override
	public <X extends Context> JoinedEventStream<C> withBroadcastState(BroadcastState<?>... states) {
		if (states.length == 0) {
			throw new RuntimeException("At least one broadcast state needs to be passed to this method");
		}
		Collection<BroadcastState<?>> newStates = new ArrayList<>(broadcastStates);
		for (BroadcastState<?> state : states) {
			newStates.add(state);
		}

		return new FlinkJoinedStream<>(runner, keyedStream, key, joinFields, newStates);
	}

	protected JoinedEventStream<JoinContext> matchPrivate(JoinField<?>... newJoinFields) {
		if (newJoinFields.length == 0) {
			throw new RuntimeException("At least one join field needs to be passed to this method");
		}
		JoinField<?>[] arr = new JoinField[newJoinFields.length + joinFields.length];
		int i = 0;
		while (i < joinFields.length) {
			arr[i] = joinFields[i];
			++i;
		}

		while (i < arr.length) {
			arr[i] = newJoinFields[i];
			++i;
		}

		return new FlinkJoinedStream<>(runner, keyedStream, key, arr);
	}
}
