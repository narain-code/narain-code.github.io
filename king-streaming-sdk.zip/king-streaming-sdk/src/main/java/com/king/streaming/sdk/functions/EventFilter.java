package com.king.streaming.sdk.functions;

import com.king.event.Event;

public interface EventFilter extends Function {
	boolean filter(Event e) throws Exception;
}
