package com.king.streaming.sdk.eventstream;

import com.king.streaming.sdk.context.Context;
import com.king.streaming.sdk.context.aggregators.AggregatorOutput;

public interface ProcessorOutput extends EventStream<Context> {

	public BroadcastState<AggregatorOutput> broadcastAggregatorOutput();

	public EventStream<Context> getAggregateEvents();
	
	public ProcessorOutput setProcessorName(String name);
	
	public ProcessorOutput uid(String uid);
	
	@Deprecated
	public ProcessorOutput setUidHash(String uid);
}
