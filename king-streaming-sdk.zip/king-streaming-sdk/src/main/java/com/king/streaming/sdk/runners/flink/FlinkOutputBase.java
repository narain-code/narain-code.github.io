package com.king.streaming.sdk.runners.flink;

import org.apache.flink.streaming.api.datastream.DataStream;

import com.king.event.Event;
import com.king.streaming.sdk.io.Output;
import com.king.streaming.sdk.io.OutputFormat;

public abstract class FlinkOutputBase<T extends Output<T>> implements Output<T> {

	protected final DataStream<Event> dataStream;
	protected OutputFormat outputFormat = DEFAULT_EVENT_FORMAT;

	public FlinkOutputBase(DataStream<Event> dataStream) {
		this.dataStream = dataStream;
	}

	@SuppressWarnings("unchecked")
	@Override
	public T withOutputFormat(OutputFormat format) {
		this.outputFormat = format;
		return (T) this;
	}

	public abstract void createSink();
}
