package com.king.streaming.sdk.application;

import org.apache.flink.runtime.state.memory.MemoryStateBackend;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.king.flink.utils.Unchecked;
import com.king.streaming.sdk.eventstream.TestRunner;
import com.king.streaming.sdk.runners.flink.FlinkOptions;
import com.king.streaming.sdk.runners.flink.FlinkRunner;

public class ApplicationTester {

	private static final Logger LOG = LoggerFactory.getLogger(ApplicationTester.class);

	public static void runTest(Unchecked.ThrowingConsumer<TestRunner> testCase) throws Exception {
		TestRunner runner = getTestRunner();
		testCase.accept(runner);

		if (!runner.wasStarted()) {
			throw new RuntimeException(
					"Runner wasn't started in the run method. Did you forget calling runner.startTest()?");
		}

		if (!runner.wasStopped()) {
			LOG.warn("stopTest wasn't called on the runner, this must be a mistake. Stopping it for you...");
			runner.stopTest();
		}
	}

	public static TestRunner getTestRunner() throws Exception {
		FlinkOptions opt = new FlinkOptions();
		opt.checkpointInterval = 500;
		opt.stateBackend = new MemoryStateBackend();

		return FlinkRunner.create("Test", opt);
	}
}
