package com.king.streaming.sdk.io;

import java.io.IOException;
import java.io.Serializable;

import com.king.event.Event;

public interface InputFormat extends Serializable {

	Event deserialize(byte[] bytes) throws IOException;
}
