package com.king.streaming.sdk.context.aggregators;

public interface Counter extends DimensionalAggregator<Counter> {

	void increment();

	void decrement();
}
