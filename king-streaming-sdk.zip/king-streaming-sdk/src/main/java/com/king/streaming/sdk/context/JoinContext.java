package com.king.streaming.sdk.context;

import java.util.Optional;

import com.king.streaming.sdk.eventstream.JoinedEventStream;
import com.king.streaming.sdk.eventstream.join.JoinField;

/**
 * Context provided by a {@link JoinedEventStream} that gives access to
 * matched/joined fields.
 * 
 */
public interface JoinContext extends KeyContext {

	/**
	 * Returns the current matched value for the given {@link JoinField}.
	 * <p>
	 * The missing value handling behavior depends on the {@link JoinField}. If
	 * it it allows missing values (as per {@link JoinField#allowsMissing()}) it
	 * returns null otherwise it throws an Exception.
	 * </p>
	 * 
	 * @param matchCondition
	 *            The field to be returned
	 * @return The current matched value
	 * @throws Exception
	 */
	default <MatchType> MatchType getMatched(JoinField<MatchType> matchCondition) throws Exception {

		Optional<MatchType> opt = matchCondition.getValue(this);

		if (matchCondition.allowsMissing()) {
			return opt.orElse(null);
		} else {
			return opt.orElseThrow(() -> new IllegalStateException("Missing element"));
		}
	}

	/**
	 * Returns the {@link Optional} value for the given {@link JoinField}.
	 * 
	 * @param joinCondition
	 *            The field to be returned
	 * @return The {@link Optional} joined value
	 * @throws Exception
	 */
	default <JoinType> Optional<JoinType> getJoined(JoinField<JoinType> joinCondition) throws Exception {
		return joinCondition.getValue(this);
	}

}
