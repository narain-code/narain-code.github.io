package com.king.streaming.sdk.context;

/**
 * A {@link Context} with access to stateful functionality such as timers and
 * state
 */
public interface StatefulContext extends Context {

	/**
	 * @return The {@link Timers} object
	 */
	Timers getTimers();

	/**
	 * Get {@link State} for the current partition (key/global). The state is
	 * scoped by state name and partition key. It is possible to define a
	 * time-to-live duration after which (if no access happens) the state is
	 * deleted.
	 *
	 * @param name
	 *            Identifier of the state
	 * @param stateType
	 *            The java type of the state object, used for serialization
	 * @return The {@link State} instance
	 */
	<T> State<T> getValueState(String name, Class<T> stateType);

	<K,V> MapState<K,V> getMapState(String name, Class<K> keyType, Class<V> valueType);
}
