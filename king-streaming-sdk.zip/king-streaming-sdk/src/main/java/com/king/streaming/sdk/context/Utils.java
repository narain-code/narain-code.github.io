package com.king.streaming.sdk.context;

import com.king.utils.CurrencyManager;
import com.king.utils.CurrencyManagerSingleton;

public interface Utils {

	default CurrencyManager getCurrencyManager() {
		return CurrencyManagerSingleton.getInstance();
	}

	public enum UtilSingleton implements Utils {
		INSTANCE
	}

}
