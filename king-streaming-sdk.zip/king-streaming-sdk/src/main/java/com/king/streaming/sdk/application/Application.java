package com.king.streaming.sdk.application;

import java.util.Properties;

import com.king.streaming.sdk.eventstream.Runner;

/**
 * Interface for defining King Streaming SDK applications
 */
public interface Application {

	/**
	 * The main entry point for the streaming application. The {@link Runner} is
	 * provided by the cluster environment and the {@link Properties} file will
	 * be supplied by the user through the command line client.
	 * 
	 * @param runner
	 *            {@link Runner} for the application
	 * @param props
	 *            Application {@link Properties}
	 * @throws Exception
	 */
	public void run(Runner runner, Properties props) throws Exception;

}
