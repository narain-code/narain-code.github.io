package com.king.streaming.sdk.eventstream;

import java.time.Duration;
import java.util.concurrent.TimeoutException;

import com.king.event.Event;

/**
 * Object for accessing the elements of an {@link EventStream}. Suitable for
 * testing the pipelines.
 * 
 * @see TestRunner
 */
public interface ResultIterator {

	/**
	 * Returns the last event produced from the stream, waiting a maximum of 30
	 * seconds before timing out.
	 * 
	 * @return Last Event in the stream
	 * @throws TimeoutException
	 */
	default Event poll() throws TimeoutException {
		return poll(Duration.ofSeconds(30));
	}

	/**
	 * Returns the last event produced from the stream, waiting up to the
	 * specified amount of time before timing out.
	 * 
	 * @param timeout
	 * 
	 * @return Last Event in the stream
	 * @throws TimeoutException
	 */
	Event poll(Duration timeout) throws TimeoutException;

	/**
	 * Checks whether the iterator queue has any elements currently. Obviously
	 * cannot tell if the event stream will have any further elements beyond
	 * this.
	 * 
	 * @return True iff the current result queue has more elements
	 */
	boolean hasNext();
}
