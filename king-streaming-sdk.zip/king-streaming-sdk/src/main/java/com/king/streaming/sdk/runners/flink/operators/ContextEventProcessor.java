/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.king.streaming.sdk.runners.flink.operators;

import java.time.Duration;
import java.time.Instant;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.apache.flink.api.common.ExecutionConfig;
import org.apache.flink.api.common.state.ListState;
import org.apache.flink.api.common.state.ListStateDescriptor;
import org.apache.flink.api.common.typeutils.TypeSerializer;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.typeutils.TypeExtractor;
import org.apache.flink.runtime.state.StateInitializationContext;
import org.apache.flink.runtime.state.StateSnapshotContext;
import org.apache.flink.streaming.api.operators.AbstractUdfStreamOperator;
import org.apache.flink.streaming.api.operators.ChainingStrategy;
import org.apache.flink.streaming.api.operators.OneInputStreamOperator;
import org.apache.flink.streaming.api.operators.TimestampedCollector;
import org.apache.flink.streaming.api.operators.TwoInputStreamOperator;
import org.apache.flink.streaming.api.watermark.Watermark;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.apache.flink.types.Either;

import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;
import com.king.event.Event;
import com.king.flink.utils.types.HashMapSerializer;
import com.king.streaming.sdk.context.Aggregators;
import com.king.streaming.sdk.context.Context;
import com.king.streaming.sdk.context.JoinContext;
import com.king.streaming.sdk.context.MapState;
import com.king.streaming.sdk.context.State;
import com.king.streaming.sdk.context.Timers;
import com.king.streaming.sdk.eventstream.BroadcastState;
import com.king.streaming.sdk.functions.EventProcessor;
import com.king.streaming.sdk.io.DefaultEventFormat;
import com.king.streaming.sdk.runners.flink.FlinkEventProcessor;
import com.king.streaming.sdk.runners.flink.types.AggregateEvent;

public class ContextEventProcessor
		extends AbstractUdfStreamOperator<Either<Event, AggregateEvent>, FlinkEventProcessor<?>>
		implements OneInputStreamOperator<Event, Either<Event, AggregateEvent>>,
		TwoInputStreamOperator<Event, Tuple2<Short, Event>, Either<Event, AggregateEvent>> {

	private static final long serialVersionUID = 1L;

	protected transient TimestampedCollector<Either<Event, AggregateEvent>> collector;
	protected transient FlinkContext processorContext;

	private transient HashMap<Object, Object> broadcastState;

	private final BiMap<BroadcastState<?>, Short> bcStateMapping;
	protected long currentTimestamp;
	protected Event currentEvent = null;

	private transient BroadcastStateContext broadcastContext;
	private final TypeSerializer<HashMap<Object, Object>> broadcastStateSerializer = new HashMapSerializer<>(
			TypeExtractor.getForClass(Object.class).createSerializer(new ExecutionConfig()),
			TypeExtractor.getForClass(Object.class).createSerializer(new ExecutionConfig()));

	private transient ListState<HashMap<Object, Object>> bcListState;

	private long currentWatermark = Long.MIN_VALUE;

	public ContextEventProcessor(FlinkEventProcessor<?> processor, Map<BroadcastState<?>, Short> bcStateMapping) {
		super(processor);
		this.bcStateMapping = bcStateMapping != null ? HashBiMap.create(bcStateMapping) : HashBiMap.create();
		chainingStrategy = ChainingStrategy.ALWAYS;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void processElement(StreamRecord<Event> in) throws Exception {
		try {
			currentTimestamp = Math.max(0, in.getValue().getTimeStamp());
			collector.setAbsoluteTimestamp(currentTimestamp);
			currentEvent = in.getValue();
			((EventProcessor<Context>) userFunction).processEvent(currentEvent, processorContext);
			currentEvent = null;
		} catch (Exception e) {
			throw new RuntimeException(
					"Error while processing event: "
							+ DefaultEventFormat.eventFormat.format(in.getValue()),
					e);
		}
	}

	@Override
	public void open() throws Exception {
		super.open();
		userFunction.open();

		collector = new TimestampedCollector<Either<Event, AggregateEvent>>(output);
		processorContext = createContext();
		broadcastContext = new BroadcastStateContext();
		broadcastState = restoreBCState(bcListState).orElse(new HashMap<>());
	}

	protected <T> Optional<T> restoreBCState(ListState<T> state) throws Exception {
		Iterator<T> stateIt = state.get().iterator();
		if (stateIt != null && stateIt.hasNext()) {
			return Optional.of(stateIt.next());
		} else {
			return Optional.empty();
		}
	}

	protected <T> void updateBCState(ListState<T> state, T val) throws Exception {
		state.clear();
		if (getRuntimeContext().getIndexOfThisSubtask() == 0) {
			state.add(val);
		}
	}

	@Override
	public void initializeState(StateInitializationContext context) throws Exception {
		super.initializeState(context);
		bcListState = context.getOperatorStateStore().getUnionListState(new ListStateDescriptor<>("bcstate", broadcastStateSerializer));
	}

	@Override
	public void snapshotState(StateSnapshotContext context) throws Exception {
		updateBCState(bcListState, broadcastState);
		super.snapshotState(context);
	}

	protected class FlinkContext implements Context {

		@Override
		public Aggregators getAggregators() {
			return new CollectingAggregators(collector);
		}

		@Override
		public long getCurrentWatermark() {
			return currentWatermark;
		}

		@Override
		public <T> Optional<T> getBroadcastState(BroadcastState<T> bcState) throws Exception {
			return bcState.field.getValue(broadcastContext);
		}

		@Override
		public void output(Event event) {
			collector.setAbsoluteTimestamp(event.getTimeStamp());
			collector.collect(Either.Left(event));
			collector.setAbsoluteTimestamp(currentTimestamp);
		}

		@Override
		public Event getCurrentEvent() throws NoSuchElementException {
			if (currentEvent != null) {
				return currentEvent;
			} else {
				throw new NoSuchElementException();
			}
		}

	}

	@Override
	public void processElement1(StreamRecord<Event> element) throws Exception {
		processElement(element);
	}

	@Override
	public void processElement2(StreamRecord<Tuple2<Short, Event>> element) throws Exception {
		Tuple2<Short, Event> t = element.getValue();
		@SuppressWarnings("unchecked")
		BroadcastState<Object> bcs = (BroadcastState<Object>) bcStateMapping.inverse().get(t.f0);
		bcs.field.check(t.f1, broadcastContext);
	}

	protected class BroadcastStateContext extends FlinkContext implements JoinContext {

		@Override
		public Timers getTimers() {
			throw new UnsupportedOperationException("Timers are not implemented for BC states currently");
		}

		@Override
		public Object getPartitionKey() {
			return null;
		}

		@Override
		public <T> State<T> getValueState(String name, Class<T> clazz) {
			return new State<T>() {

				@SuppressWarnings("unchecked")
				@Override
				public Optional<T> value() {
					return (Optional<T>) Optional.ofNullable(broadcastState.get(name));
				}

				@Override
				public void update(T value) {
					broadcastState.put(name, value);
				}

				@Override
				public void clear() {
					broadcastState.remove(name);
				}

				@Override
				public State<T> clearAfter(Duration ttl) {
					throw new UnsupportedOperationException("Not implemented");
				}
			};
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		@Override
		public <K, V> MapState<K, V> getMapState(String name, Class<K> keyType, Class<V> valueType) {
			return new MapState<>((State<HashMap<K, V>>) (State) getValueState(name, HashMap.class));
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void processWatermark(Watermark mark) throws Exception {
		this.currentWatermark = mark.getTimestamp();
		super.processWatermark(mark);
		((EventProcessor) userFunction).onWatermark(Instant.ofEpochMilli(mark.getTimestamp()), processorContext);
	}

	public long getCurrentTimestamp() {
		return currentTimestamp;
	}

	public TimestampedCollector<Either<Event, AggregateEvent>> getCollector() {
		return collector;
	}

	protected FlinkContext createContext() {
		return new FlinkContext();
	}

}
