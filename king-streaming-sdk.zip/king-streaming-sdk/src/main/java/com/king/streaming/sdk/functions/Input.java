package com.king.streaming.sdk.functions;

import java.util.Optional;

import com.king.event.Event;
import com.king.flink.utils.types.SemanticClassUtils.SerializableSC;
import com.king.utils.ClosureCleaner;

/**
 * Utility methods for handling the input of the Field updaters.
 *
 */
public final class Input {

	/**
	 * Creates an InputTransformer that filters and transforms events using the
	 * given semantic class.
	 */
	public static <SC> InputTransformer<SC> fromSemanticClass(Class<SC> semanticClass) throws Exception {
		return new SCTransformer<>(semanticClass);
	}

	/**
	 * Filters the events that will be passed to the field updater using the
	 * given FilterCondition. This should be used when the field value will be
	 * updated for only specific events.
	 */
	public static InputTransformer<Event> filter(EventFilter filter) {
		return new FilteringTransformer(filter);
	}

	/**
	 * Feeds all events to the field updater. Should only be used when the field
	 * needs to be updated on all input events.
	 */
	public static InputTransformer<Event> allEvents() {
		return new DummyTransformer();
	}

	private static final class DummyTransformer implements InputTransformer<Event> {
		private static final long serialVersionUID = 1L;

		@Override
		public Optional<Event> transform(Event input) {
			return Optional.of(input);
		}
	}

	private static final class FilteringTransformer implements InputTransformer<Event> {
		private static final long serialVersionUID = 1L;
		private final EventFilter filter;

		public FilteringTransformer(EventFilter filter) {
			ClosureCleaner.clean(filter, true);
			this.filter = filter;
		}

		@Override
		public Optional<Event> transform(Event input) throws Exception {
			return filter.filter(input) ? Optional.of(input) : Optional.empty();
		}
	}

	public static final class SCTransformer<SC, T> implements InputTransformer<SC> {

		private static final long serialVersionUID = 1L;
		private SerializableSC semClassInstance;

		public SCTransformer(Class<SC> semanticClass) throws Exception {
			semClassInstance = new SerializableSC(semanticClass);
		}

		@SuppressWarnings("unchecked")
		@Override
		public Optional<SC> transform(Event event) throws Exception {
			try {
				return Optional.ofNullable((SC) semClassInstance.process(event));
			} catch (Throwable e) {
				throw new RuntimeException(e);
			}
		}
	}
}
