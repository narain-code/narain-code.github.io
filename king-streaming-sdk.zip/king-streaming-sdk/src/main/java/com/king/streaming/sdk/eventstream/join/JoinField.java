package com.king.streaming.sdk.eventstream.join;

import java.io.Serializable;
import java.time.Duration;
import java.util.Optional;

import com.king.event.Event;
import com.king.streaming.sdk.context.JoinContext;
import com.king.streaming.sdk.context.KeyContext;
import com.king.streaming.sdk.context.State;
import com.king.streaming.sdk.eventstream.BroadcastState;
import com.king.streaming.sdk.eventstream.KeyedEventStream;
import com.king.streaming.sdk.eventstream.join.abtest.ABTestAssignments;

/**
 * The {@link JoinField} represents a conditional value that is computed per key
 * on a {@link KeyedEventStream} or across all events when used as a
 * {@link BroadcastState}. The {@link JoinField} is aware of the computations
 * performed and the behaviour might depend on this: see the difference between
 * {@link Current} and {@link Last} for instance.
 * 
 * It is is used to implement different functionality:
 * <ul type="1">
 * <li>Access past elements of the stream ({@link Last}, {@link First},
 * {@link All}, etc.})</li>
 * <li>Build up state ({@link ABTestAssignments}, {@link Aggregate})</li>
 * <li>Define patterns on the stream ({@link Match})</li>
 * </ul>
 * 
 * @see {@link JoinField}
 * @see {@link Last}
 * @see {@link First}
 * @see {@link All}
 * @see {@link Match}
 * @see {@link Aggregate}
 * @see {@link KeyedEventStream#join(JoinField...)}
 * @see {@link KeyedEventStream#match(JoinField, com.king.streaming.sdk.functions.MatchProcessor)}
 * 
 * @param <JoinedType>
 *            The type of the field
 */
public abstract class JoinField<JoinedType> implements Serializable {

	private static final long serialVersionUID = 1L;
	protected Duration ttl;
	protected boolean broadcasted = false;

	public abstract boolean check(Event e, JoinContext ctx) throws Exception;

	public abstract Optional<JoinedType> getValue(JoinContext ctx) throws Exception;

	public void postProcess(Event e, JoinContext ctx) throws Exception {}

	public abstract void deleteCompletely(KeyContext ctx);

	public JoinField<JoinedType> clearAfter(Duration ttl) {
		this.ttl = ttl;
		return this;
	}

	public JoinField<JoinedType> broadcasted() {
		this.broadcasted = true;
		return this;
	}

	public JoinField<JoinedType> copy() {
		return this;
	}

	public boolean allowsMissing() {
		return false;
	}

	public abstract String getUUID();

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((getUUID() == null) ? 0 : getUUID().hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof JoinField)) {
			return false;
		}
		JoinField<?> other = (JoinField<?>) obj;
		if (getUUID() == null) {
			if (other.getUUID() != null) {
				return false;
			}
		} else if (!getUUID().equals(other.getUUID())) {
			return false;
		}
		return true;
	}

	public <S> State<S> getTTLState(KeyContext ctx, String name, Class<S> clazz) {
		State<S> s = ctx.getValueState(name, clazz);
		if (ttl != null) {
			return s.clearAfter(ttl);
		} else {
			return s;
		}
	}
}
