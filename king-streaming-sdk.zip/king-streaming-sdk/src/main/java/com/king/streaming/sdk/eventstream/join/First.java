package com.king.streaming.sdk.eventstream.join;

import java.util.Optional;

import com.king.event.Event;
import com.king.streaming.sdk.context.JoinContext;
import com.king.streaming.sdk.context.KeyContext;
import com.king.streaming.sdk.context.State;
import com.king.streaming.sdk.functions.EventFilter;
import com.king.streaming.sdk.functions.Input;
import com.king.streaming.sdk.functions.InputTransformer;

public class First<T> extends JoinField<T> {

	private static final long serialVersionUID = 1L;
	public final InputTransformer<T> inputTransformer;
	private final Class<T> clazz;
	private final String uid;

	protected First(InputTransformer<T> inputTransformer, Class<T> clazz, String uid) {
		this.inputTransformer = inputTransformer;
		this.clazz = clazz;
		this.uid = uid;
	}

	public static <SC> First<SC> semanticClass(Class<SC> semClazz) {
		try {
			return new First<SC>(Input.fromSemanticClass(semClazz), semClazz, "f" + semClazz.getSimpleName());
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static First<Event> event() {
		return new First<Event>(e -> Optional.of(e), Event.class, "f");
	}

	public static First<Event> eventType(long typeId) {
		return new First<Event>(Input.filter(e -> e.getEventType() == typeId), Event.class, "fe" + typeId);
	}

	public static First<Event> fromFilter(EventFilter filter) {
		return new First<Event>(Input.filter(filter), Event.class, "f" + filter.hashCode());
	}

	@Override
	public boolean check(Event e, JoinContext ctx) throws Exception {
		State<T> state = getTTLState(ctx, getUUID(), clazz);

		if (state.value().isPresent()) {
			return true;
		} else {
			return inputTransformer
					.transform(e)
					.map(last -> {
						state.update(last);
						return true;
					}).orElse(false);
		}
	}

	@Override
	public Optional<T> getValue(JoinContext ctx) {
		return (Optional<T>) getTTLState(ctx, getUUID(), clazz).value();
	}

	@Override
	public void deleteCompletely(KeyContext ctx) {
		getTTLState(ctx, getUUID(), clazz).clear();
	}

	@Override
	public String getUUID() {
		return uid;
	}
}
