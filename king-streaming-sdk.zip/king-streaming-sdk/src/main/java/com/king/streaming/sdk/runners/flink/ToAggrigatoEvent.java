package com.king.streaming.sdk.runners.flink;

import org.apache.flink.api.common.functions.MapFunction;

import com.king.constants.EventType;
import com.king.constants.Flavour;
import com.king.constants.KingApp;
import com.king.constants.SignInSource;
import com.king.event.Event;
import com.king.event.EventBuilder;
import com.king.streaming.sdk.runners.flink.types.AggregateEvent;

public final class ToAggrigatoEvent implements MapFunction<AggregateEvent, Event> {
	private static final long serialVersionUID = 1L;
	private final int RBEA_FLAVOUR = Flavour.createFlavour(KingApp.RBEA, SignInSource.BACK_END);

	@Override
	public Event map(AggregateEvent agg) throws Exception {
		return new EventBuilder(RBEA_FLAVOUR)
				.buildEvent(
						EventType.AggrigatoLong(
								agg.getTimeStamp() - agg.getWindowSize(),
								agg.getWindowSize(),
								agg.getName(),
								agg.getDimensions(),
								agg.getValue()),
						0);
	}
}