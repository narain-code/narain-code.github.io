package com.king.streaming.sdk.eventstream;

import java.time.Duration;
import java.util.Optional;

import com.king.streaming.sdk.context.Context;
import com.king.streaming.sdk.context.JoinContext;
import com.king.streaming.sdk.context.KeyContext;
import com.king.streaming.sdk.eventstream.join.Aggregate;
import com.king.streaming.sdk.eventstream.join.All;
import com.king.streaming.sdk.eventstream.join.First;
import com.king.streaming.sdk.eventstream.join.JoinField;
import com.king.streaming.sdk.eventstream.join.Last;
import com.king.streaming.sdk.eventstream.join.Match;
import com.king.streaming.sdk.functions.EventFilter;
import com.king.streaming.sdk.functions.EventProcessor;
import com.king.streaming.sdk.functions.MatchProcessor;
import com.king.streaming.sdk.utils.StreamUtils;

/**
 * An {@link EventStream} that is logically partitioned by a key, allowing
 * access to key-based functionality such as key-states, joins and pattern
 * matching on the stream.
 *
 * @param <K>
 *            The type of {@link Context} accessible in the
 *            {@link EventProcessor}
 */
public interface KeyedEventStream<K extends KeyContext> extends EventStream<K> {

	/**
	 * Applies a self outer-join on the stream with the given {@link JoinField}
	 * per key. This makes the field value accessible from the
	 * {@link JoinContext}.
	 * 
	 * <p>
	 * For example we can self join with the {@link Last#semanticClass}
	 * (SCGameStart.class) to access the last SCGameStart by calling
	 * {@link JoinContext#getJoined(JoinField)}. The {@link Optional} value can
	 * be empty if we haven't received a game start for the current key.
	 * </p>
	 * 
	 * @see {@link JoinField}
	 * @see {@link Last}
	 * @see {@link First}
	 * @see {@link All}
	 * @see {@link Match}
	 * @see {@link Aggregate}
	 * 
	 * @param joinFields
	 *            Fields the join on, these conditions are handled independently
	 * 
	 * @return The resulting {@link JoinedEventStream}
	 */
	JoinedEventStream<JoinContext> join(JoinField<?>... joinFields);

	/**
	 * Matches the given pattern (by key) on the stream triggering computation
	 * whenever the conditions are satisfied.
	 * <p>
	 * For example we can pair every purchase with the last game start by using:
	 * <br>
	 * <i>Match.continuously(Last.semanticClass(SCGameStart.class),
	 * Current.semanticClass(SCPurchase.class))</i> <br>
	 * Our MatchProcessor in this case will be a function of
	 * <i>(Pair&lt;SCGameStart, SCPurchase&gt;, JoinContext) -> ()<i>
	 * </p>
	 * 
	 * @see {@link JoinField}
	 * @see {@link Last}
	 * @see {@link First}
	 * @see {@link All}
	 * @see {@link Match}
	 * @see {@link Aggregate}
	 * 
	 * @param matchField
	 *            Field/Pattern to match on the stream
	 * @param processor
	 *            Processor function to apply every time we have a match
	 * @return Output stream of elements from the processor
	 */
	<M> ProcessorOutput match(JoinField<M> matchField, MatchProcessor<M> processor);

	ProcessorOutput process(EventProcessor<K> eventProcessor);

	/**
	 * Returns a partially sorted stream based on the event timestamps. Events
	 * with the same key are delivered in event timestamp order to the output
	 * stream. Sorting happens in sort-buffers based on event time windows,
	 * determined by the source watermarks and the specified sort buffer size.
	 * 
	 * @param sortBufferSize
	 *            Time window size for sorting
	 * @return Partially ordered stream
	 */
	KeyedEventStream<K> sort(Duration sortBufferSize);

	KeyedEventStream<K> filter(EventFilter eventFilter);

	default KeyedEventStream<K> filter(long... types) {
		if (types.length == 0) {
			throw new RuntimeException("At least one condition needs to be passed to this method");
		}
		return filter(StreamUtils.filterByEventType(types));
	}

	default KeyedEventStream<K> filter(Class<?>... semClasses) {
		if (semClasses.length == 0) {
			throw new RuntimeException("At least one condition needs to be passed to this method");
		}
		return filter(StreamUtils.filterBySemClass(semClasses));
	}

	<X extends Context> KeyedEventStream<K> withBroadcastState(BroadcastState<?>... states);

}
