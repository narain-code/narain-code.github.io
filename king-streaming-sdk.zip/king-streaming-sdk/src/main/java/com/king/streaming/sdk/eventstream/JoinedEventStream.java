package com.king.streaming.sdk.eventstream;

import com.king.streaming.sdk.context.Context;
import com.king.streaming.sdk.context.JoinContext;
import com.king.streaming.sdk.functions.EventFilter;
import com.king.streaming.sdk.utils.StreamUtils;

public interface JoinedEventStream<C extends JoinContext> extends KeyedEventStream<C> {

	JoinedEventStream<C> filter(EventFilter eventFilter);

	default JoinedEventStream<C> filter(long... types) {
		if (types.length == 0) {
			throw new RuntimeException("At least one condition needs to be passed to this method");
		}
		return filter(StreamUtils.filterByEventType(types));
	}

	default JoinedEventStream<C> filter(Class<?>... semClasses) {
		if (semClasses.length == 0) {
			throw new RuntimeException("At least one condition needs to be passed to this method");
		}
		return filter(StreamUtils.filterBySemClass(semClasses));
	}

	<X extends Context> JoinedEventStream<C> withBroadcastState(BroadcastState<?>... states);
}
