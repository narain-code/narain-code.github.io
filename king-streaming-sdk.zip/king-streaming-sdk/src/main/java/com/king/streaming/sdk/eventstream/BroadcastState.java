package com.king.streaming.sdk.eventstream;

import java.io.Serializable;

import com.king.streaming.sdk.context.Context;
import com.king.streaming.sdk.eventstream.join.JoinField;

/**
 * State that is accumulated from an {@link EventStream} and can be broadcasted
 * globally to all processors.
 * <p>
 * For instance one could broadcast the latest currency rate updates so that it
 * is accessible during processing another stream from the context (
 * {@link Context#getBroadcastState(BroadcastState)}})
 * 
 * @param <T>
 *            Type of the state
 */
public class BroadcastState<T> implements Serializable {

	private static final long serialVersionUID = 1L;

	public final String id;
	public transient EventStream<?> eventStream;
	public final JoinField<T> field;

	protected BroadcastState(EventStream<?> eventStream, JoinField<T> state) {
		this.eventStream = eventStream;
		this.field = state;
		this.id = eventStream.getUUID() + state.getUUID();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof BroadcastState)) {
			return false;
		}
		BroadcastState<?> other = (BroadcastState<?>) obj;
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!id.equals(other.id)) {
			return false;
		}
		return true;
	}
}
