package com.king.streaming.sdk.io.kafka;

public enum StartOffset {
	EARLIEST, CURRENT_FOR_GROUP, LIVE
}