package com.king.streaming.sdk.utils;

import com.king.event.Event;
import com.king.flink.utils.types.SemanticClassUtils.SerializableSC;
import com.king.streaming.sdk.functions.EventFilter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class StreamUtils {
	static final Logger LOG = LoggerFactory.getLogger(StreamUtils.class);

	public static final class SemClassFilter implements EventFilter {
		private static final long serialVersionUID = 1L;
		private SerializableSC[] scs;

		public SemClassFilter(Class<?>... semClasses) {
			scs = new SerializableSC[semClasses.length];
			for (int i = 0; i < semClasses.length; i++) {
				scs[i] = new SerializableSC(semClasses[i]);
			}
		}

		@Override
		public boolean filter(Event event) throws Exception {
			for (SerializableSC sc : scs) {
				if (sc.process(event) != null) {
					return true;
				}
			}
			return false;
		}

		@Override
		public String name() {
			return "SemanticClass filter";
		}
	}

	public static final class AnyFilter implements EventFilter {
		private static final long serialVersionUID = 1L;
		private final EventFilter[] filters;

		AnyFilter(EventFilter[] filters) {
			this.filters = filters;
		}

		@Override
		public boolean filter(Event e) throws Exception {
			for (EventFilter filter : filters) {
				if (filter.filter(e)) {
					return true;
				}
			}
			return false;
		}

		@Override
		public String name() {
			return "Any filter";
		}
	}

	public static EventFilter filterByEventType(long... types) {
		return new EventFilter() {
			private static final long serialVersionUID = 1L;

			@Override
			public boolean filter(Event event) throws Exception {
				long et = event.getEventType();
				for (long t : types) {
					if (et == t) {
						return true;
					}
				}
				return false;
			}

			@Override
			public String name() {
				return "EventType filter";
			}

		};
	}

	public static EventFilter filterBySemClass(Class<?>... semClasses) {
		return new SemClassFilter(semClasses);
	}

	public static EventFilter anyOf(EventFilter... filters) {
		return new AnyFilter(filters);
	}
}
