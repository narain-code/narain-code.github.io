package com.king.streaming.sdk.eventstream.join;

import java.util.Optional;

import com.king.event.Event;
import com.king.streaming.sdk.context.JoinContext;
import com.king.streaming.sdk.context.KeyContext;

public class AllowMissing {

	/**
	 * Transforms a {@link JoinField} so that it allows null values being
	 * returned when {@link JoinContext#getMatched(JoinField)} is called. Mostly
	 * used to implement some internal functionality.
	 * 
	 * @param field
	 *            Field to be transformed
	 * @return The transformed field
	 */
	public static <T> JoinField<T> forField(JoinField<T> field) {
		return new JoinField<T>() {
			private static final long serialVersionUID = 1L;
			JoinField<T> wrapped = field;

			@Override
			public boolean check(Event e, JoinContext ctx) throws Exception {
				return wrapped.check(e, ctx);
			}

			@Override
			public Optional<T> getValue(JoinContext ctx) throws Exception {
				return wrapped.getValue(ctx);
			}

			public void deleteCompletely(KeyContext ctx) {
				wrapped.deleteCompletely(ctx);
			}

			@Override
			public String getUUID() {
				return wrapped.getUUID();
			}

			@Override
			public boolean allowsMissing() {
				return true;
			}

			@Override
			public void postProcess(Event e, JoinContext ctx) throws Exception {
				wrapped.postProcess(e, ctx);
			}
		};
	}

}
