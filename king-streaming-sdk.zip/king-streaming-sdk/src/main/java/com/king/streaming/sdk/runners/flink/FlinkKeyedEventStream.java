package com.king.streaming.sdk.runners.flink;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;

import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.KeyedStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.functions.windowing.WindowFunction;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.types.Either;
import org.apache.flink.util.Collector;

import com.google.common.collect.Lists;
import com.king.event.Event;
import com.king.flink.utils.types.EventTypeInfo;
import com.king.streaming.sdk.context.Context;
import com.king.streaming.sdk.context.JoinContext;
import com.king.streaming.sdk.context.KeyContext;
import com.king.streaming.sdk.eventstream.BroadcastState;
import com.king.streaming.sdk.eventstream.JoinedEventStream;
import com.king.streaming.sdk.eventstream.KeyedEventStream;
import com.king.streaming.sdk.eventstream.ProcessorOutput;
import com.king.streaming.sdk.eventstream.join.AllowMissing;
import com.king.streaming.sdk.eventstream.join.JoinField;
import com.king.streaming.sdk.functions.EventFilter;
import com.king.streaming.sdk.functions.EventProcessor;
import com.king.streaming.sdk.functions.Key;
import com.king.streaming.sdk.functions.MatchProcessor;
import com.king.streaming.sdk.runners.flink.operators.KeyContextEventProcessor;
import com.king.streaming.sdk.runners.flink.operators.OutputToLeft;
import com.king.streaming.sdk.runners.flink.types.AggregateEvent;

public class FlinkKeyedEventStream<C extends KeyContext> extends FlinkEventStream<C> implements KeyedEventStream<C> {

	protected final KeyedStream<Event, Object> keyedStream;
	protected final Key key;

	protected FlinkKeyedEventStream(FlinkRunner runner, KeyedStream<Event, ?> keyedStream, Key key) {
		this(runner, keyedStream, key, new ArrayList<>());
	}

	protected FlinkKeyedEventStream(FlinkRunner runner, KeyedStream<Event, ?> keyedStream, Key key,
			Collection<BroadcastState<?>> broadcastStates) {
		super(runner, keyedStream, broadcastStates);
		this.keyedStream = (KeyedStream<Event, Object>) keyedStream;
		this.key = key;
	}

	@Override
	public FlinkProcessorOutput process(EventProcessor<C> eventProcessor) {
		Map<BroadcastState<?>, Short> bcsMapping = getStateMapping();
		KeyContextEventProcessor procesor = new KeyContextEventProcessor(
				new FlinkEventProcessor<>(runner.clean(eventProcessor)), bcsMapping);

		Tuple2<SingleOutputStreamOperator<Either<Event, AggregateEvent>>, SingleOutputStreamOperator<AggregateEvent>> out = applyProcess(
				procesor, bcsMapping);

		SingleOutputStreamOperator<Either<Event, AggregateEvent>> outStream = out.f0.name(eventProcessor.name());

		return new FlinkProcessorOutput(runner,
				outStream
						.flatMap(new OutputToLeft())
						.name("Select Events"),
				out.f1);
	}

	@Override
	public FlinkKeyedEventStream<C> sort(Duration sortBufferSize) {
		DataStream<Event> sorted = keyedStream.timeWindow(Time.milliseconds(sortBufferSize.toMillis()))
				.apply(new WindowFunction<Event, Event, Object, TimeWindow>() {
					private static final long serialVersionUID = 1L;

					@Override
					public void apply(Object key, TimeWindow window, Iterable<Event> events, Collector<Event> out)
							throws Exception {
						ArrayList<Event> eventList = Lists.newArrayList(events);
						Collections.sort(eventList, (e1, e2) -> Long.compare(e1.getTimeStamp(), e2.getTimeStamp()));
						eventList.forEach(out::collect);
					}
				}, new EventTypeInfo());

		return new FlinkKeyedEventStream<>(getRunner(), sorted.keyBy(new FlinkKeyWrapper(key)), key);
	}

	@SuppressWarnings("unchecked")
	@Override
	public FlinkKeyedEventStream<C> filter(EventFilter eventFilter) {
		return (FlinkKeyedEventStream<C>) super.filter(eventFilter).keyBy(key);
	}

	@Override
	public <X extends Context> KeyedEventStream<C> withBroadcastState(BroadcastState<?>... states) {
		if (states.length == 0) {
			throw new RuntimeException("At least one broadcast state needs to be passed to this method");
		}
		Collection<BroadcastState<?>> newStates = new ArrayList<>(broadcastStates);
		for (BroadcastState<?> state : states) {
			newStates.add(state);
		}

		return new FlinkKeyedEventStream<>(runner, keyedStream, key, newStates);
	}

	@Override
	public JoinedEventStream<JoinContext> join(JoinField<?>... joinFields) {
		JoinField<?>[] arr = new JoinField[joinFields.length];
		for (int i = 0; i < joinFields.length; i++) {
			arr[i] = AllowMissing.forField(joinFields[i]);
		}
		return matchPrivate(arr);
	}

	@Override
	public <M> ProcessorOutput match(JoinField<M> m, MatchProcessor<M> processor) {
		return matchPrivate(m).process((event, ctx) -> processor.process(ctx.getMatched(m), ctx));
	}

	protected JoinedEventStream<JoinContext> matchPrivate(JoinField<?>... joinFields) {
		if (joinFields.length == 0) {
			throw new RuntimeException("At least one join field needs to be passed to this method");
		}
		return new FlinkJoinedStream<>(runner, keyedStream, key, joinFields);
	}
}
