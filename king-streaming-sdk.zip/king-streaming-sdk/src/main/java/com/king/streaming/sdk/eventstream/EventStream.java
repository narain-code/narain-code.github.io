package com.king.streaming.sdk.eventstream;

import java.util.UUID;

import com.king.event.Event;
import com.king.event.format.util.CoreUserIdFetcher;
import com.king.streaming.sdk.context.Context;
import com.king.streaming.sdk.context.GlobalContext;
import com.king.streaming.sdk.context.KeyContext;
import com.king.streaming.sdk.eventstream.join.JoinField;
import com.king.streaming.sdk.functions.EventFilter;
import com.king.streaming.sdk.functions.EventProcessor;
import com.king.streaming.sdk.functions.Key;
import com.king.streaming.sdk.io.kafka.KafkaOutput;
import com.king.streaming.sdk.utils.StreamUtils;

/**
 * The {@link EventStream} is the core abstraction of the streaming SDK. It
 * represents a parallel stream of {@link Event}s that can processed (to create
 * aggregates and other {@link EventStream}s) or written to one of the supported
 * output formats.
 *
 * @param <C>
 *            The type of {@link Context} accessible in the
 *            {@link EventProcessor}
 */
public interface EventStream<C extends Context> {

	/**
	 * Returns unique ID of the stream
	 *
	 * @return UUID of the stream
	 */
	UUID getUUID();

	/**
	 * Applies the given {@link EventProcessor} on the stream of elements. The
	 * type of {@link Context} accessible from the processor depends on the type
	 * of the {@link EventProcessor}.
	 *
	 * <p>
	 * The processing runs in parallel on the cluster so it should not be
	 * assumed that only a single instance of the event processor exists at any
	 * given time.
	 * </p>
	 *
	 * @param eventProcessor
	 *            Processor function to applied on the events
	 * @return Output stream of the processor
	 */
	ProcessorOutput process(EventProcessor<C> eventProcessor);

	/**
	 * Applies a global processing step, allowing users to keep global state.
	 * This is a non-parallel transformation so should be avoided on large input
	 * streams whenever possible.
	 *
	 * @param eventProcessor
	 *            Processor function to applied on the events
	 * @return Output stream of the processor
	 */
	ProcessorOutput processGlobal(EventProcessor<GlobalContext> eventProcessor);

	/**
	 * Creates a {@link KeyedEventStream} by defining a key for each event in
	 * the input stream. This is required to apply per-key processing logic such
	 * as self-joins or other stateful operations.
	 *
	 * @param key
	 *            Key extractor function
	 * @return The resulting {@link KeyedEventStream}
	 */
	KeyedEventStream<KeyContext> keyBy(Key key);

	/**
	 * Creates a {@link KeyedEventStream} with core user id as a key. All events
	 * must have a core user id otherwise the program will fail.
	 *
	 * @return The resulting {@link KeyedEventStream}
	 */
	default KeyedEventStream<KeyContext> keyByCoreUserID() {
		return keyBy(event -> CoreUserIdFetcher.getCoreUserId(event).get());
	}

	/**
	 * Unions the current stream with event from another {@link EventStream}s.
	 * The resulting stream will contain events from all the unioned streams
	 * without any guarantee of ordering.
	 *
	 * @param eventStreams
	 *            Streams to be unioned
	 * @return The unioned stream
	 */
	EventStream<Context> union(EventStream<?>... eventStreams);

	/**
	 * Writes the events in this stream to the give Kafka topic
	 *
	 * @param topic
	 * @return {@link KafkaOutput} object which can be used to configure the
	 *         output params
	 */
	KafkaOutput writeToKafka(String topic);

	/**
	 * Creates a {@link BroadcastState} from the current stream using the given
	 * {@link JoinField}. The current value of the field will be broadcasted in
	 * this case.
	 *
	 * @param field
	 *            Field to be broadcasted
	 * @return The resulting {@link BroadcastState}
	 */
	default <T> BroadcastState<T> broadcast(JoinField<T> field) {
		return new BroadcastState<>(this, field.copy().broadcasted());
	}

	/**
	 * Creates a new stream by keeping the elements that satisfy the given
	 * condition.
	 *
	 * @param eventFilter
	 *            Filter condition to be applied
	 * @return The filtered stream
	 */
	EventStream<C> filter(EventFilter eventFilter);

	/**
	 * Creates a new stream by only keeping the elements that have the specified
	 * event types.
	 *
	 * @param types
	 *            Types to filter
	 * @return The filtered stream
	 */
	default EventStream<C> filter(long... types) {
		if (types.length == 0) {
			throw new RuntimeException("At least one condition needs to be passed to this method");
		}
		return filter(StreamUtils.filterByEventType(types));
	}

	/**
	 * Creates a new stream by only keeping the elements that belong to the
	 * specified semantic classes.
	 *
	 * @param semClasses
	 *            Semantic classes to filter
	 * @return The filtered stream
	 */
	default EventStream<C> filter(Class<?>... semClasses) {
		if (semClasses.length == 0) {
			throw new RuntimeException("At least one condition needs to be passed to this method");
		}
		return filter(StreamUtils.filterBySemClass(semClasses));
	}

	/**
	 * Writes the events in the stream to the standard output
	 */
	void print();

	/**
	 * Collects the events in the stream into a {@link ResultIterator} only
	 * works on local runs (testing) and is not supported for cluster
	 * deployments.
	 *
	 * @return The {@link ResultIterator} with the events
	 * @see TestRunner
	 */
	ResultIterator collect();

	/**
	 * Broadcasts the specified states to all instances of the
	 * {@link EventProcessor}s during processing. This states will be accessible
	 * from the {@link Context}.
	 *
	 * @param states
	 *            Fields to broadcast
	 * @return The event stream with states broadcasted
	 */
	<X extends Context> EventStream<C> withBroadcastState(BroadcastState<?>... states);
}
