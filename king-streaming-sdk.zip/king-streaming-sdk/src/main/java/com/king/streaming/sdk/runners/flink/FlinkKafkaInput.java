package com.king.streaming.sdk.runners.flink;

import java.io.IOException;
import java.time.Duration;
import java.util.List;
import java.util.Properties;
import java.util.UUID;

import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.functions.AssignerWithPeriodicWatermarks;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer010;
import org.apache.flink.streaming.util.serialization.KeyedDeserializationSchema;

import com.king.event.Event;
import com.king.flink.utils.source.Kafka;
import com.king.flink.utils.types.EventTypeInfo;
import com.king.streaming.sdk.application.Environment;
import com.king.streaming.sdk.context.Context;
import com.king.streaming.sdk.context.GlobalContext;
import com.king.streaming.sdk.context.KeyContext;
import com.king.streaming.sdk.eventstream.BroadcastState;
import com.king.streaming.sdk.eventstream.EventStream;
import com.king.streaming.sdk.eventstream.KeyedEventStream;
import com.king.streaming.sdk.eventstream.ProcessorOutput;
import com.king.streaming.sdk.eventstream.ResultIterator;
import com.king.streaming.sdk.functions.EventFilter;
import com.king.streaming.sdk.functions.EventProcessor;
import com.king.streaming.sdk.functions.Key;
import com.king.streaming.sdk.io.DefaultEventFormat;
import com.king.streaming.sdk.io.InputFormat;
import com.king.streaming.sdk.io.kafka.KafkaInput;
import com.king.streaming.sdk.io.kafka.KafkaOutput;
import com.king.streaming.sdk.io.kafka.StartOffset;

public class FlinkKafkaInput implements KafkaInput, DataStreamWrapper {

	private UUID id = UUID.randomUUID();
	private FlinkEventStream<Context> sourceStream = null;

	private String broker;
	private String zkHosts;

	private InputFormat inputFormat = DEFAULT_EVENT_FORMAT;
	private StartOffset startOffset = DEFAULT_START_OFFSET;

	private final List<String> topics;
	private final String groupId;
	private final FlinkRunner runner;
	private boolean partitionWMs = true;
	private Duration watermarkSlack = KafkaInput.DEFAULT_WATERMARK_SLACK;
	private boolean exludeWM = false;

	private SingleOutputStreamOperator<Event> rawInputStream = null;
	private FlinkEventStream<Context> parseErrorStream = null;
	private int parallelism;
	private String uid;
	private String uidhash;

	public FlinkKafkaInput(List<String> topics, String groupId, FlinkRunner runner) {
		this.topics = topics;
		this.groupId = groupId;
		this.runner = runner;
		Environment env = runner.getEnvironment();
		this.broker = env.kafkaBrokers;
		this.zkHosts = env.zkConnectionString;
	}

	@Override
	public KafkaInput withInputFormat(InputFormat format) {
		checkNotCreated();
		this.inputFormat = format;
		return this;
	}

	@Override
	public KafkaInput withBroker(String broker) {
		checkNotCreated();
		this.broker = broker;
		return this;
	}

	@Override
	public KafkaInput withZK(String zkHosts) {
		checkNotCreated();
		this.zkHosts = zkHosts;
		return this;
	}

	@Override
	public KafkaInput startingAt(StartOffset startOffset) {
		checkNotCreated();
		this.startOffset = startOffset;
		return this;
	}

	private void checkNotCreated() {
		if (sourceStream != null) {
			throw new RuntimeException("Cannot modify source properties after applying transformations.");
		}
	}

	private EventStream<Context> getEventStream() {
		if (sourceStream != null) {
			return sourceStream;
		}

		Properties properties = Kafka.getKafkaProps(broker, zkHosts, groupId);
		FlinkKafkaConsumer010<Event> source = new FlinkKafkaConsumer010<Event>(topics,
				new InputFormatDeserializationSchema(inputFormat),
				properties);

		switch (startOffset) {
		case CURRENT_FOR_GROUP:
			source.setStartFromGroupOffsets();
			break;
		case EARLIEST:
			source.setStartFromEarliest();
			break;
		case LIVE:
			source.setStartFromLatest();
			break;
		default:
			break;
		}

		AssignerWithPeriodicWatermarks<Event> wmassigner = exludeWM ? new MaxWatermark<>()
				: runner.getWatermarkAssigner(Time.milliseconds(watermarkSlack.toMillis()));

		if (!exludeWM && partitionWMs) {
			source.assignTimestampsAndWatermarks(wmassigner);
		}

		FlinkOptions options = runner.getOptions();
		int parallelism = options.sourceParallelism != null ? options.sourceParallelism
				: runner.getFlinkEnvironment().getParallelism();

		SingleOutputStreamOperator<Event> input = runner.getFlinkEnvironment().addSource(source)
				.name("Kafka[" + topics + "]")
				.setParallelism(parallelism);

		DataStream<Event> es = input.filter(e -> e.getEventType() != DefaultEventFormat.PARSE_ERROR)
				.name("Drop parse errors")
				.setParallelism(parallelism);

		if (uidhash != null) {
			input.setUidHash(uidhash);
		} else if (uid != null) {
			input.uid(uid);
		}

		if (exludeWM || !partitionWMs) {
			es = es.assignTimestampsAndWatermarks(wmassigner).name("Watermark Assigner");
		}

		this.rawInputStream = input;
		this.sourceStream = new FlinkEventStream<>(runner, es);
		this.parallelism = parallelism;

		return sourceStream;
	}

	@Override
	public UUID getUUID() {
		return id;
	}

	@Override
	public ProcessorOutput process(EventProcessor<Context> eventProcessor) {
		return getEventStream().process(eventProcessor);
	}

	@Override
	public ProcessorOutput processGlobal(EventProcessor<GlobalContext> eventProcessor) {
		return getEventStream().processGlobal(eventProcessor);
	}

	@Override
	public KeyedEventStream<KeyContext> keyBy(Key key) {
		return getEventStream().keyBy(key);
	}

	@Override
	public EventStream<Context> union(EventStream<?>... eventStreams) {
		return getEventStream().union(eventStreams);
	}

	@Override
	public KafkaOutput writeToKafka(String topic) {
		return getEventStream().writeToKafka(topic);
	}

	@Override
	public EventStream<Context> filter(EventFilter eventFilter) {
		return getEventStream().filter(eventFilter);
	}

	@Override
	public void print() {
		getEventStream().print();
	}

	@Override
	public ResultIterator collect() {
		return getEventStream().collect();
	}

	@Override
	public <X extends Context> EventStream<Context> withBroadcastState(BroadcastState<?>... states) {
		return getEventStream().withBroadcastState(states);
	}

	private final static class InputFormatDeserializationSchema implements KeyedDeserializationSchema<Event> {

		private static final long serialVersionUID = 1L;
		private final InputFormat format;

		public InputFormatDeserializationSchema(InputFormat format) {
			this.format = format;
		}

		@Override
		public TypeInformation<Event> getProducedType() {
			return new EventTypeInfo();
		}

		@Override
		public boolean isEndOfStream(Event nextElement) {
			return false;
		}

		@Override
		public Event deserialize(byte[] messageKey, byte[] message, String topic, int partition, long offset)
				throws IOException {
			return format.deserialize(message);
		}

	}

	@Override
	public DataStream<Event> getWrappedStream() {
		return ((DataStreamWrapper) getEventStream()).getWrappedStream();
	}

	@Override
	public FlinkRunner getRunner() {
		return runner;
	}

	@Override
	public KafkaInput disablePerPartitionWatermarks() {
		this.partitionWMs = false;
		return this;
	}

	@Override
	public KafkaInput withWatermarkSlack(Duration slack) {
		this.watermarkSlack = slack;
		return this;
	}

	@Override
	public KafkaInput excludeFromTimeTracking() {
		this.exludeWM = true;
		return this;
	}

	@Override
	public EventStream<Context> getParseErrorStream() {
		getEventStream();
		if (parseErrorStream != null) {
			return parseErrorStream;
		}

		DataStream<Event> errors = rawInputStream.filter(e -> e.getEventType() == DefaultEventFormat.PARSE_ERROR)
				.name("Parse errors")
				.setParallelism(parallelism);

		this.parseErrorStream = new FlinkEventStream<>(runner, errors);
		return parseErrorStream;
	}

	@Override
	public KafkaInput uid(String uid) {
		this.uid = uid;
		if (sourceStream != null) {
			rawInputStream.uid(uid);
		}
		return this;
	}

	@Override
	public KafkaInput setUidHash(String uidhash) {
		this.uidhash = uidhash;
		if (sourceStream != null) {
			rawInputStream.setUidHash(uidhash);
		}
		return this;
	}
}
