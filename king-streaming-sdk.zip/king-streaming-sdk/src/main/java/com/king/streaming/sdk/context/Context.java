package com.king.streaming.sdk.context;

import java.util.NoSuchElementException;
import java.util.Optional;

import com.king.event.Event;
import com.king.streaming.sdk.eventstream.BroadcastState;

/**
 * The Context gives access to the core processor functionality and also exposes
 * information about the event currently being processed.
 **/
public interface Context {

	/**
	 * Returns the Aggregators object that can be used to create global window
	 * aggregates across all processors and keys.
	 */
	Aggregators getAggregators();

	/**
	 * Collects the given event to the output stream
	 */
	void output(Event event);

	/**
	 * Returns the Utils object that contains built-in utility functions such as
	 * the currency converter.
	 */
	default Utils getUtils() {
		return Utils.UtilSingleton.INSTANCE;
	}

	/**
	 * Returns the current value of the specified broadcast state.
	 * 
	 * @param bcState
	 *            Broadcast state to read
	 * @return Current value if exists
	 * @throws Exception
	 */
	<T> Optional<T> getBroadcastState(BroadcastState<T> bcState) throws Exception;

	/**
	 * @return The current watermark of the operator
	 */
	long getCurrentWatermark();

	/**
	 * @return The element being processed
	 * @throws NoSuchElementException
	 *             If the current context does not have any elements associated
	 */
	default Event getCurrentEvent() throws NoSuchElementException {
		throw new NoSuchElementException();
	}
}
