package com.king.streaming.sdk.context.aggregators;

public interface SumAggregator extends DimensionalAggregator<SumAggregator> {

	void add(long num);
}
