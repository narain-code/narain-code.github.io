package com.king.streaming.sdk.runners.flink;

import org.apache.flink.streaming.api.datastream.DataStream;

import com.king.event.Event;

public interface DataStreamWrapper {

	DataStream<Event> getWrappedStream();
	
	FlinkRunner getRunner();
}
