package com.king.streaming.sdk.context;

import com.king.streaming.sdk.context.aggregators.AggregationWindow;
import com.king.streaming.sdk.context.aggregators.Counter;
import com.king.streaming.sdk.context.aggregators.OutputType;
import com.king.streaming.sdk.context.aggregators.SumAggregator;

/**
 * Use the Aggregators to define global windowed aggregates (counters,
 * sum-aggregators) that are computed across all events. The name of each
 * aggregator is used as a unique identifier so different aggregators should
 * have different names inside one script.
 */
public interface Aggregators {

	/**
	 * Creates a windowed counter with a given name.
	 */
	default Counter getCounter(String name, AggregationWindow windowSize) {
		return getCounter(name, windowSize, OutputType.MYSQL);
	}

	/**
	 * Creates a windowed counter with a given name and the given OutputType.
	 */
	Counter getCounter(String name, AggregationWindow windowSize, OutputType outputType);

	/**
	 * Creates a windowed sum aggregator with a given name."
	 */
	default SumAggregator getSumAggregator(String name, AggregationWindow windowSize) {
		return getSumAggregator(name, windowSize, OutputType.MYSQL);
	}

	/**
	 * Creates a windowed sum aggregator with a given name and the given
	 * OutputType.
	 */
	SumAggregator getSumAggregator(String name, AggregationWindow windowSize, OutputType outputType);

}
