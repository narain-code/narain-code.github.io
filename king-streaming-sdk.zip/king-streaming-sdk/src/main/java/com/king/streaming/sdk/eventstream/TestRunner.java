package com.king.streaming.sdk.eventstream;

import com.king.streaming.sdk.context.aggregators.AggregatorOutput;

/**
 * {@link Runner} with extra capabilities for testing the applications. The
 * suggested usage is the following:
 * 
 * <ol type="1">
 * <li>Create one or more {@link ManualEventStream}</li></li>
 * <li>Apply processing logic</li>
 * <li>Use {@link EventStream#collect()} to get a {@link ResultIterator}</li>
 * <li>Start processing using {@link #startTest()}</li>
 * <li>Add events to the {@link ManualEventStream} and assert output in the
 * {@link ResultIterator}</li>
 * <li>Call {@link #stopTest()} on the runner to finsih execution</li>
 * </ol>
 */
public interface TestRunner extends Runner {

	/**
	 * Starts the streaming application in testing mode and returns a view on
	 * the aggregators (instead of writing them to the database), this is a
	 * non-blocking call in contrast with {@link #start()}. MySQL, Kafka and
	 * File outputs are not written in testing mode.
	 * 
	 * @return Real-time view of the aggregators.
	 * @throws Exception
	 */
	default AggregatorOutput startTest() throws Exception {
		return startTest(false);
	}
	
	AggregatorOutput startTest(boolean writeOutputs) throws Exception;

	/**
	 * Creates an event stream that can be fed manually for testing purposes.
	 * 
	 * @return A new {@link ManualEventStream}.
	 * @see TestRunner
	 */
	ManualEventStream createManualStream();

	/**
	 * Calling this method will close all the manual streams and block until the
	 * processing has finished.
	 */
	void stopTest();

	/**
	 * @return True iff {@link #stopTest()} was called
	 */
	boolean wasStopped();
}
