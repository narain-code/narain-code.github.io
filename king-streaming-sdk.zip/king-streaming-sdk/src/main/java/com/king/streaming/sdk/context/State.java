package com.king.streaming.sdk.context;

import java.time.Duration;
import java.util.Optional;

/**
 * Interface for accessing managed state in the streaming programs. The State
 * interface is used by both keyed and global states.
 * 
 * @see KeyContext#getValueState(String, Class, java.time.Duration)
 * @see GlobalContext#getGlobalState(String, Class, java.time.Duration)
 * 
 * @param <T>
 *            Type of the state
 */
public interface State<T> {

	/**
	 * @return The {@link Optional} value of the state for the current key.
	 *         Empty if the state was cleared or not updated with any value yet.
	 */
	Optional<T> value();

	/**
	 * Update the value of the {@link State} for the current key. The next time
	 * {@link #value()} is called for the same key this value will be returned
	 * inside the {@link Optional}.
	 * 
	 * @param value
	 *            The new value of the state
	 */
	void update(T value);

	/**
	 * Deletes the state held for the current key. The next time
	 * {@link #value()} is called it will return an empty {@link Optional}
	 */
	void clear();

	/**
	 * Sets a timeout for the state after which it will be cleared if not
	 * updated.
	 */
	State<T> clearAfter(Duration ttl);
}
