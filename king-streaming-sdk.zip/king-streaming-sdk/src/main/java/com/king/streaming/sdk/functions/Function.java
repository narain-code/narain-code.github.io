package com.king.streaming.sdk.functions;

import java.io.Serializable;

public interface Function extends Serializable {

	default void open() throws Exception {};

	default void close() throws Exception {};

	default String name() {
		return getClass().getSimpleName();
	}
}
