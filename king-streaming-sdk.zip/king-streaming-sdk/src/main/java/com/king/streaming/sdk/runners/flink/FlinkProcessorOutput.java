package com.king.streaming.sdk.runners.flink;

import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;

import com.king.event.Event;
import com.king.streaming.sdk.context.Context;
import com.king.streaming.sdk.context.aggregators.AggregatorOutput;
import com.king.streaming.sdk.eventstream.BroadcastState;
import com.king.streaming.sdk.eventstream.EventStream;
import com.king.streaming.sdk.eventstream.ProcessorOutput;
import com.king.streaming.sdk.runners.flink.types.AggregateEvent;

public class FlinkProcessorOutput extends FlinkEventStream<Context> implements ProcessorOutput {

	private EventStream<Context> aggregateStream = null;
	private DataStream<AggregateEvent> flinkAggStream;
	private SingleOutputStreamOperator<Event> operator;
	private SingleOutputStreamOperator<AggregateEvent> windowOp;
	private String uid;

	protected FlinkProcessorOutput(FlinkRunner runner, SingleOutputStreamOperator<Event> inputStream,
			DataStream<AggregateEvent> flinkAggStream) {
		super(runner, inputStream);
		operator = inputStream;
		this.flinkAggStream = flinkAggStream;
	}

	public SingleOutputStreamOperator<Event> getFlinkOperator() {
		return operator;
	}

	@Override
	public BroadcastState<AggregatorOutput> broadcastAggregatorOutput() {
		// EventStream<Context> aggStream = getAggregateEvents();
		throw new UnsupportedOperationException("Not implemented yet.");
	}

	@Override
	public EventStream<Context> getAggregateEvents() {
		if (aggregateStream != null) {
			return aggregateStream;
		} else {
			windowOp = FlinkRunner.applyWindows(flinkAggStream, uid != null ? uid : getUUID().toString());
			aggregateStream = new FlinkEventStream<Context>(runner, windowOp.map(new ToAggrigatoEvent()));
			return aggregateStream;
		}
	}

	@Override
	public ProcessorOutput setProcessorName(String name) {
		operator.name(name);
		return this;
	}

	@Override
	public ProcessorOutput uid(String uid) {
		if (windowOp != null) {
			throw new RuntimeException("Please apply uid before calling getAggregateEvents");
		}
		this.uid = uid;
		operator.uid(uid);
		return this;
	}

	@Override
	public ProcessorOutput setUidHash(String uid) {
		operator.setUidHash(uid);
		return this;
	}
}
