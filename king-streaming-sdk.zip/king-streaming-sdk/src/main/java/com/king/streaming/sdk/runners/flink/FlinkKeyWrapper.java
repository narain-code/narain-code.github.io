package com.king.streaming.sdk.runners.flink;

import org.apache.flink.api.java.functions.KeySelector;

import com.king.event.Event;
import com.king.streaming.sdk.functions.Key;

public final class FlinkKeyWrapper implements KeySelector<Event, Object> {
	private static final long serialVersionUID = 1L;
	private Key cleanedKey;

	public FlinkKeyWrapper(Key cleanedKey) {
		this.cleanedKey = cleanedKey;

	}

	@Override
	public Object getKey(Event event) throws Exception {
		try {
			return cleanedKey.getKey(event);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
}