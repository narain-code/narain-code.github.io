package com.king.streaming.sdk.context;

/**
 * A {@link Context} with access to key-based functionality such as timers and
 * state
 */
public interface KeyContext extends StatefulContext {

	/**
	 * @return The partition key of the current event
	 */
	Object getPartitionKey();
}
