package com.king.streaming.sdk.eventstream.join;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.king.event.Event;
import com.king.streaming.sdk.context.JoinContext;
import com.king.streaming.sdk.context.KeyContext;
import com.king.streaming.sdk.context.State;
import com.king.streaming.sdk.functions.EventFilter;
import com.king.streaming.sdk.functions.Input;
import com.king.streaming.sdk.functions.InputTransformer;

public class All<T> extends JoinField<List<T>> {

	private static final long serialVersionUID = 1L;
	public final InputTransformer<T> inputTransformer;
	private final String uid;

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private final Class<List<T>> clazz = (Class) List.class;

	protected All(InputTransformer<T> inputTransformer, String uid) {
		this.inputTransformer = inputTransformer;
		this.uid = uid;
	}

	public static <SC> All<SC> semanticClass(Class<SC> semClazz) {
		try {
			return new All<SC>(Input.fromSemanticClass(semClazz), "a" + semClazz.getSimpleName());
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static All<Event> event() {
		return new All<Event>(e -> Optional.of(e), "a");
	}

	public static All<Event> eventType(long type) {
		return new All<Event>(Input.filter(e -> e.getEventType() == type), "ae" + type);
	}

	public static All<Event> fromFilter(EventFilter filter) {
		return new All<Event>(Input.filter(filter), "a" + filter.hashCode());
	}

	@Override
	public boolean check(Event e, JoinContext ctx) throws Exception {
		inputTransformer.transform(e).ifPresent(o -> {
			State<List<T>> allState = getTTLState(ctx, getUUID(), clazz);
			List<T> all = allState.value().orElseGet(() -> new ArrayList<>());
			all.add(o);
			allState.update(all);
		});

		return true;
	}

	@Override
	public Optional<List<T>> getValue(JoinContext ctx) throws Exception {
		return getTTLState(ctx, getUUID(), clazz).value().map(o -> new ArrayList<>((List<T>) o));
	}

	@Override
	public void deleteCompletely(KeyContext ctx) {
		getTTLState(ctx, getUUID(), clazz).clear();
	}

	@Override
	public String getUUID() {
		return uid;
	}
}
