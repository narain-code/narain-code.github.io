package com.king.streaming.sdk.runners.flink;

import java.io.IOException;
import java.io.Serializable;

import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.contrib.streaming.state.OptionsFactory;
import org.apache.flink.contrib.streaming.state.RocksDBStateBackend;
import org.apache.flink.runtime.state.AbstractStateBackend;
import org.rocksdb.BlockBasedTableConfig;
import org.rocksdb.ColumnFamilyOptions;
import org.rocksdb.CompactionStyle;
import org.rocksdb.DBOptions;

import com.king.flink.utils.config.ConfigParam;
import com.king.flink.utils.config.ParameterMapper;
import com.king.streaming.sdk.application.Environment;

public class FlinkOptions {

	@ConfigParam(required = true)
	public Environment environment = Environment.TEST;

	@ConfigParam
	public long checkpointInterval = -1;

	@ConfigParam
	public String checkpointDir = "file:///tmp/flink-cp";

	@ConfigParam
	public String localRocksDir = null;

	@ConfigParam
	public int parallelism = -1;

	@ConfigParam
	public boolean writeToAggrigato = true;

	@ConfigParam
	public String aggrigatoTopic = "aggrigato.log";

	@ConfigParam
	public Integer sourceParallelism = null;

	public AbstractStateBackend stateBackend = null;

	public RocksOptions rocksOptions = new RocksOptions();

	public static FlinkOptions fromProperties(String path) throws Exception {
		return new ParameterMapper(ParameterTool.fromPropertiesFile(path)).read(FlinkOptions.class);
	}

	public AbstractStateBackend getStateBackend() {
		if (stateBackend != null) {
			return stateBackend;
		}

		RocksDBStateBackend backend;
		try {
			backend = new RocksDBStateBackend(checkpointDir, true);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}

		if (localRocksDir != null) {
			backend.setDbStoragePath(localRocksDir);
		}
		backend.setOptions(rocksOptions.getFactory());

		return backend;
	}

	public static class RocksOptions implements Serializable {

		private static final long serialVersionUID = 1L;

		@ConfigParam
		public long blockSize = 8 * 1024;

		@ConfigParam
		public long blockCacheSize = 1024 * 1024 * 1024;

		@ConfigParam
		public long writeBufferSize = 512 * 1024 * 1024;

		@ConfigParam
		public int minWriteBufferToMerge = 4;

		@ConfigParam
		public int maxWriteBufferNumber = 16;

		@ConfigParam
		public long targetFileSize = 256 * 1024 * 1024;

		@ConfigParam
		public long bytesPerSync = 512 * 1024;

		@ConfigParam
		public int tableCacheNumshardbits = 6;

		public static RocksOptions fromProperties(String path) throws Exception {
			return new ParameterMapper(ParameterTool.fromPropertiesFile(path)).read(RocksOptions.class);
		}

		public OptionsFactory getFactory() {
			return new OptionsFactory() {
				private static final long serialVersionUID = 1L;

				@Override
				public ColumnFamilyOptions createColumnOptions(ColumnFamilyOptions options) {

					options.setCompactionStyle(CompactionStyle.LEVEL)
							.setLevelCompactionDynamicLevelBytes(true)
							.setTargetFileSizeBase(targetFileSize)
							.setMaxBytesForLevelBase(8 * targetFileSize)
							.setWriteBufferSize(writeBufferSize)
							.setLevelZeroSlowdownWritesTrigger(48)
							.setLevelZeroStopWritesTrigger(56)
							.setMaxWriteBufferNumber(maxWriteBufferNumber)
							.setMinWriteBufferNumberToMerge(minWriteBufferToMerge)
							.setTableFormatConfig(
									new BlockBasedTableConfig()
											.setBlockCacheSize(blockCacheSize)
											.setBlockSize(blockSize));
					return options;
				}

				@Override
				public DBOptions createDBOptions(DBOptions options) {
					options
							.setUseFsync(false)
							.setAllowMmapReads(true)
							.setMaxOpenFiles(-1)
							.setTableCacheNumshardbits(tableCacheNumshardbits)
							.setBytesPerSync(bytesPerSync)
							.createStatistics();

					return options;
				}
			};
		}
	}
}
