package com.king.streaming.sdk.eventstream.join;

import java.util.Optional;

import com.king.event.Event;
import com.king.streaming.sdk.context.JoinContext;
import com.king.streaming.sdk.functions.EventFilter;
import com.king.streaming.sdk.functions.Input;
import com.king.streaming.sdk.functions.InputTransformer;

/**
 * A conditional value that is present if there was any previous events that
 * satisfy the given condition. The value is always replaced by the most recent
 * occurrence of such event and is never removed after a computation has been
 * triggered on the field (in contrast with {@link Current}).
 * <p>
 * This is useful when we want to join/match the same field multiple times, such
 * as the <i>Last.semanticClass(SCGameStart.class)</i> might be matched with
 * every current event to create a game round.
 * </p>
 *
 * @see {@link JoinField}
 * @see {@link Current}
 * @see {@link First}
 * 
 * @param <T>
 *            Type of the last object
 */
public class Last<T> extends Current<T> {

	private static final long serialVersionUID = 1L;

	private Last(InputTransformer<T> inputTransformer, Class<T> clazz, String uid) {
		super(inputTransformer, clazz, uid);
	}

	public static <SC> Last<SC> semanticClass(Class<SC> semClazz) {
		try {
			return new Last<SC>(Input.fromSemanticClass(semClazz), semClazz, "l" + semClazz.getSimpleName());
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static Last<Event> event() {
		return new Last<Event>(e -> Optional.of(e), Event.class, "l");
	}

	public static Last<Event> eventType(long typeId) {
		return new Last<Event>(Input.filter(e -> e.getEventType() == typeId), Event.class, "l" + typeId);
	}

	public static Last<Event> fromFilter(EventFilter filter) {
		return new Last<Event>(Input.filter(filter), Event.class, "l" + filter.hashCode());
	}

	@Override
	public void postProcess(Event e, JoinContext ctx) {}
}
