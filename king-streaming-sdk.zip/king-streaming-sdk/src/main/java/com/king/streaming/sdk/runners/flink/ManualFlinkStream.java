package com.king.streaming.sdk.runners.flink;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.api.java.typeutils.ResultTypeQueryable;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.LocalStreamEnvironment;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.apache.flink.streaming.api.watermark.Watermark;

import com.king.event.Event;
import com.king.flink.utils.types.EventTypeInfo;
import com.king.streaming.sdk.context.Context;
import com.king.streaming.sdk.context.GlobalContext;
import com.king.streaming.sdk.context.KeyContext;
import com.king.streaming.sdk.eventstream.BroadcastState;
import com.king.streaming.sdk.eventstream.EventStream;
import com.king.streaming.sdk.eventstream.KeyedEventStream;
import com.king.streaming.sdk.eventstream.ManualEventStream;
import com.king.streaming.sdk.eventstream.ProcessorOutput;
import com.king.streaming.sdk.eventstream.ResultIterator;
import com.king.streaming.sdk.functions.EventFilter;
import com.king.streaming.sdk.functions.EventProcessor;
import com.king.streaming.sdk.functions.Key;
import com.king.streaming.sdk.io.kafka.KafkaOutput;

public class ManualFlinkStream
		implements SourceFunction<Event>, ManualEventStream, DataStreamWrapper, ResultTypeQueryable<Event> {

	private static final long serialVersionUID = 1L;
	private transient FlinkEventStream<Context> eventStream;

	private static final List<BlockingQueue<Tuple4<Event, Long, Long, Boolean>>> queues = Collections
			.synchronizedList(new ArrayList<>());
	private static final AtomicInteger numSources = new AtomicInteger(-1);
	private final int index;
	public volatile boolean isRunning = false;

	public ManualFlinkStream(FlinkRunner runner) {
		if (!(runner.getFlinkEnvironment() instanceof LocalStreamEnvironment)) {
			throw new RuntimeException("Can't user manual source in cluster environement...sorrrry :)");
		}
		eventStream = new FlinkEventStream<>(runner,
				runner.getFlinkEnvironment().addSource(this).name("Manual source"));
		index = numSources.incrementAndGet();
		queues.add(new LinkedBlockingQueue<>());
		runner.hasManualSource = true;
	}

	@Override
	public void sendEvent(Event event) {
		queues.get(index).offer(Tuple4.of(event, null, null, null));
	}

	@Override
	public void sendWatermark(Instant timeStamp) {
		queues.get(index).offer(Tuple4.of(null, timeStamp.toEpochMilli(), null, null));
	}

	@Override
	public void sleep(Duration time) {
		queues.get(index).offer(Tuple4.of(null, null, time.toMillis(), null));
	}

	public void finish() {
		queues.get(index).offer(Tuple4.of(null, null, null, true));
	}

	@Override
	public void triggerFailure() {
		queues.get(index).offer(Tuple4.of(null, null, -1L, null));
	}

	@Override
	public void cancel() {
		isRunning = false;
	}

	@Override
	public void run(SourceContext<Event> ctx)
			throws Exception {
		BlockingQueue<Tuple4<Event, Long, Long, Boolean>> queue = queues.get(index);
		isRunning = true;
		while (isRunning) {
			Tuple4<Event, Long, Long, Boolean> t = queue.take();
			if (t.f0 != null) {
				ctx.collectWithTimestamp(t.f0, t.f0.getTimeStamp());
			}
			if (t.f1 != null) {
				ctx.emitWatermark(new Watermark(t.f1));
			}
			if (t.f2 != null) {
				if (t.f2 >= 0) {
					Thread.sleep(t.f2);
				} else {
					throw new RuntimeException("FAIL!!!");
				}
			}
			if (t.f3 != null) {
				isRunning = false;
				return;
			}
		}
	}

	@Override
	public UUID getUUID() {
		return eventStream.getUUID();
	}

	@Override
	public ProcessorOutput process(EventProcessor<Context> eventProcessor) {
		return eventStream.process(eventProcessor);
	}

	@Override
	public ProcessorOutput processGlobal(EventProcessor<GlobalContext> eventProcessor) {
		return eventStream.processGlobal(eventProcessor);
	}

	@Override
	public KeyedEventStream<KeyContext> keyBy(Key key) {
		return eventStream.keyBy(key);
	}

	@Override
	public EventStream<Context> union(EventStream<?>... eventStreams) {
		return eventStream.union(eventStreams);
	}

	@Override
	public KafkaOutput writeToKafka(String topic) {
		return eventStream.writeToKafka(topic);
	}

	@Override
	public EventStream<Context> filter(EventFilter eventFilter) {
		return eventStream.filter(eventFilter);
	}

	@Override
	public void print() {
		eventStream.print();
	}

	@Override
	public ResultIterator collect() {
		return eventStream.collect();
	}

	@Override
	public <X extends Context> EventStream<Context> withBroadcastState(BroadcastState<?>... states) {
		return eventStream.withBroadcastState(states);
	}

	@Override
	public DataStream<Event> getWrappedStream() {
		return eventStream.getWrappedStream();
	}

	@Override
	public FlinkRunner getRunner() {
		return eventStream.getRunner();
	}

	@Override
	public TypeInformation<Event> getProducedType() {
		return new EventTypeInfo();
	}

}
