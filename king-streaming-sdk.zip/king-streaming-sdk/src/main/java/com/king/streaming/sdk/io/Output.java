package com.king.streaming.sdk.io;

import com.king.event.format.EventFormat;

public interface Output<T extends Output<T>> {

	public static final OutputFormat DEFAULT_EVENT_FORMAT = DefaultEventFormat.INSTANCE;

	default T withOutputFormat(EventFormat format) {
		return withOutputFormat(e -> format.format(e).getBytes());
	}

	T withOutputFormat(OutputFormat format);
}
