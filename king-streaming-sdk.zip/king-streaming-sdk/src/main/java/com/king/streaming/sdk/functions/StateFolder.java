package com.king.streaming.sdk.functions;

import java.io.Serializable;

import com.king.event.Event;
import com.king.streaming.sdk.context.Context;

public interface StateFolder<T> extends Serializable {
	T fold(T accumulator, Event event, Context ctx) throws Exception;
}