package com.king.streaming.sdk.context.aggregators;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public interface DimensionalAggregator<T extends DimensionalAggregator<T>> {

	default T setDimensions(Object... dimensions) {
		if (dimensions == null) {
			return setNamedDimensions(Collections.singletonMap("0", null));
		}

		Map<String, Object> dims = new HashMap<>();
		for (int i = 0; i < dimensions.length; i++) {
			dims.put(Integer.toString(i), dimensions[i]);
		}
		return setNamedDimensions(dims);

	}

	T setNamedDimensions(Map<String, ?> dimensions);
}
