package com.king.streaming.sdk.functions;

import java.time.Instant;

import com.king.event.Event;
import com.king.streaming.sdk.context.Context;

public interface EventProcessor<C extends Context> extends Function {

	void processEvent(Event event, C ctx) throws Exception;

	default void onWatermark(Instant watermark, C ctx) throws Exception {}

	default void onTimer(long timerId, Instant timestamp, C ctx) throws Exception {}
}
