package com.king.streaming.sdk.runners.flink;

import java.util.Properties;

import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.DataStreamSink;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaProducer010;
import org.apache.flink.streaming.util.serialization.KeyedSerializationSchema;

import com.king.event.Event;
import com.king.streaming.sdk.io.OutputFormat;
import com.king.streaming.sdk.io.kafka.KafkaOutput;

public class FlinkKafkaOutput extends FlinkOutputBase<KafkaOutput> implements KafkaOutput {

	private String broker;
	private final String topic;
	private String uid;

	public FlinkKafkaOutput(FlinkRunner runner, DataStream<Event> dataStream, String topic) {
		super(dataStream);
		this.topic = topic;
		this.broker = runner.getEnvironment().kafkaBrokers;
	}

	@Override
	public FlinkKafkaOutput withBroker(String broker) {
		this.broker = broker;
		return this;
	}

	@Override
	public void createSink() {
		Properties properties = new Properties();
		properties.setProperty("flink.disable-metrics", "true");
		properties.setProperty("bootstrap.servers", broker);
		properties.setProperty("retries", "5");

		DataStreamSink<Event> sink = dataStream.addSink(
				new FlinkKafkaProducer010<>(
						topic, new OutputFormatSerializationSchema(topic, outputFormat), properties,
						new HashingKafkaPartitioner<>()))
				.name("Kafka sink [" + topic + "]");

		if (uid != null) {
			sink.uid(uid);
		}
	}

	private static final class OutputFormatSerializationSchema implements KeyedSerializationSchema<Event> {

		private static final long serialVersionUID = 1L;

		private final OutputFormat format;
		private final String topic;

		public OutputFormatSerializationSchema(String topic, OutputFormat format) {
			this.format = format;
			this.topic = topic;
		}

		@Override
		public byte[] serializeKey(Event element) {
			return format.getPartitionKey(element);
		}

		@Override
		public byte[] serializeValue(Event element) {
			return format.serialize(element);
		}

		@Override
		public String getTargetTopic(Event element) {
			return topic;
		}

	}

	@Override
	public KafkaOutput uid(String uid) {
		this.uid = uid;
		return this;
	}

}
