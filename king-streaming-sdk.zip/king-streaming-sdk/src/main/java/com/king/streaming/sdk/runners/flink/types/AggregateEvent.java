package com.king.streaming.sdk.runners.flink.types;

import java.util.Map;
import java.util.TreeMap;

import org.apache.flink.api.common.functions.ReduceFunction;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.streaming.api.functions.windowing.WindowFunction;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.util.Collector;
import org.apache.sling.commons.json.JSONObject;

import com.king.streaming.sdk.context.aggregators.OutputType;

public class AggregateEvent {

	private String tableName;
	private long windowSize;
	private String dimensions;
	private long value;
	private OutputType type;
	private long aggregateTs = -1;

	public static TypeInformation<AggregateEvent> TYPEINFO = new TypeHint<AggregateEvent>() {}.getTypeInfo();

	public AggregateEvent(OutputType type, String tableName, long windowSize, Map<String, ?> dimensions, long value) {
		this.tableName = tableName;
		this.windowSize = windowSize;
		this.dimensions = getJSON(dimensions);
		this.value = value;
		this.type = type;
	}

	public static String getJSON(Map<String, ?> dimensions) {
		if (dimensions == null) {
			return "{}";
		}
		return new JSONObject(new TreeMap<>(dimensions)).toString();
	}

	public long getTimeStamp() {
		return aggregateTs;
	}

	public void setAggregateTS(long ts) {
		this.aggregateTs = ts;
	}

	public String getName() {
		return tableName;
	}

	public OutputType getOutputType() {
		return type;
	}

	public String getDimensions() {
		return dimensions;
	}

	public String getKey() {
		return tableName + dimensions + windowSize;
	}

	public long getValue() {
		return value;
	}

	public long getWindowSize() {
		return windowSize;
	}

	@Override
	public String toString() {
		return "Aggregate [tableName=" + tableName + ", windowSize=" + windowSize + ", dimensions=" + dimensions
				+ ", value=" + value + ", type=" + type + ", aggregateTs=" + aggregateTs + "]";
	}

	public static final KeySelector<AggregateEvent, String> KEY = new KeySelector<AggregateEvent, String>() {
		private static final long serialVersionUID = 1L;

		@Override
		public String getKey(AggregateEvent agg) throws Exception {
			return agg.getKey();
		}
	};

	public static final ReduceFunction<AggregateEvent> SUM = new ReduceFunction<AggregateEvent>() {

		private static final long serialVersionUID = 1L;

		@Override
		public AggregateEvent reduce(AggregateEvent agg1, AggregateEvent agg2) throws Exception {
			agg1.value = agg1.value + agg2.value;
			return agg1;
		}

	};

	public static final WindowFunction<AggregateEvent, AggregateEvent, String, TimeWindow> SetTimestamp = new WindowFunction<AggregateEvent, AggregateEvent, String, TimeWindow>() {
		private static final long serialVersionUID = 1L;

		@Override
		public void apply(String key, TimeWindow window, Iterable<AggregateEvent> aggregated,
				Collector<AggregateEvent> out) throws Exception {
			AggregateEvent agg = aggregated.iterator().next();
			agg.setAggregateTS(window.getEnd());
			out.collect(agg);
		}
	};

}
