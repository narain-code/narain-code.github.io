package com.king.streaming.sdk.eventstream.join;

import java.time.Duration;
import java.util.Optional;

import com.king.event.Event;
import com.king.streaming.sdk.context.JoinContext;
import com.king.streaming.sdk.context.KeyContext;
import com.king.streaming.sdk.eventstream.KeyedEventStream;

/**
 * Match is a composite {@link JoinField} that can be used to create timely
 * patterns on the {@link KeyedEventStream}s. The value of the match is present
 * if all sub-conditions are present within the optional time duration of the
 * match.
 * <p>
 * Matching supports an arbitrary number of conditions (with specialized methods
 * for matching {@link Pair} of conditions) and can be used to match once per
 * key or continuously as many times as the conditions are satisfied. It is also
 * possible to specify the maximum time difference between the different
 * conditions using {@link Match#within(Duration)}.
 * </p>
 * 
 * <p>
 * In order to avoid keeping state indefinitely, the state of the match is
 * completely deleted after the specified
 * {@link Match#withCleanupAfter(Duration)} duration, which defaults to 7 days.
 * This means that even if we used {@link Match#once(JoinField...)} we might
 * match again after the cleanup interval for the same key.
 * </p>
 * 
 * @see {@link Match#continuously(JoinField...)}
 * @see {@link Match#once(JoinField...)}
 * 
 * @param <M>
 *            The type of the match, either a {@link Pair} or an array of
 *            object.
 */
public abstract class Match<M> extends JoinField<M> {

	private static final long serialVersionUID = 1L;
	protected Duration duration = null;
	protected Duration cleanupAfter = Duration.ofDays(7);
	protected final JoinField<?>[] fields;
	protected final boolean allowMultipleMatches;
	private String uid;

	private Match(JoinField<?>[] conditions, boolean allowMultipleMatches) {
		this.fields = conditions;
		this.allowMultipleMatches = allowMultipleMatches;
		this.uid = "";
		for (JoinField<?> cond : conditions) {
			uid = uid + cond.getUUID();
		}
		if (allowMultipleMatches) {
			uid = uid + "t";
		}
	}

	public String getUUID() {
		return uid;
	}

	public Match<M> clearAfter(Duration duration) {
		for (int i = 0; i < fields.length; i++) {
			fields[i] = fields[i].clearAfter(duration);
		}
		return this;
	}

	public Match<M> within(Duration duration) {
		return (Match<M>) clearAfter(duration);
	}

	public Match<M> withCleanupAfter(Duration cleanupAfter) {
		this.cleanupAfter = cleanupAfter;
		return this;
	}

	public static <L, R> Match<Pair<L, R>> continuously(JoinField<L> first,
			JoinField<R> second) {
		return new BinaryMatch<>(first, second, true);
	}

	public static Match<Object[]> continuously(JoinField<?>... conditions) {
		return new AllMatch(conditions, true);
	}

	public static <L, R> Match<Pair<L, R>> once(JoinField<L> first,
			JoinField<R> second) {
		return new BinaryMatch<>(first, second, false);
	}

	public static Match<Object[]> once(JoinField<?>... conditions) {
		return new AllMatch(conditions, false);
	}

	@Override
	public boolean check(Event e, JoinContext ctx) throws Exception {
		if (!allowMultipleMatches) {
			boolean alreadyMatched = ctx.getValueState(getUUID(), Boolean.class)
					.clearAfter(cleanupAfter)
					.value()
					.orElse(false);
			if (alreadyMatched) {
				return false;
			}
		}

		boolean allTrue = true;
		for (JoinField<?> field : fields) {
			if (!field.check(e, ctx)) {
				allTrue = false;
			}
		}

		return allTrue;
	}

	@Override
	public void postProcess(Event e, JoinContext ctx) throws Exception {
		if (allowMultipleMatches) {
			for (JoinField<?> field : fields) {
				field.postProcess(e, ctx);
			}
		} else {
			deleteCompletely(ctx);
			ctx.getValueState(getUUID(), Boolean.class)
					.clearAfter(cleanupAfter)
					.update(true);
		}
	}

	@Override
	public void deleteCompletely(KeyContext ctx) {
		for (JoinField<?> field : fields) {
			field.deleteCompletely(ctx);
		}
	}

	private final static class AllMatch extends Match<Object[]> {

		private static final long serialVersionUID = 1L;

		public AllMatch(JoinField<?>[] conditions, boolean allowMultipleMatches) {
			super(conditions, allowMultipleMatches);
		}

		@Override
		public Optional<Object[]> getValue(JoinContext ctx) throws Exception {
			Object[] o = new Object[fields.length];
			for (int i = 0; i < fields.length; i++) {
				Optional<?> joinedElement = fields[i].getValue(ctx);
				if (fields[i].allowsMissing() || joinedElement.isPresent()) {
					o[i] = joinedElement.orElse(null);
				} else {
					return Optional.empty();
				}
			}
			return Optional.of(o);
		}

	}

	private final static class BinaryMatch<L, R> extends Match<Pair<L, R>> {

		private static final long serialVersionUID = 1L;

		public BinaryMatch(JoinField<?> first, JoinField<?> second, boolean allowMultipleMatches) {
			super(new JoinField[] { first, second }, allowMultipleMatches);
		}

		@SuppressWarnings("unchecked")
		@Override
		public Optional<Pair<L, R>> getValue(JoinContext ctx) throws Exception {

			Optional<L> leftOpt = (Optional<L>) fields[0].getValue(ctx);
			Optional<R> rightOpt = (Optional<R>) fields[1].getValue(ctx);

			if ((leftOpt.isPresent() || fields[0].allowsMissing())
					&& (rightOpt.isPresent() || fields[1].allowsMissing())) {
				return Optional.of(new Pair<>(leftOpt.orElse(null), rightOpt.orElse(null)));
			} else {
				return Optional.empty();
			}
		}

	}
}
