package com.king.streaming.sdk.eventstream.join.abtest;

import java.io.Serializable;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import com.king.event.Event;
import com.king.kgk.SCAbTestCaseAssignedServer;
import com.king.streaming.sdk.context.Context;
import com.king.streaming.sdk.eventstream.join.Aggregate;
import com.king.streaming.sdk.eventstream.join.JoinField;
import com.king.streaming.sdk.eventstream.join.Pair;
import com.king.streaming.sdk.functions.StateFolder;

public class ABTestAssignments implements Serializable {

	private static final long serialVersionUID = 1L;

	private final Map<Pair<String, Integer>, SCAbTestCaseAssignedServer> assignments = new HashMap<>();

	private ABTestAssignments() {}

	private void updateAssignments(SCAbTestCaseAssignedServer assignment) {
		assignments.put(Pair.of(assignment.getAbTestName(), assignment.getCaseNum()), assignment);
	}

	public Optional<Integer> getCaseNum(String abTestName, Integer version) {
		return getAssignmentEvent(abTestName, version).map(a -> a.getCaseNum());
	}

	public Optional<SCAbTestCaseAssignedServer> getAssignmentEvent(String abTestName, Integer version) {
		return Optional.ofNullable(assignments.get(Pair.of(abTestName, version)));
	}

	public Collection<SCAbTestCaseAssignedServer> getAllAssignments() {
		return assignments.values();
	}

	protected static JoinField<ABTestAssignments> JOIN_FIELD_INSTANCE = Aggregate
			.<ABTestAssignments> of(new StateFolder<ABTestAssignments>() {
				private static final long serialVersionUID = 1L;

				@Override
				public ABTestAssignments fold(ABTestAssignments accumulator, Event event, Context ctx)
						throws Exception {
					SCAbTestCaseAssignedServer assignment = SCAbTestCaseAssignedServer.process(event);
					if (assignment != null) {
						accumulator.updateAssignments(assignment);
					}
					return accumulator;
				}
			}, new ABTestAssignments());
}
