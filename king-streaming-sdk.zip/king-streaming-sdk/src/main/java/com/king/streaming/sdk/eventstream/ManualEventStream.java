package com.king.streaming.sdk.eventstream;

import java.time.Duration;
import java.time.Instant;

import com.king.event.Event;
import com.king.streaming.sdk.context.Context;
import com.king.streaming.sdk.events.CustomEvent;

/**
 * {@link EventStream} that is operated manually for testing purposes. This
 * includes sending elements, waiting, sending watermarks, triggering pipeline
 * failures and closing the stream.
 * 
 * @see TestRunner
 *
 */
public interface ManualEventStream extends EventStream<Context> {

	/**
	 * Sends an {@link Event} into the {@link EventStream}.
	 * 
	 * @param event
	 * @see CustomEvent
	 */
	void sendEvent(Event event);

	/**
	 * Progresses the watermark on this stream, triggering timely functionality
	 * such as timers or aggregates
	 * 
	 * @param timeStamp
	 *            The new watermark.
	 */
	void sendWatermark(Instant timeStamp);

	/**
	 * Triggers some delay between subsequent elements.
	 * 
	 * @param time
	 *            Time to wait.
	 */
	void sleep(Duration time);

	/**
	 * Causes a failure in the pipeline, triggering recovery behavior.
	 */
	void triggerFailure();
}
