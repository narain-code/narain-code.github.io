package com.king.streaming.sdk.runners.flink;

import com.king.constants.EventField;
import com.king.event.Event;
import com.king.streaming.sdk.io.DefaultEventFormat;
import com.king.streaming.sdk.io.OutputFormat;

public final class AggrigatoOutputFormat implements OutputFormat {
	private static final long serialVersionUID = 1L;

	@Override
	public byte[] serialize(Event event) {
		return DefaultEventFormat.INSTANCE.serialize(event);
	}

	@Override
	public byte[] getPartitionKey(Event event) {
		String key = "" +
				event.get(EventField.AggrigatoLong.aggregatorId) +
				event.get(EventField.AggrigatoLong.bucketStartMsts) +
				event.get(EventField.AggrigatoLong.dimensionsJsonObject)
				+ event.get(EventField.AggrigatoLong.bucketSizeMs);
		return key.getBytes();
	}
}