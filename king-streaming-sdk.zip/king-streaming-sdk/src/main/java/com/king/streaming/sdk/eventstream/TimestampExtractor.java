package com.king.streaming.sdk.eventstream;

import java.io.Serializable;
import java.util.function.Function;

import com.king.event.Event;

public interface TimestampExtractor extends Function<Event, Long>, Serializable {

}
