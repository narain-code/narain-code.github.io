package com.king.streaming.sdk.context.aggregators;

public enum AggregationWindow {

	MINUTES_1(1000 * 60), MINUTES_5(5 * 1000 * 60), MINUTES_10(10 * 1000 * 60), MINUTES_30(
			30 * 1000 * 60), MINUTES_60(60 * 1000 * 60);

	private final long millis;

	AggregationWindow(long millis) {
		this.millis = millis;
	}

	public long toMillis() {
		return millis;
	}
}