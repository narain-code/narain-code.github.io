package com.king.streaming.sdk.runners.flink;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.Semaphore;

import org.apache.flink.api.common.restartstrategy.RestartStrategies;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.CheckpointingMode;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.CheckpointConfig;
import org.apache.flink.streaming.api.environment.CheckpointConfig.ExternalizedCheckpointCleanup;
import org.apache.flink.streaming.api.environment.LocalStreamEnvironment;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.AssignerWithPeriodicWatermarks;
import org.apache.flink.streaming.api.functions.timestamps.BoundedOutOfOrdernessTimestampExtractor;
import org.apache.flink.streaming.api.windowing.assigners.TumblingProcessingTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.king.event.Event;
import com.king.streaming.sdk.application.Environment;
import com.king.streaming.sdk.context.Context;
import com.king.streaming.sdk.context.aggregators.AggregatorOutput;
import com.king.streaming.sdk.eventstream.EventStream;
import com.king.streaming.sdk.eventstream.ManualEventStream;
import com.king.streaming.sdk.eventstream.TestRunner;
import com.king.streaming.sdk.eventstream.TimestampExtractor;
import com.king.streaming.sdk.io.DefaultEventFormat;
import com.king.streaming.sdk.io.kafka.KafkaInput;
import com.king.streaming.sdk.runners.flink.operators.AggregatorOutputSink;
import com.king.streaming.sdk.runners.flink.operators.AggregtionWindowAssigner;
import com.king.streaming.sdk.runners.flink.types.AggregateEvent;
import com.king.utils.ClosureCleaner;

public class FlinkRunner implements TestRunner {

	private final FlinkOptions options;
	private final StreamExecutionEnvironment env;

	private String flinkJobName;

	private final List<DataStream<AggregateEvent>> windowInputStreams = new ArrayList<>();
	private final List<FlinkOutputBase<?>> outputs = new ArrayList<>();
	private final List<ManualFlinkStream> manualStreams = new ArrayList<>();

	private final Semaphore finished = new Semaphore(1);

	private volatile boolean started = false;
	private volatile boolean stopped = false;

	protected boolean hasManualSource = false;

	private Time watermarkSlack = Time.seconds(30);

	private Optional<DataStream<AggregateEvent>> finalAggregateStream = Optional.empty();
	private TimestampExtractor extractor = Event::getTimeStamp;

	private static final Logger LOG = LoggerFactory.getLogger(FlinkRunner.class);

	private FlinkRunner(FlinkOptions options, StreamExecutionEnvironment env, String flinkJobName) {
		this.env = env;
		this.flinkJobName = flinkJobName;
		this.options = options;
	}

	public void addWindowInput(DataStream<AggregateEvent> stream) {
		windowInputStreams.add(stream);
	}

	public void addOutput(FlinkOutputBase<?> otuput) {
		outputs.add(otuput);
	}

	protected <F> F clean(F function) {
		ClosureCleaner.clean(function, true);
		return function;
	}

	public StreamExecutionEnvironment getFlinkEnvironment() {
		return env;
	}

	@Override
	public EventStream<Context> createEventStream(Event... events) {
		return new FlinkEventStream<>(this,
				env.fromElements(events)
						.name("Event source")
						.assignTimestampsAndWatermarks(getWatermarkAssigner(watermarkSlack))
						.setParallelism(1));
	}

	@Override
	public KafkaInput readFromKafka(List<String> topics, String groupId) {
		return new FlinkKafkaInput(topics, groupId, this);
	}

	public AssignerWithPeriodicWatermarks<Event> getWatermarkAssigner(Time slack) {
		TimestampExtractor e = extractor;
		ClosureCleaner.clean(e, true);

		return new BoundedOutOfOrdernessTimestampExtractor<Event>(slack) {
			private static final long serialVersionUID = 1L;
			private Long prevTs = null;

			@Override
			public long extractTimestamp(Event event) {
				if (event.getEventType() == DefaultEventFormat.PARSE_ERROR) {
					return prevTs != null ? prevTs : 0;
				}
				Long ts = e.apply(event);
				prevTs = ts;
				return ts;
			}
		};
	}

	@Override
	public void start() throws Exception {
		if (hasManualSource) {
			System.out.println(
					"I see you have a manual source. You might want to start in debug mode or at least in a separate thread if you dont want to deadlock. Just saying...");
		}
		createAggregateStream();

		finalAggregateStream.ifPresent(aggregates -> {
			if (getOptions().writeToAggrigato) {
				if (getOptions().aggrigatoTopic == null) {
					throw new RuntimeException("AggrigatoTopic needs to be defined in the config.");
				}

				outputs.add((FlinkOutputBase<?>) new FlinkKafkaOutput(this, aggregates.map(new ToAggrigatoEvent()),
						getOptions().aggrigatoTopic)
								.withBroker(getEnvironment().kafkaBrokers)
								.uid("Aggrigato-output")
								.withOutputFormat(new AggrigatoOutputFormat()));

			}
		});

		outputs.forEach(FlinkOutputBase::createSink);

		started = true;

		env.getStreamGraph().getJobGraph().getVertices().forEach(v -> {
			LOG.info(v.getID() + " " + v.getName() + " " + v.getOperatorName());
		});
		env.execute(flinkJobName);
	}

	@Override
	public AggregatorOutput startTest(boolean writeOutputs) throws Exception {
		if (!(env instanceof LocalStreamEnvironment)) {
			throw new RuntimeException("Can't test in cluster environement...sorrrry :)");
		}
		createAggregateStream();
		AggregatorOutput aggOut = null;
		if (finalAggregateStream.isPresent()) {
			aggOut = createAggregatorOutput(finalAggregateStream.get());
		}

		if (writeOutputs) {
			outputs.forEach(FlinkOutputBase::createSink);
		}

		finished.acquire();
		new Thread(() -> {
			try {
				try {
					env.execute(flinkJobName);
				} finally {
					finished.release();
				}
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}).start();

		started = true;

		return aggOut;
	}

	private void createAggregateStream() {
		if (!windowInputStreams.isEmpty()) {
			DataStream<AggregateEvent> aggStream = windowInputStreams.get(0);
			if (windowInputStreams.size() > 1) {
				for (int i = 1; i < windowInputStreams.size(); i++) {
					aggStream = aggStream.union(windowInputStreams.get(i));
				}
			}

			SingleOutputStreamOperator<AggregateEvent> aggOut = applyWindows(aggStream, "AggrigatoOperator");

			finalAggregateStream = Optional.of(aggOut);
		}
	}

	public static SingleOutputStreamOperator<AggregateEvent> applyWindows(DataStream<AggregateEvent> aggStream,
			String uid) {
		SingleOutputStreamOperator<AggregateEvent> aggOut = aggStream.keyBy(AggregateEvent.KEY)
				.window(new AggregtionWindowAssigner())
				.allowedLateness(Time.hours(24))
				.apply(AggregateEvent.SUM, AggregateEvent.SetTimestamp)
				.name("Window Aggregator")
				.uid(uid)
				.keyBy(new KeySelector<AggregateEvent, Tuple2<String, Long>>() {
					private static final long serialVersionUID = 1L;

					@Override
					public Tuple2<String, Long> getKey(AggregateEvent agg) throws Exception {
						return Tuple2.of(agg.getKey(), agg.getTimeStamp());
					}

				})
				.window(TumblingProcessingTimeWindows.of(Time.seconds(3)))
				.reduce((b1, b2) -> b2)
				.uid(uid + "_keep_last")
				.name("Keep last");
		return aggOut;
	}

	public static FlinkRunner create(String name, FlinkOptions options) {
		StreamExecutionEnvironment env = createEnvFromOptions(options);
		return new FlinkRunner(options, env, name);
	}

	protected static StreamExecutionEnvironment createEnvFromOptions(FlinkOptions options) {
		StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

		env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime);
		if (env instanceof LocalStreamEnvironment) {
			env.getConfig().setRestartStrategy(RestartStrategies.fixedDelayRestart(3, 500));
		}

		if (options.parallelism > 0) {
			env.setParallelism(options.parallelism);
		}

		env.setMaxParallelism(720);

		env.setStateBackend(options.getStateBackend());

		if (options.checkpointInterval > 0) {
			env.enableCheckpointing(options.checkpointInterval);
			CheckpointConfig checkpointConf = env.getCheckpointConfig();
			checkpointConf.setCheckpointingMode(CheckpointingMode.EXACTLY_ONCE);
			checkpointConf.setCheckpointTimeout(10 * 60 * 60 * 1000);
			checkpointConf.setMaxConcurrentCheckpoints(1);
			if (!(env instanceof LocalStreamEnvironment)) {
				checkpointConf.enableExternalizedCheckpoints(ExternalizedCheckpointCleanup.RETAIN_ON_CANCELLATION);
			}
		}

		return env;
	}

	public static FlinkRunner create(FlinkOptions options) {
		return create("Stream SDK Job", options);
	}

	public static FlinkRunner create() {
		return create("Stream SDK Job");
	}

	public static FlinkRunner create(String name) {
		return create(name, new FlinkOptions());
	}

	private AggregatorOutput createAggregatorOutput(DataStream<AggregateEvent> dataStream) {
		AggregatorOutputSink sink = new AggregatorOutputSink();
		dataStream.addSink(sink).name("Aggregator Output Sink").setParallelism(1);
		return sink;
	}

	@Override
	public ManualEventStream createManualStream() {
		ManualFlinkStream manStream = new ManualFlinkStream(this);
		manualStreams.add(manStream);
		return manStream;
	}

	@Override
	public void stopTest() {
		manualStreams.forEach(s -> s.finish());
		try {
			finished.acquire();
			finished.release();
			stopped = true;
		} catch (InterruptedException e) {}
	}

	@Override
	public boolean wasStopped() {
		return wasStarted() && stopped;
	}

	@Override
	public boolean wasStarted() {
		return started;
	}

	@Override
	public void setEventTimeExtractor(TimestampExtractor extractor) {
		this.extractor = extractor;
	}

	public FlinkOptions getOptions() {
		return options;
	}

	@Override
	public Environment getEnvironment() {
		return options.environment;
	}
}
