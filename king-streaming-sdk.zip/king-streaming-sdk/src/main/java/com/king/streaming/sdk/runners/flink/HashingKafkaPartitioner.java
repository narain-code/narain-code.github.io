package com.king.streaming.sdk.runners.flink;

import java.util.Arrays;
import java.util.Random;

import org.apache.flink.streaming.connectors.kafka.partitioner.FlinkKafkaPartitioner;

public class HashingKafkaPartitioner<T> extends FlinkKafkaPartitioner<T> {

	private static final long serialVersionUID = -5073273587605637390L;

	private final Random rnd = new Random();

	@Override
	public int partition(T record, byte[] key, byte[] value, String targetTopic, int[] partitions) {
		if (key == null) {
			return rnd.nextInt(partitions.length);
		} else {
			return Math.abs(Arrays.hashCode(key)) % partitions.length;
		}
	}
}
