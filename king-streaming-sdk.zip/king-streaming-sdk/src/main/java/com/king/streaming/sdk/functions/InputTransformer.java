package com.king.streaming.sdk.functions;

import java.io.Serializable;
import java.util.Optional;

import com.king.event.Event;

public interface InputTransformer<T> extends Serializable {
	Optional<T> transform(Event input) throws Exception;
}
