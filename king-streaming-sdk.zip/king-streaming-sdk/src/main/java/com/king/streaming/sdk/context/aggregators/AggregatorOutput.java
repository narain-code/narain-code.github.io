package com.king.streaming.sdk.context.aggregators;

import java.time.Duration;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.SortedMap;
import java.util.concurrent.TimeoutException;

public interface AggregatorOutput {

	default Optional<Long> getValue(String aggregatorName, Object[] dimensions, long timeStamp) {
		if (dimensions == null) {
			return getValue(aggregatorName, Collections.singletonMap("0", null), timeStamp);
		}

		Map<String, Object> dims = new HashMap<>();
		for (int i = 0; i < dimensions.length; i++) {
			dims.put(Integer.toString(i), dimensions[i]);
		}
		return getValue(aggregatorName, dims, timeStamp);
	}

	Optional<Long> getValue(String aggregatorName, Map<String, ?> dimensions, long timeStamp);

	long pollValue(Duration timeout, String aggregatorName, Map<String, ?> dimensions, long timeStamp)
			throws TimeoutException;

	default long pollValue(Duration timeout, String aggregatorName, Object[] dimensions, long timeStamp)
			throws TimeoutException {
		if (dimensions == null) {
			return pollValue(timeout, aggregatorName, Collections.singletonMap("0", null), timeStamp);
		}

		Map<String, Object> dims = new HashMap<>();
		for (int i = 0; i < dimensions.length; i++) {
			dims.put(Integer.toString(i), dimensions[i]);
		}
		return pollValue(timeout, aggregatorName, dims, timeStamp);
	}

	default long pollValue(String aggregatorName, Object[] dimensions, long timeStamp) throws TimeoutException {
		if (dimensions == null) {
			return pollValue(aggregatorName, Collections.singletonMap("0", null), timeStamp);
		}

		Map<String, Object> dims = new HashMap<>();
		for (int i = 0; i < dimensions.length; i++) {
			dims.put(Integer.toString(i), dimensions[i]);
		}
		return pollValue(aggregatorName, dims, timeStamp);
	}

	default long pollValue(String aggregatorName, Map<String, ?> dimensions, long timeStamp)
			throws TimeoutException {
		return pollValue(Duration.ofSeconds(30), aggregatorName, dimensions, timeStamp);
	}

	SortedMap<Long, Map<String, Long>> getAllValues(String aggregatorName);

	Collection<String> getAggregatorNames();
}
