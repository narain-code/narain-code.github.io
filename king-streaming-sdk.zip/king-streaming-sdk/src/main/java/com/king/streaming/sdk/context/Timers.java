package com.king.streaming.sdk.context;

import java.time.Instant;

/**
 * Timers can be used to register event time callbacks for the current user.
 */
public interface Timers {

	/**
	 * Registers a timer to be triggered at the specific event time Instant (using random id)
	 */
	long registerTimer(Instant instant);

	/**
	 * Registers a timer to be triggered at the specific event time Instant (using specified id)
	 */
	long registerTimerWithId(long id, Instant instant);
	/**
	 * Removes the callback registered with the given id. Returns true iff an
	 * unfired timer with the given id existed.
	 *
	 */
	boolean removeTimer(long id);

	/**
	 * Removes all registered callbacks for the current key. Returns true iff at
	 * least one timer was removed.
	 */
	boolean removeAllTimers();

}
