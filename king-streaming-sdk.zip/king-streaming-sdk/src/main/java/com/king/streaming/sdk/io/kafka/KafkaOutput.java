package com.king.streaming.sdk.io.kafka;

import com.king.streaming.sdk.io.Output;
import com.king.streaming.sdk.io.OutputFormat;

public interface KafkaOutput extends Output<KafkaOutput> {

	KafkaOutput withOutputFormat(OutputFormat format);

	KafkaOutput withBroker(String broker);

	KafkaOutput uid(String uid);
}
