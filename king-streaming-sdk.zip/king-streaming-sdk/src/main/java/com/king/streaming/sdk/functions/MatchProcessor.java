package com.king.streaming.sdk.functions;

import com.king.streaming.sdk.context.JoinContext;

public interface MatchProcessor<M> extends Function {
	void process(M matched, JoinContext ctx) throws Exception;
}