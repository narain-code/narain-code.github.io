package com.king.streaming.sdk.io;

import java.io.Serializable;

import org.apache.commons.compress.utils.Charsets;

import com.king.event.Event;

public interface OutputFormat extends Serializable {

	default byte[] getPartitionKey(Event event) {
		try {
			return event.getString(0).getBytes(Charsets.UTF_8);
		} catch (Throwable ignore) {
			return null;
		}
	}

	byte[] serialize(Event event);
}
