package com.king.streaming.sdk.io.kafka;

import java.time.Duration;

import com.king.event.format.EventFormat;
import com.king.streaming.sdk.context.Context;
import com.king.streaming.sdk.eventstream.EventStream;
import com.king.streaming.sdk.io.DefaultEventFormat;
import com.king.streaming.sdk.io.InputFormat;

public interface KafkaInput extends EventStream<Context> {

	public static final InputFormat DEFAULT_EVENT_FORMAT = DefaultEventFormat.INSTANCE;
	public static final StartOffset DEFAULT_START_OFFSET = StartOffset.CURRENT_FOR_GROUP;
	public static final Duration DEFAULT_WATERMARK_SLACK = Duration.ofSeconds(30);

	KafkaInput withInputFormat(InputFormat format);

	default KafkaInput withInputFormat(EventFormat format) {
		return withInputFormat(bytes -> {
			try {
				return format.parse(new String(bytes));
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		});
	}

	KafkaInput withBroker(String broker);

	KafkaInput withZK(String zkHost);

	KafkaInput startingAt(StartOffset startOffset);

	KafkaInput withWatermarkSlack(Duration slack);

	KafkaInput disablePerPartitionWatermarks();

	KafkaInput excludeFromTimeTracking();

	KafkaInput uid(String uid);

	@Deprecated
	public KafkaInput setUidHash(String uid);

	EventStream<Context> getParseErrorStream();
}
