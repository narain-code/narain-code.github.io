package com.king.streaming.sdk.eventstream.join;

import java.util.Optional;

import com.king.event.Event;
import com.king.streaming.sdk.context.JoinContext;
import com.king.streaming.sdk.context.KeyContext;
import com.king.streaming.sdk.functions.EventFilter;
import com.king.streaming.sdk.functions.Input;
import com.king.streaming.sdk.functions.InputTransformer;

/**
 * A conditional value that is present if there was any previous events that
 * satisfy the specified condition for which a computation wasn't triggered yet.
 * <p>
 * The value is always replaced by the most recent occurrence of such event and
 * is cleared by computations on the field (in contrast with {@link Last}).
 * </p>
 * <p>
 * This is useful when we want to join/match the a given field every time it
 * "changes", such as trigger a computation on every
 * <i>Current.semanticClass(SCPurchase.class)</i>.
 * </p>
 * 
 * @see {@link JoinField}
 * @see {@link Last}
 * @see {@link First}
 * 
 * @param <T>
 *            Type of the current object
 */
public class Current<T> extends JoinField<T> {

	private static final long serialVersionUID = 1L;
	public final InputTransformer<T> inputTransformer;
	private final Class<T> clazz;
	private final String uid;

	protected Current(InputTransformer<T> inputTransformer, Class<T> clazz, String uid) {
		this.inputTransformer = inputTransformer;
		this.clazz = clazz;
		this.uid = uid;
	}

	public static <SC> Current<SC> semanticClass(Class<SC> semClazz) {
		try {
			return new Current<SC>(Input.fromSemanticClass(semClazz), semClazz, "c" + semClazz.getSimpleName());
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static Current<Event> event() {
		return new Current<Event>(e -> Optional.of(e), Event.class, "c");
	}

	public static Current<Event> eventType(long typeId) {
		return new Current<Event>(Input.filter(e -> e.getEventType() == typeId), Event.class, "ce" + typeId);
	}

	public static Current<Event> fromFilter(EventFilter filter) {
		return new Current<Event>(Input.filter(filter), Event.class, "c" + filter.hashCode());
	}

	@Override
	public boolean check(Event e, JoinContext ctx) throws Exception {
		return inputTransformer
				.transform(e)
				.map(last -> {
					getTTLState(ctx, getUUID(), clazz).update(last);
					return true;
				}).orElseGet(() -> {
					return getTTLState(ctx, getUUID(), clazz).value().isPresent();
				});
	}

	@Override
	public void postProcess(Event e, JoinContext ctx) {
		deleteCompletely(ctx);
	}

	@Override
	public void deleteCompletely(KeyContext ctx) {
		getTTLState(ctx, getUUID(), clazz).clear();
	}

	@Override
	public Optional<T> getValue(JoinContext ctx) {
		return (Optional<T>) getTTLState(ctx, getUUID(), clazz).value();
	}

	@Override
	public String getUUID() {
		return uid;
	}
}
