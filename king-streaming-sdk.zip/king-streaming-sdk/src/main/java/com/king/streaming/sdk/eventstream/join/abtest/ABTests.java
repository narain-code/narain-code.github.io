package com.king.streaming.sdk.eventstream.join.abtest;

import com.king.streaming.sdk.eventstream.join.JoinField;

public class ABTests {

	public static JoinField<ABTestAssignments> createAssignmentInfo() {
		return ABTestAssignments.JOIN_FIELD_INSTANCE;
	}

}
