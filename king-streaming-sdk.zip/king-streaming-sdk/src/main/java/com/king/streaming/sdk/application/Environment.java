package com.king.streaming.sdk.application;

public enum Environment {

	DEV(
			"kafkadev01.vm.dev.midasplayer.com:9092,kafkadev02.vm.dev.midasplayer.com:9092,kafkadev03.vm.dev.midasplayer.com:9092",
			"zkdev01.vm.dev.midasplayer.com:2181,zkdev02.vm.dev.midasplayer.com:2181,zkdev03.vm.dev.midasplayer.com:2181/kafka10"),

	QA(
			"kafkaqa04.qa.midasplayer.com:9092,kafkaqa05.qa.midasplayer.com:9092,kafkaqa06.qa.midasplayer.com:9092",
			"zkqa04.qa.midasplayer.com:2181,zkqa05.qa.midasplayer.com:2181,zkqa06.qa.midasplayer.com:2181/kafka10"),

	PROD(
			"kafka27.sto.midasplayer.com:9092,kafka28.sto.midasplayer.com:9092,kafka29.sto.midasplayer.com:9092",
			"zk04.sto.midasplayer.com:2181,zk05.sto.midasplayer.com:2181,zk06.skd.midasplayer.com:2181,zk07.sto.midasplayer.com:2181,zk08.skd.midasplayer.com:2181/kafka10"),

	LIVE(
			"kafka27.sto.midasplayer.com:9092,kafka28.sto.midasplayer.com:9092,kafka29.sto.midasplayer.com:9092",
			"zk04.sto.midasplayer.com:2181,zk05.sto.midasplayer.com:2181,zk06.skd.midasplayer.com:2181,zk07.sto.midasplayer.com:2181,zk08.skd.midasplayer.com:2181/kafka10"),

	TEST(
			"test",
			"test");

	public final String kafkaBrokers;
	public final String zkConnectionString;

	private Environment(String b, String zk) {
		this.kafkaBrokers = b;
		this.zkConnectionString = zk;
	}

}
