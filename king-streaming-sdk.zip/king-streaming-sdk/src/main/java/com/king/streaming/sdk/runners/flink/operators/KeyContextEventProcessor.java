/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.king.streaming.sdk.runners.flink.operators;

import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Random;

import org.apache.flink.api.common.state.ListState;
import org.apache.flink.api.common.state.ListStateDescriptor;
import org.apache.flink.api.common.state.OperatorStateStore;
import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.api.common.typeinfo.BasicTypeInfo;
import org.apache.flink.api.common.typeinfo.PrimitiveArrayTypeInfo;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeutils.TypeSerializer;
import org.apache.flink.api.common.typeutils.base.LongSerializer;
import org.apache.flink.api.java.typeutils.TypeExtractor;
import org.apache.flink.runtime.state.StateInitializationContext;
import org.apache.flink.runtime.state.StateSnapshotContext;
import org.apache.flink.runtime.state.VoidNamespace;
import org.apache.flink.runtime.state.VoidNamespaceSerializer;
import org.apache.flink.streaming.api.operators.InternalTimer;
import org.apache.flink.streaming.api.operators.InternalTimerService;
import org.apache.flink.streaming.api.operators.Triggerable;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.apache.flink.util.InstantiationUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.king.event.Event;
import com.king.flink.utils.Unchecked;
import com.king.flink.utils.types.EventTypeInfo;
import com.king.flink.utils.types.HashMapTypeInfo;
import com.king.flink.utils.types.SemanticClassTypeInfo;
import com.king.flink.utils.types.SemanticClassUtils.SerializableSC;
import com.king.kgk.KingDataClass;
import com.king.streaming.sdk.context.GlobalContext;
import com.king.streaming.sdk.context.JoinContext;
import com.king.streaming.sdk.context.KeyContext;
import com.king.streaming.sdk.context.MapState;
import com.king.streaming.sdk.context.State;
import com.king.streaming.sdk.context.Timers;
import com.king.streaming.sdk.eventstream.BroadcastState;
import com.king.streaming.sdk.functions.EventProcessor;
import com.king.streaming.sdk.io.DefaultEventFormat;
import com.king.streaming.sdk.runners.flink.FlinkEventProcessor;

public class KeyContextEventProcessor extends ContextEventProcessor {

	private static final long serialVersionUID = 1L;
	protected HashMap<String, ValueState<?>> states = new HashMap<>();

	private static final Logger LOG = LoggerFactory.getLogger(KeyContextEventProcessor.class);

	InternalTimerService<Long> timerService;
	InternalTimerService<VoidNamespace> stateTimerService;

	private ValueState<Map<Long, Long>> timersTimestamps;
	private ValueState<Map<String, Long>> stateExpiryTimes;
	private Random rnd = new Random();

	private ListState<HashMap<String, Long>> ttlBcState;
	private ListState<HashMap<String, byte[]>> typeBcState;

	private HashMap<String, Long> ttlDurations;
	private HashMap<String, ValueStateDescriptor<?>> descriptors;

	public KeyContextEventProcessor(FlinkEventProcessor<?> processor, Map<BroadcastState<?>, Short> bcStateMapping) {
		super(processor, bcStateMapping);
	}

	@SuppressWarnings({ "unchecked", "rawtypes", "deprecation" })
	@Override
	public void open() throws Exception {
		super.open();
		this.timerService = getInternalTimerService("user-timers", LongSerializer.INSTANCE, new UserTimers());
		this.stateTimerService = getInternalTimerService("state-timers", VoidNamespaceSerializer.INSTANCE,
				new StateExpiryTimers());

		this.timersTimestamps = getRuntimeContext().getState(new ValueStateDescriptor("timer-state",
				new HashMapTypeInfo<>(BasicTypeInfo.LONG_TYPE_INFO, BasicTypeInfo.LONG_TYPE_INFO), new HashMap<>()));
		this.stateExpiryTimes = getRuntimeContext().getState(new ValueStateDescriptor("expiry-state",
				new HashMapTypeInfo<>(BasicTypeInfo.STRING_TYPE_INFO, BasicTypeInfo.LONG_TYPE_INFO), new HashMap<>()));

		ttlDurations = mergeBCState(ttlBcState).orElse(new HashMap<>());
		HashMap<String, byte[]> restoredTypeState = mergeBCState(typeBcState).orElse(new HashMap<>());
		descriptors = new HashMap<>();
		for (Entry<String, byte[]> e : restoredTypeState.entrySet()) {
			ValueStateDescriptor<?> desc = new ValueStateDescriptor<>(e.getKey(), (TypeSerializer<?>) InstantiationUtil
					.deserializeObject(e.getValue(), Event.class.getClassLoader()));
			descriptors.put(e.getKey(), desc);
			try {
				states.put(e.getKey(), getRuntimeContext().getState(desc));
			} catch (Throwable t) {
				LOG.error("Error while loading state info from checkpoint for state {} descriptor {}", e.getKey(),
						desc);
				throw t;
			}
		}

		LOG.debug("Restored ttl info {}", ttlDurations);
		LOG.debug("Restored descriptor info {}", descriptors);
	}

	protected <K, V> Optional<HashMap<K, V>> mergeBCState(ListState<HashMap<K, V>> state) throws Exception {
		Iterator<HashMap<K, V>> stateIt = state.get().iterator();
		HashMap<K, V> merged = stateIt.hasNext() ? stateIt.next() : null;
		if (merged == null) {
			return Optional.empty();
		} else {
			while (stateIt.hasNext()) {
				merged.putAll(stateIt.next());
			}
			merged.entrySet().removeIf(e -> e.getKey() == null || e.getValue() == null);
			return Optional.of(merged);
		}
	}

	@Override
	public void initializeState(StateInitializationContext context) throws Exception {
		super.initializeState(context);
		OperatorStateStore stateStore = context.getOperatorStateStore();
		ttlBcState = stateStore.getUnionListState(new ListStateDescriptor<>("ttlState",
				new HashMapTypeInfo<>(BasicTypeInfo.STRING_TYPE_INFO, BasicTypeInfo.LONG_TYPE_INFO)));

		typeBcState = stateStore.getUnionListState(
				new ListStateDescriptor<>("descriptorState", new HashMapTypeInfo<>(BasicTypeInfo.STRING_TYPE_INFO,
						PrimitiveArrayTypeInfo.BYTE_PRIMITIVE_ARRAY_TYPE_INFO)));
	}

	@Override
	public void snapshotState(StateSnapshotContext context) throws Exception {
		ttlBcState.clear();
		ttlBcState.add(ttlDurations);

		typeBcState.clear();
		HashMap<String, byte[]> m = new HashMap<>();
		for (Entry<String, ValueStateDescriptor<?>> e : descriptors.entrySet()) {
			if (ttlDurations.containsKey(e.getKey())) {
				m.put(e.getKey(), InstantiationUtil.serializeObject(e.getValue().getSerializer()));
			}
		}
		typeBcState.add(m);

		super.snapshotState(context);
	}

	private class StateExpiryTimers implements Triggerable<Object, VoidNamespace> {

		@Override
		public void onEventTime(InternalTimer<Object, VoidNamespace> timer) throws Exception {
			LOG.trace("On State Expiry Timer: {}", timer);
			if (ttlDurations.isEmpty()) {
				throw new RuntimeException("TTL map seems to empty. This indicates a bug...");
			}

			Map<String, Long> expiryTimes = stateExpiryTimes.value();
			Iterator<Entry<String, Long>> it = expiryTimes.entrySet().iterator();
			while (it.hasNext()) {
				Entry<String, Long> e = it.next();
				String name = e.getKey();
				Long expiry = e.getValue();
				if (timer.getTimestamp() >= expiry) {
					LOG.trace("Expiring state {}", name);
					ValueState<?> state = states.get(name);
					if (state == null) {
						throw new RuntimeException("Cannot find expired state. This indicates a bug...");
					}
					states.get(name).clear();
					it.remove();
				} else {
					LOG.trace("Reregistering timer to {} for {}", expiry, name);
					stateTimerService.registerEventTimeTimer(VoidNamespace.INSTANCE, expiry);
				}
			}
		}

		@Override
		public void onProcessingTime(InternalTimer<Object, VoidNamespace> arg0) throws Exception {
			throw new RuntimeException("This method should never be called...");
		}

	}

	private class UserTimers implements Triggerable<Object, Long> {

		@SuppressWarnings("unchecked")
		@Override
		public void onEventTime(InternalTimer<Object, Long> timer) throws Exception {
			LOG.trace("On User Timer: {}", timer);
			long timerId = timer.getNamespace();
			collector.setAbsoluteTimestamp(timer.getTimestamp());
			((EventProcessor<KeyContext>) userFunction)
					.onTimer(timerId,
							Instant.ofEpochMilli(timer.getTimestamp()), getContext());
			Map<Long, Long> idToTs = timersTimestamps.value();
			idToTs.remove(timerId);
			timersTimestamps.update(idToTs);
		}

		@Override
		public void onProcessingTime(InternalTimer<Object, Long> arg0) {
			throw new RuntimeException("This method should never be called...");
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public void processElement(StreamRecord<Event> in) throws Exception {
		try {
			currentEvent = in.getValue();
			currentTimestamp = Math.max(0, in.getValue().getTimeStamp());
			collector.setAbsoluteTimestamp(currentTimestamp);
			FlinkKeyContext ctx = getContext();
			Object key = getCurrentKey();
			executeWithState(key, () -> ((EventProcessor<KeyContext>) userFunction).processEvent(currentEvent, ctx));
		} catch (Exception e) {
			throw new RuntimeException(
					"Error while processing event: "
							+ DefaultEventFormat.eventFormat.format(in.getValue()),
					e);
		}
	}

	public void executeWithState(Object key, Unchecked.ThrowingRunnable runnable) throws Exception {
		Object prevKey = getCurrentKey();
		setCurrentKey(key);
		runnable.run();
		setCurrentKey(prevKey);
	}

	protected class FlinkKeyContext extends FlinkContext implements JoinContext, GlobalContext {

		@Override
		public Timers getTimers() {
			return new Timers() {

				@Override
				public long registerTimer(Instant instant) {
					return registerTimerWithId(rnd.nextLong(), instant);
				}

				@Override
				public long registerTimerWithId(long timerId, Instant instant) {
					timerService.registerEventTimeTimer(timerId, instant.toEpochMilli());
					LOG.trace("Registered user timer at {} with id {}", instant.toEpochMilli(), timerId);
					try {
						Map<Long, Long> idToTs = timersTimestamps.value();
						idToTs.put(timerId, instant.toEpochMilli());
						timersTimestamps.update(idToTs);
						return timerId;
					} catch (Exception e) {
						throw new RuntimeException(e);
					}
				}

				@Override
				public boolean removeTimer(long id) {
					try {
						Map<Long, Long> idToTs = timersTimestamps.value();
						Long ts = idToTs.remove(id);
						timersTimestamps.update(idToTs);
						LOG.trace("Removing user timer at {} with id {}", ts, id);
						if (ts != null) {
							timerService.deleteEventTimeTimer(id, ts);
							return true;
						} else {
							return false;
						}
					} catch (Exception e) {
						throw new RuntimeException(e);
					}
				}

				@Override
				public boolean removeAllTimers() {
					try {
						LOG.trace("Removing all user timers");
						Map<Long, Long> idToTs = timersTimestamps.value();
						if (idToTs.isEmpty()) {
							return false;
						}
						for (Entry<Long, Long> e : idToTs.entrySet()) {
							timerService.deleteEventTimeTimer(e.getKey(), e.getValue());
						}
						timersTimestamps.update(new HashMap<>());
						return true;
					} catch (Exception e) {
						throw new RuntimeException(e);
					}
				}
			};
		}

		@Override
		public Object getPartitionKey() {
			return getCurrentKey();
		}

		@Override
		public <T> State<T> getValueState(String name, Class<T> clazz) {
			return new KeyedLazyState<>(name, clazz);
		}

		@Override
		public <K, V> MapState<K, V> getMapState(String name, Class<K> keyType, Class<V> valueType) {
			return new MapState<>(new KeyedLazyState<>(name, keyType, valueType));
		}
	}

	private class KeyedLazyState<T> implements State<T> {

		private long ttlMillis = -1;

		private final String stateName;
		private final ValueState<T> state;

		@SuppressWarnings("unchecked")
		public KeyedLazyState(String name, Class<T> clazz) {
			this.stateName = name;
			ValueState<?> cachedState = states.get(name);
			if (cachedState == null) {
				TypeInformation<T> type = getTypeFor(clazz);
				ValueStateDescriptor<T> descriptor = new ValueStateDescriptor<>(name, type);
				state = getRuntimeContext().getState(descriptor);
				states.put(name, state);
				descriptors.put(name, descriptor);
			} else {
				state = (ValueState<T>) cachedState;
			}
		}

		@SuppressWarnings("unchecked")
		public KeyedLazyState(String name, Class<?> keyType, Class<?> valueType) {
			this.stateName = name;
			ValueState<?> cachedState = states.get(name);
			if (cachedState == null) {
				TypeInformation type = new HashMapTypeInfo<>(getTypeFor(keyType),
						getTypeFor(valueType));
				ValueStateDescriptor<T> descriptor = new ValueStateDescriptor<>(name, type);
				state = getRuntimeContext().getState(descriptor);
				states.put(name, state);
				descriptors.put(name, descriptor);
			} else {
				state = (ValueState<T>) cachedState;
			}
		}

		@SuppressWarnings("unchecked")
		private <X> TypeInformation<X> getTypeFor(Class<X> clazz) {
			if (Event.class.isAssignableFrom(clazz)) {
				return (TypeInformation<X>) new EventTypeInfo();
			}

			if (KingDataClass.class.isAssignableFrom(clazz)) {
				try {
					new SerializableSC(clazz);
					return new SemanticClassTypeInfo(clazz);
				} catch (Throwable t) {}
			}

			return TypeExtractor.getForClass(clazz);
		}

		@Override
		public State<T> clearAfter(Duration ttl) {
			ttlMillis = ttl.toMillis();
			Long prev = ttlDurations.put(stateName, ttlMillis);
			if (prev != null && ttlMillis != prev) {
				throw new RuntimeException(
						"Set different state ttl and different times. This is currently not supported.");
			}
			return this;
		}

		@Override
		public void update(T value) {
			try {
				state.update(value);
				if (ttlMillis > 0) {
					Map<String, Long> exp = stateExpiryTimes.value();
					long expiry = currentTimestamp + ttlMillis;
					exp.put(stateName, expiry);
					stateExpiryTimes.update(exp);
					long triggerTime = currentTimestamp - (currentTimestamp % ttlMillis) + ttlMillis;
					stateTimerService.registerEventTimeTimer(VoidNamespace.INSTANCE, triggerTime);
					LOG.trace("Updating TTL state {} expiring at {}. Timer at {} ", stateName, expiry, triggerTime);
				}
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}

		@Override
		public void clear() {
			try {
				state.clear();
				if (ttlMillis > 0) {
					Map<String, Long> exp = stateExpiryTimes.value();
					exp.remove(stateName);
					stateExpiryTimes.update(exp);
				}
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}

		@Override
		public Optional<T> value() {
			try {
				return Optional.ofNullable(state.value());
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}
	}

	@Override
	protected FlinkContext createContext() {
		return new FlinkKeyContext();
	}

	public FlinkKeyContext getContext() {
		return (FlinkKeyContext) processorContext;
	}
}
