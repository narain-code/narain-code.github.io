package com.king.streaming.sdk.io;

import java.io.IOException;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.esotericsoftware.minlog.Log;
import com.king.event.Event;
import com.king.event.format.EventFormat;
import com.king.event.format.EventFormatException;
import com.king.flink.utils.CustomEvent;
import com.king.flink.utils.events.LazyEventFormat;

public enum DefaultEventFormat implements InputFormat, OutputFormat {

	INSTANCE;

	protected static final Logger LOG = LoggerFactory.getLogger(DefaultEventFormat.class);

	public static final EventFormat eventFormat = new LazyEventFormat();

	@Override
	public Event deserialize(byte[] bytes) throws IOException {
		String raw = new String(bytes);
		try {
			Event parsed = eventFormat.parse(raw);
			parsed.getTimeStamp();
			parsed.getHostname();
			return parsed;
		} catch (EventFormatException e) {
			Log.error("Error while parsing event: " + raw, e);
			String stackTrace = ExceptionUtils.getStackTrace(e);
			return wrapFailure(raw, stackTrace);
		}
	}

	public static final long PARSE_ERROR = -666;

	public static Event wrapFailure(String rawEvent, String stackTrace) {
		return CustomEvent.create(PARSE_ERROR).withField(0, rawEvent).withField(1, stackTrace);
	}

	@Override
	public byte[] serialize(Event event) {
		return eventFormat.format(event).getBytes();
	}
}
