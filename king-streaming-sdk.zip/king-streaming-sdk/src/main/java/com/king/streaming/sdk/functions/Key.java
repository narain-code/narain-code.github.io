package com.king.streaming.sdk.functions;

import java.io.Serializable;

import com.king.event.Event;

public interface Key extends Serializable {
	Object getKey(Event event) throws Exception;
}
