package com.king.streaming.sdk.application;

import java.io.File;
import java.util.Properties;

import org.apache.commons.io.FileUtils;

import com.king.streaming.sdk.eventstream.Runner;
import com.king.streaming.sdk.runners.flink.FlinkOptions;
import com.king.streaming.sdk.runners.flink.FlinkRunner;

public class Launcher {

	public static void main(String[] args) throws Exception {
		if (args.length < 2) {
			System.out.println("Arguments: ApplicationClass RunnerProps ApplicationProps");
			return;
		}

		try {
			@SuppressWarnings("unchecked")
			Class<? extends Application> appClass = (Class<? extends Application>) Class.forName(args[0], true,
					Thread.currentThread().getContextClassLoader());

			Application app = appClass.newInstance();

			Runner runner = getRunner(args);

			Properties props = new Properties();
			if (args.length > 2) {
				props.load(FileUtils.openInputStream(new File(args[2])));
			}
			app.run(runner, props);

			if (!runner.wasStarted()) {
				throw new RuntimeException(
						"Runner wasn't started in the run method. Did you forget calling runner.start()?");
			}
		} catch (ClassNotFoundException e) {
			throw new RuntimeException("Could not find application class", e);
		}
	}

	private static Runner getRunner(String[] args) throws Exception {
		FlinkOptions opt = FlinkOptions.fromProperties(args[1]);
		return FlinkRunner.create(opt);
	}

}
