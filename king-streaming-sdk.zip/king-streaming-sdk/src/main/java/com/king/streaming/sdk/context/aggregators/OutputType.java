package com.king.streaming.sdk.context.aggregators;

public enum OutputType {
	MYSQL, PRINT, KAFKA
}
