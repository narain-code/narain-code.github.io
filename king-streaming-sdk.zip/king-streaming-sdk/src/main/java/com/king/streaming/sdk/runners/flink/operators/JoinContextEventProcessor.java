/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.king.streaming.sdk.runners.flink.operators;

import java.util.Map;

import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;

import com.king.event.Event;
import com.king.streaming.sdk.context.KeyContext;
import com.king.streaming.sdk.eventstream.BroadcastState;
import com.king.streaming.sdk.eventstream.join.JoinField;
import com.king.streaming.sdk.functions.EventProcessor;
import com.king.streaming.sdk.io.DefaultEventFormat;
import com.king.streaming.sdk.runners.flink.FlinkEventProcessor;

public class JoinContextEventProcessor extends KeyContextEventProcessor {

	private static final long serialVersionUID = 1L;
	private JoinField<?>[] joinFields;

	public JoinContextEventProcessor(FlinkEventProcessor<?> processor, Map<BroadcastState<?>, Short> bcStateMapping,
			JoinField<?>[] joinFields) {
		super(processor, bcStateMapping);
		this.joinFields = joinFields;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void processElement(StreamRecord<Event> in) throws Exception {
		try {
			currentTimestamp = Math.max(0, in.getValue().getTimeStamp());
			collector.setAbsoluteTimestamp(currentTimestamp);
			currentEvent = in.getValue();

			FlinkKeyContext ctx = getContext();
			Object key = getCurrentKey();
			setCurrentKey(key);

			boolean fire = true;
			for (JoinField<?> condition : joinFields) {
				if (!condition.check(currentEvent, ctx) && !condition.allowsMissing()) {
					fire = false;
				}
			}

			if (fire) {
				executeWithState(key, () -> {
					((EventProcessor<KeyContext>) userFunction).processEvent(currentEvent, ctx);
					for (JoinField<?> condition : joinFields) {
						condition.postProcess(currentEvent, ctx);
					}
				});
			} else {
				executeWithState(key, () -> {});
			}
			currentEvent = null;
		} catch (Exception e) {
			throw new RuntimeException(
					"Error while processing event: "
							+ DefaultEventFormat.eventFormat.format(in.getValue()),
					e);
		}
	}
}
