package com.king.streaming.sdk.runners.flink.operators;

import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.typeutils.ResultTypeQueryable;
import org.apache.flink.types.Either;
import org.apache.flink.util.Collector;

import com.king.event.Event;
import com.king.streaming.sdk.runners.flink.types.AggregateEvent;

public class OutputToRight
		implements FlatMapFunction<Either<Event, AggregateEvent>, AggregateEvent>, ResultTypeQueryable<AggregateEvent> {
	private static final long serialVersionUID = 1L;

	@Override
	public TypeInformation<AggregateEvent> getProducedType() {
		return AggregateEvent.TYPEINFO;
	}

	@Override
	public void flatMap(Either<Event, AggregateEvent> in, Collector<AggregateEvent> out) throws Exception {
		if (in.isRight()) {
			out.collect(in.right());
		}
	}

}
