package com.king.streaming.sdk.eventstream;

import java.util.List;

import com.google.common.collect.Lists;
import com.king.event.Event;
import com.king.streaming.sdk.application.Environment;
import com.king.streaming.sdk.context.Context;
import com.king.streaming.sdk.io.kafka.KafkaInput;

/**
 * The {@link Runner} is the entry point of any streaming application. It can be
 * used to create {@link EventStream}s and to start the application.
 *
 */
public interface Runner {

	/**
	 * Create {@link EventStream} by reading from Kafka
	 * 
	 * @param topic
	 * @param groupId
	 * @return EventStream containing the events from the Kafka topic
	 */
	default KafkaInput readFromKafka(String topic, String groupId) {
		return readFromKafka(Lists.newArrayList(topic), groupId);
	}

	void setEventTimeExtractor(TimestampExtractor extractor);

	Environment getEnvironment();

	/**
	 * Create {@link EventStream} by reading from Kafka
	 * 
	 * @param topics
	 * @param groupId
	 * @return EventStream containing the events from the Kafka topics
	 */
	KafkaInput readFromKafka(List<String> topics, String groupId);

	/**
	 * Create {@link EventStream} containing the provided events
	 * 
	 * @param events
	 * @return EventStream containing the given events
	 */
	EventStream<Context> createEventStream(Event... events);

	/**
	 * Executes the streaming application, this call blocks until the execution is
	 * done.
	 * 
	 * @throws Exception
	 */
	void start() throws Exception;

	/**
	 * @return True iff the {@link #start()} method was called on the runner
	 */
	boolean wasStarted();
}
