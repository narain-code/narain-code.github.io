package com.king.streaming.sdk.eventstream.join;

import java.io.Serializable;
import java.util.Optional;

import org.apache.flink.util.InstantiationUtil;

import com.king.event.Event;
import com.king.streaming.sdk.context.JoinContext;
import com.king.streaming.sdk.context.KeyContext;
import com.king.streaming.sdk.context.State;
import com.king.streaming.sdk.functions.StateFolder;

public class Aggregate<T> extends JoinField<T> {

	private static final long serialVersionUID = 1L;
	public final StateFolder<T> folder;
	public final Serializable initialValue;
	private final Class<T> stateClass;
	private final String uid;

	@SuppressWarnings("unchecked")
	private Aggregate(StateFolder<T> folder, T initialValue) {
		this.folder = folder;
		this.initialValue = (Serializable) initialValue;
		this.stateClass = (Class<T>) (initialValue != null ? initialValue.getClass() : Object.class);
		uid = "" + folder.hashCode() + (initialValue != null ? initialValue.hashCode() : "");
	}

	@SuppressWarnings("unchecked")
	public JoinField<T> copy() {
		return of(folder, (T) initialValue);
	}

	public static <T> Aggregate<T> of(StateFolder<T> folder, T initialValue) {
		return new Aggregate<>(folder, initialValue);
	}

	@Override
	public boolean check(Event e, JoinContext ctx) throws Exception {
		State<T> aggregateState = getTTLState(ctx, getUUID(), stateClass);
		aggregateState.update(folder.fold(aggregateState.value().orElseGet(this::getInitialValue), e, ctx));
		return true;
	}

	@SuppressWarnings("unchecked")
	private T getInitialValue() {
		if (broadcasted) {
			return (T) initialValue;
		}
		try {
			return (T) InstantiationUtil.clone(initialValue);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public Optional<T> getValue(JoinContext ctx) throws Exception {
		Optional<T> value = getTTLState(ctx, getUUID(), stateClass).value();
		return value.isPresent() ? value : Optional.ofNullable(getInitialValue());
	}

	@Override
	public void deleteCompletely(KeyContext ctx) {
		getTTLState(ctx, getUUID(), stateClass).clear();
	}

	@Override
	public String getUUID() {
		return uid;
	}

}
