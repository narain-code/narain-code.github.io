package com.king.streaming.sdk.runners.flink;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.functions.RichFilterFunction;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.typeutils.EitherTypeInfo;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.transformations.StreamTransformation;
import org.apache.flink.streaming.api.transformations.UnionTransformation;
import org.apache.flink.types.Either;

import com.king.event.Event;
import com.king.flink.utils.types.EventTypeInfo;
import com.king.streaming.sdk.context.Context;
import com.king.streaming.sdk.context.GlobalContext;
import com.king.streaming.sdk.context.KeyContext;
import com.king.streaming.sdk.eventstream.BroadcastState;
import com.king.streaming.sdk.eventstream.EventStream;
import com.king.streaming.sdk.eventstream.ResultIterator;
import com.king.streaming.sdk.functions.EventFilter;
import com.king.streaming.sdk.functions.EventProcessor;
import com.king.streaming.sdk.functions.Key;
import com.king.streaming.sdk.io.DefaultEventFormat;
import com.king.streaming.sdk.io.kafka.KafkaOutput;
import com.king.streaming.sdk.runners.flink.operators.CollectingSink;
import com.king.streaming.sdk.runners.flink.operators.ContextEventProcessor;
import com.king.streaming.sdk.runners.flink.operators.OutputToLeft;
import com.king.streaming.sdk.runners.flink.operators.OutputToRight;
import com.king.streaming.sdk.runners.flink.operators.ToTupleStream;
import com.king.streaming.sdk.runners.flink.types.AggregateEvent;
import com.king.streaming.sdk.runners.flink.utils.ConnectedStreamUtils;

public class FlinkEventStream<C extends Context> implements EventStream<C>, DataStreamWrapper {

	public final static TypeInformation<Event> eventType = new EventTypeInfo();
	public final static TypeInformation<Either<Event, AggregateEvent>> outType = new EitherTypeInfo<>(eventType,
			AggregateEvent.TYPEINFO);

	private final DataStream<Event> inputStream;
	protected final FlinkRunner runner;
	protected final Collection<BroadcastState<?>> broadcastStates;
	private UUID id = UUID.randomUUID();

	protected FlinkEventStream(FlinkRunner runner, DataStream<Event> inputStream) {
		this(runner, inputStream, new ArrayList<>());
	}

	protected FlinkEventStream(FlinkRunner runner, DataStream<Event> inputStream,
			Collection<BroadcastState<?>> broadcastStates) {
		this.runner = runner;
		this.inputStream = inputStream;
		this.broadcastStates = broadcastStates;
	}

	@Override
	public FlinkProcessorOutput process(EventProcessor<C> eventProcessor) {
		Map<BroadcastState<?>, Short> bcsMapping = getStateMapping();
		ContextEventProcessor procesor = new ContextEventProcessor(
				new FlinkEventProcessor<>(runner.clean(eventProcessor)), bcsMapping);

		Tuple2<SingleOutputStreamOperator<Either<Event, AggregateEvent>>, SingleOutputStreamOperator<AggregateEvent>> out = applyProcess(
				procesor, bcsMapping);

		SingleOutputStreamOperator<Either<Event, AggregateEvent>> outStream = out.f0.name(eventProcessor.name());

		if (inputStream instanceof SingleOutputStreamOperator<?>) {
			outStream.setParallelism(((SingleOutputStreamOperator<?>) inputStream).getParallelism());
			out.f1.setParallelism(((SingleOutputStreamOperator<?>) inputStream).getParallelism());
		}

		return new FlinkProcessorOutput(runner,
				outStream.flatMap(new OutputToLeft())
						.name("Select Events")
						.setParallelism(outStream.getParallelism()),
				out.f1);
	}

	protected Map<BroadcastState<?>, Short> getStateMapping() {
		if (broadcastStates.isEmpty()) {
			return null;
		}

		Map<BroadcastState<?>, Short> mapping = new HashMap<>();
		short i = 0;
		for (BroadcastState<?> bcs : broadcastStates) {
			mapping.put(bcs, i++);
		}
		return mapping;
	}

	protected Tuple2<SingleOutputStreamOperator<Either<Event, AggregateEvent>>, SingleOutputStreamOperator<AggregateEvent>> applyProcess(
			ContextEventProcessor procesor,
			Map<BroadcastState<?>, Short> bcsMapping) {
		DataStream<Tuple2<Short, Event>> stateStream = createBroadcastStream(bcsMapping);

		SingleOutputStreamOperator<Either<Event, AggregateEvent>> output = null;
		if (stateStream == null) {
			output = inputStream.transform("Process", outType, procesor);
		} else {
			output = ConnectedStreamUtils.executeWithBroadcast(inputStream.connect(stateStream), procesor);
		}

		SingleOutputStreamOperator<AggregateEvent> aggregateEvents = output.flatMap(new OutputToRight())
				.name("Select Aggregates");
		runner.addWindowInput(aggregateEvents);
		return Tuple2.of(output, aggregateEvents);
	}

	@Override
	public EventStream<Context> union(EventStream<?>... eventStreams) {
		return union(this, eventStreams);
	}

	@Override
	public FlinkKeyedEventStream<KeyContext> keyBy(Key key) {
		Key k = runner.clean(key);
		return new FlinkKeyedEventStream<>(runner, inputStream.keyBy(new FlinkKeyWrapper(k)), k, broadcastStates);
	}

	@SuppressWarnings("unchecked")
	@Override
	public EventStream<C> filter(EventFilter eventFilter) {
		StreamTransformation<Event> transformation = inputStream.getTransformation();
		if (transformation instanceof UnionTransformation) {

			List<EventStream<?>> inputs = ((UnionTransformation<?>) transformation)
					.getInputs()
					.stream()
					.map(t -> new FlinkEventStream<>(
							runner,
							(DataStream<Event>) new DataStream<>(inputStream.getExecutionEnvironment(), t))
									.filter(eventFilter))
					.collect(Collectors.toList());

			EventStream<?> first = inputs.get(0);
			for (int i = 1; i < inputs.size(); i++) {
				first = first.union(inputs.get(i));
			}
			return (EventStream<C>) first;
		} else {
			EventFilter cleaned = runner.clean(eventFilter);
			SingleOutputStreamOperator<Event> outStream = inputStream.filter(new RichFilterFunction<Event>() {
				private static final long serialVersionUID = 1L;

				EventFilter f = cleaned;

				@Override
				public boolean filter(Event event) throws Exception {
					try {
						return f.filter(event);
					} catch (Exception e) {
						throw new RuntimeException(
								"Error while processing event: " + DefaultEventFormat.eventFormat.format(event),
								e);
					}
				}

				@Override
				public void open(Configuration c) throws Exception {
					f.open();
				}

				@Override
				public void close() throws Exception {
					f.close();
				}
			}).name(cleaned.name());
			outStream.setParallelism(inputStream.getParallelism());
			return new FlinkEventStream<>(runner, outStream);
		}
	}

	@Override
	public DataStream<Event> getWrappedStream() {
		return inputStream;
	}

	protected static EventStream<Context> union(EventStream<?> first, EventStream<?>[] eventStreams) {
		@SuppressWarnings("unchecked")
		DataStream<Event>[] streams = new DataStream[eventStreams.length];
		for (int i = 0; i < streams.length; i++) {
			EventStream<?> es = eventStreams[i];
			streams[i] = ((DataStreamWrapper) es).getWrappedStream();
		}

		return new FlinkEventStream<>(((DataStreamWrapper) first).getRunner(),
				((DataStreamWrapper) first).getWrappedStream().union(streams));
	}

	public FlinkRunner getRunner() {
		return runner;
	}

	@Override
	public void print() {
		inputStream.map(new MapFunction<Event, String>() {
			private static final long serialVersionUID = 1L;

			@Override
			public String map(Event value) throws Exception {
				try {
					return DefaultEventFormat.eventFormat.format(value);
				} catch (Exception e) {
					return value.toString();
				}
			}
		}).print();
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public FlinkProcessorOutput processGlobal(EventProcessor<GlobalContext> eventProcessor) {
		FlinkProcessorOutput output = keyBy(e -> 0).process((EventProcessor) eventProcessor);
		output.getFlinkOperator().setParallelism(1);
		return output;
	}

	@Override
	public KafkaOutput writeToKafka(String topic) {
		FlinkKafkaOutput output = new FlinkKafkaOutput(runner, inputStream, topic);
		runner.addOutput(output);
		return output;
	}

	@Override
	public ResultIterator collect() {
		CollectingSink sink = new CollectingSink();
		inputStream.addSink(sink).name("Collect result").setParallelism(1);
		return sink;
	}

	private DataStream<Tuple2<Short, Event>> createBroadcastStream(Map<BroadcastState<?>, Short> bcsMapping) {
		if (bcsMapping == null) {
			return null;
		} else {
			List<DataStream<Tuple2<Short, Event>>> streams = bcsMapping.entrySet().stream()
					.map(bcsEntry -> {
						DataStream<Event> in = ((DataStreamWrapper) bcsEntry.getKey().eventStream).getWrappedStream();
						return in.map(new ToTupleStream(bcsEntry.getValue()))
								.setParallelism(in.getParallelism())
								.name("Attach ID");
					}).collect(Collectors.toList());

			DataStream<Tuple2<Short, Event>> first = streams.get(0);
			for (int i = 1; i < streams.size(); i++) {
				first = first.union(streams.get(i));
			}
			return first.broadcast();
		}
	}

	@Override
	public <X extends Context> EventStream<C> withBroadcastState(BroadcastState<?>... states) {
		if (states.length == 0) {
			throw new RuntimeException("At least one broadcast state needs to be passed to this method");
		}
		Collection<BroadcastState<?>> newStates = new ArrayList<>(broadcastStates);
		for (BroadcastState<?> state : states) {
			newStates.add(state);
		}

		return new FlinkEventStream<>(runner, inputStream, newStates);
	}

	@Override
	public UUID getUUID() {
		return id;
	}

}
