package com.king.streaming.sdk.runners.flink.operators;

import java.util.Map;
import java.util.regex.Pattern;

import org.apache.flink.types.Either;
import org.apache.flink.util.Collector;

import com.king.event.Event;
import com.king.streaming.sdk.context.Aggregators;
import com.king.streaming.sdk.context.aggregators.AggregationWindow;
import com.king.streaming.sdk.context.aggregators.Counter;
import com.king.streaming.sdk.context.aggregators.OutputType;
import com.king.streaming.sdk.context.aggregators.SumAggregator;
import com.king.streaming.sdk.runners.flink.types.AggregateEvent;

public class CollectingAggregators implements Aggregators {

	private Collector<Either<Event, AggregateEvent>> collector;
	private static final Pattern VALID_TABLE_NAME_REGEX = Pattern.compile("^[a-zA-Z_][a-zA-Z0-9_]{0,63}$");
	private static final Pattern WHITESPACE_REGEX = Pattern.compile("\\s+");

	public CollectingAggregators(Collector<Either<Event, AggregateEvent>> collector) {
		this.collector = collector;
	}

	@Override
	public CollectingCounter getCounter(String name, AggregationWindow windowSize, OutputType outputType) {
		return new CollectingCounter(name, windowSize.toMillis(), outputType);
	}

	@Override
	public CollectingSum getSumAggregator(String name, AggregationWindow windowSize, OutputType outputType) {
		return new CollectingSum(name.toString(), windowSize.toMillis(), outputType);
	}

	private class CollectingCounter implements Counter {
		private final CollectingSum sumAgg;

		private CollectingCounter(Object name, long millis, OutputType type) {
			sumAgg = new CollectingSum(name.toString(), millis, type);
		}

		@Override
		public void increment() {
			sumAgg.add(1);
		}

		@Override
		public void decrement() {
			sumAgg.add(-1);
		}

		@Override
		public Counter setNamedDimensions(Map<String, ?> dimensions) {
			sumAgg.setNamedDimensions(dimensions);
			return this;
		}

	}

	private class CollectingSum implements SumAggregator {

		String name;
		Map<String, ?> dimensions = null;
		final long windowSizeMillis;
		final OutputType type;

		public CollectingSum(String name, long bucketSizeMillis, OutputType type) {
			if (bucketSizeMillis < 1) {
				throw new RuntimeException("Bucket size must be greater than zero.");
			}

			if (name.equals("")) {
				throw new RuntimeException("Aggregator name cannot be empty.");
			}

			this.name = WHITESPACE_REGEX.matcher(name.trim()).replaceAll("_");

			if (type == OutputType.MYSQL && !VALID_TABLE_NAME_REGEX.matcher(this.name).matches()) {
				throw new RuntimeException(
						"Aggregator name needs to be a valid MySQL table name if MySQL OutputType is used.");
			}

			this.type = type;
			this.windowSizeMillis = bucketSizeMillis;
		}

		@Override
		public void add(long num) {
			collector.collect(Either.Right(new AggregateEvent(type, name, windowSizeMillis, dimensions, num)));
		}

		@Override
		public SumAggregator setNamedDimensions(Map<String, ?> dimensions) {
			this.dimensions = dimensions;
			return this;
		}

	}

}
