package com.king.streaming.sdk.runners.flink;

import java.time.Instant;

import org.apache.flink.api.common.functions.AbstractRichFunction;
import org.apache.flink.configuration.Configuration;

import com.king.event.Event;
import com.king.streaming.sdk.context.Context;
import com.king.streaming.sdk.functions.EventProcessor;

public class FlinkEventProcessor<C extends Context> extends AbstractRichFunction implements EventProcessor<C> {
	private static final long serialVersionUID = 1L;
	private final EventProcessor<C> processor;

	public FlinkEventProcessor(EventProcessor<C> processor) {
		this.processor = processor;
	}

	@Override
	public void processEvent(Event event, C ctx) throws Exception {
		processor.processEvent(event, ctx);
	}

	@Override
	public void open(Configuration c) throws Exception {
		processor.open();
	}

	@Override
	public void close() throws Exception {
		processor.close();
	}

	@Override
	public void onWatermark(Instant wm, C ctx) throws Exception {
		processor.onWatermark(wm, ctx);
	}

	@Override
	public void onTimer(long tiemrId, Instant timestamp, C ctx) throws Exception {
		processor.onTimer(tiemrId, timestamp, ctx);
	}

}
