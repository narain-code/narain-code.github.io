package com.king.streaming.sdk.context;

import com.king.streaming.sdk.eventstream.EventStream;

/**
 * A {@link Context} with access to global functionality such as global timers
 * and state. Accessible when applying {@link EventStream#processGlobal()}
 */
public interface GlobalContext extends StatefulContext {

}
