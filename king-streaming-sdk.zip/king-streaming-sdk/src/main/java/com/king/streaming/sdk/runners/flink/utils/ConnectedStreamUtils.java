package com.king.streaming.sdk.runners.flink.utils;

import java.lang.reflect.Constructor;

import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.ConnectedStreams;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.KeyedStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.operators.TwoInputStreamOperator;
import org.apache.flink.streaming.api.transformations.StreamTransformation;
import org.apache.flink.streaming.api.transformations.TwoInputTransformation;
import org.apache.flink.types.Either;

import com.king.event.Event;
import com.king.streaming.sdk.runners.flink.FlinkEventStream;
import com.king.streaming.sdk.runners.flink.types.AggregateEvent;

public class ConnectedStreamUtils {

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static SingleOutputStreamOperator<Either<Event, AggregateEvent>> executeWithBroadcast(
			ConnectedStreams<Event, Tuple2<Short, Event>> connectedStream,
			TwoInputStreamOperator<Event, Tuple2<Short, Event>, Either<Event, AggregateEvent>> operator) {

		DataStream<Event> inputStream1 = connectedStream.getFirstInput();
		DataStream<Tuple2<Short, Event>> inputStream2 = connectedStream.getSecondInput();
		StreamExecutionEnvironment environment = inputStream1.getExecutionEnvironment();

		TwoInputTransformation<Event, Tuple2<Short, Event>, Either<Event, AggregateEvent>> transform = new TwoInputTransformation<>(
				inputStream1.getTransformation(),
				inputStream2.getTransformation(),
				"Co-FlatMap",
				operator,
				FlinkEventStream.outType,
				environment.getParallelism());

		if (inputStream1 instanceof KeyedStream) {
			KeyedStream<Event, ?> keyedInput1 = (KeyedStream<Event, ?>) inputStream1;

			TypeInformation<?> keyType1 = keyedInput1.getKeyType();

			transform.setStateKeySelectors(keyedInput1.getKeySelector(), null);
			transform.setStateKeyType(keyType1);
		}

		// You can't stop me...muhahaha
		Constructor<SingleOutputStreamOperator> constructor;
		try {
			constructor = (Constructor<SingleOutputStreamOperator>) SingleOutputStreamOperator.class
					.getDeclaredConstructor(StreamExecutionEnvironment.class, StreamTransformation.class);
			constructor.setAccessible(true);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}

		SingleOutputStreamOperator<Either<Event, AggregateEvent>> returnStream = null;
		try {
			returnStream = constructor.newInstance(environment, transform);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}

		environment.addOperator(transform);
		return returnStream;
	}
}
