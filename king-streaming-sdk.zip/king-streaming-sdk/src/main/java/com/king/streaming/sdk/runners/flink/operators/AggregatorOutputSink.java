package com.king.streaming.sdk.runners.flink.operators;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.Optional;
import java.util.TreeMap;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentSkipListMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.streaming.api.functions.sink.SinkFunction;

import com.king.streaming.sdk.context.aggregators.AggregatorOutput;
import com.king.streaming.sdk.runners.flink.types.AggregateEvent;

public class AggregatorOutputSink implements SinkFunction<AggregateEvent>, AggregatorOutput {

	private static final long serialVersionUID = 1L;

	private static final List<Map<String, NavigableMap<Long, Map<String, Long>>>> allLists = Collections
			.synchronizedList(new ArrayList<>());

	private static final List<Map<Tuple3<String, String, Long>, CompletableFuture<Long>>> pollFutures = Collections
			.synchronizedList(new ArrayList<>());

	private static final AtomicInteger index = new AtomicInteger(0);
	private int i;

	public AggregatorOutputSink() {
		allLists.add(new ConcurrentHashMap<>());
		pollFutures.add(new ConcurrentHashMap<>());
		i = index.getAndIncrement();
	}

	@Override
	public void invoke(AggregateEvent agg) throws Exception {
		NavigableMap<Long, Map<String, Long>> tableValues = allLists.get(i).getOrDefault(agg.getName(),
				new ConcurrentSkipListMap<>());
		Map<String, Long> dimValues = tableValues.getOrDefault(agg.getWindowSize(), new ConcurrentHashMap<>());

		dimValues.put(agg.getDimensions(), agg.getValue());

		tableValues.put(agg.getTimeStamp(), dimValues);
		allLists.get(i).put(agg.getName(), tableValues);

		Tuple3<String, String, Long> t = Tuple3.of(agg.getName(), agg.getDimensions(), agg.getTimeStamp());
		if (pollFutures.get(i).containsKey(t)) {
			pollFutures.get(i).get(t).complete(agg.getValue());
		}
	}

	@Override
	public Optional<Long> getValue(String aggregatorName, Map<String, ?> dims, long timeStamp) {
		return Optional.ofNullable(allLists.get(i)
				.getOrDefault(aggregatorName, new TreeMap<>())
				.getOrDefault(timeStamp, new HashMap<>())
				.get(AggregateEvent.getJSON(dims)));
	}

	@Override
	public NavigableMap<Long, Map<String, Long>> getAllValues(String aggregatorName) {
		return allLists.get(i).get(aggregatorName);
	}

	@Override
	public Collection<String> getAggregatorNames() {
		return allLists.get(i).keySet();
	}

	@Override
	public String toString() {
		return allLists.toString();
	}

	@Override
	public long pollValue(Duration timeout, String aggregatorName, Map<String, ?> dims, long timeStamp)
			throws TimeoutException {
		CompletableFuture<Long> pollFuture = new CompletableFuture<>();
		Tuple3<String, String, Long> t = Tuple3.of(aggregatorName, AggregateEvent.getJSON(dims), timeStamp);

		Optional<Long> val = getValue(aggregatorName, dims, timeStamp);

		if (val.isPresent()) {
			return val.get();
		} else {
			pollFutures.get(i).put(t, pollFuture);
			// We need to check again
			val = getValue(aggregatorName, dims, timeStamp);
			if (val.isPresent()) {
				pollFutures.get(i).remove(t);
				return val.get();
			} else {
				try {
					return pollFuture.get(timeout.toMillis(), TimeUnit.MILLISECONDS);
				} catch (InterruptedException | ExecutionException e) {
					throw new RuntimeException(e);
				}
			}
		}

	}

}
