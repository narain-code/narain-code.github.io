package com.king.streaming.sdk.examples;

import java.util.Optional;

import org.junit.Test;

import com.king.constants.EventType;
import com.king.event.Event;
import com.king.kgk.SCClientStart;
import com.king.kgk.SCGameEnd;
import com.king.kgk.SCGameStart;
import com.king.kgk.SCPurchase;
import com.king.streaming.sdk.context.Context;
import com.king.streaming.sdk.context.JoinContext;
import com.king.streaming.sdk.context.KeyContext;
import com.king.streaming.sdk.context.aggregators.AggregationWindow;
import com.king.streaming.sdk.events.CustomEvent;
import com.king.streaming.sdk.eventstream.BroadcastState;
import com.king.streaming.sdk.eventstream.EventStream;
import com.king.streaming.sdk.eventstream.JoinedEventStream;
import com.king.streaming.sdk.eventstream.KeyedEventStream;
import com.king.streaming.sdk.eventstream.Runner;
import com.king.streaming.sdk.eventstream.join.JoinField;
import com.king.streaming.sdk.eventstream.join.Last;
import com.king.streaming.sdk.eventstream.join.Match;
import com.king.streaming.sdk.eventstream.join.Pair;
import com.king.streaming.sdk.eventstream.join.abtest.ABTestAssignments;
import com.king.streaming.sdk.eventstream.join.abtest.ABTests;
import com.king.streaming.sdk.functions.EventProcessor;
import com.king.streaming.sdk.runners.flink.FlinkRunner;

@SuppressWarnings("unused")
public class ExampleProgram {

	private static Last<SCGameStart> lastGS = Last.semanticClass(SCGameStart.class);
	private static Last<Event> lastABCase = Last.eventType(EventType.AbTestCaseAssigned);

	@Test
	public void testTopologyCreation() {
		Runner runner = FlinkRunner.create("Test");

		EventStream<Context> events = runner.createEventStream(CustomEvent.create(0));
		KeyedEventStream<KeyContext> keyed = events.keyByCoreUserID();

		EventStream<Context> currencyStream = runner.createEventStream(CustomEvent.create(0));
		EventStream<Context> purchases = events.filter(SCPurchase.class);

		BroadcastState<Event> lastCurrency = currencyStream.broadcast(Last.fromFilter(e -> true));

		purchases = purchases.withBroadcastState(lastCurrency);
		purchases.process(new EventProcessor<Context>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void processEvent(Event event, Context ctx) throws Exception {
				Event currency = ctx.getBroadcastState(lastCurrency).get();
			}

		});

		Match<Pair<SCGameStart, Event>> matchTwo = Match.once(
				Last.semanticClass(SCGameStart.class),
				Last.eventType(EventType.AbTestCaseAssigned));

		Match<Object[]> matchAll = Match.once(
				Last.semanticClass(SCClientStart.class),
				Last.semanticClass(SCGameStart.class),
				Last.semanticClass(SCGameEnd.class));

		KeyedEventStream<KeyContext> eventStream = runner.createEventStream(CustomEvent.create(0)).keyByCoreUserID();

		JoinField<ABTestAssignments> assignmentField = ABTests.createAssignmentInfo();

		eventStream.join(assignmentField).process((e, ctx) -> {
			Optional<ABTestAssignments> opt = ctx.getJoined(assignmentField);

			opt.ifPresent(assignments -> {
				Integer caseNum = assignments.getCaseNum("name", 3).orElse(-1);
				ctx.getAggregators()
						.getCounter("", AggregationWindow.MINUTES_10)
						.setDimensions(caseNum)
						.increment();
			});

		});

		purchases.keyByCoreUserID()
				.join(assignmentField)
				.process((event, jctx) -> {
					ABTestAssignments assignments = jctx.getMatched(assignmentField);
					assignments.getCaseNum("asd", 1);

				});

	}

}
