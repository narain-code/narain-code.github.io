package com.king.streaming.sdk.utils;

import static java.util.Arrays.asList;
import static org.junit.Assert.assertEquals;

import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;

import com.king.event.Event;
import com.king.streaming.sdk.events.CustomEvent;
import com.king.streaming.sdk.functions.EventFilter;

@RunWith(Parameterized.class)
public class StreamUtilsTest {

	static final Event EVENT = CustomEvent.create(-1).withTimeStamp(0);

	@Parameters
	public static Collection<Object[]> data() {
		return asList(new Object[][] {
			{ $(), false },
			{ $(e -> false), false },
			{ $(e -> true), true },
			{ $(e -> false, e -> false), false },
			{ $(e -> true, e -> false), true },
			{ $(e -> false, e -> true), true },
			{ $(e -> true, e -> true), true },
		});
	}

	@Parameter(0)
	public EventFilter[] filters;

	@Parameter(1)
	public boolean expected;

	@Test
	public void testAnyFilter() throws Exception {
		assertEquals(expected, StreamUtils.anyOf(filters).filter(EVENT));
	}

	private static EventFilter[] $(EventFilter... filters) {
		return filters;
	}

}
