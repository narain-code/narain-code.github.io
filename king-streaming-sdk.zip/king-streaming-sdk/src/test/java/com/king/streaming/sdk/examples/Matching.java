package com.king.streaming.sdk.examples;

import java.time.Duration;
import java.util.List;

import org.junit.Test;

import com.king.event.Event;
import com.king.kgk.SCAbTestCaseAssignment;
import com.king.kgk.SCGameStart;
import com.king.kgk.SCItemTransaction;
import com.king.kgk.SCPurchase;
import com.king.streaming.sdk.context.Context;
import com.king.streaming.sdk.context.KeyContext;
import com.king.streaming.sdk.eventstream.EventStream;
import com.king.streaming.sdk.eventstream.KeyedEventStream;
import com.king.streaming.sdk.eventstream.Runner;
import com.king.streaming.sdk.eventstream.join.All;
import com.king.streaming.sdk.eventstream.join.Current;
import com.king.streaming.sdk.eventstream.join.Last;
import com.king.streaming.sdk.eventstream.join.Match;
import com.king.streaming.sdk.eventstream.join.Pair;
import com.king.streaming.sdk.runners.flink.FlinkRunner;

@SuppressWarnings("unused")
public class Matching {

	@Test
	public void testTopologyCreation() {
		Runner runner = FlinkRunner.create("Test");

		EventStream<Context> events = runner.readFromKafka("event1.log", "group");
		KeyedEventStream<KeyContext> keyed = events.keyByCoreUserID();

		Last<SCGameStart> lastGs = Last.semanticClass(SCGameStart.class);
		Last<SCPurchase> lastP = Last.semanticClass(SCPurchase.class);

		Current<SCAbTestCaseAssignment> currentAB = Current.semanticClass(SCAbTestCaseAssignment.class);
		Current<SCPurchase> currentP = Current.semanticClass(SCPurchase.class);

		Match.once(lastGs, lastP).within(Duration.ofHours(8)).withCleanupAfter(Duration.ofDays(7));

		keyed.join(lastGs);

		Match<Pair<Event, List<SCItemTransaction>>> m = Match.continuously(
				Last.fromFilter(e -> {
					SCItemTransaction it = SCItemTransaction.process(e);
					return it != null && it.getItemType().equals(40100) && it.getAmount() >= 100;
				}),
				All.semanticClass(SCItemTransaction.class));

		keyed.match(m, (matched, ctx) -> {

			System.out.println();
		});

	}

}
