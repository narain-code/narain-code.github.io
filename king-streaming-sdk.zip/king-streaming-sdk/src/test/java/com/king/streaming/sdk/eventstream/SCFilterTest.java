package com.king.streaming.sdk.eventstream;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.Serializable;

import org.apache.commons.lang3.SerializationUtils;
import org.junit.Test;

import com.king.streaming.sdk.SCLong;
import com.king.streaming.sdk.events.CustomEvent;
import com.king.streaming.sdk.functions.EventFilter;
import com.king.streaming.sdk.runners.flink.FlinkRunner;
import com.king.streaming.sdk.utils.StreamUtils;
import com.king.utils.ClosureCleaner;

public class SCFilterTest implements Serializable {

	private static final long serialVersionUID = 1L;

	@Test
	public void serializationTest() throws Exception {

		EventFilter f = StreamUtils.filterBySemClass(SCLong.class);
		ClosureCleaner.clean(f, true);

		EventFilter fds = (EventFilter) SerializationUtils.deserialize(SerializationUtils.serialize(f));
		fds.open();

		assertTrue(fds.filter(CustomEvent.create(0).withField(0, "2")));
	}

	@Test
	public void simpleTest() throws Exception {

		TestRunner runner = FlinkRunner.create("test");

		ManualEventStream manualStream = runner.createManualStream();

		ResultIterator output = manualStream
				.filter(SCLong.class)
				.collect();

		runner.startTest();

		manualStream.sendEvent(CustomEvent.create(0).withField(0, "a"));
		manualStream.sendEvent(CustomEvent.create(1).withField(0, "2"));
		assertEquals(1, output.poll().getEventType());
		manualStream.sendEvent(CustomEvent.create(0).withField(0, "b"));
		manualStream.sendEvent(CustomEvent.create(2).withField(0, "3"));
		assertEquals(2, output.poll().getEventType());
		runner.stopTest();
	}
}
