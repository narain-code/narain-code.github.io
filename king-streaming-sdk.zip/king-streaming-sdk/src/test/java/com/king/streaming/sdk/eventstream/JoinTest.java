package com.king.streaming.sdk.eventstream;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import java.time.Duration;
import java.time.Instant;
import java.util.Optional;

import org.junit.Test;

import com.king.event.Event;
import com.king.streaming.sdk.SCLong;
import com.king.streaming.sdk.context.Context;
import com.king.streaming.sdk.context.JoinContext;
import com.king.streaming.sdk.context.KeyContext;
import com.king.streaming.sdk.events.CustomEvent;
import com.king.streaming.sdk.eventstream.join.Current;
import com.king.streaming.sdk.eventstream.join.Last;
import com.king.streaming.sdk.eventstream.join.Match;
import com.king.streaming.sdk.eventstream.join.Pair;
import com.king.streaming.sdk.functions.EventProcessor;
import com.king.streaming.sdk.runners.flink.FlinkRunner;

public class JoinTest {

	@Test
	public void joinTest() throws Exception {

		TestRunner runner = FlinkRunner.create("test");
		ManualEventStream manualStream = runner.createManualStream();

		Last<SCLong> lastLong = Last.semanticClass(SCLong.class);

		EventStream<JoinContext> stream = manualStream
				.keyBy(e -> e.getHostname())
				.join(lastLong);

		EventStream<Context> sendLast = stream.process(new EventProcessor<JoinContext>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void processEvent(Event event, JoinContext ctx) throws Exception {
				Optional<SCLong> last = ctx.getJoined(lastLong);
				if (last.isPresent()) {
					ctx.output(CustomEvent.create(0).withField(0, last.get().get()));
				} else {
					ctx.output(CustomEvent.create(1));
				}
			}
		});

		ResultIterator outputIterator = sendLast.collect();

		runner.startTest();

		manualStream.sendEvent(CustomEvent.create(0).withField(0, "a").withHostname("k1"));
		assertEquals(1, outputIterator.poll().getEventType());
		manualStream.sendEvent(CustomEvent.create(0).withField(0, "1").withHostname("k100"));
		assertEquals(1, outputIterator.poll().getInt(0));
		manualStream.sendEvent(CustomEvent.create(0).withField(0, "3").withHostname("k1"));
		assertEquals(3, outputIterator.poll().getInt(0));
		manualStream.sendEvent(CustomEvent.create(0).withField(0, "a").withHostname("k1"));
		assertEquals(3, outputIterator.poll().getInt(0));
		manualStream.sendEvent(CustomEvent.create(0).withField(0, "4").withHostname("k1"));
		assertEquals(4, outputIterator.poll().getInt(0));

		runner.stopTest();
		assertFalse(outputIterator.hasNext());
	}

	@Test
	public void matchTest() throws Exception {

		TestRunner runner = FlinkRunner.create("test");
		ManualEventStream manualStream = runner.createManualStream();

		Match<Pair<SCLong, Event>> match = Match.once(
				Last.semanticClass(SCLong.class),
				Last.fromFilter(e -> e.getString(0).equals("m")));

		EventStream<Context> sendLast = manualStream
				.keyBy(e -> e.getHostname())
				.match(match, (p, ctx) -> {
					ctx.output(CustomEvent.create(0)
							.withField(0, p.left.get())
							.withField(1, p.right.getString(0)));
				});

		ResultIterator outputIterator = sendLast.collect();

		runner.startTest();

		manualStream.sendEvent(CustomEvent.create(0).withField(0, "ignore").withHostname("k1"));
		manualStream.sendEvent(CustomEvent.create(0).withField(0, "m").withHostname("k100"));
		manualStream.sendEvent(CustomEvent.create(0).withField(0, "2").withHostname("k1"));
		manualStream.sendEvent(CustomEvent.create(0).withField(0, "5").withHostname("k1"));
		manualStream.sendEvent(CustomEvent.create(0).withField(0, "m").withHostname("k1"));
		Event next = outputIterator.poll();
		assertEquals(5, next.getInt(0));
		assertEquals("m", next.getString(1));
		manualStream.sendEvent(CustomEvent.create(0).withField(0, "4").withHostname("k1"));
		manualStream.sendEvent(CustomEvent.create(0).withField(0, "3").withHostname("k100"));

		next = outputIterator.poll();
		assertEquals(3, next.getInt(0));
		assertEquals("m", next.getString(1));

		runner.stopTest();
		assertFalse(outputIterator.hasNext());
	}

	@Test
	public void TTLMatchTest() throws Exception {

		TestRunner runner = FlinkRunner.create("test");
		ManualEventStream manualStream = runner.createManualStream();

		Match<Pair<Event, Event>> match = Match.once(
				Current.eventType(1),
				Current.eventType(2))
				.within(Duration.ofSeconds(1));

		EventStream<Context> stream = manualStream
				.keyBy(e -> {
					return 0;
				})
				.match(match, (matched, ctx) -> ctx.output(CustomEvent.create(ctx.getCurrentWatermark())));

		ResultIterator outputIterator = stream.collect();

		runner.startTest();
		manualStream.sendWatermark(Instant.ofEpochMilli(500));
		manualStream.sendEvent(CustomEvent.create(1).withTimeStamp(510));
		manualStream.sendWatermark(Instant.ofEpochMilli(1600));
		manualStream.sendEvent(CustomEvent.create(2).withTimeStamp(1700));
		manualStream.sendEvent(CustomEvent.create(3).withTimeStamp(1700));
		manualStream.sendWatermark(Instant.ofEpochMilli(1800));
		manualStream.sendEvent(CustomEvent.create(1).withTimeStamp(1900));
		manualStream.sendWatermark(Instant.ofEpochMilli(1900));
		assertEquals(1800, outputIterator.poll().getEventType());
		runner.stopTest();
		assertFalse(outputIterator.hasNext());
	}

	@Test
	public void matchMultipleTest() throws Exception {

		TestRunner runner = FlinkRunner.create("test");
		ManualEventStream manualStream = runner.createManualStream();

		KeyedEventStream<KeyContext> stream = manualStream
				.keyBy(e -> e.getHostname());

		EventStream<Context> sendLast = stream.match(
				Match.continuously(
						Current.semanticClass(SCLong.class),
						Last.fromFilter(e -> e.getString(0).equals("m"))),
				(pair, ctx) -> ctx
						.output(CustomEvent.create(0)
								.withField(0, pair.left.get())
								.withField(1, pair.right.getString(0))));

		ResultIterator outputIterator = sendLast.collect();

		runner.startTest();

		manualStream.sendEvent(CustomEvent.create(0).withField(0, "ignore").withHostname("k1"));
		manualStream.sendEvent(CustomEvent.create(0).withField(0, "m").withHostname("k100"));
		manualStream.sendEvent(CustomEvent.create(0).withField(0, "2").withHostname("k1"));
		manualStream.sendEvent(CustomEvent.create(0).withField(0, "5").withHostname("k1"));
		manualStream.sendEvent(CustomEvent.create(0).withField(0, "m").withHostname("k1"));
		Event next = outputIterator.poll();
		assertEquals(5, next.getInt(0));
		assertEquals("m", next.getString(1));

		manualStream.sendEvent(CustomEvent.create(0).withField(0, "4").withHostname("k1"));
		next = outputIterator.poll();
		assertEquals(4, next.getInt(0));
		assertEquals("m", next.getString(1));

		manualStream.sendEvent(CustomEvent.create(0).withField(0, "3").withHostname("k100"));
		next = outputIterator.poll();
		assertEquals(3, next.getInt(0));
		assertEquals("m", next.getString(1));

		runner.stopTest();
		assertFalse(outputIterator.hasNext());
	}

	@Test
	public void joinWithMatchTest() throws Exception {

		TestRunner runner = FlinkRunner.create("test");
		ManualEventStream manualStream = runner.createManualStream();

		Match<Pair<SCLong, Event>> match = Match.continuously(
				Last.semanticClass(SCLong.class),
				Current.event());

		EventStream<Context> sendLast = manualStream
				.keyBy(e -> e.getHostname())
				.match(match, (matched, ctx) -> {
					ctx.output(CustomEvent.create(0).withField(0, matched.left.get()));
				});

		ResultIterator outputIterator = sendLast.collect();

		runner.startTest();

		manualStream.sendEvent(CustomEvent.create(0).withField(0, "a").withHostname("k1"));
		manualStream.sendEvent(CustomEvent.create(0).withField(0, "1").withHostname("k100"));
		assertEquals(1, outputIterator.poll().getInt(0));
		manualStream.sendEvent(CustomEvent.create(0).withField(0, "3").withHostname("k1"));
		assertEquals(3, outputIterator.poll().getInt(0));
		manualStream.sendEvent(CustomEvent.create(0).withField(0, "a").withHostname("k1"));
		assertEquals(3, outputIterator.poll().getInt(0));
		manualStream.sendEvent(CustomEvent.create(0).withField(0, "4").withHostname("k1"));
		assertEquals(4, outputIterator.poll().getInt(0));

		runner.stopTest();
		assertFalse(outputIterator.hasNext());
	}

	@Test
	public void matchWithinIntegrationTest() throws Exception {

		TestRunner runner = FlinkRunner.create("test");
		ManualEventStream manualStream = runner.createManualStream();

		Match<Pair<SCLong, Event>> match = Match.continuously(
				Last.semanticClass(SCLong.class),
				Current.fromFilter(e -> e.getString(0).equals("m")))
				.within(Duration.ofSeconds(1));

		EventStream<Context> sendLast = manualStream
				.keyBy(e -> e.getHostname())
				.match(match, (p, ctx) -> {
					ctx.output(CustomEvent.create(0)
							.withField(0, p.left.get())
							.withField(1, p.right.getString(0)));
				});

		ResultIterator outputIterator = sendLast.collect();

		runner.startTest();
		manualStream.sendEvent(CustomEvent.create(0).withField(0, "m").withHostname("k100").withTimeStamp(100));
		manualStream.sendEvent(CustomEvent.create(0).withField(0, "2").withHostname("k1").withTimeStamp(100));
		manualStream.sendEvent(CustomEvent.create(0).withField(0, "5").withHostname("k1").withTimeStamp(100));
		manualStream.sendWatermark(Instant.ofEpochMilli(3000));
		manualStream.sendEvent(CustomEvent.create(0).withField(0, "m").withHostname("k1").withTimeStamp(3100));
		manualStream.sendEvent(CustomEvent.create(0).withField(0, "6").withHostname("k1").withTimeStamp(3100));

		Event next = outputIterator.poll();
		assertEquals(6, next.getInt(0));
		assertEquals("m", next.getString(1));

		manualStream.sendWatermark(Instant.ofEpochMilli(3500));
		manualStream.sendEvent(CustomEvent.create(0).withField(0, "m").withHostname("k1").withTimeStamp(3500));

		next = outputIterator.poll();
		assertEquals(6, next.getInt(0));
		assertEquals("m", next.getString(1));

		manualStream.sendEvent(CustomEvent.create(0).withField(0, "4").withHostname("k1").withTimeStamp(3600));

		runner.stopTest();
		assertFalse(outputIterator.hasNext());
	}
}
