package com.king.streaming.sdk;

public final class SCLong {
	private final long i;

	public SCLong(long i) {
		this.i = i;
	}

	public long get() {
		return i;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (i ^ (i >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof SCLong)) {
			return false;
		}
		SCLong other = (SCLong) obj;
		if (i != other.i) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "Long(" + i + ")";
	}

	public static SCLong process(com.king.event.Event e) {
		try {
			return new SCLong(Long.parseLong(e.getString(0)));
		} catch (Exception ex) {
			return null;
		}
	}
}
