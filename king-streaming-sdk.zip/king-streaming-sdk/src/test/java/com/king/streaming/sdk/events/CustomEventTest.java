package com.king.streaming.sdk.events;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.apache.commons.lang3.SerializationUtils;
import org.junit.Test;

import com.king.constants.EventField;
import com.king.constants.EventType;
import com.king.event.Event;
import com.king.event.EventBuilder;
import com.king.event.format.EventFormatException;
import com.king.streaming.sdk.io.DefaultEventFormat;

public class CustomEventTest {

	@Test
	public void testFields2() throws EventFormatException {
		// System.out.println(DefaultEventFormat.eventFormat.format(CustomEvent.create(-1).withTimeStamp(1)));
		Event e = DefaultEventFormat.eventFormat.parse("B	19700101T010000.001+0100	0	-1	0		0");
		System.out.println(e);
	}

	@Test
	public void testFields() throws EventFormatException {
		CustomEvent event = dummyEvent();

		event = (CustomEvent) SerializationUtils.deserialize(SerializationUtils.serialize(event));

		String formatted = DefaultEventFormat.eventFormat.format(event);
		Event event2 = DefaultEventFormat.eventFormat.parse(formatted);

		assertEquals(2, event.get(coreUserId));
		assertEquals(2, event.getLong(0));
		assertEquals(2, event2.get(coreUserId));
		assertEquals(2, event2.getLong(0));

		assertEquals("t", event.get(abTestName));
		assertEquals("t", event.getString(1));
		assertEquals("t", event2.get(abTestName));
		assertEquals("t", event2.getString(1));

		assertEquals("Yolo", event.getString(5));
		assertEquals("Yolo", event2.getString(5));
	}

	public static int[][] coreUserId = new int[][] { { 9020, 0 } };
	public static int[][][] abTestName = new int[][][] { { { 9020, 1 } } };
	public static int[] abTestVersion = new int[] { 9020, 2 };

	@Test
	public void testFromEvent() {
		Event event = new EventBuilder(1).buildEvent(EventType.AbTestCaseAssigned(1, "a", 2, 3), 3);
		CustomEvent custom = CustomEvent.fromEvent(event);
		custom.withField(4, 10);
		assertEquals(1, custom.getInt(0));
		assertEquals("a", custom.getString(1));
		assertEquals(2, custom.getInt(2));
		assertEquals(3, custom.getInt(3));
		assertEquals(10, custom.getInt(4));
	}

	@Test
	public void testErrors() throws EventFormatException {
		CustomEvent event = CustomEvent.create(2)
				.withField(0, "asd")
				.withField(2, 3);

		try {
			event.get(EventField.AbTestCaseAssigned.abTestName);
			fail();
		} catch (Exception expected) {}

		try {
			event.withField(2, 4);
			fail();
		} catch (Exception expected) {}

		event.getRawField(0);
		try {
			event.getRawField(1);
			fail();
		} catch (Exception expected) {}
	}

	@Test
	public void testEquals() {
		Event dummy1 = dummyEvent();
		Event dummy2 = dummyEvent();
		assertEquals(dummy1, dummy2);
	}

	@Test
	public void testHashCode() {
		Event dummy1 = dummyEvent();
		Event dummy2 = dummyEvent();
		assertEquals(dummy1.hashCode(), dummy2.hashCode());
	}
	
	CustomEvent dummyEvent() {
		return CustomEvent.create(EventType.AbTestCaseAssigned)
			.withFlavourId(1)
			.withTimeStamp(2)
			.withHostname("h")
			.withField(coreUserId, 2)
			.withField(abTestName, "t")
			.withField(abTestVersion, 3)
			.withField(5, "Yolo");
	}
}
