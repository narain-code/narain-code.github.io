package com.king.streaming.sdk.flink;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.king.streaming.sdk.runners.flink.FlinkOptions;

public class FlinkParamTest {

	@Test
	public void test() throws Exception {

		FlinkOptions opt = FlinkOptions.fromProperties("src/main/resources/FlinkTestProps.props");

		assertEquals(5, opt.parallelism);
		assertEquals(500, opt.checkpointInterval);
	}
}
