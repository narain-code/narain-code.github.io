
package com.king.streaming.sdk.eventstream;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import java.time.Duration;
import java.time.Instant;

import org.apache.flink.runtime.state.memory.MemoryStateBackend;
import org.junit.Test;

import com.king.event.Event;
import com.king.streaming.sdk.context.Context;
import com.king.streaming.sdk.context.KeyContext;
import com.king.streaming.sdk.context.State;
import com.king.streaming.sdk.events.CustomEvent;
import com.king.streaming.sdk.functions.EventProcessor;
import com.king.streaming.sdk.runners.flink.FlinkOptions;
import com.king.streaming.sdk.runners.flink.FlinkRunner;

public class KeyedStreamTest {

	@Test
	public void testSimpleState() throws Exception {

		FlinkOptions opt = new FlinkOptions();
		opt.checkpointInterval = 500;
		opt.stateBackend = new MemoryStateBackend();

		TestRunner runner = FlinkRunner.create("test", opt);
		ManualEventStream manualStream = runner.createManualStream();

		EventStream<KeyContext> stream = manualStream.keyBy(e -> e.getEventType());

		EventStream<Context> countPerKey = stream.process(new EventProcessor<KeyContext>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void processEvent(Event event, KeyContext ctx) throws Exception {
				State<IntWrapper> countState = ctx.getValueState("Count", IntWrapper.class);
				IntWrapper count = countState.value().orElse(new IntWrapper());
				++count.wrapped;
				countState.update(count);
				ctx.output(CustomEvent.create(0).withField(0, ctx.getPartitionKey() + "-" + count.wrapped));
			}
		});

		ResultIterator outputIterator = countPerKey.collect();

		runner.startTest();

		manualStream.sendEvent(CustomEvent.create(10).withTimeStamp(1));
		assertEquals("10-1", outputIterator.poll().getString(0));
		manualStream.sendEvent(CustomEvent.create(11).withTimeStamp(1));

		// Wait for checkpoint to trigger
		manualStream.sleep(Duration.ofSeconds(1));
		manualStream.triggerFailure();

		assertEquals("11-1", outputIterator.poll().getString(0));
		manualStream.sendEvent(CustomEvent.create(10).withTimeStamp(2));
		assertEquals("10-2", outputIterator.poll().getString(0));

		runner.stopTest();
		assertFalse(outputIterator.hasNext());
	}

	@Test
	public void testTTLState() throws Exception {
		FlinkOptions opt = new FlinkOptions();
		opt.checkpointInterval = 500;
		opt.stateBackend = new MemoryStateBackend();

		TestRunner runner = FlinkRunner.create("test", opt);
		ManualEventStream manualStream = runner.createManualStream();

		EventStream<KeyContext> stream = manualStream.keyBy(e -> e.getEventType());

		EventStream<Context> countPerKey = stream.process(new EventProcessor<KeyContext>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void processEvent(Event event, KeyContext ctx) throws Exception {
				State<IntWrapper> countState = ctx.getValueState("Count", IntWrapper.class).clearAfter(Duration.ofMillis(10));
				IntWrapper count = countState.value().orElse(new IntWrapper());
				++count.wrapped;
				countState.update(count);
				ctx.output(CustomEvent.create(0).withField(0, ctx.getPartitionKey() + "-" + count.wrapped));
			}
		});

		ResultIterator outputIterator = countPerKey.collect();
		// countPerKey.process((e, c) -> {
		// System.err.println(e);
		// });

		runner.startTest();

		manualStream.sendEvent(CustomEvent.create(10).withTimeStamp(1));
		assertEquals("10-1", outputIterator.poll().getString(0));
		manualStream.sendEvent(CustomEvent.create(11).withTimeStamp(1));
		assertEquals("11-1", outputIterator.poll().getString(0));
		// This should clear the TTL state for both keys
		manualStream.sendWatermark(Instant.ofEpochMilli(50));
		manualStream.sendEvent(CustomEvent.create(10).withTimeStamp(100));
		assertEquals("10-1", outputIterator.poll().getString(0));
		manualStream.sendEvent(CustomEvent.create(10).withTimeStamp(105));
		assertEquals("10-2", outputIterator.poll().getString(0));

		// Wait for checkpoint to trigger
		manualStream.sleep(Duration.ofSeconds(1));
		manualStream.triggerFailure();

		// This should clear the TTL state for key=10
		manualStream.sendWatermark(Instant.ofEpochMilli(120));
		manualStream.sendEvent(CustomEvent.create(10).withTimeStamp(121));
		assertEquals("10-1", outputIterator.poll().getString(0));
		manualStream.sendEvent(CustomEvent.create(11).withTimeStamp(122));
		assertEquals("11-1", outputIterator.poll().getString(0));

		runner.stopTest();
		assertFalse(outputIterator.hasNext());
	}
	
	public static class IntWrapper {
		public int wrapped;
	}

	@Test
	public void testInOrderProcessing() throws Exception {
		FlinkOptions opt = new FlinkOptions();
		opt.checkpointInterval = 500;
		opt.stateBackend = new MemoryStateBackend();

		TestRunner runner = FlinkRunner.create("test", opt);
		ManualEventStream manualStream = runner.createManualStream();

		KeyedEventStream<KeyContext> stream = manualStream.keyBy(event -> 0);

		ResultIterator outputIterator = stream
				.sort(Duration.ofMillis(10))
				.process((event, ctx) -> ctx.output(event))
				.collect();

		runner.startTest();

		manualStream.sendEvent(CustomEvent.create(0).withTimeStamp(1));
		manualStream.sendEvent(CustomEvent.create(2).withTimeStamp(3));
		manualStream.sendEvent(CustomEvent.create(3).withTimeStamp(15));

		manualStream.sleep(Duration.ofSeconds(2));
		manualStream.triggerFailure();

		manualStream.sendEvent(CustomEvent.create(1).withTimeStamp(2));
		manualStream.sendWatermark(Instant.ofEpochMilli(5));
		manualStream.sendWatermark(Instant.ofEpochMilli(11));
		manualStream.sendEvent(CustomEvent.create(4).withTimeStamp(16));
		manualStream.sendEvent(CustomEvent.create(5).withTimeStamp(21));
		manualStream.sendWatermark(Instant.ofEpochMilli(9999));

		assertEquals(0, outputIterator.poll().getEventType());
		assertEquals(1, outputIterator.poll().getEventType());
		assertEquals(2, outputIterator.poll().getEventType());
		assertEquals(3, outputIterator.poll().getEventType());
		assertEquals(4, outputIterator.poll().getEventType());
		assertEquals(5, outputIterator.poll().getEventType());

		runner.stopTest();
		assertFalse(outputIterator.hasNext());
	}
}
