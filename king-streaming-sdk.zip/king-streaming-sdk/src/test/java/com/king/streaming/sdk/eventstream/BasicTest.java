package com.king.streaming.sdk.eventstream;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.king.streaming.sdk.events.CustomEvent;
import com.king.streaming.sdk.runners.flink.FlinkRunner;

public class BasicTest {

	@Test
	public void simpleTest() throws Exception {

		TestRunner runner = FlinkRunner.create("test");

		ManualEventStream manualStream = runner.createManualStream();

		ResultIterator output = manualStream
				.filter(e -> !e.getString(0).equals("b"))
				.collect();

		runner.startTest();

		manualStream.sendEvent(CustomEvent.create(0).withField(0, "a"));
		assertEquals("a", output.poll().getString(0));

		manualStream.sendEvent(CustomEvent.create(0).withField(0, "b"));
		manualStream.sendEvent(CustomEvent.create(0).withField(0, "c"));
		assertEquals("c", output.poll().getString(0));

		runner.stopTest();
	}
}
