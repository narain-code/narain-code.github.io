package com.king.streaming.sdk.eventstream;

import static org.junit.Assert.assertEquals;

import java.time.Duration;
import java.time.Instant;
import java.util.Collections;
import java.util.Random;

import org.junit.Test;

import com.king.event.Event;
import com.king.streaming.sdk.context.Context;
import com.king.streaming.sdk.context.aggregators.AggregationWindow;
import com.king.streaming.sdk.context.aggregators.AggregatorOutput;
import com.king.streaming.sdk.events.CustomEvent;
import com.king.streaming.sdk.functions.EventProcessor;
import com.king.streaming.sdk.runners.flink.FlinkOptions;
import com.king.streaming.sdk.runners.flink.FlinkRunner;

public class AggregateTest {

	@Test
	public void aggregateTest() throws Exception {

		FlinkOptions opt = new FlinkOptions();
		opt.parallelism = 1;
		TestRunner runner = FlinkRunner.create("test", opt);

		String aggregatorName = "A" + new Random().nextInt(9999);

		ManualEventStream manualStream = runner.createManualStream();

		manualStream.process(new EventProcessor<Context>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void processEvent(Event event, Context ctx) throws Exception {
				ctx.getAggregators()
						.getCounter(aggregatorName, AggregationWindow.MINUTES_10)
						.setDimensions(event.getString(0))
						.increment();
			}
		});

		AggregatorOutput aggValues = runner.startTest();

		manualStream.sendEvent(CustomEvent.create(0).withField(0, "a").withTimeStamp(100000));
		manualStream.sendEvent(CustomEvent.create(0).withField(0, "a").withTimeStamp(300000));
		manualStream.sendEvent(CustomEvent.create(0).withField(0, "a").withTimeStamp(700000));
		manualStream.sendEvent(CustomEvent.create(0).withField(0, "b").withTimeStamp(800000));
		manualStream.sendWatermark(Instant.ofEpochMilli(700000));

		assertEquals(2L, aggValues.pollValue(aggregatorName, Collections.singletonMap("0", "a"), 600000));

		manualStream.sendEvent(CustomEvent.create(0).withField(0, "c").withTimeStamp(1300000));
		manualStream.sendWatermark(Instant.ofEpochMilli(1250000));

		Thread.sleep(3500);

		assertEquals(1, aggValues.pollValue(aggregatorName, Collections.singletonMap("0", "b"), 1200000));
		assertEquals(1, (long) aggValues.getValue(aggregatorName, Collections.singletonMap("0", "a"), 1200000).get());

		manualStream.sendEvent(CustomEvent.create(0).withField(0, "a").withTimeStamp(100000));

		Thread.sleep(3500);
		assertEquals(3, (long) aggValues.getValue(aggregatorName, Collections.singletonMap("0", "a"), 600000).get());

		// timestamps should be disregarded from now
		manualStream.sendWatermark(Instant.ofEpochMilli(Duration.ofDays(2).toMillis()));

		manualStream.sendEvent(CustomEvent.create(0).withField(0, "a").withTimeStamp(100000));

		Thread.sleep(3500);

		assertEquals(3, aggValues.pollValue(aggregatorName, Collections.singletonMap("0", "a"), 600000));

		runner.stopTest();
	}
}
