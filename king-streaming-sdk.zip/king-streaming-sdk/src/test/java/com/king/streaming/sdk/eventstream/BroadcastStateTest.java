package com.king.streaming.sdk.eventstream;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import java.time.Duration;

import org.apache.flink.runtime.state.memory.MemoryStateBackend;
import org.junit.Test;

import com.king.event.Event;
import com.king.streaming.sdk.context.Context;
import com.king.streaming.sdk.events.CustomEvent;
import com.king.streaming.sdk.eventstream.join.Aggregate;
import com.king.streaming.sdk.eventstream.join.Last;
import com.king.streaming.sdk.functions.EventProcessor;
import com.king.streaming.sdk.runners.flink.FlinkOptions;
import com.king.streaming.sdk.runners.flink.FlinkRunner;

public class BroadcastStateTest {

	@Test
	public void testSimpleBroadcastState() throws Exception {

		FlinkOptions opt = new FlinkOptions();
		opt.checkpointInterval = 100;
		opt.stateBackend = new MemoryStateBackend();

		FlinkRunner runner = FlinkRunner.create("test", opt);
		runner.getFlinkEnvironment().setBufferTimeout(1);

		ManualEventStream events = runner.createManualStream();
		ManualEventStream states = runner.createManualStream();

		BroadcastState<Event> bc = states.broadcast(Last.event());

		EventStream<Context> outStream = events.withBroadcastState(bc)
				.process(new EventProcessor<Context>() {
					private static final long serialVersionUID = 1L;

					@Override
					public void processEvent(Event event, Context ctx) throws Exception {
						ctx.getBroadcastState(bc).ifPresent(ctx::output);
					}
				});

		ResultIterator output = outStream.collect();
		runner.startTest();

		events.sendEvent(CustomEvent.create(0).withField(0, "a"));
		events.sleep(Duration.ofSeconds(2));
		states.sendEvent(CustomEvent.create(0).withField(0, "state1"));
		events.sleep(Duration.ofSeconds(2));
		events.sendEvent(CustomEvent.create(0).withField(0, "b"));
		assertEquals("state1", output.poll().getString(0));

		events.sendEvent(CustomEvent.create(0).withField(0, "a"));
		events.sendEvent(CustomEvent.create(0).withField(0, "a"));
		assertEquals("state1", output.poll().getString(0));
		assertEquals("state1", output.poll().getString(0));
		states.sendEvent(CustomEvent.create(0).withField(0, "state2"));
		Thread.sleep(10000);
		events.sendEvent(CustomEvent.create(0).withField(0, "b"));
		assertEquals("state2", output.poll().getString(0));
		events.triggerFailure();
		events.sendEvent(CustomEvent.create(0).withField(0, "b"));
		assertEquals("state2", output.poll().getString(0));

		runner.stopTest();
		assertFalse(output.hasNext());
	}

	@Test
	public void testComplexBroadcastState() throws Exception {

		FlinkOptions opt = new FlinkOptions();
		opt.checkpointInterval = 500;
		opt.stateBackend = new MemoryStateBackend();

		TestRunner runner = FlinkRunner.create("test", opt);

		ManualEventStream events = runner.createManualStream();
		ManualEventStream states = runner.createManualStream();

		BroadcastState<Event> bc = states.broadcast(Last.event());
		BroadcastState<Integer> count = states.broadcast(Aggregate.of((c, event, ctx) -> c + 1, 0));

		EventStream<Context> outStream = events.withBroadcastState(bc, count)
				.process(new EventProcessor<Context>() {
					private static final long serialVersionUID = 1L;

					@Override
					public void processEvent(Event event, Context ctx) throws Exception {
						ctx.getBroadcastState(bc).ifPresent(ctx::output);
						ctx.getBroadcastState(count).ifPresent(c -> ctx.output(CustomEvent.create(0).withField(0, c)));
					}
				});

		ResultIterator output = outStream.collect();
		runner.startTest();

		events.sendEvent(CustomEvent.create(0).withField(0, "a"));
		assertEquals("0", output.poll().getString(0));
		events.sleep(Duration.ofSeconds(1));
		states.sendEvent(CustomEvent.create(0).withField(0, "state1"));
		events.sleep(Duration.ofSeconds(1));
		events.sendEvent(CustomEvent.create(0).withField(0, "b"));
		assertEquals("state1", output.poll().getString(0));
		assertEquals("1", output.poll().getString(0));

		events.sendEvent(CustomEvent.create(0).withField(0, "a"));
		events.sendEvent(CustomEvent.create(0).withField(0, "a"));
		assertEquals("state1", output.poll().getString(0));
		assertEquals("1", output.poll().getString(0));
		assertEquals("state1", output.poll().getString(0));
		assertEquals("1", output.poll().getString(0));
		states.sendEvent(CustomEvent.create(0).withField(0, "state2"));
		events.sleep(Duration.ofSeconds(1));
		events.triggerFailure();
		events.sendEvent(CustomEvent.create(0).withField(0, "b"));
		assertEquals("state2", output.poll().getString(0));
		assertEquals("2", output.poll().getString(0));

		runner.stopTest();
		assertFalse(output.hasNext());
	}
}
