package com.king.streaming.sdk;

import java.util.Map;
import java.util.Optional;

import com.king.event.Event;
import com.king.streaming.sdk.context.Aggregators;
import com.king.streaming.sdk.context.Context;
import com.king.streaming.sdk.context.Utils;
import com.king.streaming.sdk.context.aggregators.AggregationWindow;
import com.king.streaming.sdk.context.aggregators.Counter;
import com.king.streaming.sdk.context.aggregators.OutputType;
import com.king.streaming.sdk.context.aggregators.SumAggregator;
import com.king.streaming.sdk.eventstream.BroadcastState;

public class MockContext implements Context {

	public final MockAggregators agg;
	public final MockUtils utils;
	public final long cuid;

	public MockContext(long cuid) {
		this.agg = new MockAggregators();
		this.utils = new MockUtils();
		this.cuid = cuid;
	}

	@Override
	public MockAggregators getAggregators() {
		return agg;
	}

	@Override
	public MockUtils getUtils() {
		return utils;
	}

	public static class MockUtils implements Utils {}

	public static class MockAggregators implements Aggregators {

		@Override
		public Counter getCounter(String name, AggregationWindow windowSize, OutputType outputType) {
			return new MockCounter(name, windowSize, outputType);
		}

		@Override
		public SumAggregator getSumAggregator(String name, AggregationWindow windowSize, OutputType outputType) {
			return new MockSumAggregator(name, windowSize, outputType);
		}
	}

	public static class MockCounter implements Counter {

		public final Object name;
		public final AggregationWindow ws;
		public final OutputType ot;

		public MockCounter(Object name, AggregationWindow ws, OutputType ot) {
			this.name = name;
			this.ws = ws;
			this.ot = ot;
		}

		@Override
		public void increment() {}

		@Override
		public void decrement() {}

		@Override
		public Counter setNamedDimensions(Map<String, ?> dimensions) {
			return null;
		}

	}

	public static class MockSumAggregator implements SumAggregator {

		public final Object name;
		public final AggregationWindow ws;
		public final OutputType ot;

		public MockSumAggregator(Object name, AggregationWindow ws, OutputType ot) {
			this.name = name;
			this.ws = ws;
			this.ot = ot;
		}

		@Override
		public void add(long num) {}

		@Override
		public SumAggregator setNamedDimensions(Map<String, ?> dimensions) {
			return null;
		}

	}

	@Override
	public long getCurrentWatermark() {
		return 0;
	}

	@Override
	public void output(Event event) {
		// TODO Auto-generated method stub

	}

	@Override
	public <T> Optional<T> getBroadcastState(BroadcastState<T> bcState) {
		// TODO Auto-generated method stub
		return null;
	}

}
