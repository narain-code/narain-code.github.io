package com.king.streaming.sdk.eventstream;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.junit.Test;

import com.king.constants.EventType;
import com.king.event.Event;
import com.king.event.EventBuilder;
import com.king.event.format.EventFormat;
import com.king.event.format.EventFormatException;
import com.king.flink.utils.events.LazyEventFormat;
import com.king.streaming.sdk.io.DefaultEventFormat;

public class TestFailureWrapping {

	@Test
	public void test() throws EventFormatException {
		EventFormat format = new LazyEventFormat();
		Event e = new EventBuilder(1).buildEvent(EventType.AbTestClose("testName"), 3);
		String raw = format.format(e);
		Event failure = DefaultEventFormat.wrapFailure(raw, ExceptionUtils.getStackTrace(new RuntimeException("yolo")));
		String rawFailure = format.format(failure);
		format.parse(rawFailure).getHostname();
	}

}
