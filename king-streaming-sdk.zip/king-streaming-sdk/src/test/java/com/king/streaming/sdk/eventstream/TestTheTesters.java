package com.king.streaming.sdk.eventstream;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import org.junit.Test;

import com.king.streaming.sdk.context.Context;
import com.king.streaming.sdk.events.CustomEvent;
import com.king.streaming.sdk.runners.flink.FlinkRunner;

public class TestTheTesters {
	@Test
	public void testTests() throws Exception {

		TestRunner runner = FlinkRunner.create("test");

		ManualEventStream manualStream1 = runner.createManualStream();
		ManualEventStream manualStream2 = runner.createManualStream();

		EventStream<Context> stream = manualStream1.union(manualStream2);

		ResultIterator allout1 = stream.collect();
		ResultIterator stream1out = manualStream1.collect();

		runner.startTest();

		manualStream1.sendEvent(CustomEvent.create(1));
		assertEquals(1, stream1out.poll().getEventType());
		assertEquals(1, allout1.poll().getEventType());

		manualStream2.sendEvent(CustomEvent.create(2));
		assertEquals(2, allout1.poll().getEventType());

		manualStream1.sendEvent(CustomEvent.create(3));
		assertEquals(3, stream1out.poll().getEventType());
		assertEquals(3, allout1.poll().getEventType());

		runner.stopTest();
		assertFalse(allout1.hasNext());
		assertFalse(stream1out.hasNext());
	}
}
