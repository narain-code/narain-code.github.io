package com.king.streaming.sdk.eventstream;

import static org.junit.Assert.assertEquals;

import java.time.Duration;
import java.time.Instant;

import org.apache.flink.runtime.state.memory.MemoryStateBackend;
import org.junit.Test;

import com.king.event.Event;
import com.king.streaming.sdk.context.GlobalContext;
import com.king.streaming.sdk.context.State;
import com.king.streaming.sdk.events.CustomEvent;
import com.king.streaming.sdk.functions.EventProcessor;
import com.king.streaming.sdk.runners.flink.FlinkOptions;
import com.king.streaming.sdk.runners.flink.FlinkRunner;

public class GlobalProcessorTest {

	@Test
	public void globalProcessorTest() throws Exception {

		FlinkOptions opt = new FlinkOptions();
		opt.checkpointInterval = 500;
		opt.stateBackend = new MemoryStateBackend();

		TestRunner runner = FlinkRunner.create("test", opt);

		ManualEventStream manualStream = runner.createManualStream();

		ResultIterator output = manualStream
				.processGlobal(new EventProcessor<GlobalContext>() {
					private static final long serialVersionUID = 1L;

					@Override
					public void processEvent(Event event, GlobalContext ctx) throws Exception {
						State<Integer> c = ctx.getValueState("Count", Integer.class).clearAfter(Duration.ofMillis(100));
						Integer count = c.value().orElse(0) + 1;
						c.update(count);
						ctx.output(CustomEvent.create(0).withField(0, count));
					}
				}).collect();

		runner.startTest();

		manualStream.sendEvent(CustomEvent.create(0).withTimeStamp(0));
		assertEquals(1, output.poll().getInt(0));

		manualStream.sendEvent(CustomEvent.create(0).withTimeStamp(50));
		assertEquals(2, output.poll().getInt(0));

		Thread.sleep(3000);
		manualStream.triggerFailure();

		manualStream.sendWatermark(Instant.ofEpochMilli(240));

		manualStream.sendEvent(CustomEvent.create(0).withTimeStamp(250));
		assertEquals(1, output.poll().getInt(0));
		runner.stopTest();
	}
}
