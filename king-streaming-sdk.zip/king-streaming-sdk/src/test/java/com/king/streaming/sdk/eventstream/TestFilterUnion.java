package com.king.streaming.sdk.eventstream;

import static org.junit.Assert.assertEquals;

import java.io.Serializable;

import org.junit.Test;

import com.king.streaming.sdk.SCLong;
import com.king.streaming.sdk.events.CustomEvent;
import com.king.streaming.sdk.runners.flink.FlinkRunner;

public class TestFilterUnion implements Serializable {

	private static final long serialVersionUID = 1L;

	@Test
	public void testUnion() throws Exception {

		TestRunner runner = FlinkRunner.create("test");

		ManualEventStream stream1 = runner.createManualStream();
		ManualEventStream stream2 = runner.createManualStream();
		ManualEventStream stream3 = runner.createManualStream();
		ManualEventStream stream4 = runner.createManualStream();

		EventStream<?> all = stream1.union(stream2.union(stream3).filter(3), stream4);

		ResultIterator output = all
				.filter(1, 3)
				.collect();

		runner.startTest();

		stream1.sendEvent(CustomEvent.create(0));
		stream1.sendEvent(CustomEvent.create(1));
		output.poll();
		stream2.sendEvent(CustomEvent.create(1));
		stream2.sendEvent(CustomEvent.create(3));
		output.poll();
		stream3.sendEvent(CustomEvent.create(3));
		stream3.sendEvent(CustomEvent.create(1));
		output.poll();
		stream4.sendEvent(CustomEvent.create(2));
		stream4.sendEvent(CustomEvent.create(1));
		output.poll();
		runner.stopTest();
	}
}
