package com.king.splat;

import static org.elasticsearch.common.xcontent.XContentFactory.jsonBuilder;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.concurrent.ThreadPoolExecutor;

import org.elasticsearch.action.admin.indices.create.CreateIndexRequestBuilder;
import org.elasticsearch.action.admin.indices.delete.DeleteIndexRequestBuilder;
import org.elasticsearch.action.admin.indices.exists.indices.IndicesExistsResponse;
import org.elasticsearch.action.index.IndexRequestBuilder;
import org.elasticsearch.client.ElasticsearchClient;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.elasticsearch.common.xcontent.XContentBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ElasticSearchClient {
	
	private final Logger logger = LoggerFactory.getLogger(ElasticsearchClient.class);
	
	
	private  ThreadPoolExecutor asyncRestPool;
	
	private TransportClient client;
	
	
	private static final String HOST = "fbweb619.sto.midasplayer.com";
	private static final int PORT=9300;
	private static final String clusterName ="elasticsearch";
	
	
	public ElasticSearchClient() throws UnknownHostException{
		
		final Settings settings = Settings.settingsBuilder()
				.put("client.transport.sniff", true)
				.put("cluster.name", clusterName)
				.build();
		client =new TransportClient.Builder()
				.settings(settings)
				.build()
				.addTransportAddress(new InetSocketTransportAddress(InetAddress.getByName(HOST), PORT));
		
		
	}
	
	public TransportClient getClient(){
		return client;
	}
	
	/**
	 * 
	 * bulk processing of GameEnd
	 * 
	 * id == coreuserid
	 * 
	 */
	
	
	public void doBulk(){
		client.prepareBulk();
		
		
	}
	
	
	
	
    
	
	public XContentBuilder addMappingToIndex() throws IOException{
		final XContentBuilder mappingBuilder = jsonBuilder().startObject().startObject("SCGameEnd")
                .startObject("_ttl").field("enabled", "true").field("default", "1s").endObject() //endobject for ttl
                .startObject("_all").field("enabled","false").endObject() //endfor all
                .startObject("_source").field("enabled","false").endObject() //endfor source
                .startObject("properties")
                .startObject("coreuserid").field("type","long").field("docvalues","true").field("index","no").endObject()
                .startObject("msts").field("type","long").field("docvalues","true").field("index","no").endObject()
                .startObject("episode").field("type","int").field("docvalues","true").field("index","no").endObject()
                .startObject("flavourid").field("type","long").field("docvalues","true").field("index","no").endObject()
                .startObject("Gameendreason").field("type","int").field("docvalues","true").field("index","no").endObject()
                 .startObject("gameRoundId").field("type","long").field("docvalues","true").field("index","no").endObject()
                 .startObject("installId").field("type","string").field("docvalues","true").field("index","no").endObject()
                 .startObject("kingappid").field("type","int").field("docvalues","true").field("index","no").endObject()
                 .startObject("level").field("type","int").field("docvalues","true").field("index","no").endObject()
                .endObject() //end properties
                .endObject()
                .endObject();
       // System.out.println(mappingBuilder.string());
		return mappingBuilder;
       
	}
	
	private static String indexName ="RBEA";
	private static String documentType = "SCGameEnd";
	
	public static void main(String[] args) {
		try{
		ElasticSearchClient cl = new ElasticSearchClient();
		//cl.doBulk();
		
		final IndicesExistsResponse res = cl.getClient().admin().indices().prepareExists(indexName).execute().actionGet();
		if (res.isExists()) {
            DeleteIndexRequestBuilder delIdx = cl.getClient().admin().indices().prepareDelete(indexName );
            delIdx.execute().actionGet();
        }
		/*  final CreateIndexRequestBuilder createIndexRequestBuilder = cl.getClient().admin().indices().prepareCreate(indexName);
		  createIndexRequestBuilder.addMapping(documentType, cl.addMappingToIndex()); 
		  
		
	        createIndexRequestBuilder.execute().actionGet();

	        String documentId = "1";
	      
	        final IndexRequestBuilder indexRequestBuilder = cl.getClient().prepareIndex(indexName, documentType, documentId);
	  
	        final XContentBuilder contentBuilder = jsonBuilder().startObject().prettyPrint();
	        String fieldName = "1";
	        String value = "1";
	        contentBuilder.field(fieldName, value);

	        indexRequestBuilder.setSource(contentBuilder);
	        indexRequestBuilder.execute().actionGet();*/

		System.out.println(res.isExists());
		
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}

}
