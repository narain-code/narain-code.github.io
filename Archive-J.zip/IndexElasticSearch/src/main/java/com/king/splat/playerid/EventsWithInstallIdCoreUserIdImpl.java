package com.king.splat.playerid;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import com.king.constants.EventField;
import com.king.constants.EventType;

public class EventsWithInstallIdCoreUserIdImpl {

	private final Map<Long, Position> mappedEvents = new HashMap<>();

    public EventsWithInstallIdCoreUserIdImpl() {
        buildMapping();
    }

    public static class Position implements Serializable {
        private static final long serialVersionUID = -2631341318068812777L;

        private final int coreUserIdPos;
        private final int installIdPos;

        public Position(int coreUserIdPos, int installIdPos) {
            this.coreUserIdPos = coreUserIdPos;
            this.installIdPos = installIdPos;
        }

        public int getCoreUserIdPos() {
            return coreUserIdPos;
        }

        public int getInstallIdPos() {
            return installIdPos;
        }

        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + coreUserIdPos;
            result = prime * result + installIdPos;
            return result;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj)
                return true;
            if (obj == null)
                return false;
            if (getClass() != obj.getClass())
                return false;
            Position other = (Position) obj;
            if (coreUserIdPos != other.coreUserIdPos)
                return false;
            if (installIdPos != other.installIdPos)
                return false;
            return true;
        }

        @Override
        public String toString() {
            return "Position [coreUserIdPos=" + coreUserIdPos + ", installIdPos=" + installIdPos + "]";
        }

    }

    private void buildMapping() {

        try {

            Map<String, Long> eventToId = getEventTypeNameId();

            Class<?>[] declaredClasses = EventField.class.getDeclaredClasses();
            for (Class<?> class1 : declaredClasses) {
                Field[] fields = class1.getFields();

                int cuidpos = -1;
                int iIdpos = -1;

                for (Field field : fields) {
                    if (field.getName().toLowerCase().equals("coreuseridargpos")) {
                        cuidpos = field.getInt(null);
                    }
                    if (field.getName().toLowerCase().equals("installidargpos")) {
                        iIdpos = field.getInt(null);
                    }
                }
                if (cuidpos != -1 && iIdpos != -1) {
                    Long id = eventToId.get(class1.getSimpleName());
                    mappedEvents.put(id, new Position(cuidpos, iIdpos));
                }
            }
        } catch (Exception e) {
            throw new RuntimeException("Could not build the mapping.", e);
        }

    }

    private Map<String, Long> getEventTypeNameId() {

        HashMap<String, Long> returnMe = new HashMap<>();

        EventType[] enumConstants = EventType.class.getEnumConstants();
        for (EventType eventType : enumConstants) {
            returnMe.put(eventType.name(), eventType.id);
        }

        return returnMe;
    }

    
    public Map<Long, Position> getMappedEvents() {
        return mappedEvents;
    }

}
