package com.king.splat.time;

import java.util.LinkedList;

public class MinTimestampTracker<E> implements TimestampTracker<E> {

    private final LinkedList<Stamped<E>> descendingSubsequence = new LinkedList<>();

    // in the case that incoming traffic is very small, the records maybe put and polled
    // within a single iteration, in this case we need to remember the last polled
    // record's timestamp
    private long lastKnownTime = NOT_KNOWN;

    /**
     * @throws NullPointerException if the element is null
     */
    public void addElement(Stamped<E> elem) {
        if (elem == null) throw new NullPointerException();

        Stamped<E> minElem = descendingSubsequence.peekLast();
        while (minElem != null && minElem.timestamp >= elem.timestamp) {
            descendingSubsequence.removeLast();
            minElem = descendingSubsequence.peekLast();
        }
        descendingSubsequence.offerLast(elem);
    }

    public void removeElement(Stamped<E> elem) {
        if (elem != null && descendingSubsequence.peekFirst() == elem)
            descendingSubsequence.removeFirst();

        if (descendingSubsequence.isEmpty())
            lastKnownTime = elem.timestamp;
    }

    public int size() {
        return descendingSubsequence.size();
    }

    public long get() {
        Stamped<E> stamped = descendingSubsequence.peekFirst();

        if (stamped == null)
            return lastKnownTime;
        else
            return stamped.timestamp;
    }

}