package com.king.splat.time;

public interface TimestampTracker<E> {

    static final long NOT_KNOWN = -1L;

    /**
     * Adds a stamped elements to this tracker.
     *
     * @param elem the added element
     */
    void addElement(Stamped<E> elem);

    /**
     * Removed a stamped elements to this tracker.
     *
     * @param elem the removed element
     */
    void removeElement(Stamped<E> elem);

    /**
     * Returns the current tracked timestamp
     *
     * @return timestamp, or {@link #NOT_KNOWN} when empty
     */
    long get();

    /**
     * Returns the size of internal structure. The meaning of "size" depends on the implementation.
     *
     * @return size
     */
    int size();

}


