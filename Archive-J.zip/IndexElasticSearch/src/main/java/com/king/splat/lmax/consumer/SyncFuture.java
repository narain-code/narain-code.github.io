package com.king.splat.lmax.consumer;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import com.lmax.disruptor.EventTranslator;

/**
 * A sync future.  Its done when sync completes.  Implements actual Future though only implements part.
 * Also has facility for riding the ring buffer.
 */
public class SyncFuture implements EventTranslator<RingBufferTruck>, Future<Long> {

	
	   
	    volatile long ringBufferWriteSequence;
	    private long sequence = 0;
	    private Throwable throwable = null;
	    private volatile boolean done = false;

	    public void translateTo(RingBufferTruck payload, long sequence) {
	      this.ringBufferWriteSequence = sequence;
	      payload.setPayload(this);
	    }
	 
	    synchronized void done(final long sequence) {
	      this.done = true;
	      this.sequence = sequence;
	      notify();
	    }

	    synchronized void failed(final Throwable t) {
	      this.done = true;
	      this.throwable = t;
	      notify();
	    }

	    public boolean cancel(boolean mayInterruptIfRunning) {
	      throw new UnsupportedOperationException();
	    }

	    public synchronized Long get() throws InterruptedException, ExecutionException {
	      while (!this.done) wait();
	      if (this.throwable != null) throw new ExecutionException(this.throwable);
	      return this.sequence;
	    }

	    public Long get(long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
	      throw new UnsupportedOperationException();
	    }

	    public boolean isCancelled() {
	      throw new UnsupportedOperationException();
	    }

	    public boolean isDone() {
	      return this.done;
	    }
	  }


