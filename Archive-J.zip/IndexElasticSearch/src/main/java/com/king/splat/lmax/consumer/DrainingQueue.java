package com.king.splat.lmax.consumer;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.rocksdb.WriteBatch;

import com.lmax.disruptor.EventFactory;
import com.lmax.disruptor.EventHandler;
import com.lmax.disruptor.EventTranslator;
import com.lmax.disruptor.ExceptionHandler;
import com.lmax.disruptor.SleepingWaitStrategy;
import com.lmax.disruptor.dsl.Disruptor;
import com.lmax.disruptor.dsl.ProducerType;


/**
 * Draining Queue 
 */

public class DrainingQueue {
	
	  

	    /**
	     * Ring buffer that takes edits from the Handlers and passes them to the appender executor.
	     */
	    private final Disruptor<RingBufferTruck> ringBuffer;
	    /**
	     * An executorservice that runs the AppenderEventHandler appender executor.
	     */
	    private final ExecutorService appenderExecutor;
	    /**
	     * An ES to run the syncs.
	     */
	    private final ExecutorService syncerExecutor;

	    /**
	     * The handler that is run by the appenderExecutor.  The ringBuffer calls onEvent below to consume events.
	     */
	    static class AppenderEventHandler implements EventHandler<RingBufferTruck> {
	      private List<SyncFuture> syncsToDo = new ArrayList<SyncFuture>();
	     // private List<Edit> appendsToDo = new ArrayList<Edit>();
	      private WriteBatch appendsToDo;
	      
	      //remote things to do
	      
	      
	      private final ExecutorService syncerExecutor;

	      AppenderEventHandler(final ExecutorService syncerExecutor) {
	        this.syncerExecutor = syncerExecutor;
	      }

	      public void onEvent(final RingBufferTruck truck, final long sequence, final boolean endOfBatch)
	      throws Exception {
	        // TODO: Check size of the appends; if over a threshold, pass them on to the syncer?
	        if (truck.getSyncFuture() != null) {
	          if (this.syncsToDo == null) this.syncsToDo = new ArrayList<SyncFuture>();
	          this.syncsToDo.add(truck.getSyncFuture());
	        } else if (truck.getEdit() != null) {
	          if (this.appendsToDo == null) this.appendsToDo = new WriteBatch();
	          //this.appendsToDo.add(truck.getEdit());
	        } else {
	          // They can't both be null
	          throw new IllegalStateException();
	        }
	        // If not a batch, return to consume more events from the ring buffer; get up a batch of edits to append
	        // and sync.
	        if (!endOfBatch) return;
	        // Ok, 
	      //  System.out.println("sequence=" + sequence + ", batchCount=" + (this.appendsToDo == null? 0: this.appendsToDo.size()) + ", syncCount=" + (this.syncsToDo == null? 0: this.syncsToDo.size()));
	        // Now sync.  I have to sync everyone because there is a handler waiting to be woken up again at other end
	        // of a sync call.
	        if (this.syncsToDo != null && !this.syncsToDo.isEmpty()) {
	         
	          this.syncerExecutor.execute(new Syncer(this.syncsToDo, sequence));
	          this.syncsToDo = null;
	          // First run the appends.
	          if (this.appendsToDo != null && this.appendsToDo.count() == 0) {
	            // Have to create new ArrayList each time rather than clear because executors may be iterating the lists
	            // when we call clear and we'll get a CME.
	            this.appendsToDo = null;
	          }
	        }
	      }
	      
	      public void addOrDrop(Edit e){
	    	  /**
	    	   *  here we need to check if this combo already exists
	    	   * 
	    	   * first check if there is a merge in edit
	    	   *  -- merge exists --- check if cuid--mergeid 
	    	   *  								--exists -- move on
	    	   *  								--no  -- 1.put in merge	 
	    	   *  										 2.send write to install 
	    	   *  
	    	   *  --install exists --- check if cuid-install
	    	   *  										-- exists -- moveon
	    	   *  										--no  -- 1. add install to cuid
	    	   *  												 2. put reverse link in install
	    	   */
	    	  
	      }
	    }

	    /**
	     * Sync runnable that is run by the sync executor service.
	     */
	    static class Syncer implements Runnable {
	      private final long sequence;
	      private final List<SyncFuture> syncs;
	 
	      Syncer(final List<SyncFuture> syncs, final long sequence) {
	        this.sequence = sequence;
	        this.syncs = syncs;
	      }

	      public void run() {
	        // Go do sync.
	        // When it comes back go inform the threads and let them go.
	        if (this.syncs != null) {
	          for (SyncFuture sync: this.syncs) sync.done(this.sequence);
	        }
	      }
	    }

	    /**
	     * TODO
	     */
	    static class AppenderExceptionHandler implements ExceptionHandler {

	      public void handleEventException(Throwable arg0, long arg1, Object arg2) {
	        // TODO Auto-generated method stub
	        
	      }

	      public void handleOnShutdownException(Throwable arg0) {
	        // TODO Auto-generated method stub
	        
	      }

	      public void handleOnStartException(Throwable arg0) {
	        // TODO Auto-generated method stub
	        
	      }
	    }

	  public  DrainingQueue() {
	      this.appenderExecutor = Executors.newSingleThreadExecutor(/*Threads.getNamedThreadFactory("ringbuffer")*/);
	      this.ringBuffer = new Disruptor<RingBufferTruck>(RingBufferTruck.EVENT_FACTORY, 1024, this.appenderExecutor,
	        ProducerType.MULTI, new SleepingWaitStrategy());
	      this.syncerExecutor = Executors.newCachedThreadPool(/*Threads.etc.*/);
	      ringBuffer.handleEventsWith(new AppenderEventHandler [] {new AppenderEventHandler(this.syncerExecutor)});
	      ringBuffer.handleExceptionsWith(new AppenderExceptionHandler());
	      ringBuffer.start();
	    }

	   
	  
	    void shutdown() {
	      if (this.ringBuffer != null) this.ringBuffer.shutdown();
	      if (this.appenderExecutor !=  null) this.appenderExecutor.shutdown();
	      if (this.syncerExecutor != null) this.syncerExecutor.shutdown();
	    }

	    void append(final Edit e) {
	      this.ringBuffer.publishEvent(e);
	    }

	    void sync() throws InterruptedException {
	      SyncFuture syncFuture = new SyncFuture();
	      this.ringBuffer.publishEvent(syncFuture);
	      // Now we have published to the ringbuffer, halt the current thread until we get an answer back.
	      try {
	        syncFuture.get();
	      } catch (ExecutionException e) {
	        // TODO Auto-generated catch block
	        e.printStackTrace();
	      }
	    }
	 // }

	  
	  
	 

	  
	  }
	


