package com.king.splat.lmax.consumer;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Pattern;

import kafka.consumer.ConsumerConfig;

import org.I0Itec.zkclient.ZkClient;
import org.I0Itec.zkclient.exception.ZkMarshallingError;
import org.I0Itec.zkclient.serialize.ZkSerializer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.king.event.format.DelegatingEventFormat;
import com.king.event.format.EventFormat;
import com.king.event.format.util.HTMLEntityEncoder;
import com.king.event.format.util.IdentityDecoder;
import com.king.splat.cluster.Ring;
import com.king.splat.grain.IContext;

public class KafkaDrainer {
	
		
		private final int soTimeOut = 30000;
		private final int bufferSize = 65536;
		

		boolean paused = false;
		private final ObjectMapper mapper = new ObjectMapper();
		
		
		private static final EventFormat eventFormat = new DelegatingEventFormat(new HTMLEntityEncoder(),
																				new IdentityDecoder());
		
		HashSet<Integer> partitions;
		IContext context;
		
		
		private  AtomicReference<Map<Integer, Broker>> brokers;
		private  AtomicReference<List<String>> topicNames;
		private  ConcurrentMap<String, Topic> topics;
		
		private static final int DEFAULT_ZK_TIMEOUT_MILLIS = 20000;
		private static final String ZOOKEEPER_TOPIC_PATH = "/kafka/brokers/topics";
		private static final String ZOOKEEPER_BROKER_PATH = "/kafka/brokers/ids";
		private static final String zkConnectString = "zk04.sto.midasplayer.com:2181";
		private Pattern eventFilter = Pattern.compile("^event\\..*\\.log$");
		
		private ZkClient zkClient = zkConnect(zkConnectString,DEFAULT_ZK_TIMEOUT_MILLIS);
		
		

		
		
		
		
		private Map<Broker,List<Partition>> kafkaPartitionsOwned = new HashMap<Broker, List<Partition>>();
		
		private ZkClient zkConnect(String zkConnect, long timeoutMillis) {
			ZkClient client = new ZkClient(zkConnect, (int)timeoutMillis, (int)timeoutMillis, new ZkSerializer() {
				public byte[] serialize(Object arg) throws ZkMarshallingError {
					throw new IllegalStateException("Serializing not supported");
				}

				public Object deserialize(byte[] data) throws ZkMarshallingError {
					try {
						return new String(data, "UTF-8");
					}
					catch (UnsupportedEncodingException e) {
						throw new IllegalArgumentException("Failed to deserilaize zk data");
					}
				}
			});

			return client;
		}
		
		
		
		public List<String> getTopicNames() {
			List<String> nameList = null;
			if(topicNames != null)
			  nameList = topicNames.get();
			else
				topicNames = new AtomicReference<List<String>>();
			if (nameList == null) {
				List<String> zkTopics = zkClient.getChildren(ZOOKEEPER_TOPIC_PATH);
				//System.out.println(String.format("Found {} topics", zkTopics.size()));
				//System.out.println(String.format("Topics found: {}", zkTopics));
				nameList = Collections.unmodifiableList(new ArrayList<String>(zkTopics));
				topicNames.set(nameList);
			}

			return nameList;
		}

		public List<String> getTopicNames(Pattern filter) {
			List<String> result = new ArrayList<String>();
			for (String topicName : getTopicNames()) {
				if (filter.matcher(topicName).matches()) {
					result.add(topicName);
				}
			}
			
			return result;		
		}

		
		private Topic getTopicFromZk(String topicName) {
			String topicPath = ZOOKEEPER_TOPIC_PATH + "/" + topicName + "/partitions";
			//System.out.println("Listing topic partitions on on zookeeper path: " + topicPath);
			List<String> partitionIds = zkClient.getChildren(topicPath);

			ArrayList<Partition> partitions = new ArrayList<Partition>();

			for (String partitionIdStr : partitionIds) {
				int partitionId = Integer.parseInt(partitionIdStr);
				String nodePath = topicPath + "/" + partitionId + "/state";

				String partitionInfoJson = zkClient.<String>readData(nodePath);

				try {
					Map<?, ?> partitionInfo = mapper.readValue(partitionInfoJson, HashMap.class);

					// Get leader broker for this partition
					Integer leader = (Integer) partitionInfo.get("leader");

					// Get in-sync-replicas
					@SuppressWarnings("unchecked")
					List<String> isr = (List<String>) partitionInfo.get("isr");

					Broker leaderBroker = getBrokers().get(leader);
					if (leaderBroker == null) {
						throw new IllegalStateException("Error on topic/partition '" + topicName + "', leader broker not found: " + leader);
					}
					
					partitions.add(new Partition(topicName, partitionId, leaderBroker));
				} catch (IOException e) {
					throw new RuntimeException(e);
				}
			}
			
			return new Topic(topicName, Collections.unmodifiableList(partitions));
		}

		
		public Map<Integer, Broker> getBrokers() {
			Map<Integer, Broker> brokerMap  = null;
			if(brokers!= null)
			 brokerMap= brokers.get();
			else
				brokers = new AtomicReference<Map<Integer,Broker>>();
			if (brokerMap == null) {
				brokerMap = getBrokersFromZk();
				brokers.set(brokerMap);
			}

			return brokerMap;
		}
		
		private Map<Integer, Broker> getBrokersFromZk() {
		System.out.println("Listing brokers on on zookeeper path: " + ZOOKEEPER_BROKER_PATH);
			Map<Integer, Broker> brokers = new HashMap<Integer, Broker>();
			List<String> brokerIds = zkClient.getChildren(ZOOKEEPER_BROKER_PATH);

			System.out.println("Brokers found: " + brokerIds);

			for (String brokerIdStr : brokerIds) {
				String zkBrokerIdPath = ZOOKEEPER_BROKER_PATH + "/" + brokerIdStr;
				String brokerInfoJson = zkClient.<String>readData(zkBrokerIdPath);
				if (brokerInfoJson == null) {
					throw new IllegalStateException("No zookeeper data for broker: " + zkBrokerIdPath);
				}

				int brokerId = Integer.parseInt(brokerIdStr);
				try {
					Map<?, ?> brokerInfo = mapper.readValue(brokerInfoJson, HashMap.class);
					brokers.put(brokerId, new Broker(brokerId, (String)brokerInfo.get("host"), (Integer)brokerInfo.get("port")));
				} catch (IOException e) {
					throw new RuntimeException(e);
				}
			}

			return Collections.unmodifiableMap(brokers);
		}
		
		
		private List<String> getAllRelevantTopicsFromZK() {
			try{
		
			//List<String> zkTopics = zkClient.getChildren(ZOOKEEPER_TOPIC_PATH);
			//System.out.println(zkTopics.size());
			 List<String> zkTopics = new ArrayList<String>(1);
			 zkTopics.add("splat.kpidevent_20160213.log");
			String topicPath = ZOOKEEPER_TOPIC_PATH + "/" + "splat.kpidevent_20160213.log" + "/partitions";
			List<String> partitionIds = zkClient.getChildren(topicPath);
			for (String partitionIdStr : partitionIds) {
				int partitionId = Integer.parseInt(partitionIdStr);
				String nodePath = topicPath + "/" + partitionId + "/state";
				System.out.println(" partition id " + partitionId);
				String partitionInfoJson = zkClient.<String>readData(nodePath);

				
					Map<?, ?> partitionInfo = mapper.readValue(partitionInfoJson, HashMap.class);
					
					for(Entry<?, ?> e:partitionInfo.entrySet()){
						System.out.println( e.getKey() + " :: " + e.getValue() ); 
					}
					
			}	
			Collections.sort(zkTopics);
			return zkTopics;
			}catch(Exception ex){
				ex.printStackTrace();
				zkClient.close();
				this.zkClient = zkConnect(zkConnectString, DEFAULT_ZK_TIMEOUT_MILLIS);
			}
			return null;
		}
		


	   DrainingQueue queue;
		
	   
	   
		public KafkaDrainer(
			 String zkConnect
			)
		{
			
			
			//this.zkConnectString = zkConnect ;
			
			
			
			executor.scheduleWithFixedDelay(new Runnable() {
				@Override
				public void run() {
					try {
						shdReconnectToZk.set(true);
					}
					
					catch (Exception e) {
						e.printStackTrace();
						System.out.println("Error while updating wich wildcard topics to consume");
					}
				}
			}, 0, 300, TimeUnit.SECONDS);
			
			//create queue
			queue = new DrainingQueue();
		}
		
		final ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);
		AtomicBoolean shdReconnectToZk = new AtomicBoolean(false);
		
		private  List<String> currentConsumedTopics = null;

		
		private ConsumerConfig createConsumerProperties(){
			 Properties props = new Properties();
			 props.put("zookeeper.connect", zkConnectString);
			 Map<Integer,Broker> brokers =getBrokers();
			 Entry<Integer,Broker> b = brokers.entrySet().iterator().next();
			 
			 String value =b.getValue().getHost() + ":" + b.getValue().getPort();
			 props.put("metadata.broker.list", value);
			 return new ConsumerConfig(props);
		}
		
		public void assignPartitions(Broker broker,Partition p){
			if(this.kafkaPartitionsOwned == null){
				this.kafkaPartitionsOwned = new HashMap<Broker, List<Partition>>();
			}
			
			if(!this.kafkaPartitionsOwned.containsKey(broker) ){
				ArrayList<Partition> partOwned = new ArrayList<Partition>();
				partOwned.add(p);
				kafkaPartitionsOwned.put(broker, partOwned);
			}else{
				List<Partition> partOwned = kafkaPartitionsOwned.get(broker);
				partOwned.add(p);
			}
		}
		
		
		
		
		public void consume(){
		try {	
			 kafka.api.FetchRequestBuilder builder = null;
	
			 if(currentConsumedTopics == null || shdReconnectToZk.get()){
				 List<String> zkTopics =  	getAllRelevantTopicsFromZK();
				
				 if(currentConsumedTopics == null || !zkTopics.equals(currentConsumedTopics)){
					 currentConsumedTopics = new ArrayList<String>(zkTopics);
					
					
					for(String t:zkTopics){	
						List<Partition> _parts = getTopicFromZk(t).getPartitions();
						for(Partition p:_parts){
							Broker broker = p.getLeader();
							int brokerId =broker.getBrokerId();
							// if(this.partitions.contains(context.computeIDtoDestination(""+brokerId))){
								assignPartitions(broker, p);
							 //}
						}
					}
					
			
					//  String clientName = "Client_"  + "_" + this.memberNode.getIdentifier();
					  
					
				      Set<Broker> brokersOwned =this.kafkaPartitionsOwned.keySet();
				      int index =0;
				      for(Broker broker:brokersOwned){
				    	  
				    	  List<Partition> listOwned =this.kafkaPartitionsOwned.get(broker);
				    	
				    	  
				    	 // one thread for each partition
				    	 for(Partition p:listOwned){ 
				    		/*
				    		 * for now one thread per partition of the topic
				    		 *  in future we can batch this together
				    		 */
				    	 List<Partition> _parts = new ArrayList<Partition>(1);
				    	 _parts.add(p);
				    	 DrainQueueHandler handler = new DrainQueueHandler(queue, index, 1000, _parts, broker,34);
				    	 handler.start();
				    	 index ++;
				    	 }
				      }
				      
				  
				 
				 }
			 }
			//}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		
		
		public static void main(String[] args){
			KafkaDrainer _drainer = new KafkaDrainer(null, zkConnectString);
			_drainer.consume();
		}
		
	}



