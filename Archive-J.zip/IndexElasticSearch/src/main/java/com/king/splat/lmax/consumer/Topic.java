package com.king.splat.lmax.consumer;

import java.util.List;



public  class Topic {
	private final String name;
	private final List<Partition> partitions;

	Topic(String name, List<Partition> partitions) {
		this.name = name;
		this.partitions = partitions;
	}

	public String getName() {
		return name;
	}

	public List<Partition> getPartitions() {
		return partitions;
	}

	@Override
	public String toString() {
		return "Topic [name=" + name + ", partitions=" + partitions + "]";
	}
	
}
