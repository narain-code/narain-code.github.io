package com.king.splat.lmax.consumer;


import com.lmax.disruptor.EventFactory;

/**
 * Carries an edit to append OR a sync future across the ring buffer.  When one is set, the other is null.
 */
public class RingBufferTruck {

	    private Edit e;
	    private SyncFuture syncFuture;

	    void setPayload(final SyncFuture t) {
	      this.e = null;
	      this.syncFuture = t;
	    }

	    void setPayload(final Edit e) {
	      this.e = e;
	      this.syncFuture = null;
	    }

	    Edit getEdit() {
	      return this.e;
	    }

	    SyncFuture getSyncFuture() {
	      return this.syncFuture;
	    }

	    final static EventFactory<RingBufferTruck> EVENT_FACTORY =
	      new EventFactory<RingBufferTruck>() {
	        public RingBufferTruck newInstance() {
	            return new RingBufferTruck();
	        }
	    };
	    
}


