package com.king.splat;

public class Index {

}
