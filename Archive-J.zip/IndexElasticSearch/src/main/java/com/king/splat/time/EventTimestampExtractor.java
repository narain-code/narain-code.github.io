package com.king.splat.time;

import com.king.event.Event;

public class EventTimestampExtractor implements TimestampExtractor{

	@Override
	public long extract(Event message) {
		return message.getTimeStamp();
	}

}
