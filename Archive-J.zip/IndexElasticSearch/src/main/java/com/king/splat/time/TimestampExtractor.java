package com.king.splat.time;

import com.king.event.Event;

import kafka.message.MessageAndOffset;

public interface TimestampExtractor {
	
	public long extract(Event message);

}
