package com.king.splat.lmax.consumer;

public class Partition {
	private final String topic;
	private final int partition;
	private final Broker leader;
	

	Partition(String topic, int partition, Broker leader) {
		this.topic = topic;
		this.partition = partition;
		this.leader = leader;
	}

	public String getTopic() {
		return topic;
	}

	public int getPartitionId() {
		return partition;
	}

	public Broker getLeader() {
		return leader;
	}
	
	
	
	@Override
	public String toString() {
		return "Partition [topic=" + topic + ", partition=" + partition	+ ", leader=" + leader + "]";
	}
}
