package com.king.splat.lmax.consumer;

import java.util.List;

public class TopicPartitionAssigner implements PartitionAssigner{

	@Override
	public void assignTopicParts(List<DrainQueueHandler> handlers, List<Partition> parts) {
		//for nw keeping things simple ... hand out one handler per part on roundrobin
		int handlerSize = handlers.size();
		for (int part=0;part<parts.size();part++){
			
			handlers.get(part%handlerSize).addPartition(parts.get(part));
			
		}
		
	}

}
