package com.king.splat.lmax.consumer;

import java.nio.ByteBuffer;
import java.util.Map;

import kafka.message.MessageAndOffset;

import com.king.event.Event;
import com.king.event.format.DelegatingEventFormat;
import com.king.event.format.EventFormat;
import com.king.event.format.util.HTMLEntityEncoder;
import com.king.event.format.util.IdentityDecoder;
import com.king.splat.playerid.EventsWithInstallIdCoreUserIdImpl;
import com.king.splat.playerid.EventsWithInstallIdCoreUserIdImpl.Position;
import com.lmax.disruptor.EventTranslator;

/**
 * Fake edit.  Just has a KafkaMessage.
 */
public class Edit implements EventTranslator<RingBufferTruck> {

	
    /**
     *  is it really needed to create one for every object  ... is this heavy handed ?
     */
 /*	private  final EventFormat eventFormat = new DelegatingEventFormat(new HTMLEntityEncoder(),
			new IdentityDecoder());
	
	 private static final Map<Long, Position> mappedEvents = new EventsWithInstallIdCoreUserIdImpl().getMappedEvents();*/
	 
	  final MessageAndOffset messageAndOffset;
	    volatile long disruptorWriteSequence;
	    
	    private static final long EMPTY_MERGE = 0;
		private static final long EMPTY_INSTALL = -1;
		
		/**
		 * 
		 * data
		 */
		public Long coreUserId;
		public Long installId;
		public Long mergeId;
		

	  public  Edit( final MessageAndOffset messageAndOffset) {
	      this.messageAndOffset = messageAndOffset;
	    }

	  MessageAndOffset getMessage() {
		 
	      return this.messageAndOffset;
	    }

	   
	    public void translateTo(RingBufferTruck truck, final long sequence) {
	     try{ 	
	    	 ByteBuffer payload = messageAndOffset.message().payload();
	    	 byte[] bytes = new byte[payload.limit()];
             payload.get(bytes);
             String value = new String(bytes, "UTF-8");
           /*  Event event = eventFormat.parse(value);
             Long eventId = Long.valueOf(event.getEventType());
             Position position = mappedEvents.get(eventId);

             long timestamp = event.getTimeStamp();
             if (position != null) {
         
           	     String installId = event.getString(position.getInstallIdPos());
                 long coreUserId = event.getLong(position.getCoreUserIdPos());
	    	
	             this.disruptorWriteSequence = sequence;
	             truck.setPayload(this);
           	 
	      
	     
	     }*/
            
 			
 			/**
 			 * put into queue
 			 */
 			 this.disruptorWriteSequence = sequence;
             truck.setPayload(this);
             
	    }catch(Exception ex){
      		 ex.printStackTrace();
      	 }
	    }
}
