package com.king.splat.lmax.consumer;

import kafka.javaapi.consumer.SimpleConsumer;



public class Broker {
	private final int brokerId;
	private final String host;
	private final int port;
	private SimpleConsumer consumer;

	Broker(int brokerId, String host, int port) {
		this.brokerId = brokerId;
		this.host = host;
		this.port = port;
	}

	public String getHost() {
		return host;
	}

	public int getPort() {
		return port;
	}

	public int getBrokerId() {
		return brokerId;
	}
	
	public void setConsumer(SimpleConsumer consumer){
		this.consumer = consumer;
	}
	
	public SimpleConsumer getConsumer(){
		return consumer;
	}
	
	@Override
	public String toString() {
		return "Broker [brokerId=" + brokerId + ", host=" + host + ", port=" + port + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + brokerId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Broker other = (Broker) obj;
		if (brokerId != other.brokerId)
			return false;
		return true;
	}
}

