package com.king.splat.lmax.consumer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import kafka.api.FetchRequest;
import kafka.api.FetchRequestBuilder;
import kafka.api.OffsetRequest;
import kafka.api.PartitionOffsetRequestInfo;
import kafka.common.ErrorMapping;
import kafka.common.TopicAndPartition;
import kafka.javaapi.OffsetResponse;
import kafka.javaapi.consumer.SimpleConsumer;
import kafka.message.MessageAndOffset;
import scala.collection.Iterator;




/**
 * Simple appender class.  
 */
public class DrainQueueHandler extends Thread{

	private final int soTimeOut = 30000;
	private final int bufferSize = 65536;
	private final int fetchSize = 1024*1024; //1 MB
	  
	    private final int threadIdentifier;
	    private final DrainingQueue queue;
	    private final int syncNumber;
	    
	    private List<Partition> parts;
	   
	    
	    private long[] nextOffsets;
	    private  int numberOfRocksInst;
	    
	    public DrainQueueHandler(final DrainingQueue queue, final int index, final int syncNumber,
	    		
	    		 Broker broker,
	    		  int numberOfRocksInst) {
	      setName("" + index);
	     
	     this.threadIdentifier=index; 
	     this.queue = queue;
	     this.syncNumber = syncNumber;
	     this.parts = new ArrayList<Partition>();
	     
	     this.numberOfRocksInst = numberOfRocksInst;
	     //Partitions occupy same index here as in the parts
	     nextOffsets = new long[parts.size()];
	    }
	    
	    public void addPartition(Partition part){
	    	parts.add(part);
	    }
	    
	    public void createRocks(){
	    	
	    }
	    
	    public long findInitialOffset( final SimpleConsumer consumer, final String topic, final int partitionNum , String clientName){
	
	    	    	TopicAndPartition topicAndPartition = new TopicAndPartition(topic, partitionNum);
	    	        Map<TopicAndPartition, PartitionOffsetRequestInfo> requestInfo = new HashMap<TopicAndPartition, PartitionOffsetRequestInfo>();
	    	        requestInfo.put(topicAndPartition, new PartitionOffsetRequestInfo(OffsetRequest.EarliestTime(), 1));
	    	        kafka.javaapi.OffsetRequest request = new kafka.javaapi.OffsetRequest(requestInfo, kafka.api.OffsetRequest.CurrentVersion(),clientName);
	    	        OffsetResponse response = consumer.getOffsetsBefore(request);
	    	        final long[] allOffsets =response.offsets(topic, partitionNum);
	    	        return allOffsets[0];
	    }
	    
	    public FetchRequest buildRequest4Partitions(FetchRequestBuilder builder , Broker broker ,Partition p, long nextOffset){
			
	   			builder.addFetch(p.getTopic(), p.getPartitionId(), nextOffset , fetchSize);
			    return builder.build();
		}

	    @Override
	    public void run() {
	      try {
	      super.run();
	      
	     FetchRequestBuilder builder =new kafka.api.FetchRequestBuilder().
	  					clientId(getName());
	     for(Partition p : parts){
	      Broker broker=	 p.getLeader();
	     SimpleConsumer consumer = new SimpleConsumer(broker.getHost(), broker.getPort(), soTimeOut, bufferSize, getName() );
	     int index = 0;
	    
	    	 nextOffsets[index] =findInitialOffset( consumer,p.getTopic() , p.getPartitionId() ,
	    			                     getName());
	    	  index ++ ;
	      }
	      // System.out.println("Started " + getName());
	      
	    
	      
	        long counter = 0;
	        while(true){
	        
	        for(int i =0 ; i < parts.size(); i++){
	        Partition part = parts.get(i);
	        Broker broker=	 part.getLeader();
	       // System.out.println("off set is " +nextOffsets[i]);
	        SimpleConsumer consumer = new SimpleConsumer(broker.getHost(), broker.getPort(), soTimeOut, bufferSize, getName() );
	        kafka.javaapi.FetchResponse response = consumer.fetch(buildRequest4Partitions(builder, broker, part, nextOffsets[i]));
	        final short errorCode = response.errorCode(part.getTopic(), part.getPartitionId());		
				if (errorCode == ErrorMapping.OffsetOutOfRangeCode()) {
				     System.out.println( " All caught up for " + part);
				}
				if (errorCode != ErrorMapping.NoError()) {
				ErrorMapping.maybeThrowException(errorCode);
				} // --> else we try 
				
		    kafka.javaapi.message.ByteBufferMessageSet messageSet =response.messageSet(part.getTopic(), part.getPartitionId());
		    java.util.Iterator<MessageAndOffset> messageItr =messageSet.iterator();
		   while(messageItr.hasNext()){
			MessageAndOffset message = messageItr.next();
	        Edit e = new Edit(message);
	        this.queue.append(e);
	        // Every syncNumber append, wait on sync
	        if (counter != 0 && counter % syncNumber == 0 ) this.queue.sync();
	        counter ++;
	        if(counter % 1000000 == 0)
	         System.out.println(getName() + " sucked in " + counter );
	        this.nextOffsets[i]=message.nextOffset();
		   }
	      }
	     }
	   } catch (Exception e) {
	        e.printStackTrace();
	   }
	 }
 }

