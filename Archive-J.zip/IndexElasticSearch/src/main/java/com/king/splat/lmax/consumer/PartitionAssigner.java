package com.king.splat.lmax.consumer;

import java.util.List;

public interface PartitionAssigner {
	
	public void assignTopicParts(List<DrainQueueHandler> handlers, List<Partition> parts) ;

}
