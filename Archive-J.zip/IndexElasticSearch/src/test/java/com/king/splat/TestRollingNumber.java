package com.king.splat;

public class TestRollingNumber {
	
	public static void main(String[] args){
		
	 RollingNumber rn= new	RollingNumber(5 * 1000, 5);
	 rn.increment(RollingNumberEvent.SUCCESS);
	}

}
